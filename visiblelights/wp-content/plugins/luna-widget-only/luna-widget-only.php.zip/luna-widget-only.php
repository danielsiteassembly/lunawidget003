<?php
/**
 * Plugin Name: Luna Chat — Widget (Client)
 * Description: Floating chat widget + shortcode with conversation logging. Pulls client facts from Visible Light Hub and blends them with AI answers. Includes chat history hydration and Hub-gated REST endpoints.
 * Version:     1.7.0
 * Author:      Visible Light
 * License:     GPLv2 or later
 */

if (!defined('ABSPATH')) exit;

if (defined('LUNA_WIDGET_ONLY_BOOTSTRAPPED')) {
  return;
}
define('LUNA_WIDGET_ONLY_BOOTSTRAPPED', true);

/* ============================================================
 * CONSTANTS & OPTIONS
 * ============================================================ */
if (!defined('LUNA_WIDGET_PLUGIN_VERSION')) define('LUNA_WIDGET_PLUGIN_VERSION', '1.7.0');
if (!defined('LUNA_WIDGET_OPT_COMPOSER_ENABLED')) define('LUNA_WIDGET_OPT_COMPOSER_ENABLED', 'luna_composer_enabled');
if (!defined('LUNA_WIDGET_ASSET_URL')) define('LUNA_WIDGET_ASSET_URL', plugin_dir_url(__FILE__));

function luna_composer_default_prompts() {
  $defaults = array(
    array(
      'label'  => 'What can Luna help me with?',
      'prompt' => "Hey Luna! What can you help me with today?",
    ),
    array(
      'label'  => 'Site health overview',
      'prompt' => 'Can you give me a quick health check of my WordPress site?',
    ),
    array(
      'label'  => 'Pending updates',
      'prompt' => 'Do I have any plugin, theme, or WordPress core updates waiting?',
    ),
    array(
      'label'  => 'Security status',
      'prompt' => 'Is my SSL certificate active and are there any security concerns?',
    ),
    array(
      'label'  => 'Content inventory',
      'prompt' => 'How many pages and posts are on the site right now?',
    ),
    array(
      'label'  => 'Help contact info',
      'prompt' => 'Remind me how someone can contact our team for help.',
    ),
  );

  return apply_filters('luna_composer_default_prompts', $defaults);
}

/* ============================================================
 * LUNA COMPOSE SPRITE LIBRARY
 * ============================================================ */

/**
 * Validate sprite library JSON against schema
 */
function luna_validate_sprite_library($json_data) {
  if (!is_array($json_data)) {
    return array('valid' => false, 'error' => 'Invalid JSON structure');
  }
  
  $errors = array();
  
  // Check required top-level fields
  if (!isset($json_data['version']) || !preg_match('/^[0-9]+\.[0-9]+\.[0-9]+$/', $json_data['version'])) {
    $errors[] = 'Invalid or missing version (must match pattern: X.Y.Z)';
  }
  
  if (!isset($json_data['updated_at']) || !strtotime($json_data['updated_at'])) {
    $errors[] = 'Invalid or missing updated_at (must be valid date-time)';
  }
  
  if (!isset($json_data['sprites']) || !is_array($json_data['sprites']) || count($json_data['sprites']) < 1) {
    $errors[] = 'Invalid or missing sprites array (must have at least 1 item)';
  }
  
  // Validate each sprite
  if (isset($json_data['sprites']) && is_array($json_data['sprites'])) {
    foreach ($json_data['sprites'] as $index => $sprite) {
      if (!is_array($sprite)) {
        $errors[] = "Sprite at index {$index} is not an object";
        continue;
      }
      
      // Required sprite fields
      $required = array('id', 'name', 'department', 'intent', 'triggers', 'prompt', 'output');
      foreach ($required as $field) {
        if (!isset($sprite[$field])) {
          $errors[] = "Sprite at index {$index} missing required field: {$field}";
        }
      }
      
      // Validate sprite ID pattern
      if (isset($sprite['id']) && !preg_match('/^[a-z0-9-]{3,64}$/', $sprite['id'])) {
        $errors[] = "Sprite at index {$index} has invalid id format (must match: [a-z0-9-]{3,64})";
      }
      
      // Validate department enum
      if (isset($sprite['department'])) {
        $valid_departments = array('WebOps', 'DevOps', 'Marketing', 'Executive', 'Cross-Department');
        if (!in_array($sprite['department'], $valid_departments)) {
          $errors[] = "Sprite at index {$index} has invalid department: {$sprite['department']}";
        }
      }
      
      // Validate triggers
      if (isset($sprite['triggers']) && is_array($sprite['triggers'])) {
        if (count($sprite['triggers']) < 1) {
          $errors[] = "Sprite at index {$index} must have at least one trigger";
        }
        foreach ($sprite['triggers'] as $tidx => $trigger) {
          if (!isset($trigger['phrase']) || strlen($trigger['phrase']) < 2) {
            $errors[] = "Sprite at index {$index}, trigger at index {$tidx} has invalid phrase";
          }
          if (isset($trigger['match'])) {
            $valid_matches = array('contains', 'equals', 'starts_with', 'regex');
            if (!in_array($trigger['match'], $valid_matches)) {
              $errors[] = "Sprite at index {$index}, trigger at index {$tidx} has invalid match type";
            }
          }
        }
      }
      
      // Validate output type
      if (isset($sprite['output']) && is_array($sprite['output'])) {
        if (!isset($sprite['output']['type'])) {
          $errors[] = "Sprite at index {$index} output missing type";
        } else {
          $valid_types = array('report', 'email', 'memo', 'blog_post', 'press_release', 'summary', 
                               'changelog', 'release_notes', 'analysis', 'presentation_brief', 
                               'social_captions', 'landing_page_copy');
          if (!in_array($sprite['output']['type'], $valid_types)) {
            $errors[] = "Sprite at index {$index} has invalid output type: {$sprite['output']['type']}";
          }
        }
        if (isset($sprite['output']['format'])) {
          $valid_formats = array('markdown', 'html', 'plaintext');
          if (!in_array($sprite['output']['format'], $valid_formats)) {
            $errors[] = "Sprite at index {$index} has invalid output format: {$sprite['output']['format']}";
          }
        }
      }
      
      // Validate prompt structure
      if (isset($sprite['prompt']) && is_array($sprite['prompt'])) {
        if (!isset($sprite['prompt']['system']) || !isset($sprite['prompt']['user'])) {
          $errors[] = "Sprite at index {$index} prompt missing required system or user field";
        }
      }
      
      // Validate priority range
      if (isset($sprite['priority'])) {
        $priority = intval($sprite['priority']);
        if ($priority < 0 || $priority > 10) {
          $errors[] = "Sprite at index {$index} priority must be between 0 and 10";
        }
      }
    }
  }
  
  return array(
    'valid' => empty($errors),
    'errors' => $errors
  );
}

/**
 * Get seed sprite library
 */
function luna_get_seed_sprite_library() {
  return array(
    'version' => '1.0.0',
    'updated_at' => '2025-11-12T14:00:00Z',
    'sprites' => array(
      array(
        'id' => 'webops-site-health-report',
        'name' => 'Generate site health report',
        'department' => 'WebOps',
        'intent' => 'Summarize uptime, performance, SEO, accessibility, and security for the selected site.',
        'description' => 'Pulls VL-connected data and outputs an executive-friendly site health report with actions.',
        'tags' => array('health', 'uptime', 'performance', 'seo', 'a11y', 'security'),
        'priority' => 9,
        'triggers' => array(
          array('phrase' => 'generate site health report', 'match' => 'contains'),
          array('phrase' => 'site health', 'match' => 'contains'),
          array('phrase' => 'weekly webops summary', 'match' => 'contains')
        ),
        'inputs' => array(
          array('key' => 'site_id', 'label' => 'Site', 'type' => 'string', 'required' => true, 'description' => 'VL internal site id or domain'),
          array('key' => 'period', 'label' => 'Period', 'type' => 'enum', 'enum' => array('7d', '14d', '30d', '90d'), 'default' => '7d'),
          array('key' => 'audience', 'label' => 'Audience', 'type' => 'enum', 'enum' => array('executive', 'technical'), 'default' => 'executive')
        ),
        'data_bindings' => array(
          array('source' => 'uptime', 'scope' => '{{site_id}}', 'query' => 'uptime.last_period({{period}})', 'required' => true),
          array('source' => 'lighthouse', 'scope' => '{{site_id}}', 'query' => 'lighthouse.latest()', 'required' => true),
          array('source' => 'ga4', 'scope' => '{{site_id}}', 'query' => 'ga4.traffic.summary({{period}})'),
          array('source' => 'cloudflare', 'scope' => '{{site_id}}', 'query' => 'cf.security.events({{period}})')
        ),
        'prompt' => array(
          'system' => 'You are Luna Compose, generating a concise, accurate web health report following Visible Light\'s brand tone: confident, helpful, and actionable.',
          'user' => 'Create a {{audience}}-friendly site health report for {{site_id}} over {{period}}.\nData:\n- Uptime: {{uptime}}\n- Lighthouse: {{lighthouse}}\n- GA4: {{ga4}}\n- Security: {{cloudflare}}\nProvide: Summary, Key Findings, Top Risks, Recommended Actions (ranked), and a Brief Next-Week Plan.',
          'redactions' => array('access_tokens', 'api_keys')
        ),
        'output' => array(
          'type' => 'report',
          'format' => 'markdown',
          'template' => "# Site Health — {{site_id}} ({{period}})\n\n## Summary\n{{summary}}\n\n## Key Findings\n{{key_findings}}\n\n## Risks & Mitigations\n{{risks}}\n\n## Recommended Actions (Next 7 Days)\n{{actions}}\n"
        ),
        'style' => array('tone' => 'confident, helpful', 'reading_level' => 'executive', 'brand' => 'Visible Light'),
        'permissions' => array('scopes' => array('read:uptime', 'read:lighthouse', 'read:ga4', 'read:cloudflare')),
        'examples' => array(
          array('input' => 'generate site health report for commonwealthhealthservices.xyz (last 7 days)', 'output_hint' => 'Exec summary with bullets and actions')
        ),
        'telemetry' => array('category' => 'webops', 'event_name' => 'sprite_run'),
        'constraints' => array('max_tokens' => 2000, 'temperature' => 0.3, 'allowed_tools' => array('data.fetch'))
      ),
      array(
        'id' => 'webops-lighthouse-audit',
        'name' => 'Summarize Lighthouse audit',
        'department' => 'WebOps',
        'intent' => 'Explain latest Lighthouse scores and prioritized fixes.',
        'tags' => array('performance', 'lighthouse'),
        'priority' => 8,
        'triggers' => array(
          array('phrase' => 'summarize lighthouse audit', 'match' => 'contains'),
          array('phrase' => 'lighthouse summary', 'match' => 'contains')
        ),
        'inputs' => array(
          array('key' => 'site_id', 'type' => 'string', 'required' => true),
          array('key' => 'pages', 'type' => 'array', 'description' => 'Optional list of URLs to include')
        ),
        'data_bindings' => array(
          array('source' => 'lighthouse', 'scope' => '{{site_id}}', 'query' => 'lighthouse.latest({{pages}})', 'required' => true)
        ),
        'prompt' => array(
          'system' => 'Be precise. Rank fixes by business impact and effort.',
          'user' => 'Using Lighthouse data: {{lighthouse}}, produce a summary of scores and top 7 fixes with impact/effort tags.'
        ),
        'output' => array('type' => 'summary', 'format' => 'markdown'),
        'style' => array('tone' => 'direct', 'reading_level' => 'general'),
        'permissions' => array('scopes' => array('read:lighthouse')),
        'constraints' => array('max_tokens' => 1200, 'temperature' => 0.2)
      ),
      array(
        'id' => 'webops-downtime-postmortem',
        'name' => 'Explain latest downtime event',
        'department' => 'WebOps',
        'intent' => 'Create a plain-English incident post-mortem with RCA and actions.',
        'tags' => array('incident', 'rca', 'uptime'),
        'triggers' => array(
          array('phrase' => 'explain latest downtime event', 'match' => 'contains'),
          array('phrase' => 'postmortem', 'match' => 'contains')
        ),
        'inputs' => array(
          array('key' => 'site_id', 'type' => 'string', 'required' => true),
          array('key' => 'incident_id', 'type' => 'string', 'required' => false)
        ),
        'data_bindings' => array(
          array('source' => 'uptime', 'scope' => '{{site_id}}', 'query' => 'uptime.incident.latest({{incident_id}})', 'required' => true),
          array('source' => 'cloudflare', 'scope' => '{{site_id}}', 'query' => 'cf.security.events(window=\'incident\')')
        ),
        'prompt' => array(
          'system' => 'Write a clear, blameless post-mortem for stakeholders.',
          'user' => 'Using incident data {{uptime}} and related security context {{cloudflare}}, create a post-mortem with: Impact, Timeline, Root Cause, Corrective Actions, Preventive Measures, Owner & Due Dates.'
        ),
        'output' => array('type' => 'memo', 'format' => 'markdown'),
        'permissions' => array('scopes' => array('read:uptime', 'read:cloudflare')),
        'constraints' => array('max_tokens' => 1500, 'temperature' => 0.2)
      ),
      array(
        'id' => 'devops-deployment-plan',
        'name' => 'Generate deployment plan',
        'department' => 'DevOps',
        'intent' => 'Convert notes/commits into a CI/CD rollout plan with checks and rollback.',
        'tags' => array('deploy', 'cicd', 'runbook'),
        'priority' => 8,
        'triggers' => array(
          array('phrase' => 'generate deployment plan', 'match' => 'contains'),
          array('phrase' => 'rollout plan', 'match' => 'contains')
        ),
        'inputs' => array(
          array('key' => 'service', 'type' => 'string', 'required' => true),
          array('key' => 'env', 'type' => 'enum', 'enum' => array('dev', 'staging', 'prod'), 'default' => 'staging'),
          array('key' => 'window', 'type' => 'string', 'description' => 'Planned window, e.g., 22:00-23:00 ET')
        ),
        'data_bindings' => array(
          array('source' => 'github', 'scope' => '{{service}}', 'query' => 'github.commits.since(\'7d\')'),
          array('source' => 'kubernetes', 'scope' => '{{service}}', 'query' => 'k8s.deployment.status()')
        ),
        'prompt' => array(
          'system' => 'Output a safe, auditable plan with preflight checks, steps, verification, and rollback.',
          'user' => 'Create a deployment plan for {{service}} in {{env}} using commits {{github}} and current k8s status {{kubernetes}}.\nInclude: Prereqs, Change Summary, Step-by-Step, Health Checks, Rollback, Owners.'
        ),
        'output' => array('type' => 'analysis', 'format' => 'markdown'),
        'permissions' => array('scopes' => array('read:github', 'read:kubernetes')),
        'constraints' => array('max_tokens' => 1600, 'temperature' => 0.2)
      ),
      array(
        'id' => 'devops-incident-rca',
        'name' => 'Write post-incident review (RCA)',
        'department' => 'DevOps',
        'intent' => 'Structured RCA based on logs and metrics with action items.',
        'tags' => array('incident', 'rca', 'logs'),
        'triggers' => array(
          array('phrase' => 'write post-incident review', 'match' => 'contains'),
          array('phrase' => 'rca', 'match' => 'contains')
        ),
        'inputs' => array(
          array('key' => 'service', 'type' => 'string', 'required' => true),
          array('key' => 'period', 'type' => 'enum', 'enum' => array('24h', '48h', '7d'), 'default' => '24h')
        ),
        'data_bindings' => array(
          array('source' => 'kubernetes', 'scope' => '{{service}}', 'query' => 'k8s.logs.errors(window={{period}})', 'required' => true),
          array('source' => 'clickhouse', 'scope' => '{{service}}', 'query' => 'metrics.latency_error(window={{period}})')
        ),
        'prompt' => array(
          'system' => 'Keep it factual and blameless; attach measurable next steps.',
          'user' => 'Using logs {{kubernetes}} and metrics {{clickhouse}}, produce an RCA with sections: Customer Impact, Detection, Timeline, Root Cause, Contributing Factors, Action Items with owners/dates.'
        ),
        'output' => array('type' => 'memo', 'format' => 'markdown'),
        'permissions' => array('scopes' => array('read:kubernetes', 'read:clickhouse')),
        'constraints' => array('max_tokens' => 1500, 'temperature' => 0.2)
      ),
      array(
        'id' => 'devops-api-performance',
        'name' => 'Summarize API performance metrics',
        'department' => 'DevOps',
        'intent' => 'Latency, throughput, error rates with top endpoints and recommendations.',
        'tags' => array('api', 'performance'),
        'triggers' => array(
          array('phrase' => 'summarize api performance', 'match' => 'contains'),
          array('phrase' => 'api latency report', 'match' => 'contains')
        ),
        'inputs' => array(
          array('key' => 'service', 'type' => 'string', 'required' => true),
          array('key' => 'period', 'type' => 'enum', 'enum' => array('24h', '7d', '30d'), 'default' => '7d')
        ),
        'data_bindings' => array(
          array('source' => 'clickhouse', 'scope' => '{{service}}', 'query' => 'api.summary(window={{period}})', 'required' => true)
        ),
        'prompt' => array(
          'system' => 'Focus on trends and actionable tuning advice.',
          'user' => 'With performance data {{clickhouse}}, produce a summary with KPIs, slow endpoints, error spikes, and top 5 optimizations.'
        ),
        'output' => array('type' => 'report', 'format' => 'markdown'),
        'permissions' => array('scopes' => array('read:clickhouse'))
      ),
      array(
        'id' => 'mkt-weekly-report',
        'name' => 'Create weekly marketing report',
        'department' => 'Marketing',
        'intent' => 'Summarize traffic, conversions, ROAS, and channel trends for the week.',
        'tags' => array('ga4', 'reporting', 'weekly'),
        'priority' => 9,
        'triggers' => array(
          array('phrase' => 'create weekly marketing report', 'match' => 'contains'),
          array('phrase' => 'weekly marketing summary', 'match' => 'contains')
        ),
        'inputs' => array(
          array('key' => 'site_id', 'type' => 'string', 'required' => true),
          array('key' => 'period', 'type' => 'enum', 'enum' => array('7d', '14d'), 'default' => '7d'),
          array('key' => 'audience', 'type' => 'enum', 'enum' => array('executive', 'marketing'), 'default' => 'executive')
        ),
        'data_bindings' => array(
          array('source' => 'ga4', 'scope' => '{{site_id}}', 'query' => 'ga4.kpis(window={{period}})', 'required' => true),
          array('source' => 'ga4', 'scope' => '{{site_id}}', 'query' => 'ga4.channels(window={{period}})')
        ),
        'prompt' => array(
          'system' => 'Translate GA4 into clear business language; highlight actions.',
          'user' => 'Using GA4 KPIs {{ga4[0]}} and channel trends {{ga4[1]}}, write a {{audience}}-friendly weekly report with KPIs, Drivers, Risks, and 3 Action Items.'
        ),
        'output' => array('type' => 'report', 'format' => 'markdown'),
        'style' => array('tone' => 'insightful', 'reading_level' => 'executive'),
        'permissions' => array('scopes' => array('read:ga4')),
        'constraints' => array('max_tokens' => 1400, 'temperature' => 0.3)
      ),
      array(
        'id' => 'mkt-blog-generator',
        'name' => 'Write blog post on topic',
        'department' => 'Marketing',
        'intent' => 'Generate an SEO-optimized blog draft.',
        'tags' => array('content', 'seo', 'blog'),
        'triggers' => array(
          array('phrase' => 'write blog post on', 'match' => 'starts_with'),
          array('phrase' => 'blog about', 'match' => 'starts_with')
        ),
        'inputs' => array(
          array('key' => 'topic', 'type' => 'string', 'required' => true),
          array('key' => 'length', 'type' => 'enum', 'enum' => array('short', 'standard', 'long'), 'default' => 'standard'),
          array('key' => 'audience', 'type' => 'string')
        ),
        'prompt' => array(
          'system' => 'Write engaging, SEO-friendly blog content following Visible Light brand guidelines.',
          'user' => 'Create a {{length}} blog post about {{topic}} for {{audience}} audience. Include: compelling headline, intro hook, structured sections with subheadings, key takeaways, and a strong conclusion with CTA.'
        ),
        'output' => array('type' => 'blog_post', 'format' => 'markdown'),
        'style' => array('tone' => 'engaging, informative', 'reading_level' => 'general'),
        'constraints' => array('max_tokens' => 3000, 'temperature' => 0.7)
      )
    )
  );
}

/**
 * Ingest sprite library and create WordPress posts
 */
function luna_ingest_sprite_library($library_data = null) {
  if ($library_data === null) {
    $library_data = luna_get_seed_sprite_library();
  }
  
  // Validate library
  $validation = luna_validate_sprite_library($library_data);
  if (!$validation['valid']) {
    error_log('[Luna Sprite Library] Validation failed: ' . implode(', ', $validation['errors']));
    return array('success' => false, 'errors' => $validation['errors']);
  }
  
  $imported = 0;
  $updated = 0;
  $skipped = 0;
  $errors = array();
  
  foreach ($library_data['sprites'] as $sprite) {
    try {
      // Check if sprite already exists by sprite_id meta
      $existing = get_posts(array(
        'post_type' => 'luna_canned_response',
        'post_status' => 'any',
        'meta_query' => array(
          array(
            'key' => '_luna_sprite_id',
            'value' => $sprite['id'],
            'compare' => '='
          )
        ),
        'posts_per_page' => 1,
        'fields' => 'ids'
      ));
      
      // Build title from first trigger phrase or name
      $title = $sprite['name'];
      if (!empty($sprite['triggers']) && isset($sprite['triggers'][0]['phrase'])) {
        $title = $sprite['triggers'][0]['phrase'];
      }
      
      // Build content from intent and description
      $content = '';
      if (!empty($sprite['description'])) {
        $content = trim($sprite['description']);
        if (!empty($sprite['intent'])) {
          $content .= "\n\n" . $sprite['intent'];
        }
      } else {
        $content = $sprite['intent'];
      }
      
      // Build prompt text for display (use first trigger phrase)
      $prompt_text = '';
      if (!empty($sprite['triggers']) && isset($sprite['triggers'][0]['phrase'])) {
        $prompt_text = $sprite['triggers'][0]['phrase'];
      }
      
      $post_data = array(
        'post_title' => $title,
        'post_content' => $content,
        'post_type' => 'luna_canned_response',
        'post_status' => 'publish', // Published by default, users can move to draft
        'menu_order' => isset($sprite['priority']) ? (10 - intval($sprite['priority'])) : 5 // Higher priority = lower menu_order
      );
      
      if (!empty($existing)) {
        // Update existing
        $post_data['ID'] = $existing[0];
        $post_id = wp_update_post($post_data);
        $updated++;
      } else {
        // Create new
        $post_id = wp_insert_post($post_data);
        $imported++;
      }
      
      if (is_wp_error($post_id)) {
        $errors[] = "Failed to create/update sprite '{$sprite['id']}': " . $post_id->get_error_message();
        $skipped++;
        continue;
      }
      
      // Store sprite metadata
      update_post_meta($post_id, '_luna_sprite_id', $sprite['id']);
      update_post_meta($post_id, '_luna_sprite_data', $sprite); // Store full sprite data
      update_post_meta($post_id, '_luna_sprite_name', $sprite['name']);
      update_post_meta($post_id, '_luna_sprite_department', $sprite['department']);
      update_post_meta($post_id, '_luna_sprite_intent', $sprite['intent']);
      update_post_meta($post_id, '_luna_sprite_prompt', $prompt_text);
      
      if (isset($sprite['tags']) && is_array($sprite['tags'])) {
        update_post_meta($post_id, '_luna_sprite_tags', $sprite['tags']);
      }
      
      if (isset($sprite['priority'])) {
        update_post_meta($post_id, '_luna_sprite_priority', intval($sprite['priority']));
      }
      
      // Store triggers for matching
      if (isset($sprite['triggers']) && is_array($sprite['triggers'])) {
        update_post_meta($post_id, '_luna_sprite_triggers', $sprite['triggers']);
      }
      
      // Store prompt template
      if (isset($sprite['prompt']) && is_array($sprite['prompt'])) {
        update_post_meta($post_id, '_luna_sprite_prompt_template', $sprite['prompt']);
      }
      
      // Store output config
      if (isset($sprite['output']) && is_array($sprite['output'])) {
        update_post_meta($post_id, '_luna_sprite_output', $sprite['output']);
      }
      
      // Store other metadata
      if (isset($sprite['inputs']) && is_array($sprite['inputs'])) {
        update_post_meta($post_id, '_luna_sprite_inputs', $sprite['inputs']);
      }
      
      if (isset($sprite['data_bindings']) && is_array($sprite['data_bindings'])) {
        update_post_meta($post_id, '_luna_sprite_data_bindings', $sprite['data_bindings']);
      }
      
      if (isset($sprite['style']) && is_array($sprite['style'])) {
        update_post_meta($post_id, '_luna_sprite_style', $sprite['style']);
      }
      
      if (isset($sprite['constraints']) && is_array($sprite['constraints'])) {
        update_post_meta($post_id, '_luna_sprite_constraints', $sprite['constraints']);
      }
      
    } catch (Exception $e) {
      $errors[] = "Error processing sprite '{$sprite['id']}': " . $e->getMessage();
      $skipped++;
    }
  }
  
  // Store library version
  update_option('_luna_sprite_library_version', $library_data['version']);
  update_option('_luna_sprite_library_updated_at', $library_data['updated_at']);
  
  return array(
    'success' => true,
    'imported' => $imported,
    'updated' => $updated,
    'skipped' => $skipped,
    'errors' => $errors
  );
}

/**
 * Auto-install seed library on plugin activation
 */
function luna_install_seed_sprite_library() {
  // Check if library already installed
  $installed_version = get_option('_luna_sprite_library_version', '0.0.0');
  $seed_version = '1.0.0';
  
  // Only install if not already installed or if version is older
  if (version_compare($installed_version, $seed_version, '<')) {
    $result = luna_ingest_sprite_library();
    if ($result['success']) {
      error_log('[Luna Sprite Library] Installed seed library: ' . $result['imported'] . ' imported, ' . $result['updated'] . ' updated');
    } else {
      error_log('[Luna Sprite Library] Failed to install seed library: ' . implode(', ', $result['errors']));
    }
  }
}

// Hook into plugin activation
register_activation_hook(__FILE__, 'luna_install_seed_sprite_library');

// Also run on admin init to catch updates
add_action('admin_init', function() {
  // Only run once per day to avoid performance issues
  $last_check = get_option('_luna_sprite_library_last_check', 0);
  if (time() - $last_check > 86400) { // 24 hours
    luna_install_seed_sprite_library();
    update_option('_luna_sprite_library_last_check', time());
  }
}, 10);

define('LUNA_WIDGET_OPT_LICENSE',         'luna_widget_license');
define('LUNA_WIDGET_OPT_MODE',            'luna_widget_mode');           // 'shortcode' | 'widget'
define('LUNA_WIDGET_OPT_SETTINGS',        'luna_widget_ui_settings');    // array
define('LUNA_WIDGET_OPT_LICENSE_SERVER',  'luna_widget_license_server'); // hub base URL
define('LUNA_WIDGET_OPT_LAST_PING',       'luna_widget_last_ping');      // array {ts,url,code,err,body}
define('LUNA_WIDGET_OPT_SUPERCLUSTER_ONLY', 'luna_widget_supercluster_only'); // '1' | '0'

/* Cache */
define('LUNA_CACHE_PROFILE_TTL',          300); // 5 min

/* Hub endpoints map (your Hub can alias to these) */
$GLOBALS['LUNA_HUB_ENDPOINTS'] = array(
  'profile'  => '/wp-json/vl-hub/v1/profile',   // preferred single profile
  'security' => '/wp-json/vl-hub/v1/security',  // fallback piece
  'content'  => '/wp-json/vl-hub/v1/content',   // fallback piece
  'users'    => '/wp-json/vl-hub/v1/users',     // fallback piece
);

/* ============================================================
 * ACTIVATION / DEACTIVATION
 * ============================================================ */
register_activation_hook(__FILE__, function () {
  if (!get_option(LUNA_WIDGET_OPT_MODE, null)) {
    update_option(LUNA_WIDGET_OPT_MODE, 'widget');
  }
  if (!get_option(LUNA_WIDGET_OPT_SETTINGS, null)) {
    update_option(LUNA_WIDGET_OPT_SETTINGS, array(
      'position'    => 'bottom-right',
      'title'       => 'Luna Chat',
      'avatar_url'  => '',
      'header_text' => "Hi, I'm Luna",
      'sub_text'    => 'How can I help today?',
    ));
  }
  if (!get_option(LUNA_WIDGET_OPT_LICENSE_SERVER, null)) {
    update_option(LUNA_WIDGET_OPT_LICENSE_SERVER, 'https://visiblelight.ai');
  }
  if (get_option(LUNA_WIDGET_OPT_COMPOSER_ENABLED, null) === null) {
    update_option(LUNA_WIDGET_OPT_COMPOSER_ENABLED, '1');
  }
  if (!wp_next_scheduled('luna_widget_heartbeat_event')) {
    wp_schedule_event(time() + 60, 'hourly', 'luna_widget_heartbeat_event');
  }
});

register_deactivation_hook(__FILE__, function () {
  $ts = wp_next_scheduled('luna_widget_heartbeat_event');
  if ($ts) wp_unschedule_event($ts, 'luna_widget_heartbeat_event');
});

/* ============================================================
 * ADMIN MENU (Top-level)
 * ============================================================ */
add_action('admin_menu', function () {
  add_menu_page(
    'Luna Widget',
    'Luna Widget',
    'manage_options',
    'luna-widget',
    'luna_widget_admin_page',
    'dashicons-format-chat',
    64
  );
  add_submenu_page(
    'luna-widget',
    'Compose',
    'Compose',
    'manage_options',
    'luna-widget-compose',
    'luna_widget_compose_admin_page'
  );
  add_submenu_page(
    'luna-widget',
    'Settings',
    'Settings',
    'manage_options',
    'luna-widget',
    'luna_widget_admin_page'
  );
  add_submenu_page(
    'luna-widget',
    'Chats',
    'Chats',
    'manage_options',
    'luna-widget-chats',
    'luna_widget_chats_admin_page'
  );
  add_submenu_page(
    'luna-widget',
    'Keywords',
    'Keywords',
    'manage_options',
    'luna-widget-keywords',
    'luna_widget_keywords_admin_page'
  );
  
  // Add JavaScript for keywords page
  add_action('admin_enqueue_scripts', function($hook) {
    if ($hook === 'luna-widget_page_luna-widget-keywords') {
      add_action('admin_footer', 'luna_keywords_admin_scripts');
    }
  });
  add_submenu_page(
    'luna-widget',
    'Analytics',
    'Analytics',
    'manage_options',
    'luna-widget-analytics',
    'luna_widget_analytics_admin_page'
  );
});

/* ============================================================
 * SETTINGS
 * ============================================================ */
add_action('admin_init', function () {
  register_setting('luna_widget_settings', LUNA_WIDGET_OPT_LICENSE, array(
    'type' => 'string',
    'sanitize_callback' => function($v){ return preg_replace('/[^A-Za-z0-9\-\_]/','', (string)$v); },
    'default' => '',
  ));
  register_setting('luna_widget_settings', 'luna_openai_api_key', array(
    'type' => 'string',
    'sanitize_callback' => function($v){ return trim((string)$v); },
    'default' => '',
  ));
  register_setting('luna_widget_settings', LUNA_WIDGET_OPT_LICENSE_SERVER, array(
    'type' => 'string',
    'sanitize_callback' => function($v){
      $v = trim((string)$v);
      if ($v === '') return 'https://visiblelight.ai';
      $v = preg_replace('#/+$#','',$v);
      $v = preg_replace('#^http://#i','https://',$v);
      return esc_url_raw($v);
    },
    'default' => 'https://visiblelight.ai',
  ));
  register_setting('luna_widget_settings', LUNA_WIDGET_OPT_MODE, array(
    'type' => 'string',
    'sanitize_callback' => function($v){ return in_array($v, array('shortcode','widget'), true) ? $v : 'widget'; },
    'default' => 'widget',
  ));
  register_setting('luna_widget_settings', LUNA_WIDGET_OPT_SETTINGS, array(
    'type' => 'array',
    'sanitize_callback' => function($a){
      $a = is_array($a) ? $a : array();
      $pos = isset($a['position']) ? strtolower((string)$a['position']) : 'bottom-right';
      $valid_positions = array('top-left','top-center','top-right','bottom-left','bottom-center','bottom-right');
      if (!in_array($pos, $valid_positions, true)) $pos = 'bottom-right';
      return array(
        'position'    => $pos,
        'title'       => sanitize_text_field(isset($a['title']) ? $a['title'] : 'Luna Chat'),
        'avatar_url'  => esc_url_raw(isset($a['avatar_url']) ? $a['avatar_url'] : ''),
        'header_text' => sanitize_text_field(isset($a['header_text']) ? $a['header_text'] : "Hi, I'm Luna"),
        'sub_text'    => sanitize_text_field(isset($a['sub_text']) ? $a['sub_text'] : 'How can I help today?'),
        'button_desc_chat'    => sanitize_textarea_field(isset($a['button_desc_chat']) ? $a['button_desc_chat'] : 'Start a conversation with Luna to ask questions and get answers about your digital universe.'),
        'button_desc_report'  => sanitize_textarea_field(isset($a['button_desc_report']) ? $a['button_desc_report'] : 'Generate comprehensive reports about your site health, performance, and security.'),
        'button_desc_compose' => sanitize_textarea_field(isset($a['button_desc_compose']) ? $a['button_desc_compose'] : 'Access Luna Composer to use canned prompts and responses for quick interactions.'),
        'button_desc_automate' => sanitize_textarea_field(isset($a['button_desc_automate']) ? $a['button_desc_automate'] : 'Set up automated workflows and tasks with Luna to streamline your operations.'),
      );
    },
    'default' => array(),
  ));

  register_setting('luna_composer_settings', LUNA_WIDGET_OPT_COMPOSER_ENABLED, array(
    'type' => 'string',
    'sanitize_callback' => function($value) {
      return $value === '1' ? '1' : '0';
    },
    'default' => '1',
  ));

  register_setting('luna_widget_settings', LUNA_WIDGET_OPT_SUPERCLUSTER_ONLY, array(
    'type' => 'string',
    'sanitize_callback' => function($value) {
      return $value === '1' ? '1' : '0';
    },
    'default' => '0',
  ));
});

/* Settings page */
function luna_widget_admin_page(){
  if (!current_user_can('manage_options')) return;
  $mode  = get_option(LUNA_WIDGET_OPT_MODE, 'widget');
  $ui    = get_option(LUNA_WIDGET_OPT_SETTINGS, array());
  $lic   = get_option(LUNA_WIDGET_OPT_LICENSE, '');
  $hub   = luna_widget_hub_base();
  $last  = get_option(LUNA_WIDGET_OPT_LAST_PING, array());
  ?>
  <div class="wrap">
    <h1>Luna Chat — Widget</h1>

    <div class="notice notice-info" style="padding:8px 12px;margin-top:10px;">
      <strong>Hub connection:</strong>
      <?php if (!empty($last['code'])): ?>
        Response <code><?php echo (int)$last['code']; ?></code> at <?php echo esc_html(isset($last['ts']) ? $last['ts'] : ''); ?>.
      <?php else: ?>
        No heartbeat recorded yet.
      <?php endif; ?>
      <div style="margin-top:6px;display:flex;gap:8px;align-items:center;">
        <button type="button" class="button" id="luna-test-activation">Test Activation</button>
        <button type="button" class="button" id="luna-test-heartbeat">Heartbeat Now</button>
        <button type="button" class="button button-primary" id="luna-sync-to-hub">Sync to Hub</button>
        <span style="opacity:.8;">Hub: <?php echo esc_html($hub); ?></span>
      </div>
    </div>

    <form method="post" action="options.php">
      <?php settings_fields('luna_widget_settings'); ?>
      <table class="form-table" role="presentation">
        <tr>
          <th scope="row">Corporate License Code</th>
          <td>
            <input type="text" name="<?php echo esc_attr(LUNA_WIDGET_OPT_LICENSE); ?>" value="<?php echo esc_attr($lic); ?>" class="regular-text code" placeholder="VL-XXXX-XXXX-XXXX" />
            <p class="description">Required for secured Hub data.</p>
          </td>
        </tr>
        <tr>
          <th scope="row">License Server (Hub)</th>
          <td>
            <input type="url" name="<?php echo esc_attr(LUNA_WIDGET_OPT_LICENSE_SERVER); ?>" value="<?php echo esc_url($hub); ?>" class="regular-text code" placeholder="https://visiblelight.ai" />
            <p class="description">HTTPS enforced; trailing slashes removed automatically.</p>
          </td>
        </tr>
        <tr>
          <th scope="row">Embedding mode</th>
          <td>
            <label style="display:block;margin-bottom:.4rem;">
              <input type="radio" name="<?php echo esc_attr(LUNA_WIDGET_OPT_MODE); ?>" value="shortcode" <?php checked($mode, 'shortcode'); ?>>
              Shortcode only (<code>[luna_chat]</code>)
            </label>
            <label>
              <input type="radio" name="<?php echo esc_attr(LUNA_WIDGET_OPT_MODE); ?>" value="widget" <?php checked($mode, 'widget'); ?>>
              Floating chat widget (site-wide)
            </label>
            <br>
            <label style="display:block;margin-top:.4rem;">
              <input type="checkbox" name="<?php echo esc_attr(LUNA_WIDGET_OPT_SUPERCLUSTER_ONLY); ?>" value="1" <?php checked(get_option(LUNA_WIDGET_OPT_SUPERCLUSTER_ONLY, '0'), '1'); ?>>
              Supercluster only
            </label>
            <p class="description" style="margin-top:.25rem;margin-left:1.5rem;">When enabled, the widget will only appear in Supercluster and not on the frontend site.</p>
          </td>
        </tr>
        <tr>
          <th scope="row">Widget UI</th>
          <td>
            <label style="display:block;margin:.25rem 0;">
              <span style="display:inline-block;width:140px;">Title</span>
              <input type="text" name="<?php echo esc_attr(LUNA_WIDGET_OPT_SETTINGS); ?>[title]" value="<?php echo esc_attr(isset($ui['title']) ? $ui['title'] : 'Luna Chat'); ?>" />
            </label>
            <label style="display:block;margin:.25rem 0;">
              <span style="display:inline-block;width:140px;">Avatar URL</span>
              <input type="url" name="<?php echo esc_attr(LUNA_WIDGET_OPT_SETTINGS); ?>[avatar_url]" value="<?php echo esc_url(isset($ui['avatar_url']) ? $ui['avatar_url'] : ''); ?>" class="regular-text code" placeholder="https://…/luna.png" />
            </label>
            <label style="display:block;margin:.25rem 0;">
              <span style="display:inline-block;width:140px;">Header text</span>
              <input type="text" name="<?php echo esc_attr(LUNA_WIDGET_OPT_SETTINGS); ?>[header_text]" value="<?php echo esc_attr(isset($ui['header_text']) ? $ui['header_text'] : "Hi, I'm Luna"); ?>" />
            </label>
            <label style="display:block;margin:.25rem 0;">
              <span style="display:inline-block;width:140px;">Sub text</span>
              <input type="text" name="<?php echo esc_attr(LUNA_WIDGET_OPT_SETTINGS); ?>[sub_text]" value="<?php echo esc_attr(isset($ui['sub_text']) ? $ui['sub_text'] : 'How can I help today?'); ?>" />
            </label>
            <label style="display:block;margin:.25rem 0;">
              <span style="display:inline-block;width:140px;">Position</span>
              <?php $pos = isset($ui['position']) ? $ui['position'] : 'bottom-right'; ?>
              <select name="<?php echo esc_attr(LUNA_WIDGET_OPT_SETTINGS); ?>[position]">
                <?php foreach (array('top-left','top-center','top-right','bottom-left','bottom-center','bottom-right') as $p): ?>
                  <option value="<?php echo esc_attr($p); ?>" <?php selected($p, $pos); ?>><?php echo esc_html($p); ?></option>
                <?php endforeach; ?>
              </select>
            </label>
          </td>
        </tr>
        <tr>
          <th scope="row">Button Descriptions</th>
          <td>
            <p class="description" style="margin-bottom:1rem;">Customize the descriptions that appear when users hover over the "?" icon on each Luna greeting button.</p>
            <label style="display:block;margin:.75rem 0;">
              <span style="display:inline-block;width:140px;vertical-align:top;padding-top:4px;">Luna Chat</span>
              <textarea name="<?php echo esc_attr(LUNA_WIDGET_OPT_SETTINGS); ?>[button_desc_chat]" rows="2" style="width:400px;max-width:100%;"><?php echo esc_textarea(isset($ui['button_desc_chat']) ? $ui['button_desc_chat'] : 'Start a conversation with Luna to ask questions and get answers about your digital universe.'); ?></textarea>
            </label>
            <label style="display:block;margin:.75rem 0;">
              <span style="display:inline-block;width:140px;vertical-align:top;padding-top:4px;">Luna Report</span>
              <textarea name="<?php echo esc_attr(LUNA_WIDGET_OPT_SETTINGS); ?>[button_desc_report]" rows="2" style="width:400px;max-width:100%;"><?php echo esc_textarea(isset($ui['button_desc_report']) ? $ui['button_desc_report'] : 'Generate comprehensive reports about your site health, performance, and security.'); ?></textarea>
            </label>
            <label style="display:block;margin:.75rem 0;">
              <span style="display:inline-block;width:140px;vertical-align:top;padding-top:4px;">Luna Compose</span>
              <textarea name="<?php echo esc_attr(LUNA_WIDGET_OPT_SETTINGS); ?>[button_desc_compose]" rows="2" style="width:400px;max-width:100%;"><?php echo esc_textarea(isset($ui['button_desc_compose']) ? $ui['button_desc_compose'] : 'Access Luna Composer to use canned prompts and responses for quick interactions.'); ?></textarea>
            </label>
            <label style="display:block;margin:.75rem 0;">
              <span style="display:inline-block;width:140px;vertical-align:top;padding-top:4px;">Luna Automate</span>
              <textarea name="<?php echo esc_attr(LUNA_WIDGET_OPT_SETTINGS); ?>[button_desc_automate]" rows="2" style="width:400px;max-width:100%;"><?php echo esc_textarea(isset($ui['button_desc_automate']) ? $ui['button_desc_automate'] : 'Set up automated workflows and tasks with Luna to streamline your operations.'); ?></textarea>
            </label>
          </td>
        </tr>
        <tr>
          <th scope="row">OpenAI API key</th>
          <td>
            <input type="password" name="luna_openai_api_key"
                   value="<?php echo esc_attr( get_option('luna_openai_api_key','') ); ?>"
                   class="regular-text code" placeholder="sk-..." />
            <p class="description">If present, AI answers are blended with Hub facts. Otherwise, deterministic replies only.</p>
          </td>
        </tr>
      </table>
      <?php submit_button('Save changes'); ?>
    </form>
  </div>

  <script>
    (function(){
      const nonce = '<?php echo wp_create_nonce('wp_rest'); ?>';
      async function call(path){
        try{ await fetch(path, {method:'POST', headers:{'X-WP-Nonce': nonce}}); location.reload(); }
        catch(e){ alert('Request failed. See console.'); console.error(e); }
      }
      document.addEventListener('click', function(e){
        if(e.target && e.target.id==='luna-test-activation'){ e.preventDefault(); call('<?php echo esc_url_raw( rest_url('luna_widget/v1/ping-hub') ); ?>'); }
        if(e.target && e.target.id==='luna-test-heartbeat'){ e.preventDefault(); call('<?php echo esc_url_raw( rest_url('luna_widget/v1/heartbeat-now') ); ?>'); }
        if(e.target && e.target.id==='luna-sync-to-hub'){ e.preventDefault(); call('<?php echo esc_url_raw( rest_url('luna_widget/v1/sync-to-hub') ); ?>'); }
      });
    })();
  </script>
  <?php
}

function luna_widget_compose_admin_page() {
  if (!current_user_can('manage_options')) {
    return;
  }

  $enabled = get_option(LUNA_WIDGET_OPT_COMPOSER_ENABLED, '1') === '1';
  $history = luna_composer_recent_entries(10);
  $canned  = get_posts(array(
    'post_type'        => 'luna_canned_response',
    'post_status'      => 'publish',
    'numberposts'      => 10,
    'orderby'          => array('menu_order' => 'ASC', 'title' => 'ASC'),
    'order'            => 'ASC',
    'suppress_filters' => false,
  ));

  ?>
  <div class="wrap luna-composer-admin">
    <h1>Luna Composer</h1>
    <p class="description">Manage the Luna Composer experience alongside the floating widget without installing additional plugins.</p>

    <form method="post" action="options.php" style="margin-bottom:2rem;">
      <?php settings_fields('luna_composer_settings'); ?>
      <table class="form-table" role="presentation">
        <tr>
          <th scope="row">Status</th>
          <td>
            <label>
              <input type="checkbox" name="<?php echo esc_attr(LUNA_WIDGET_OPT_COMPOSER_ENABLED); ?>" value="1" <?php checked($enabled); ?> />
              <?php esc_html_e('Activate Luna Composer front-end shortcode and REST handling', 'luna'); ?>
            </label>
            <p class="description">When disabled, the shortcode renders a notice and API requests return a friendly deactivation message.</p>
          </td>
        </tr>
        <tr>
          <th scope="row">Shortcode</th>
          <td>
            <code style="font-size:1.1em;">[luna_composer]</code>
            <p class="description">Place this shortcode on any page or post to embed the Composer interface. It automatically shares canned prompts and the same REST endpoint as the Luna widget.</p>
            <?php
            // Only show demo shortcode on visiblelight.ai
            $current_domain = parse_url(home_url(), PHP_URL_HOST);
            if ($current_domain === 'visiblelight.ai' || $current_domain === 'www.visiblelight.ai') :
            ?>
            <div style="margin-top:1rem;padding-top:1rem;border-top:1px solid #ddd;">
              <code style="font-size:1.1em;">[luna_composer_demo_only]</code>
              <p class="description">Demo version that uses sample data instead of real VL Hub data. Only available on visiblelight.ai domain.</p>
            </div>
            <?php endif; ?>
          </td>
        </tr>
      </table>
      <?php submit_button(__('Save Composer Settings', 'luna')); ?>
    </form>

    <h2>Recent Composer History</h2>
    <?php if (!empty($history)) : ?>
      <ol class="luna-composer-history" style="max-width:900px;">
        <?php foreach ($history as $entry) :
          $prompt = get_post_meta($entry->ID, 'prompt', true);
          $answer = get_post_meta($entry->ID, 'answer', true);
          $timestamp = (int) get_post_meta($entry->ID, 'timestamp', true);
          $meta = get_post_meta($entry->ID, 'meta', true);
          $source = is_array($meta) && !empty($meta['source']) ? $meta['source'] : 'unknown';
          $time_display = $timestamp ? date_i18n(get_option('date_format') . ' ' . get_option('time_format'), $timestamp) : get_the_date('', $entry);
          ?>
          <li style="margin-bottom:1.5rem;padding:1rem;border:1px solid #dfe4ea;border-radius:8px;background:#fff;">
            <strong><?php echo esc_html($time_display); ?></strong>
            <?php
            // Get feedback status
            $feedback_meta = get_post_meta($entry->ID, 'feedback', true);
            $feedback_status = '';
            if ($feedback_meta === 'like') {
              $feedback_status = '<span style="display:inline-block;margin-left:12px;padding:4px 8px;background:#8D8C00;color:#fff;border-radius:4px;font-size:0.85em;font-weight:600;">Liked</span>';
            } elseif ($feedback_meta === 'dislike') {
              $feedback_status = '<span style="display:inline-block;margin-left:12px;padding:4px 8px;background:#d63638;color:#fff;border-radius:4px;font-size:0.85em;font-weight:600;">Disliked</span>';
            }
            echo $feedback_status;
            ?>
            <div style="margin-top:.5rem;">
              <span style="display:block;font-weight:600;">Prompt:</span>
              <div style="margin-top:.35rem;white-space:pre-wrap;"><?php echo esc_html(wp_trim_words($prompt, 50, '…')); ?></div>
            </div>
            <div style="margin-top:.75rem;">
              <span style="display:block;font-weight:600;">Response (<?php echo esc_html($source); ?>):</span>
              <div style="margin-top:.35rem;white-space:pre-wrap;"><?php echo esc_html(wp_trim_words($answer, 120, '…')); ?></div>
            </div>
            <div style="margin-top:.5rem;font-size:.9em;">
              <a href="<?php echo esc_url(get_edit_post_link($entry->ID)); ?>">View full entry</a>
            </div>
          </li>
        <?php endforeach; ?>
      </ol>
    <?php else : ?>
      <p>No composer history recorded yet.</p>
    <?php endif; ?>

    <h2>Canned Prompts &amp; Responses</h2>
    <?php if (!empty($canned)) : ?>
      <table class="widefat fixed striped" style="max-width:900px;">
        <thead>
          <tr>
            <th scope="col">Prompt</th>
            <th scope="col" style="width:35%;">Response preview</th>
            <th scope="col" style="width:120px;">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($canned as $post) :
            $content = luna_widget_prepare_canned_response_content($post->post_content);
            ?>
            <tr>
              <td><?php echo esc_html($post->post_title); ?></td>
              <td><?php echo esc_html(wp_trim_words($content, 30, '…')); ?></td>
              <td><a href="<?php echo esc_url(get_edit_post_link($post->ID)); ?>">Edit</a></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <p style="margin-top:1rem;"><a class="button" href="<?php echo esc_url(admin_url('edit.php?post_type=luna_canned_response')); ?>">Manage canned responses</a></p>
      
      <?php
      // Show sprite library status
      $sprite_version = get_option('_luna_sprite_library_version', '0.0.0');
      $sprite_updated = get_option('_luna_sprite_library_updated_at', '');
      $sprite_count = get_posts(array(
        'post_type' => 'luna_canned_response',
        'post_status' => 'publish',
        'meta_query' => array(
          array(
            'key' => '_luna_sprite_id',
            'compare' => 'EXISTS'
          )
        ),
        'posts_per_page' => -1,
        'fields' => 'ids'
      ));
      $sprite_count = count($sprite_count);
      
      if ($sprite_version !== '0.0.0') {
        echo '<div style="margin-top:1rem;padding:12px;background:#f0f0f1;border-left:4px solid #2271b1;border-radius:4px;">';
        echo '<strong>Sprite Library:</strong> Version ' . esc_html($sprite_version);
        if ($sprite_updated) {
          echo ' (Updated: ' . esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($sprite_updated))) . ')';
        }
        echo '<br>';
        echo '<span style="color:#646970;">' . esc_html($sprite_count) . ' sprite(s) installed. Sprites are published by default; move to draft to hide them from Luna Compose.</span>';
        echo '</div>';
      } else {
        echo '<div style="margin-top:1rem;padding:12px;background:#fff3cd;border-left:4px solid #dba617;border-radius:4px;">';
        echo '<strong>Sprite Library:</strong> Not installed. The seed library will be installed automatically on plugin activation or update.';
        echo '</div>';
      }
      ?>
    <?php else : ?>
      <p>No canned responses found. <a href="<?php echo esc_url(admin_url('post-new.php?post_type=luna_canned_response')); ?>">Create your first canned response</a> to provide offline answers when the Hub is unavailable.</p>
    <?php endif; ?>
  </div>
  <?php
}

function luna_widget_chats_admin_page() {
  if (!current_user_can('manage_options')) {
    return;
  }

  $conversations = luna_chat_recent_conversations(100);

  ?>
  <div class="wrap luna-chats-admin">
    <h1>Luna Chat Conversations</h1>
    <p class="description">View all chat conversations from the Luna Chat widget. Click on any conversation to view the full transcript.</p>

    <h2>Chat Sessions</h2>
    <?php if (!empty($conversations)) : ?>
      <table class="wp-list-table widefat fixed striped" style="margin-top:1rem;">
        <thead>
          <tr>
            <th style="width:200px;">Date & Time</th>
            <th style="width:80px;">Turns</th>
            <th style="width:150px;">Session ID</th>
            <th style="width:150px;">Status</th>
            <th style="width:100px;">Actions</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($conversations as $conversation) :
          $transcript = get_post_meta($conversation->ID, 'transcript', true);
          $cid = get_post_meta($conversation->ID, 'luna_cid', true);
          $session_closed = get_post_meta($conversation->ID, 'session_closed', true);
          $session_closed_reason = get_post_meta($conversation->ID, 'session_closed_reason', true);
          
          if (!is_array($transcript)) {
            $transcript = array();
          }
          
          $total_turns = count($transcript);
          $time_display = get_the_date(get_option('date_format') . ' ' . get_option('time_format'), $conversation);
          $conversation_id = 'luna-chat-' . $conversation->ID;
            
            // Get first user message for preview
            $first_user_msg = '';
            $first_assistant_msg = '';
            foreach ($transcript as $turn) {
              if (!empty($turn['user']) && $first_user_msg === '') {
                $first_user_msg = wp_trim_words($turn['user'], 15);
              }
              if (!empty($turn['assistant']) && $first_assistant_msg === '') {
                $first_assistant_msg = wp_trim_words($turn['assistant'], 15);
              }
              if ($first_user_msg !== '' && $first_assistant_msg !== '') break;
            }
            ?>
            <tr>
              <td>
                <strong style="cursor:pointer;color:#2271b1;" onclick="toggleTranscript('<?php echo esc_js($conversation_id); ?>')">
                  <?php echo esc_html($time_display); ?>
                </strong>
              </td>
              <td><?php echo esc_html($total_turns); ?></td>
              <td style="font-size:.85em;color:#8c8f94;">
                <?php if ($cid) : ?>
                  <?php echo esc_html(substr($cid, 0, 16)); ?>…
                <?php else : ?>
                  —
                <?php endif; ?>
              </td>
              <td>
                <?php if ($session_closed) : ?>
                  <span style="color:#d63638;">Closed</span>
                  <?php if ($session_closed_reason) : ?>
                    <br><span style="font-size:.85em;color:#8c8f94;">(<?php echo esc_html($session_closed_reason); ?>)</span>
                  <?php endif; ?>
                <?php else : ?>
                  <span style="color:#00a32a;">Active</span>
                <?php endif; ?>
              </td>
              <td>
                <button type="button" class="button button-small" onclick="toggleTranscript('<?php echo esc_js($conversation_id); ?>')">
                  <span class="toggle-text-<?php echo esc_attr($conversation_id); ?>">View</span>
                </button>
              </td>
            </tr>
            <tr id="<?php echo esc_attr($conversation_id); ?>" style="display:none;">
              <td colspan="5" style="padding:1.5rem;background:#f6f7f7;border-top:2px solid #2271b1;">
              <h3 style="margin-top:0;margin-bottom:1rem;">Full Transcript</h3>
              <?php if (!empty($transcript)) : ?>
                  <div style="max-height:600px;overflow-y:auto;background:#fff;padding:1rem;border-radius:4px;border:1px solid #dcdcde;">
                  <?php foreach ($transcript as $index => $turn) :
                      $user_msg = isset($turn['user']) ? trim($turn['user']) : '';
                      $assistant_msg = isset($turn['assistant']) ? trim($turn['assistant']) : '';
                      ?>
                      <?php if ($user_msg) : ?>
                        <div style="margin-bottom:1rem;padding:.75rem;background:#e7f5fe;border-left:3px solid #2271b1;border-radius:4px;">
                          <div style="font-size:.85em;color:#2271b1;margin-bottom:.25rem;font-weight:600;">User</div>
                          <div style="white-space:pre-wrap;word-wrap:break-word;color:#1d2327;"><?php echo esc_html($user_msg); ?></div>
                        </div>
                      <?php endif; ?>
                      <?php if ($assistant_msg) : ?>
                        <div style="margin-bottom:1rem;padding:.75rem;background:#f0f6fc;border-left:3px solid #00a32a;border-radius:4px;">
                          <div style="font-size:.85em;color:#00a32a;margin-bottom:.25rem;font-weight:600;">Luna</div>
                          <div style="white-space:pre-wrap;word-wrap:break-word;color:#1d2327;"><?php echo esc_html($assistant_msg); ?></div>
                        </div>
                      <?php endif; ?>
                  <?php endforeach; ?>
                </div>
              <?php else : ?>
                <p style="color:#646970;">No messages in this conversation.</p>
              <?php endif; ?>
              </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    <?php else : ?>
      <p>No chat conversations recorded yet.</p>
    <?php endif; ?>
  </div>
  
  <script>
    function toggleTranscript(conversationId) {
      const transcriptRow = document.getElementById(conversationId);
      const toggleTexts = document.querySelectorAll('.toggle-text-' + conversationId);
      
      if (transcriptRow && transcriptRow.style.display === 'none') {
        transcriptRow.style.display = 'table-row';
        toggleTexts.forEach(function(el) {
          el.textContent = 'Hide';
        });
      } else if (transcriptRow) {
        transcriptRow.style.display = 'none';
        toggleTexts.forEach(function(el) {
          el.textContent = 'View';
        });
      }
    }
  </script>
  
  <style>
    .luna-chat-history li {
      transition: box-shadow 0.2s;
    }
    .luna-chat-history li:hover {
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
  </style>
  <?php
}

/* ============================================================
 * HEARTBEAT / HUB HELPERS
 * ============================================================ */
function luna_widget_hub_base() {
  $base = (string) get_option(LUNA_WIDGET_OPT_LICENSE_SERVER, 'https://visiblelight.ai');
  $base = preg_replace('#/+$#','',$base);
  $base = preg_replace('#^http://#i','https://',$base);
  return $base ? $base : 'https://visiblelight.ai';
}
function luna_widget_hub_url($path = '') {
  $path = '/'.ltrim($path,'/');
  return luna_widget_hub_base() . $path;
}
function luna_widget_store_last_ping($url, $resp) {
  $log = array(
    'ts'   => gmdate('c'),
    'url'  => $url,
    'code' => is_wp_error($resp) ? 0 : (int) wp_remote_retrieve_response_code($resp),
    'err'  => is_wp_error($resp) ? $resp->get_error_message() : '',
    'body' => is_wp_error($resp) ? '' : substr((string) wp_remote_retrieve_body($resp), 0, 500),
  );
  update_option(LUNA_WIDGET_OPT_LAST_PING, $log, false);
}
function luna_widget_try_activation() {
  $license = trim((string) get_option(LUNA_WIDGET_OPT_LICENSE, ''));
  if ($license === '') return;
  $body = array(
    'license'        => $license,
    'site_url'       => home_url('/'),
    'site_name'      => get_bloginfo('name'),
    'wp_version'     => get_bloginfo('version'),
    'plugin_version' => LUNA_WIDGET_PLUGIN_VERSION,
  );
  $url = luna_widget_hub_url('/wp-json/vl-license/v1/activate');
  $resp = wp_remote_post($url, array(
    'timeout' => 15,
    'headers' => array(
      'Content-Type'   => 'application/json',
      'X-Luna-License' => $license,
      'X-Luna-Site'    => home_url('/'),
    ),
    'body'    => wp_json_encode($body),
  ));
  luna_widget_store_last_ping($url, $resp);
}
function luna_widget_send_heartbeat() {
  $license = trim((string) get_option(LUNA_WIDGET_OPT_LICENSE, ''));
  if ($license === '') return;
  $body = array(
    'license'        => $license,
    'site_url'       => home_url('/'),
    'wp_version'     => get_bloginfo('version'),
    'plugin_version' => LUNA_WIDGET_PLUGIN_VERSION,
  );
  $url  = luna_widget_hub_url('/wp-json/vl-license/v1/heartbeat');
  $resp = wp_remote_post($url, array(
    'timeout' => 15,
    'headers' => array(
      'Content-Type'   => 'application/json',
      'X-Luna-License' => $license,
      'X-Luna-Site'    => home_url('/'),
    ),
    'body'    => wp_json_encode($body),
  ));
  luna_widget_store_last_ping($url, $resp);
}
add_action('luna_widget_heartbeat_event', function () {
  if (!wp_next_scheduled('luna_widget_heartbeat_event')) {
    wp_schedule_event(time() + 3600, 'hourly', 'luna_widget_heartbeat_event');
  }
  luna_widget_send_heartbeat();
});
add_action('update_option_' . LUNA_WIDGET_OPT_LICENSE, function($old, $new){
  if ($new && $new !== $old) { luna_widget_try_activation(); luna_widget_send_heartbeat(); luna_profile_cache_bust(true); }
}, 10, 2);
add_action('update_option_' . LUNA_WIDGET_OPT_LICENSE_SERVER, function($old, $new){
  if ($new && $new !== $old) { luna_widget_try_activation(); luna_widget_send_heartbeat(); luna_profile_cache_bust(true); }
}, 10, 2);

/* ============================================================
 * CONVERSATIONS: CPT + helpers
 * ============================================================ */
add_action('init', function () {
  register_post_type('luna_widget_convo', array(
    'label'        => 'Luna Conversations',
    'public'       => false,
    'show_ui'      => true,
    'show_in_menu' => false,
    'supports'     => array('title'),
    'map_meta_cap' => true,
  ));
});

/* ============================================================
 * COMPOSER ENTRIES CPT (history)
 * ============================================================ */
add_action('init', function () {
  $labels = array(
    'name'          => __('Compose', 'luna'),
    'singular_name' => __('Compose Entry', 'luna'),
  );

  register_post_type('luna_compose', array(
    'labels'              => $labels,
    'public'              => false,
    'show_ui'             => false,
    'show_in_menu'        => false,
    'capability_type'     => 'post',
    'map_meta_cap'        => true,
    'supports'            => array('title'),
  ));
});

/* ============================================================
 * CANNED RESPONSES FALLBACK
 * ============================================================ */
add_action('init', function () {
  $labels = array(
    'name'               => __('Canned Responses', 'luna'),
    'singular_name'      => __('Canned Response', 'luna'),
    'add_new'            => __('Add New', 'luna'),
    'add_new_item'       => __('Add New Canned Response', 'luna'),
    'edit_item'          => __('Edit Canned Response', 'luna'),
    'new_item'           => __('New Canned Response', 'luna'),
    'view_item'          => __('View Canned Response', 'luna'),
    'search_items'       => __('Search Canned Responses', 'luna'),
    'not_found'          => __('No canned responses found.', 'luna'),
    'not_found_in_trash' => __('No canned responses found in Trash.', 'luna'),
    'menu_name'          => __('Canned Responses', 'luna'),
  );

  register_post_type('luna_canned_response', array(
    'labels'              => $labels,
    'public'              => false,
    'show_ui'             => true,
    'show_in_menu'        => 'luna-widget',
    'show_in_rest'        => true,
    'capability_type'     => 'post',
    'map_meta_cap'        => true,
    'supports'            => array('title', 'editor', 'revisions'),
    'menu_icon'           => 'dashicons-text-page',
    'menu_position'       => 26,
  ));
});

function luna_widget_normalize_prompt_text($value) {
  $value = is_string($value) ? $value : '';
  $value = wp_strip_all_tags($value);
  $value = html_entity_decode($value, ENT_QUOTES, get_option('blog_charset', 'UTF-8'));
  $value = preg_replace('/\s+/u', ' ', $value);
  return trim($value);
}

function luna_widget_prepare_canned_response_content($content) {
  $content = (string) apply_filters('the_content', $content);
  $content = str_replace(array("\r\n", "\r"), "\n", $content);
  $content = preg_replace('/<\s*br\s*\/?\s*>/i', "\n", $content);
  $content = preg_replace('/<\/(p|div|li|h[1-6])\s*>/i', '</$1>\n\n', $content);
  $content = wp_strip_all_tags($content);
  $content = html_entity_decode($content, ENT_QUOTES, get_option('blog_charset', 'UTF-8'));
  $content = preg_replace("/\n{3,}/", "\n\n", $content);
  // Remove trailing newlines (including \n\n) from the end
  $content = rtrim($content, "\n\r");
  return trim($content);
}

function luna_widget_find_canned_response($prompt) {
  $normalized = luna_widget_normalize_prompt_text($prompt);
  if ($normalized === '') {
    return null;
  }

  $posts = get_posts(array(
    'post_type'        => 'luna_canned_response',
    'post_status'      => 'publish',
    'numberposts'      => -1,
    'orderby'          => array('menu_order' => 'ASC', 'title' => 'ASC'),
    'order'            => 'ASC',
    'suppress_filters' => false,
  ));

  if (empty($posts)) {
    return null;
  }

  $normalized_lc = function_exists('mb_strtolower') ? mb_strtolower($normalized, 'UTF-8') : strtolower($normalized);
  $best = null;
  $best_score = 0.0;

  foreach ($posts as $post) {
    $title_normalized = luna_widget_normalize_prompt_text($post->post_title);
    if ($title_normalized === '') {
      continue;
    }
    $title_lc = function_exists('mb_strtolower') ? mb_strtolower($title_normalized, 'UTF-8') : strtolower($title_normalized);

    if ($title_lc === $normalized_lc) {
      return array(
        'id'      => $post->ID,
        'title'   => $post->post_title,
        'content' => luna_widget_prepare_canned_response_content($post->post_content),
      );
    }

    $score = 0.0;
    if (function_exists('similar_text')) {
      similar_text($normalized_lc, $title_lc, $percent);
      $score = (float) $percent;
    } elseif (function_exists('levenshtein')) {
      $distance = levenshtein($normalized_lc, $title_lc);
      $max_len = max(strlen($normalized_lc), strlen($title_lc), 1);
      $score = 100.0 - (min($distance, $max_len) / $max_len * 100.0);
    } else {
      $score = strpos($normalized_lc, $title_lc) !== false || strpos($title_lc, $normalized_lc) !== false ? 100.0 : 0.0;
    }

    if ($score > $best_score) {
      $best_score = $score;
      $best = $post;
    }
  }

  if ($best && $best_score >= 55.0) {
    return array(
      'id'      => $best->ID,
      'title'   => $best->post_title,
      'content' => luna_widget_prepare_canned_response_content($best->post_content),
    );
  }

  return null;
}

function luna_widget_create_conversation_post($cid) {
  // First check if a conversation with this CID already exists
  $existing = get_posts(array(
    'post_type'   => 'luna_widget_convo',
    'meta_key'    => 'luna_cid',
    'meta_value'  => $cid,
    'fields'      => 'ids',
    'numberposts' => 1,
    'post_status' => 'any',
  ));
  if ($existing && !empty($existing[0])) {
    // Conversation already exists, return it
    return (int)$existing[0];
  }
  
  // Create new conversation
  $pid = wp_insert_post(array(
    'post_type'   => 'luna_widget_convo',
    'post_title'  => 'Conversation ' . substr($cid, 0, 8),
    'post_status' => 'publish',
  ));
  if ($pid && !is_wp_error($pid)) {
    update_post_meta($pid, 'luna_cid', $cid);
    // Only initialize transcript if it doesn't exist
    $existing_transcript = get_post_meta($pid, 'transcript', true);
    if (!is_array($existing_transcript)) {
    update_post_meta($pid, 'transcript', array());
    }
    return (int)$pid;
  }
  return 0;
}

function luna_widget_current_conversation_id() {
  $cookie_key = 'luna_widget_cid';
  if (empty($_COOKIE[$cookie_key])) {
    return 0;
  }
  $cid = sanitize_text_field(wp_unslash($_COOKIE[$cookie_key]));
  if ($cid === '' || !preg_match('/^lwc_/', $cid)) {
    return 0;
  }
  $existing = get_posts(array(
    'post_type'   => 'luna_widget_convo',
    'meta_key'    => 'luna_cid',
    'meta_value'  => $cid,
    'fields'      => 'ids',
    'numberposts' => 1,
    'post_status' => 'any',
    'orderby'     => 'date',
    'order'       => 'DESC',
  ));
  if ($existing && !empty($existing[0])) {
    return (int)$existing[0];
  }
  return 0;
}

function luna_conv_id($force_new = false) {
  $cookie_key = 'luna_widget_cid';
  $cid = isset($_COOKIE[$cookie_key]) ? sanitize_text_field(wp_unslash($_COOKIE[$cookie_key])) : '';

  if (!$force_new) {
    // First, try to find existing conversation by CID
    if ($cid !== '' && preg_match('/^lwc_/', $cid)) {
    $pid = luna_widget_current_conversation_id();
      if ($pid) {
        // Ensure cookie is set for future requests
        @setcookie($cookie_key, $cid, time() + (86400 * 30), COOKIEPATH ? COOKIEPATH : '/', COOKIE_DOMAIN ? COOKIE_DOMAIN : '', is_ssl(), true);
        $_COOKIE[$cookie_key] = $cid;
        return $pid;
      }
      // CID exists but no conversation found - create one with this CID
      @setcookie($cookie_key, $cid, time() + (86400 * 30), COOKIEPATH ? COOKIEPATH : '/', COOKIE_DOMAIN ? COOKIE_DOMAIN : '', is_ssl(), true);
      $_COOKIE[$cookie_key] = $cid;
      return luna_widget_create_conversation_post($cid);
    }
  }

  // Create new conversation with new CID
  $cid = 'lwc_' . uniqid('', true);
  @setcookie($cookie_key, $cid, time() + (86400 * 30), COOKIEPATH ? COOKIEPATH : '/', COOKIE_DOMAIN ? COOKIE_DOMAIN : '', is_ssl(), true);
  $_COOKIE[$cookie_key] = $cid;
  return luna_widget_create_conversation_post($cid);
}

function luna_widget_close_conversation($pid, $reason = '') {
  if (!$pid) return;
  update_post_meta($pid, 'session_closed', time());
  if ($reason !== '') {
    update_post_meta($pid, 'session_closed_reason', sanitize_text_field($reason));
  }
}
function luna_log_turn($user, $assistant, $meta = array()) {
  $pid = luna_conv_id(); 
  if (!$pid) {
    error_log('[Luna Widget] luna_log_turn: No conversation ID available');
    return;
  }
  
  $t = get_post_meta($pid, 'transcript', true);
  if (!is_array($t)) {
    $t = array();
  }
  
  // Only add turn if there's actual content (user or assistant message)
  if (trim($user) !== '' || trim($assistant) !== '') {
    $t[] = array(
      'ts' => time(),
      'user' => trim((string)$user),
      'assistant' => trim((string)$assistant),
      'meta' => $meta
    );
  update_post_meta($pid, 'transcript', $t);

  // Also log to Hub
  luna_log_conversation_to_hub($t);
  } else {
    error_log('[Luna Widget] luna_log_turn: Skipping empty turn (user and assistant both empty)');
  }
}

function luna_composer_log_entry($prompt, $answer, $meta = array(), $conversation_id = 0) {
  $prompt = trim(wp_strip_all_tags((string) $prompt));
  $answer = trim((string) $answer);
  if ($prompt === '' && $answer === '') {
    return 0;
  }

  $title = $prompt !== '' ? wp_trim_words($prompt, 12, '…') : __('Composer Entry', 'luna');
  $post_id = wp_insert_post(array(
    'post_type'   => 'luna_compose',
    'post_title'  => $title,
    'post_status' => 'publish',
  ));

  if (!$post_id || is_wp_error($post_id)) {
    return 0;
  }

  update_post_meta($post_id, 'prompt', $prompt);
  update_post_meta($post_id, 'answer', $answer);
  update_post_meta($post_id, 'meta', is_array($meta) ? $meta : array());
  if ($conversation_id) {
    update_post_meta($post_id, 'conversation_post', (int) $conversation_id);
  }
  update_post_meta($post_id, 'timestamp', time());

  return (int) $post_id;
}

function luna_composer_recent_entries($limit = 10) {
  $query = new WP_Query(array(
    'post_type'      => 'luna_compose',
    'post_status'    => 'publish',
    'posts_per_page' => max(1, (int) $limit),
    'orderby'        => 'date',
    'order'          => 'DESC',
    'no_found_rows'  => true,
  ));

  $posts = $query->posts;
  wp_reset_postdata();
  return $posts;
}

function luna_chat_recent_conversations($limit = 50) {
  $query = new WP_Query(array(
    'post_type'      => 'luna_widget_convo',
    'post_status'    => 'publish',
    'posts_per_page' => max(1, (int) $limit),
    'orderby'        => 'date',
    'order'          => 'DESC',
    'no_found_rows'  => true,
  ));

  $posts = $query->posts;
  wp_reset_postdata();
  return $posts;
}

/* Log conversation to Hub */
function luna_log_conversation_to_hub($transcript) {
  $license = luna_get_license();
  if (!$license) {
    error_log('Luna Hub Log: No license found');
    return false;
  }
  
  $hub_url = luna_widget_hub_base();
  $conversation_data = array(
    'id' => 'conv_' . uniqid('', true),
    'started_at' => !empty($transcript[0]['ts']) ? gmdate('c', (int)$transcript[0]['ts']) : gmdate('c'),
    'transcript' => $transcript
  );
  
  error_log('Luna Hub Log: Sending conversation to Hub: ' . print_r($conversation_data, true));
  
  $response = wp_remote_post($hub_url . '/wp-json/luna_widget/v1/conversations/log', array(
    'headers' => array(
      'X-Luna-License' => $license,
      'Content-Type' => 'application/json'
    ),
    'body' => wp_json_encode($conversation_data),
    'timeout' => 10
  ));
  
  if (is_wp_error($response)) {
    error_log('Luna Hub Log: Error sending to Hub: ' . $response->get_error_message());
    return false;
  }
  
  $response_code = wp_remote_retrieve_response_code($response);
  $response_body = wp_remote_retrieve_body($response);
  
  error_log('Luna Hub Log: Hub response code: ' . $response_code);
  error_log('Luna Hub Log: Hub response body: ' . $response_body);
  
  return $response_code >= 200 && $response_code < 300;
}

/* ============================================================
 * HUB PROFILE FETCH (LICENSE-GATED) + FACTS
 * ============================================================ */
function luna_get_license() { return trim((string) get_option(LUNA_WIDGET_OPT_LICENSE, '')); }

function luna_profile_cache_key() {
  $license = luna_get_license();
  $hub     = luna_widget_hub_base();
  $site    = home_url('/');
  return 'luna_profile_' . md5($license . '|' . $hub . '|' . $site);
}
function luna_profile_cache_bust($all=false){
  // Single-site cache key; $all kept for API symmetry
  delete_transient( luna_profile_cache_key() );
  if ($all) {
    delete_transient( luna_hub_collections_cache_key() );
  }
}

function luna_hub_normalize_payload($payload) {
  if (!is_array($payload)) {
    return $payload;
  }

  if (isset($payload['data']) && is_array($payload['data'])) {
    $payload = $payload['data'];
  } elseif (isset($payload['profile']) && is_array($payload['profile'])) {
    $payload = $payload['profile'];
  } elseif (isset($payload['payload']) && is_array($payload['payload'])) {
    $payload = $payload['payload'];
  }

  return $payload;
}

function luna_hub_get_json($path) {
  $license = luna_get_license();
  if ($license === '') return null;
  
  // CRITICAL: Always use HTTP request to fetch from VL Hub Profile server (visiblelight.ai)
  // Direct access only returns streams from local WordPress, not the full comprehensive Raw JSON
  // We MUST fetch from the VL Hub Profile server to get ALL data (GA4, SSL/TLS, Cloudflare, AWS S3, etc.)
  
  // Determine if this is a profile/comprehensive endpoint that needs full Raw JSON
  $is_profile_endpoint = (strpos($path, '/profile') !== false || 
                          strpos($path, '/system/comprehensive') !== false ||
                          strpos($path, '/all-connections') !== false ||
                          strpos($path, '/connections') !== false);
  
  if ($is_profile_endpoint) {
    error_log('[Luna] PROFILE ENDPOINT DETECTED: ' . $path . ' - Fetching full Raw JSON from VL Hub Profile server');
  }
  
  // Always use HTTP request to get data from VL Hub Profile server
  // This ensures we get the complete Raw JSON with all Hub Profile data
  // Add license parameter to URL if not already present
  $url = luna_widget_hub_url($path);
  if (strpos($url, '?') !== false) {
    $url .= '&license=' . rawurlencode($license);
  } else {
    $url .= '?license=' . rawurlencode($license);
  }
  
  // CRITICAL: Verify we're fetching from VL Hub Profile server, not local WordPress
  $hub_base = luna_widget_hub_base();
  if (strpos($url, $hub_base) === false) {
    error_log('[Luna] ⚠️ WARNING: URL does not match Hub base! URL: ' . $url . ' | Hub base: ' . $hub_base);
  } else {
    error_log('[Luna] ✅ Fetching from VL Hub Profile server: ' . $url);
  }
  
  // Reduced timeout for faster failure - prevents blocking on slow/failed requests
  // This is especially important for first message latency
  $resp = wp_remote_get($url, array(
    'timeout' => 5, // Reduced from 12 to 5 seconds for faster failure
    'headers' => array(
      'X-Luna-License' => $license,
      'X-Luna-Site'    => home_url('/'),
      'Accept'         => 'application/json'
    ),
    'sslverify' => true,
  ));
  
  if (is_wp_error($resp)) {
    error_log('[Luna] HTTP error fetching ' . $path . ': ' . $resp->get_error_message());
    return null;
  }
  
  $code = (int) wp_remote_retrieve_response_code($resp);
  if ($code >= 400) {
    $error_body = wp_remote_retrieve_body($resp);
    error_log('[Luna] HTTP ' . $code . ' error fetching ' . $path . ' from ' . $url . ': ' . substr($error_body, 0, 200));
    
    // If 403, try direct access as fallback
    if ($code === 403 && class_exists('VL_Hub_Profile')) {
      error_log('[Luna] 403 error detected, attempting direct access to VL Hub data');
      // Return null to trigger fallback in calling function
    }
    return null;
  }
  
  $raw_body = wp_remote_retrieve_body($resp);
  $body = json_decode($raw_body, true);
  if (!is_array($body)) {
    error_log('[Luna] Invalid JSON response from ' . $path . ' (URL: ' . $url . ') - Response: ' . substr($raw_body, 0, 200));
    return null;
  }
  
  // Log what data we received for profile endpoints
  if ($is_profile_endpoint) {
    $data_keys = is_array($body) ? array_keys($body) : array();
    error_log('[Luna] ✅ Received profile data from VL Hub Profile server (' . $url . ') with keys: ' . implode(', ', $data_keys));
    if (isset($body['data_streams']) && is_array($body['data_streams'])) {
      error_log('[Luna] ✅ Profile contains ' . count($body['data_streams']) . ' data streams');
    }
    if (isset($body['ga4_metrics'])) {
      error_log('[Luna] ✅ Profile contains GA4 metrics data');
    }
    if (isset($body['ssl_tls']) || isset($body['security'])) {
      error_log('[Luna] ✅ Profile contains security/SSL data');
    }
    if (isset($body['aws_s3'])) {
      error_log('[Luna] ✅ Profile contains AWS S3 data');
    }
    if (isset($body['cloudflare'])) {
      error_log('[Luna] ✅ Profile contains Cloudflare data');
    }
  }

  $normalized = luna_hub_normalize_payload($body);
  
  // Log normalized data structure for profile endpoints
  if ($is_profile_endpoint && is_array($normalized)) {
    $normalized_keys = array_keys($normalized);
    error_log('[Luna] ✅ Normalized profile data keys: ' . implode(', ', $normalized_keys));
  }
  
  return $normalized;
}

function luna_hub_profile() {
  if (isset($_GET['luna_profile_nocache'])) luna_profile_cache_bust();
  $key = luna_profile_cache_key();
  $cached = get_transient($key);
  if (is_array($cached)) return $cached;

  $map = isset($GLOBALS['LUNA_HUB_ENDPOINTS']) ? $GLOBALS['LUNA_HUB_ENDPOINTS'] : array();
  $profile = luna_hub_get_json(isset($map['profile']) ? $map['profile'] : '/wp-json/vl-hub/v1/profile');
  if (is_array($profile)) {
    $profile = luna_hub_normalize_payload($profile);
  }

  if (!$profile) {
    // Fallback to local data only if Hub profile is not available
    $profile = array(
      'site'      => array('url' => home_url('/')),
      'wordpress' => array('version' => get_bloginfo('version')),
      'security'  => array(),
      'content'   => array(),
      'users'     => array(),
    );
  }

  set_transient($key, $profile, LUNA_CACHE_PROFILE_TTL);
  return $profile;
}

function luna_hub_collections_cache_key() {
  $license = luna_get_license();
  $hub     = luna_widget_hub_base();
  return 'luna_hub_collections_' . md5($license . '|' . $hub);
}

function luna_hub_fetch_first_json($paths) {
  if (!is_array($paths)) {
    $paths = array($paths);
  }

  foreach ($paths as $path) {
    $payload = luna_hub_get_json($path);
    if (is_array($payload)) {
      $normalized = luna_hub_normalize_payload($payload);
      if (is_array($normalized) && !empty($normalized)) {
        return $normalized;
      }
    }
  }

  return null;
}

function luna_hub_collect_collections($force_refresh = false, $prefetched = array()) {
  $license = luna_get_license();
  if ($license === '') {
    error_log('[Luna] ❌ No license key found in luna_hub_collect_collections');
    return array();
  }
  
  $hub_url = luna_widget_hub_base();
  error_log('[Luna] 🔄 luna_hub_collect_collections called - Hub URL: ' . $hub_url . ' | License: ' . $license . ' | Force refresh: ' . ($force_refresh ? 'YES' : 'NO'));

  $key = luna_hub_collections_cache_key();
  if (!$force_refresh) {
    $cached = get_transient($key);
    if (is_array($cached)) {
      error_log('[Luna] ✅ Using cached hub collections (cache key: ' . $key . ')');
      if (is_array($prefetched) && !empty($prefetched)) {
        $updated = false;
        foreach ($prefetched as $pref_key => $pref_value) {
          if (is_array($pref_value) && !empty($pref_value) && (!isset($cached[$pref_key]) || $cached[$pref_key] !== $pref_value)) {
            $cached[$pref_key] = $pref_value;
            $updated = true;
          }
        }
        if ($updated) {
          if (!isset($cached['_meta']) || !is_array($cached['_meta'])) {
            $cached['_meta'] = array();
          }
          $cached['_meta']['retrieved_at'] = gmdate('c');
          $cached['_meta']['categories'] = isset($cached['_meta']['categories']) ? $cached['_meta']['categories'] : array_keys(array_diff_key($cached, array('_meta' => true)));
          set_transient($key, $cached, LUNA_CACHE_PROFILE_TTL);
        }
      }
      return $cached;
    } else {
      error_log('[Luna] ⚠️ No cached hub collections found, fetching from VL Hub Profile server');
    }
  } else {
    error_log('[Luna] 🔄 Force refresh requested, fetching fresh data from VL Hub Profile server');
  }

  $categories = array(
    'profile'      => array('/wp-json/vl-hub/v1/profile', '/wp-json/luna_widget/v1/system/comprehensive'),
    'connections'  => array('/wp-json/vl-hub/v1/connections', '/wp-json/vl-hub/v1/all-connections', '/wp-json/vl-hub/v1/data-sources'),
    'cloudops'     => array('/wp-json/vl-hub/v1/cloudops', '/wp-json/vl-hub/v1/cloud-ops'),
    'content'      => array('/wp-json/vl-hub/v1/content'),
    'search'       => array('/wp-json/vl-hub/v1/search', '/wp-json/vl-hub/v1/search-console'),
    'analytics'    => array('/wp-json/vl-hub/v1/analytics', '/wp-json/vl-hub/v1/ga4'),
    'marketing'    => array('/wp-json/vl-hub/v1/marketing'),
    'ecommerce'    => array('/wp-json/vl-hub/v1/ecommerce', '/wp-json/vl-hub/v1/e-commerce'),
    'security'     => array('/wp-json/vl-hub/v1/security'),
    'web_infra'    => array('/wp-json/vl-hub/v1/web-infra', '/wp-json/vl-hub/v1/web-infrastructure', '/wp-json/vl-hub/v1/infra'),
    'identity'     => array('/wp-json/vl-hub/v1/identity'),
    'competitive'  => array('/wp-json/vl-hub/v1/competitive', '/wp-json/vl-hub/v1/competition', '/wp-json/vl-hub/v1/competitors'),
    'users'        => array('/wp-json/vl-hub/v1/users'),
    'plugins'      => array('/wp-json/vl-hub/v1/plugins'),
    'themes'       => array('/wp-json/vl-hub/v1/themes'),
    'updates'      => array('/wp-json/vl-hub/v1/updates'),
  );

  $collections = array();

  if (is_array($prefetched) && !empty($prefetched)) {
    foreach ($prefetched as $pref_key => $pref_value) {
      if (is_array($pref_value) && !empty($pref_value)) {
        $collections[$pref_key] = $pref_value;
      }
    }
  }

  // Limit concurrent requests to prevent overwhelming the server
  // Process most critical categories first, skip less critical ones if cache is empty
  $critical_categories = array('profile', 'connections');
  $has_critical_data = false;
  
  // First, fetch critical categories
  error_log('[Luna] 🔄 Fetching critical categories from VL Hub Profile server: ' . implode(', ', $critical_categories));
  foreach ($critical_categories as $name) {
    if (isset($categories[$name]) && !isset($collections[$name])) {
      $paths = $categories[$name];
      error_log('[Luna] 🔄 Fetching ' . $name . ' from paths: ' . implode(', ', $paths));
      $data = luna_hub_fetch_first_json($paths);
      if ($data !== null) {
        $collections[$name] = $data;
        $has_critical_data = true;
        $data_keys = is_array($data) ? array_keys($data) : array();
        error_log('[Luna] ✅ Successfully fetched ' . $name . ' with keys: ' . implode(', ', array_slice($data_keys, 0, 10)) . (count($data_keys) > 10 ? '...' : ''));
      } else {
        error_log('[Luna] ❌ Failed to fetch ' . $name . ' from VL Hub Profile server');
      }
    } elseif (isset($collections[$name])) {
      $has_critical_data = true;
      error_log('[Luna] ✅ ' . $name . ' already in collections (from prefetched data)');
    }
  }
  
  // Then fetch other categories (but skip if cache is empty and we don't have critical data)
  // This prevents making too many requests on first load when cache is empty
  foreach ($categories as $name => $paths) {
    // Skip critical categories we already processed
    if (in_array($name, $critical_categories)) {
      continue;
    }
    
    if (isset($collections[$name]) && is_array($collections[$name])) {
      continue;
    }
    
    // Only fetch if:
    // 1. Force refresh is requested, OR
    // 2. We have critical data already (cache was partially populated), OR
    // 3. We have prefetched data (indicating this is not a cold start)
    if ($force_refresh || $has_critical_data || !empty($prefetched)) {
      $data = luna_hub_fetch_first_json($paths);
      if ($data !== null) {
        $collections[$name] = $data;
      }
    }
  }

  // CRITICAL: Fetch data streams from VL Hub Profile server
  // This endpoint contains ALL client data: GA4 metrics, SSL/TLS, Cloudflare, etc.
  // Always use HTTP to get the complete data from https://visiblelight.ai/wp-json/vl-hub/v1/data-streams
  error_log('[Luna] 🔄 Fetching data streams from VL Hub Profile server (data-streams endpoint)');
  $streams = luna_fetch_hub_data_streams($license); // Always use HTTP to get client_streams
  if (empty($streams) || !is_array($streams)) {
    // Fallback to direct access only if HTTP fails
    error_log('[Luna] ⚠️ HTTP fetch failed, trying direct access as fallback');
    $streams = luna_fetch_hub_data_streams_direct($license);
  }
  if (is_array($streams) && !empty($streams)) {
    $collections['data_streams'] = $streams;
    error_log('[Luna] ✅ Added ' . count($streams) . ' data streams to collections');
    
    // Extract and add GA4 metrics directly from streams for faster access
    $ga4_stream = null;
    foreach ($streams as $stream) {
      if (isset($stream['ga4_metrics']) && is_array($stream['ga4_metrics']) && !empty($stream['ga4_metrics'])) {
        $ga4_stream = $stream;
        break;
      }
    }
    if ($ga4_stream) {
      if (!isset($collections['analytics']) || !is_array($collections['analytics'])) {
        $collections['analytics'] = array();
      }
      $collections['analytics']['ga4'] = array(
        'metrics' => $ga4_stream['ga4_metrics'],
        'dimensions' => isset($ga4_stream['ga4_dimensions']) ? $ga4_stream['ga4_dimensions'] : array(),
        'property_id' => isset($ga4_stream['ga4_property_id']) ? $ga4_stream['ga4_property_id'] : null,
        'last_synced' => isset($ga4_stream['ga4_last_synced']) ? $ga4_stream['ga4_last_synced'] : null,
        'date_range' => isset($ga4_stream['ga4_date_range']) ? $ga4_stream['ga4_date_range'] : null,
      );
      error_log('[Luna] ✅ Extracted GA4 metrics from data streams');
    }
    
    // Extract SSL/TLS data from streams
    foreach ($streams as $stream) {
      if (isset($stream['id']) && $stream['id'] === 'ssl_tls_status') {
        if (isset($stream['ssl_tls_data']) && is_array($stream['ssl_tls_data'])) {
          if (!isset($collections['security']) || !is_array($collections['security'])) {
            $collections['security'] = array();
          }
          $collections['security']['ssl_tls'] = $stream['ssl_tls_data'];
          error_log('[Luna] ✅ Extracted SSL/TLS data from data streams');
          break;
        }
      }
    }
  } else {
    error_log('[Luna] ❌ No data streams found from VL Hub Profile server');
  }
  
  // Try to fetch activity/connections data directly if VL Hub Profile is available
  if (class_exists('VL_Hub_Profile')) {
    try {
      $hub_profile = VL_Hub_Profile::get_instance();
      // Get all connections data
      if (method_exists($hub_profile, 'data_streams_store_get')) {
        $all_streams_store = $hub_profile->data_streams_store_get();
        if (is_array($all_streams_store) && isset($all_streams_store[$license])) {
          $license_streams = $all_streams_store[$license];
          if (is_array($license_streams) && !empty($license_streams)) {
            // Add to collections if not already present
            if (!isset($collections['data_streams']) || empty($collections['data_streams'])) {
              $collections['data_streams'] = $license_streams;
            } else {
              // Merge with existing streams
              $collections['data_streams'] = array_merge($collections['data_streams'], $license_streams);
            }
          }
        }
      }
    } catch (Exception $e) {
      error_log('[Luna] Error accessing VL Hub Profile directly: ' . $e->getMessage());
    }
  }

  $collections['_meta'] = array(
    'retrieved_at' => gmdate('c'),
    'license'      => $license,
    'categories'   => array_keys(array_diff_key($collections, array('_meta' => true))),
  );

  set_transient($key, $collections, LUNA_CACHE_PROFILE_TTL);

  return $collections;
}

/* Helpers to normalize Hub data and provide local fallbacks */
function luna_is_list_array($value) {
  if (!is_array($value)) return false;
  if ($value === array()) return true;
  return array_keys($value) === range(0, count($value) - 1);
}

function luna_extract_hub_items($payload, $key) {
  if (!is_array($payload)) return null;

  $sources = array();
  if (isset($payload[$key])) {
    $sources[] = $payload[$key];
  }

  $underscored = '_' . $key;
  if (isset($payload[$underscored])) {
    $sources[] = $payload[$underscored];
  }

  if (isset($payload['content']) && is_array($payload['content']) && isset($payload['content'][$key])) {
    $sources[] = $payload['content'][$key];
  }

  foreach ($sources as $source) {
    if (!is_array($source)) {
      continue;
    }

    if (isset($source['items']) && is_array($source['items'])) {
      return $source['items'];
    }

    if (luna_is_list_array($source)) {
      return $source;
    }
  }

  return null;
}

function luna_collect_local_post_type_snapshot($post_type, $limit = 25) {
  $post_type = sanitize_key($post_type);
  if (!$post_type) return array();

  $ids = get_posts(array(
    'post_type'       => $post_type,
    'post_status'     => array('publish','draft','pending','private'),
    'numberposts'     => $limit,
    'orderby'         => 'date',
    'order'           => 'DESC',
    'fields'          => 'ids',
    'suppress_filters'=> true,
  ));

  if (!is_array($ids)) return array();

  $items = array();
  foreach ($ids as $pid) {
    $items[] = array(
      'id'        => (int) $pid,
      'title'     => get_the_title($pid),
      'slug'      => get_post_field('post_name', $pid),
      'status'    => get_post_status($pid),
      'date'      => get_post_time('c', true, $pid),
      'permalink' => get_permalink($pid),
    );
  }

  return $items;
}

/* Build compact facts, prioritizing Hub over local snapshot; no network/probe overrides */
function luna_profile_facts() {
  $hub     = luna_hub_profile();
  $local   = luna_snapshot_system(); // fallback only
  $license = luna_get_license();

  $site_url = isset($hub['site']['url']) ? (string)$hub['site']['url'] : home_url('/');

  // TLS from Hub (authoritative)
  $tls        = isset($hub['security']['tls']) ? $hub['security']['tls'] : array();
  $tls_valid  = (bool) ( isset($tls['valid']) ? $tls['valid'] : ( isset($hub['security']['tls_valid']) ? $hub['security']['tls_valid'] : false ) );
  $tls_issuer = isset($tls['issuer']) ? (string)$tls['issuer'] : '';
  $tls_expires= isset($tls['expires_at']) ? (string)$tls['expires_at'] : ( isset($tls['not_after']) ? (string)$tls['not_after'] : '' );
  $tls_checked= isset($tls['checked_at']) ? (string)$tls['checked_at'] : '';

  // Host/Infra from Hub
  $host  = '';
  if (isset($hub['infra']['host'])) $host = (string)$hub['infra']['host'];
  elseif (isset($hub['hosting']['provider'])) $host = (string)$hub['hosting']['provider'];

  // WordPress version from Hub then local
  $wpv   = isset($hub['wordpress']['version']) ? (string)$hub['wordpress']['version'] : ( isset($local['wordpress']['version']) ? (string)$local['wordpress']['version'] : '' );
  // Theme: prefer Hub if provided as object with name; else local
  $theme = (isset($hub['wordpress']['theme']) && is_array($hub['wordpress']['theme']) && isset($hub['wordpress']['theme']['name']))
    ? (string)$hub['wordpress']['theme']['name']
    : ( isset($local['wordpress']['theme']['name']) ? (string)$local['wordpress']['theme']['name'] : '' );

  // Content counts (Hub first) + fallback to local snapshots
  $pages = 0; $posts = 0;
  if (isset($hub['content']['pages_total'])) $pages = (int)$hub['content']['pages_total'];
  elseif (isset($hub['content']['pages']))   $pages = (int)$hub['content']['pages'];
  if (isset($hub['content']['posts_total'])) $posts = (int)$hub['content']['posts_total'];
  elseif (isset($hub['content']['posts']))   $posts = (int)$hub['content']['posts'];

  $pages_items = luna_extract_hub_items($hub, 'pages');
  if (!is_array($pages_items)) {
    $pages_items = luna_collect_local_post_type_snapshot('page');
  }
  if ($pages === 0 && is_array($pages_items)) {
    $pages = count($pages_items);
  }

  $posts_items = luna_extract_hub_items($hub, 'posts');
  if (!is_array($posts_items)) {
    $posts_items = luna_collect_local_post_type_snapshot('post');
  }
  if ($posts === 0 && is_array($posts_items)) {
    $posts = count($posts_items);
  }

  // Users
  $users_total = isset($hub['users']['total']) ? (int)$hub['users']['total'] : 0;
  if ($users_total === 0 && isset($hub['users']) && is_array($hub['users'])) {
    $users_total = count($hub['users']);
  }
  if ($users_total === 0) {
    $user_counts = count_users();
    if (isset($user_counts['total_users'])) {
      $users_total = (int) $user_counts['total_users'];
    }
  }

  $users_items = luna_extract_hub_items($hub, 'users');
  if (!is_array($users_items)) {
    $users_items = array();
  }

  $plugins_items = array();
  if (isset($hub['plugins']) && is_array($hub['plugins'])) {
    $plugins_items = $hub['plugins'];
  } elseif (isset($local['plugins']) && is_array($local['plugins'])) {
    $plugins_items = $local['plugins'];
  }

  $themes_items = array();
  if (isset($hub['themes']) && is_array($hub['themes'])) {
    $themes_items = $hub['themes'];
  } elseif (isset($local['themes']) && is_array($local['themes'])) {
    $themes_items = $local['themes'];
  }

  // Updates (Hub first; fallback to derived counts)
  $plugin_updates = isset($hub['updates']['plugins_pending']) ? (int)$hub['updates']['plugins_pending'] : 0;
  $theme_updates  = isset($hub['updates']['themes_pending'])  ? (int)$hub['updates']['themes_pending']  : 0;
  if ($plugin_updates === 0 && !empty($plugins_items)) {
    $c = 0; foreach ($plugins_items as $p) { if (!empty($p['update_available'])) $c++; } $plugin_updates = $c;
  }
  if ($theme_updates === 0 && !empty($themes_items)) {
    $c = 0; foreach ($themes_items as $t) { if (!empty($t['update_available'])) $c++; } $theme_updates = $c;
  }
  $core_updates = 0;
  if (isset($hub['updates']['core_pending'])) {
    $core_updates = (int) $hub['updates']['core_pending'];
  } elseif (!empty($local['wordpress']['core_update_available'])) {
    $core_updates = $local['wordpress']['core_update_available'] ? 1 : 0;
  }

  $facts = array(
    'site_url'   => $site_url,
    'tls'        => array(
      'valid'    => (bool)$tls_valid,
      'issuer'   => $tls_issuer,
      'expires'  => $tls_expires,
      'checked'  => $tls_checked,
    ),
    'host'       => $host,
    'wp_version' => $wpv,
    'theme'      => $theme,
    'counts'     => array(
      'pages'   => $pages,
      'posts'   => $posts,
      'users'   => $users_total,
      'plugins' => is_array($plugins_items) ? count($plugins_items) : 0,
    ),
    'updates'    => array(
      'plugins' => $plugin_updates,
      'themes'  => $theme_updates,
      'core'    => $core_updates,
    ),
    'generated'  => gmdate('c'),
    'comprehensive' => false,
  );

  if ($license) {
    $ga4_info = luna_fetch_ga4_metrics_from_hub($license);
    if ($ga4_info && isset($ga4_info['metrics'])) {
      $facts['ga4_metrics'] = $ga4_info['metrics'];
      if (!empty($ga4_info['last_synced'])) {
        $facts['ga4_last_synced'] = $ga4_info['last_synced'];
      }
      if (!empty($ga4_info['date_range'])) {
        $facts['ga4_date_range'] = $ga4_info['date_range'];
      }
      if (!empty($ga4_info['source_url'])) {
        $facts['ga4_source_url'] = $ga4_info['source_url'];
      }
      if (!empty($ga4_info['property_id'])) {
        $facts['ga4_property_id'] = $ga4_info['property_id'];
      }
      if (!empty($ga4_info['measurement_id'])) {
        $facts['ga4_measurement_id'] = $ga4_info['measurement_id'];
      }
    }
  }

  $facts['__source'] = 'basic';

  return $facts;
}

/* Enhanced facts with comprehensive Hub data */
function luna_get_active_theme_status($comprehensive) {
  // First try to get from themes array (more accurate)
  if (isset($comprehensive['themes']) && is_array($comprehensive['themes'])) {
    foreach ($comprehensive['themes'] as $theme) {
      if (isset($theme['is_active']) && $theme['is_active']) {
        return true;
      }
    }
  }
  
  // Fallback to basic theme info
  return isset($comprehensive['wordpress']['theme']['is_active']) ? (bool)$comprehensive['wordpress']['theme']['is_active'] : true;
}

/**
 * Comprehensive facts function that pulls ALL VL Hub data for Luna Chat Widget.
 * 
 * This function fetches the complete client profile from VL Hub which includes:
 * - WordPress Core Data (version, PHP, MySQL, memory, multisite status)
 * - Content Data (pages, posts with full details)
 * - Users Data (all users with details)
 * - Plugins & Themes (full lists with status and versions)
 * - Security Data (TLS, WAF, IDS, authentication, domain info)
 * - AWS S3 Cloud Storage (buckets, objects, settings, storage usage)
 * - Liquid Web Hosting (assets, account info, connection status)
 * - GA4 Analytics (all metrics, property ID, measurement ID, date ranges)
 * - All Data Streams (complete data stream details including categories, health scores, status)
 * - Competitor Analysis (full reports with Lighthouse scores, keywords, meta descriptions, timestamps)
 * - VLDR Metrics (domain ranking scores for all tracked domains - client and competitors)
 * - Performance Metrics (Lighthouse scores from PageSpeed Insights)
 * - SEO Data (Search Console data - clicks, impressions, CTR, top queries)
 * - Data Streams Summary (counts, categories, recent streams)
 * 
 * All this data is made available to Luna AI for intelligent, context-aware responses.
 */
function luna_profile_facts_comprehensive() {
  try {
  $license = luna_get_license();
  if (!$license) {
    error_log('[Luna] No license key found, falling back to basic facts');
    $fallback = luna_profile_facts(); // fallback to basic facts
    $fallback['__source'] = 'fallback-basic';
    return $fallback;
  }
  
    // CRITICAL: Force refresh to ensure we get latest data from VL Hub Profile server
    // This ensures we're fetching the full Raw JSON from visiblelight.ai, not local WordPress data
    error_log('[Luna Widget] 🔄 Fetching comprehensive Hub Profile data from VL Hub Profile server (visiblelight.ai)');
    $hub_url = luna_widget_hub_base();
    error_log('[Luna Widget] 🔄 Hub URL: ' . $hub_url . ' | License: ' . $license);
    
    $hub_collections = luna_hub_collect_collections(false);
    if (empty($hub_collections) || !is_array($hub_collections)) {
      error_log('[Luna] ❌ Hub collections were empty or invalid, falling back to basic facts');
    $fallback = luna_profile_facts();
    $fallback['__source'] = 'fallback-basic';
      return $fallback;
    }
    
    // Log what collections we received
    $collection_keys = array_keys($hub_collections);
    error_log('[Luna Widget] ✅ Received hub collections: ' . implode(', ', $collection_keys));

  $comprehensive = array();
  if (isset($hub_collections['profile']) && is_array($hub_collections['profile'])) {
    error_log('[Luna Widget] ✅ Processing profile data from hub_collections');
    $comprehensive = luna_hub_normalize_payload($hub_collections['profile']);
  }
  
  // Normalize the payload if it's still not an array
  if (!is_array($comprehensive) && isset($hub_collections['profile'])) {
    error_log('[Luna Widget] ⚠️ Profile not array after first normalization, trying again');
    $comprehensive = luna_hub_normalize_payload($hub_collections['profile']);
  }
  
  // CRITICAL: Merge data_streams from hub_collections into comprehensive
  // The data-streams endpoint contains ALL client data (GA4, SSL/TLS, Cloudflare, etc.)
  if (isset($hub_collections['data_streams']) && is_array($hub_collections['data_streams']) && !empty($hub_collections['data_streams'])) {
    $comprehensive['data_streams'] = $hub_collections['data_streams'];
    error_log('[Luna Widget] ✅ Merged ' . count($hub_collections['data_streams']) . ' data streams into comprehensive profile');
    
    // Also extract and merge GA4 data directly from streams into comprehensive
    foreach ($hub_collections['data_streams'] as $stream) {
      if (isset($stream['ga4_metrics']) && is_array($stream['ga4_metrics']) && !empty($stream['ga4_metrics'])) {
        if (!isset($comprehensive['ga4_metrics']) || empty($comprehensive['ga4_metrics'])) {
          $comprehensive['ga4_metrics'] = $stream['ga4_metrics'];
          if (isset($stream['ga4_dimensions'])) {
            $comprehensive['ga4_dimensions'] = $stream['ga4_dimensions'];
          }
          if (isset($stream['ga4_property_id'])) {
            $comprehensive['ga4_property_id'] = $stream['ga4_property_id'];
          }
          if (isset($stream['ga4_last_synced'])) {
            $comprehensive['ga4_last_synced'] = $stream['ga4_last_synced'];
          }
          error_log('[Luna Widget] ✅ Merged GA4 data from data_streams into comprehensive profile');
          break;
        }
      }
      
      // Extract SSL/TLS data from streams
      if (isset($stream['id']) && $stream['id'] === 'ssl_tls_status') {
        if (isset($stream['ssl_tls_data']) && is_array($stream['ssl_tls_data']) && !empty($stream['ssl_tls_data'])) {
          $comprehensive['ssl_tls'] = $stream['ssl_tls_data'];
          error_log('[Luna Widget] ✅ Merged SSL/TLS data from data_streams into comprehensive profile');
        }
      }
    }
  }

  if (!is_array($comprehensive)) {
    error_log('[Luna] ❌ Could not locate a normalized Hub profile payload, falling back to basic facts');
    $fallback = luna_profile_facts();
    $fallback['__source'] = 'fallback-basic';
    return $fallback;
  }

  // Log available data keys in comprehensive profile for debugging
  $profile_keys = array_keys($comprehensive);
  error_log('[Luna Widget] ✅ Comprehensive profile keys (' . count($profile_keys) . '): ' . implode(', ', $profile_keys));
  error_log('[Luna Widget] ✅ Comprehensive profile has aws_s3: ' . (isset($comprehensive['aws_s3']) ? 'YES' : 'NO'));
  error_log('[Luna Widget] ✅ Comprehensive profile has liquidweb: ' . (isset($comprehensive['liquidweb']) ? 'YES' : 'NO'));
  error_log('[Luna Widget] ✅ Comprehensive profile has ga4_metrics: ' . (isset($comprehensive['ga4_metrics']) ? 'YES' : 'NO'));
  error_log('[Luna Widget] ✅ Comprehensive profile has data_streams: ' . (isset($comprehensive['data_streams']) ? 'YES (' . count($comprehensive['data_streams']) . ')' : 'NO'));
  error_log('[Luna Widget] ✅ Comprehensive profile has competitor_reports_full: ' . (isset($comprehensive['competitor_reports_full']) ? 'YES (' . count($comprehensive['competitor_reports_full']) . ')' : 'NO'));
  error_log('[Luna Widget] ✅ Comprehensive profile has vldr_metrics: ' . (isset($comprehensive['vldr_metrics']) ? 'YES (' . count($comprehensive['vldr_metrics']) . ')' : 'NO'));
  error_log('[Luna Widget] ✅ Comprehensive profile has ssl_tls: ' . (isset($comprehensive['ssl_tls']) ? 'YES' : 'NO'));
  error_log('[Luna Widget] ✅ Comprehensive profile has cloudflare: ' . (isset($comprehensive['cloudflare']) ? 'YES' : 'NO'));

  // Keep the original hub_collections for reference
  // Don't call luna_hub_collect_collections again - we already have the data we need
  
  // Build enhanced facts from comprehensive data with local fallbacks
  $local_snapshot = luna_snapshot_system();

  // Support multiple possible keys for site URL (from profile endpoint structure)
  $site_url = '';
  if (isset($comprehensive['home_url'])) {
    $site_url = (string) $comprehensive['home_url'];
  } elseif (isset($comprehensive['site_info']['site']) && !empty($comprehensive['site_info']['site'])) {
    $site_url = (string) $comprehensive['site_info']['site'];
  } elseif (isset($comprehensive['site']['url'])) {
    $site_url = (string) $comprehensive['site']['url'];
  } elseif (isset($local_snapshot['site']['home_url'])) {
    $site_url = (string) $local_snapshot['site']['home_url'];
  } else {
    $site_url = home_url('/');
  }
  $https    = isset($comprehensive['https']) ? (bool) $comprehensive['https'] : (isset($local_snapshot['site']['https']) ? (bool) $local_snapshot['site']['https'] : is_ssl());
  $wp_version = isset($comprehensive['wordpress']['version']) ? (string) $comprehensive['wordpress']['version'] : (isset($local_snapshot['wordpress']['version']) ? (string) $local_snapshot['wordpress']['version'] : '');

  $theme_data = array();
  if (isset($comprehensive['wordpress']['theme']) && is_array($comprehensive['wordpress']['theme'])) {
    $theme_data = $comprehensive['wordpress']['theme'];
  } elseif (isset($local_snapshot['wordpress']['theme']) && is_array($local_snapshot['wordpress']['theme'])) {
    $theme_data = $local_snapshot['wordpress']['theme'];
  }
  $theme_name    = isset($theme_data['name']) ? (string) $theme_data['name'] : '';
  $theme_version = isset($theme_data['version']) ? (string) $theme_data['version'] : '';
  $theme_active  = isset($theme_data['is_active']) ? (bool) $theme_data['is_active'] : luna_get_active_theme_status($comprehensive);

  // SSL/TLS data from VL Hub - check multiple possible locations
  // First check category-specific endpoints (security endpoint)
  $tls_data = array();
  if (!empty($hub_collections['security']) && is_array($hub_collections['security'])) {
    $security_data = luna_hub_normalize_payload($hub_collections['security']);
    if (isset($security_data['data']['ssl_tls']) && is_array($security_data['data']['ssl_tls'])) {
      $tls_data = $security_data['data']['ssl_tls'];
    } elseif (isset($security_data['ssl_tls']) && is_array($security_data['ssl_tls'])) {
      $tls_data = $security_data['ssl_tls'];
    }
  }
  
  // Fallback to comprehensive profile data
  if (empty($tls_data)) {
    if (isset($comprehensive['ssl_tls']) && is_array($comprehensive['ssl_tls'])) {
      $tls_data = $comprehensive['ssl_tls'];
    } elseif (isset($comprehensive['security']['tls']) && is_array($comprehensive['security']['tls'])) {
      $tls_data = $comprehensive['security']['tls'];
    } elseif (isset($comprehensive['tls']) && is_array($comprehensive['tls'])) {
      $tls_data = $comprehensive['tls'];
    }
  }
  $tls_valid   = isset($tls_data['connected']) ? (bool) $tls_data['connected'] : (isset($tls_data['valid']) ? (bool) $tls_data['valid'] : false);
  $tls_certificate = isset($tls_data['certificate']) ? (string) $tls_data['certificate'] : '';
  $tls_issuer  = isset($tls_data['issuer']) ? (string) $tls_data['issuer'] : '';
  $tls_expires = '';
  if (isset($tls_data['expires'])) {
    $tls_expires = (string) $tls_data['expires'];
  } elseif (isset($tls_data['expires_at'])) {
    $tls_expires = (string) $tls_data['expires_at'];
  } elseif (isset($tls_data['not_after'])) {
    $tls_expires = (string) $tls_data['not_after'];
  }
  $tls_days_until_expiry = isset($tls_data['days_until_expiry']) ? (int) $tls_data['days_until_expiry'] : null;
  $tls_status = isset($tls_data['status']) ? (string) $tls_data['status'] : '';
  $tls_checked = isset($tls_data['last_checked']) ? (string) $tls_data['last_checked'] : (isset($tls_data['checked_at']) ? (string) $tls_data['checked_at'] : '');

  $host = isset($comprehensive['host']) ? (string) $comprehensive['host'] : '';
  if ($host === '' && isset($comprehensive['hosting']['provider'])) {
    $host = (string) $comprehensive['hosting']['provider'];
  }

  $plugins_items = luna_extract_hub_items($comprehensive, 'plugins');
  if (!is_array($plugins_items)) {
    $plugins_items = isset($local_snapshot['plugins']) ? $local_snapshot['plugins'] : array();
  }

  $themes_items = luna_extract_hub_items($comprehensive, 'themes');
  if (!is_array($themes_items)) {
    $themes_items = isset($local_snapshot['themes']) ? $local_snapshot['themes'] : array();
  }

  $pages_items = luna_extract_hub_items($comprehensive, 'pages');
  if (!is_array($pages_items) && isset($comprehensive['content']['pages']) && is_array($comprehensive['content']['pages'])) {
    $pages_items = $comprehensive['content']['pages'];
  }
  if (!is_array($pages_items)) {
    $pages_items = luna_collect_local_post_type_snapshot('page');
  }

  $posts_items = luna_extract_hub_items($comprehensive, 'posts');
  if (!is_array($posts_items) && isset($comprehensive['content']['posts']) && is_array($comprehensive['content']['posts'])) {
    $posts_items = $comprehensive['content']['posts'];
  }
  if (!is_array($posts_items)) {
    $posts_items = luna_collect_local_post_type_snapshot('post');
  }

  $users_items = luna_extract_hub_items($comprehensive, 'users');
  if (!is_array($users_items) && isset($comprehensive['users']) && is_array($comprehensive['users'])) {
    $users_items = $comprehensive['users'];
  }
  if (!is_array($users_items)) {
    $users_items = array();
  }

  $pages_count = is_array($pages_items) ? count($pages_items) : 0;
  if ($pages_count === 0 && isset($comprehensive['counts']['pages'])) {
    $pages_count = (int) $comprehensive['counts']['pages'];
  } elseif ($pages_count === 0 && isset($comprehensive['content']['pages_total'])) {
    $pages_count = (int) $comprehensive['content']['pages_total'];
  }

  $posts_count = is_array($posts_items) ? count($posts_items) : 0;
  if ($posts_count === 0 && isset($comprehensive['counts']['posts'])) {
    $posts_count = (int) $comprehensive['counts']['posts'];
  } elseif ($posts_count === 0 && isset($comprehensive['content']['posts_total'])) {
    $posts_count = (int) $comprehensive['content']['posts_total'];
  }

  $users_count = is_array($users_items) ? count($users_items) : 0;
  if ($users_count === 0 && isset($comprehensive['users_total'])) {
    $users_count = (int) $comprehensive['users_total'];
  } elseif ($users_count === 0 && isset($comprehensive['users']) && is_array($comprehensive['users'])) {
    $users_count = count($comprehensive['users']);
  }

  $plugins_count = is_array($plugins_items) ? count($plugins_items) : 0;

  $plugin_updates = 0;
  if (is_array($plugins_items)) {
    foreach ($plugins_items as $plugin) {
      if (!empty($plugin['update_available'])) {
        $plugin_updates++;
      }
    }
  }

  $theme_updates = 0;
  if (is_array($themes_items)) {
    foreach ($themes_items as $theme_row) {
      if (!empty($theme_row['update_available'])) {
        $theme_updates++;
      }
    }
  }

  $core_updates = 0;
  if (isset($comprehensive['wordpress']['core_update_available'])) {
    $core_updates = $comprehensive['wordpress']['core_update_available'] ? 1 : 0;
  } elseif (!empty($local_snapshot['wordpress']['core_update_available'])) {
    $core_updates = $local_snapshot['wordpress']['core_update_available'] ? 1 : 0;
  }

  // Extract and merge category-specific data from hub_collections BEFORE building facts array
  // This ensures all VL Hub data is available in the facts array
  if (!empty($hub_collections)) {
    // Security endpoint data (SSL/TLS, Cloudflare)
    if (isset($hub_collections['security']) && is_array($hub_collections['security'])) {
      $security_data = luna_hub_normalize_payload($hub_collections['security']);
      if (isset($security_data['data']) && is_array($security_data['data'])) {
        $security_category_data = $security_data['data'];
        
        // Merge SSL/TLS data - update tls_data if it's empty or if security endpoint has more complete data
        if (isset($security_category_data['ssl_tls']) && is_array($security_category_data['ssl_tls'])) {
          if (empty($tls_data) || (isset($security_category_data['ssl_tls']['connected']) && $security_category_data['ssl_tls']['connected'])) {
            $tls_data = $security_category_data['ssl_tls'];
            // Update tls_* variables from merged data
            $tls_valid = isset($tls_data['connected']) ? (bool)$tls_data['connected'] : false;
            $tls_certificate = isset($tls_data['certificate']) ? (string)$tls_data['certificate'] : '';
            $tls_issuer = isset($tls_data['issuer']) ? (string)$tls_data['issuer'] : '';
            $tls_expires = isset($tls_data['expires']) ? (string)$tls_data['expires'] : '';
            $tls_days_until_expiry = isset($tls_data['days_until_expiry']) ? (int)$tls_data['days_until_expiry'] : null;
            $tls_status = isset($tls_data['status']) ? (string)$tls_data['status'] : '';
            $tls_checked = isset($tls_data['last_checked']) ? (string)$tls_data['last_checked'] : '';
          }
        }
      } elseif (isset($security_data['ssl_tls']) && is_array($security_data['ssl_tls'])) {
        if (empty($tls_data) || (isset($security_data['ssl_tls']['connected']) && $security_data['ssl_tls']['connected'])) {
          $tls_data = $security_data['ssl_tls'];
          $tls_valid = isset($tls_data['connected']) ? (bool)$tls_data['connected'] : false;
          $tls_certificate = isset($tls_data['certificate']) ? (string)$tls_data['certificate'] : '';
          $tls_issuer = isset($tls_data['issuer']) ? (string)$tls_data['issuer'] : '';
          $tls_expires = isset($tls_data['expires']) ? (string)$tls_data['expires'] : '';
          $tls_days_until_expiry = isset($tls_data['days_until_expiry']) ? (int)$tls_data['days_until_expiry'] : null;
          $tls_status = isset($security_data['ssl_tls']['status']) ? (string)$security_data['ssl_tls']['status'] : '';
          $tls_checked = isset($security_data['ssl_tls']['last_checked']) ? (string)$security_data['ssl_tls']['last_checked'] : '';
        }
      }
    }
  }

  $facts = array(
    'site_url'   => $site_url,
    'https'      => $https,
    'wp_version' => $wp_version,
    'theme'      => $theme_name,
    'theme_version' => $theme_version,
    'theme_active'  => $theme_active,
    'tls'        => array(
      'valid'   => $tls_valid,
      'connected' => $tls_valid,
      'certificate' => $tls_certificate,
      'issuer'  => $tls_issuer,
      'expires' => $tls_expires,
      'days_until_expiry' => $tls_days_until_expiry,
      'status' => $tls_status,
      'checked' => $tls_checked,
    ),
    'ssl_tls' => $tls_data, // Include full SSL/TLS data for comprehensive access
    'host'       => $host,
    'counts'     => array(
      'pages'   => $pages_count,
      'posts'   => $posts_count,
      'users'   => $users_count,
      'plugins' => $plugins_count,
    ),
    'updates'    => array(
      'plugins' => $plugin_updates,
      'themes'  => $theme_updates,
      'core'    => $core_updates,
    ),
    'generated'  => gmdate('c'),
    'comprehensive' => true, // Flag to indicate this is comprehensive data
    'plugins' => isset($comprehensive['plugins']) ? $comprehensive['plugins'] : array(),
    'users' => isset($comprehensive['users']) ? $comprehensive['users'] : array(),
    'themes' => isset($comprehensive['themes']) ? $comprehensive['themes'] : array(),
    'posts' => is_array($posts_items) ? $posts_items : (isset($comprehensive['_posts']['items']) ? $comprehensive['_posts']['items'] : (isset($comprehensive['content']['posts']) ? $comprehensive['content']['posts'] : array())),
    'pages' => is_array($pages_items) ? $pages_items : (isset($comprehensive['_pages']['items']) ? $comprehensive['_pages']['items'] : (isset($comprehensive['content']['pages']) ? $comprehensive['content']['pages'] : array())),
    'security' => isset($comprehensive['security']) ? $comprehensive['security'] : array(), // Add security data
  );
  
  $ga4_info = null;
  if (isset($comprehensive['ga4_metrics']) && is_array($comprehensive['ga4_metrics'])) {
    $ga4_info = array(
      'metrics'        => $comprehensive['ga4_metrics'],
      'last_synced'    => isset($comprehensive['ga4_last_synced']) ? $comprehensive['ga4_last_synced'] : (isset($comprehensive['last_synced']) ? $comprehensive['last_synced'] : null),
      'date_range'     => isset($comprehensive['ga4_date_range']) ? $comprehensive['ga4_date_range'] : null,
      'source_url'     => isset($comprehensive['ga4_source_url']) ? $comprehensive['ga4_source_url'] : (isset($comprehensive['source_url']) ? $comprehensive['source_url'] : null),
      'property_id'    => isset($comprehensive['ga4_property_id']) ? $comprehensive['ga4_property_id'] : null,
      'measurement_id' => isset($comprehensive['ga4_measurement_id']) ? $comprehensive['ga4_measurement_id'] : null,
    );
    
    // Extract GA4 dimensional data from comprehensive profile if available
    // Check for nested structure first
    if (isset($comprehensive['ga4_dimensions']) && is_array($comprehensive['ga4_dimensions']) && !empty($comprehensive['ga4_dimensions'])) {
      $ga4_info['dimensions'] = $comprehensive['ga4_dimensions'];
      error_log('[Luna] GA4 dimensions present in comprehensive payload (nested structure).');
    }
    // Also check for legacy flat arrays
    elseif (isset($comprehensive['ga4_geographic']) || isset($comprehensive['ga4_device']) || isset($comprehensive['ga4_traffic']) || isset($comprehensive['ga4_pages']) || isset($comprehensive['ga4_events'])) {
      $ga4_info['dimensions'] = array();
      if (isset($comprehensive['ga4_geographic']) && is_array($comprehensive['ga4_geographic'])) {
        $ga4_info['dimensions']['geographic'] = array('rows' => $comprehensive['ga4_geographic']);
      }
      if (isset($comprehensive['ga4_device']) && is_array($comprehensive['ga4_device'])) {
        $ga4_info['dimensions']['device'] = array('rows' => $comprehensive['ga4_device']);
      }
      if (isset($comprehensive['ga4_traffic']) && is_array($comprehensive['ga4_traffic'])) {
        $ga4_info['dimensions']['traffic'] = array('rows' => $comprehensive['ga4_traffic']);
      }
      if (isset($comprehensive['ga4_pages']) && is_array($comprehensive['ga4_pages'])) {
        $ga4_info['dimensions']['pages'] = array('rows' => $comprehensive['ga4_pages']);
      }
      if (isset($comprehensive['ga4_events']) && is_array($comprehensive['ga4_events'])) {
        $ga4_info['dimensions']['events'] = array('rows' => $comprehensive['ga4_events']);
      }
      if (isset($comprehensive['ga4_page_location']) && is_array($comprehensive['ga4_page_location'])) {
        $ga4_info['dimensions']['page_location'] = array('rows' => $comprehensive['ga4_page_location']);
      }
      error_log('[Luna] GA4 dimensions built from legacy flat arrays in comprehensive payload.');
    }
    
    error_log('[Luna] GA4 metrics present in comprehensive payload.');
  } else {
    error_log('[Luna] No GA4 metrics in comprehensive payload, attempting data streams fetch.');
    $ga4_info = luna_fetch_ga4_metrics_from_hub($license);
  }

  if ($ga4_info && isset($ga4_info['metrics'])) {
    $facts['ga4_metrics'] = $ga4_info['metrics'];
    if (!empty($ga4_info['last_synced'])) {
      $facts['ga4_last_synced'] = $ga4_info['last_synced'];
    }
    if (!empty($ga4_info['date_range'])) {
      $facts['ga4_date_range'] = $ga4_info['date_range'];
    }
    if (!empty($ga4_info['source_url'])) {
      $facts['ga4_source_url'] = $ga4_info['source_url'];
    }
    if (!empty($ga4_info['property_id'])) {
      $facts['ga4_property_id'] = $ga4_info['property_id'];
    }
    if (!empty($ga4_info['measurement_id'])) {
      $facts['ga4_measurement_id'] = $ga4_info['measurement_id'];
    }
    // Extract GA4 dimensional data if available
    if (isset($ga4_info['dimensions']) && is_array($ga4_info['dimensions']) && !empty($ga4_info['dimensions'])) {
      $facts['ga4_dimensions'] = $ga4_info['dimensions'];
    }
    error_log('[Luna] GA4 metrics hydrated: ' . print_r($facts['ga4_metrics'], true));
  } else {
    error_log('[Luna] Unable to hydrate GA4 metrics from Hub.');
  }

  if (!empty($hub_collections)) {
    $facts['hub_collections'] = $hub_collections;

    $collection_map = array(
      'profile'      => 'hub_profile',
      'connections'  => 'hub_connections',
      'cloudops'     => 'hub_cloudops',
      'content'      => 'hub_content',
      'search'       => 'hub_search',
      'analytics'    => 'hub_analytics',
      'marketing'    => 'hub_marketing',
      'ecommerce'    => 'hub_ecommerce',
      'security'     => 'hub_security',
      'web_infra'    => 'hub_web_infra',
      'identity'     => 'hub_identity',
      'competitive'  => 'hub_competitive',
      'data_streams' => 'hub_data_streams',
      'users'        => 'hub_users',
      'plugins'      => 'hub_plugins',
      'themes'       => 'hub_themes',
      'updates'      => 'hub_updates',
    );

    foreach ($collection_map as $source_key => $dest_key) {
      if (isset($hub_collections[$source_key])) {
        $facts[$dest_key] = $hub_collections[$source_key];
      }
    }

    $facts['hub_sources_loaded'] = isset($hub_collections['_meta']['categories'])
      ? $hub_collections['_meta']['categories']
      : array_keys(array_diff_key($hub_collections, array('_meta' => true)));
    
    // Extract and merge category-specific data into main facts array
    // Security endpoint data (SSL/TLS, Cloudflare)
    if (isset($hub_collections['security']) && is_array($hub_collections['security'])) {
      $security_data = luna_hub_normalize_payload($hub_collections['security']);
      if (isset($security_data['data']) && is_array($security_data['data'])) {
        $security_category_data = $security_data['data'];
        
        // Merge SSL/TLS data
        if (isset($security_category_data['ssl_tls']) && is_array($security_category_data['ssl_tls'])) {
          $facts['ssl_tls'] = $security_category_data['ssl_tls'];
          // Also update tls_data if it's empty
          if (empty($tls_data)) {
            $tls_data = $security_category_data['ssl_tls'];
          }
        }
        
        // Merge Cloudflare data
        if (isset($security_category_data['cloudflare']) && is_array($security_category_data['cloudflare'])) {
          $facts['cloudflare'] = $security_category_data['cloudflare'];
        }
      } elseif (isset($security_data['ssl_tls']) && is_array($security_data['ssl_tls'])) {
        $facts['ssl_tls'] = $security_data['ssl_tls'];
        if (empty($tls_data)) {
          $tls_data = $security_data['ssl_tls'];
        }
      } elseif (isset($security_data['cloudflare']) && is_array($security_data['cloudflare'])) {
        $facts['cloudflare'] = $security_data['cloudflare'];
      }
    }
    
    // CloudOps endpoint data (AWS S3, Liquid Web)
    if (isset($hub_collections['cloudops']) && is_array($hub_collections['cloudops'])) {
      $cloudops_data = luna_hub_normalize_payload($hub_collections['cloudops']);
      if (isset($cloudops_data['data']) && is_array($cloudops_data['data'])) {
        $cloudops_category_data = $cloudops_data['data'];
        
        // Merge AWS S3 data
        if (isset($cloudops_category_data['aws_s3']) && is_array($cloudops_category_data['aws_s3'])) {
          $facts['aws_s3'] = $cloudops_category_data['aws_s3'];
        }
        
        // Merge Liquid Web data
        if (isset($cloudops_category_data['liquidweb']) && is_array($cloudops_category_data['liquidweb'])) {
          $facts['liquidweb'] = $cloudops_category_data['liquidweb'];
        }
      } elseif (isset($cloudops_data['aws_s3']) && is_array($cloudops_data['aws_s3'])) {
        $facts['aws_s3'] = $cloudops_data['aws_s3'];
      } elseif (isset($cloudops_data['liquidweb']) && is_array($cloudops_data['liquidweb'])) {
        $facts['liquidweb'] = $cloudops_data['liquidweb'];
      }
    }
    
    // Analytics endpoint data (GA4)
    if (isset($hub_collections['analytics']) && is_array($hub_collections['analytics'])) {
      $analytics_data = luna_hub_normalize_payload($hub_collections['analytics']);
      if (isset($analytics_data['data']) && is_array($analytics_data['data'])) {
        $analytics_category_data = $analytics_data['data'];
        if (isset($analytics_category_data['ga4']) && is_array($analytics_category_data['ga4'])) {
          $facts['ga4'] = $analytics_category_data['ga4'];
        }
      } elseif (isset($analytics_data['ga4']) && is_array($analytics_data['ga4'])) {
        $facts['ga4'] = $analytics_data['ga4'];
      }
    }
    
    // CRITICAL: Extract GA4 data from data_streams collection (primary source)
    // The data-streams endpoint returns client_streams with GA4 data including metrics and dimensions
    if (isset($hub_collections['data_streams']) && is_array($hub_collections['data_streams'])) {
      error_log('[Luna] 🔄 Extracting GA4 data from data_streams collection (' . count($hub_collections['data_streams']) . ' streams)');
      foreach ($hub_collections['data_streams'] as $stream) {
        if (!is_array($stream)) continue;
        
        // Look for GA4 stream (has ga4_metrics)
        if (isset($stream['ga4_metrics']) && is_array($stream['ga4_metrics']) && !empty($stream['ga4_metrics'])) {
          error_log('[Luna] ✅ Found GA4 stream in data_streams: ' . (isset($stream['name']) ? $stream['name'] : 'unnamed'));
          
          // Extract GA4 metrics
          if (!isset($facts['ga4_metrics']) || empty($facts['ga4_metrics'])) {
            $facts['ga4_metrics'] = $stream['ga4_metrics'];
            error_log('[Luna] ✅ Extracted GA4 metrics from data_streams');
          }
          
          // Extract GA4 metadata
          if (isset($stream['ga4_property_id'])) {
            $facts['ga4_property_id'] = $stream['ga4_property_id'];
          }
          if (isset($stream['ga4_last_synced'])) {
            $facts['ga4_last_synced'] = $stream['ga4_last_synced'];
          } elseif (isset($stream['last_updated'])) {
            $facts['ga4_last_synced'] = $stream['last_updated'];
          }
          if (isset($stream['ga4_date_range']) && is_array($stream['ga4_date_range'])) {
            $facts['ga4_date_range'] = $stream['ga4_date_range'];
          }
          if (isset($stream['source_url'])) {
            $facts['ga4_source_url'] = $stream['source_url'];
          }
          if (isset($stream['ga4_measurement_id'])) {
            $facts['ga4_measurement_id'] = $stream['ga4_measurement_id'];
          }
          
          // Extract GA4 dimensional data (geographic, device, traffic, pages, events, page_location)
          // Check for nested structure (ga4_dimensions.geographic.rows) first
          if (isset($stream['ga4_dimensions']) && is_array($stream['ga4_dimensions']) && !empty($stream['ga4_dimensions'])) {
            $facts['ga4_dimensions'] = $stream['ga4_dimensions'];
            $dimension_types = array_keys($stream['ga4_dimensions']);
            error_log('[Luna] ✅ GA4 dimensions extracted from data_streams: ' . implode(', ', $dimension_types));
          }
          // Also check for legacy flat arrays (ga4_geographic, ga4_device, etc.)
          elseif (isset($stream['ga4_geographic']) || isset($stream['ga4_device']) || isset($stream['ga4_traffic']) || isset($stream['ga4_pages']) || isset($stream['ga4_events'])) {
            // Build dimensions structure from flat arrays
            $facts['ga4_dimensions'] = array();
            if (isset($stream['ga4_geographic']) && is_array($stream['ga4_geographic'])) {
              $facts['ga4_dimensions']['geographic'] = array('rows' => $stream['ga4_geographic']);
            }
            if (isset($stream['ga4_device']) && is_array($stream['ga4_device'])) {
              $facts['ga4_dimensions']['device'] = array('rows' => $stream['ga4_device']);
            }
            if (isset($stream['ga4_traffic']) && is_array($stream['ga4_traffic'])) {
              $facts['ga4_dimensions']['traffic'] = array('rows' => $stream['ga4_traffic']);
            }
            if (isset($stream['ga4_pages']) && is_array($stream['ga4_pages'])) {
              $facts['ga4_dimensions']['pages'] = array('rows' => $stream['ga4_pages']);
            }
            if (isset($stream['ga4_events']) && is_array($stream['ga4_events'])) {
              $facts['ga4_dimensions']['events'] = array('rows' => $stream['ga4_events']);
            }
            if (isset($stream['ga4_page_location']) && is_array($stream['ga4_page_location'])) {
              $facts['ga4_dimensions']['page_location'] = array('rows' => $stream['ga4_page_location']);
            }
            error_log('[Luna] ✅ GA4 dimensions built from legacy flat arrays: ' . count($facts['ga4_dimensions']) . ' dimension types');
          }
          
          break; // Use first GA4 stream found
        }
      }
    }
    
    // Extract GA4 data from all-connections endpoint (streams format) - fallback
    // The all-connections endpoint returns GA4 as a stream with ga4_metrics
    if ((!isset($facts['ga4_metrics']) || empty($facts['ga4_metrics'])) && isset($hub_collections['connections']) && is_array($hub_collections['connections'])) {
      $connections_data = luna_hub_normalize_payload($hub_collections['connections']);
      
      // Check for streams array in connections data
      if (isset($connections_data['streams']) && is_array($connections_data['streams'])) {
        foreach ($connections_data['streams'] as $stream_id => $stream) {
          if (is_array($stream) && !empty($stream['ga4_metrics']) && is_array($stream['ga4_metrics'])) {
            // Found GA4 stream - extract metrics
            if (!isset($facts['ga4_metrics']) || empty($facts['ga4_metrics'])) {
              $facts['ga4_metrics'] = $stream['ga4_metrics'];
              if (isset($stream['ga4_property_id'])) {
                $facts['ga4_property_id'] = $stream['ga4_property_id'];
              }
              if (isset($stream['ga4_last_synced'])) {
                $facts['ga4_last_synced'] = $stream['ga4_last_synced'];
              } elseif (isset($stream['last_updated'])) {
                $facts['ga4_last_synced'] = $stream['last_updated'];
              }
              if (isset($stream['ga4_date_range']) && is_array($stream['ga4_date_range'])) {
                $facts['ga4_date_range'] = $stream['ga4_date_range'];
              }
              if (isset($stream['source_url'])) {
                $facts['ga4_source_url'] = $stream['source_url'];
              }
              if (isset($stream['ga4_measurement_id'])) {
                $facts['ga4_measurement_id'] = $stream['ga4_measurement_id'];
              }
              
              // Extract GA4 dimensional data (geographic, device, traffic, pages, events, page_location)
              // Check for nested structure (ga4_dimensions.geographic.rows) first
              if (isset($stream['ga4_dimensions']) && is_array($stream['ga4_dimensions']) && !empty($stream['ga4_dimensions'])) {
                $facts['ga4_dimensions'] = $stream['ga4_dimensions'];
                error_log('[Luna] GA4 dimensions extracted from all-connections stream: ' . count($stream['ga4_dimensions']) . ' dimension types');
              }
              // Also check for legacy flat arrays (ga4_geographic, ga4_device, etc.)
              elseif (isset($stream['ga4_geographic']) || isset($stream['ga4_device']) || isset($stream['ga4_traffic']) || isset($stream['ga4_pages']) || isset($stream['ga4_events'])) {
                // Build dimensions structure from flat arrays
                $facts['ga4_dimensions'] = array();
                if (isset($stream['ga4_geographic']) && is_array($stream['ga4_geographic'])) {
                  $facts['ga4_dimensions']['geographic'] = array('rows' => $stream['ga4_geographic']);
                }
                if (isset($stream['ga4_device']) && is_array($stream['ga4_device'])) {
                  $facts['ga4_dimensions']['device'] = array('rows' => $stream['ga4_device']);
                }
                if (isset($stream['ga4_traffic']) && is_array($stream['ga4_traffic'])) {
                  $facts['ga4_dimensions']['traffic'] = array('rows' => $stream['ga4_traffic']);
                }
                if (isset($stream['ga4_pages']) && is_array($stream['ga4_pages'])) {
                  $facts['ga4_dimensions']['pages'] = array('rows' => $stream['ga4_pages']);
                }
                if (isset($stream['ga4_events']) && is_array($stream['ga4_events'])) {
                  $facts['ga4_dimensions']['events'] = array('rows' => $stream['ga4_events']);
                }
                if (isset($stream['ga4_page_location']) && is_array($stream['ga4_page_location'])) {
                  $facts['ga4_dimensions']['page_location'] = array('rows' => $stream['ga4_page_location']);
                }
                error_log('[Luna] GA4 dimensions built from legacy flat arrays: ' . count($facts['ga4_dimensions']) . ' dimension types');
              }
              
              error_log('[Luna] GA4 metrics extracted from all-connections stream: ' . print_r($facts['ga4_metrics'], true));
              break; // Use first GA4 stream found
            }
          }
        }
      }
      
      // Also check if connections data has GA4 directly (non-stream format)
      if (isset($connections_data['ga4']) && is_array($connections_data['ga4'])) {
        if (!isset($facts['ga4_metrics']) || empty($facts['ga4_metrics'])) {
          if (isset($connections_data['ga4']['ga4_metrics']) && is_array($connections_data['ga4']['ga4_metrics'])) {
            $facts['ga4_metrics'] = $connections_data['ga4']['ga4_metrics'];
          } elseif (isset($connections_data['ga4']['metrics']) && is_array($connections_data['ga4']['metrics'])) {
            $facts['ga4_metrics'] = $connections_data['ga4']['metrics'];
          }
        }
      }
    }
    
    // Search endpoint data (GSC)
    if (isset($hub_collections['search']) && is_array($hub_collections['search'])) {
      $search_data = luna_hub_normalize_payload($hub_collections['search']);
      if (isset($search_data['data']) && is_array($search_data['data'])) {
        $search_category_data = $search_data['data'];
        if (isset($search_category_data['gsc']) && is_array($search_category_data['gsc'])) {
          $facts['gsc'] = $search_category_data['gsc'];
        }
      } elseif (isset($search_data['gsc']) && is_array($search_data['gsc'])) {
        $facts['gsc'] = $search_data['gsc'];
      }
    }
    
    // Competitive endpoint data (Competitor Reports, VLDR)
    if (isset($hub_collections['competitive']) && is_array($hub_collections['competitive'])) {
      $competitive_data = luna_hub_normalize_payload($hub_collections['competitive']);
      if (isset($competitive_data['data']) && is_array($competitive_data['data'])) {
        $competitive_category_data = $competitive_data['data'];
        
        // Merge competitor reports
        if (isset($competitive_category_data['competitor_reports']) && is_array($competitive_category_data['competitor_reports'])) {
          $facts['competitor_reports'] = $competitive_category_data['competitor_reports'];
        }
        
        // Merge VLDR metrics
        if (isset($competitive_category_data['vldr_metrics']) && is_array($competitive_category_data['vldr_metrics'])) {
          $facts['vldr'] = $competitive_category_data['vldr_metrics'];
        }
      } elseif (isset($competitive_data['competitor_reports']) && is_array($competitive_data['competitor_reports'])) {
        $facts['competitor_reports'] = $competitive_data['competitor_reports'];
      } elseif (isset($competitive_data['vldr_metrics']) && is_array($competitive_data['vldr_metrics'])) {
        $facts['vldr'] = $competitive_data['vldr_metrics'];
      }
    }
  }

  // Fetch competitor analysis data - first try from comprehensive profile
  $competitor_urls = array();
  error_log('[Luna Widget] Checking comprehensive profile for competitors: ' . print_r(isset($comprehensive['competitors']) ? $comprehensive['competitors'] : 'NOT SET', true));
  
  if (isset($comprehensive['competitors']) && is_array($comprehensive['competitors']) && !empty($comprehensive['competitors'])) {
    // Extract competitor URLs from enriched profile
    foreach ($comprehensive['competitors'] as $competitor) {
      if (!empty($competitor['url'])) {
        $competitor_urls[] = $competitor['url'];
      } elseif (!empty($competitor['domain'])) {
        $competitor_urls[] = 'https://' . $competitor['domain'];
      }
    }
    $facts['competitors'] = $competitor_urls;
    error_log('[Luna Widget] Found competitors in comprehensive profile: ' . print_r($competitor_urls, true));
  } else {
    error_log('[Luna Widget] No competitors in comprehensive profile, falling back to direct fetch');
    // Fallback: fetch competitor data directly
    $competitor_data = luna_fetch_competitor_data($license);
    if ($competitor_data) {
      $facts['competitors'] = $competitor_data['competitors'] ?? array();
      $facts['competitor_reports'] = $competitor_data['reports'] ?? array();
      $competitor_urls = $facts['competitors'];
      error_log('[Luna Widget] Fetched competitors via direct call: ' . print_r($competitor_urls, true));
    } else {
      error_log('[Luna Widget] No competitor data found via direct fetch');
    }
  }
  
  // Fetch competitor reports if not already in comprehensive data
  // Always fetch reports when we have competitor URLs to ensure we have the latest data
  // Also check if comprehensive profile already has competitor_reports_full
  if (!empty($competitor_urls)) {
    if (isset($comprehensive['competitor_reports_full']) && is_array($comprehensive['competitor_reports_full']) && !empty($comprehensive['competitor_reports_full'])) {
      // Use reports from comprehensive profile
      $facts['competitor_reports'] = $comprehensive['competitor_reports_full'];
      error_log('[Luna Widget] Using competitor reports from comprehensive profile: ' . count($comprehensive['competitor_reports_full']) . ' reports');
    } else {
      // Fallback: fetch directly
      $competitor_data = luna_fetch_competitor_data($license);
      if ($competitor_data && !empty($competitor_data['reports'])) {
        $facts['competitor_reports'] = $competitor_data['reports'];
        error_log('[Luna Widget] Fetched competitor reports via direct call: ' . count($competitor_data['reports']) . ' reports');
      } elseif (!isset($facts['competitor_reports'])) {
        // Initialize empty array if no reports found
        $facts['competitor_reports'] = array();
        error_log('[Luna Widget] No competitor reports found for ' . count($competitor_urls) . ' competitors');
      }
    }
  }
  
  // Fetch VLDR data for each competitor and client domain
  // First check if comprehensive profile already has vldr_metrics
  if (isset($comprehensive['vldr_metrics']) && is_array($comprehensive['vldr_metrics']) && !empty($comprehensive['vldr_metrics'])) {
    // Use VLDR metrics from comprehensive profile
    $facts['vldr'] = $comprehensive['vldr_metrics'];
    error_log('[Luna Widget] Using VLDR metrics from comprehensive profile: ' . count($comprehensive['vldr_metrics']) . ' domains');
    
    // Mark client domain if available
    $client_domain = parse_url($site_url, PHP_URL_HOST);
    if ($client_domain && isset($facts['vldr'][$client_domain])) {
      $facts['vldr'][$client_domain]['is_client'] = true;
    }
  } elseif (!empty($competitor_urls) || !empty($site_url)) {
    // Fallback: fetch VLDR data directly
    $vldr_data = array();
    
    // Fetch VLDR for all competitors
    foreach ($competitor_urls as $competitor_url) {
      $domain = parse_url($competitor_url, PHP_URL_HOST);
      if ($domain) {
        $vldr = luna_fetch_vldr_data($domain, $license);
        if ($vldr) {
          $vldr_data[$domain] = $vldr;
        }
      }
    }
    
    // Also fetch VLDR for client's own domain
    $client_domain = parse_url($site_url, PHP_URL_HOST);
    if ($client_domain) {
      $client_vldr = luna_fetch_vldr_data($client_domain, $license);
      if ($client_vldr) {
        $vldr_data[$client_domain] = $client_vldr;
        $vldr_data[$client_domain]['is_client'] = true;
      }
    }
    
    if (!empty($vldr_data)) {
      $facts['vldr'] = $vldr_data;
      error_log('[Luna Widget] Fetched VLDR data via direct call: ' . count($vldr_data) . ' domains');
    }
  }
  
  // Add performance metrics if available
  if (isset($comprehensive['performance']) && is_array($comprehensive['performance'])) {
    $facts['performance'] = $comprehensive['performance'];
  }
  
  // Add Lighthouse Insights data (from VL Hub)
  if (isset($comprehensive['lighthouse_insights']) && is_array($comprehensive['lighthouse_insights'])) {
    $facts['lighthouse_insights'] = $comprehensive['lighthouse_insights'];
  } elseif (isset($comprehensive['lighthouse']) && is_array($comprehensive['lighthouse'])) {
    $facts['lighthouse_insights'] = $comprehensive['lighthouse'];
  } elseif (isset($comprehensive['pagespeed']) && is_array($comprehensive['pagespeed'])) {
    $facts['lighthouse_insights'] = $comprehensive['pagespeed'];
  } elseif (isset($comprehensive['performance']['lighthouse']) && is_array($comprehensive['performance']['lighthouse'])) {
    $facts['lighthouse_insights'] = $comprehensive['performance']['lighthouse'];
  }
  
  // Add SEO data if available
  if (isset($comprehensive['seo']) && is_array($comprehensive['seo'])) {
    $facts['seo'] = $comprehensive['seo'];
  }
  
  // Add data stream summary if available
  if (isset($comprehensive['data_streams_summary']) && is_array($comprehensive['data_streams_summary'])) {
    $facts['data_streams_summary'] = $comprehensive['data_streams_summary'];
  }
  
  // Add Google Ads data (when available)
  if (isset($comprehensive['google_ads']) && is_array($comprehensive['google_ads'])) {
    $facts['google_ads'] = $comprehensive['google_ads'];
  } elseif (isset($comprehensive['marketing']['google_ads']) && is_array($comprehensive['marketing']['google_ads'])) {
    $facts['google_ads'] = $comprehensive['marketing']['google_ads'];
  }
  
  // Add LinkedIn Ads data (when available)
  if (isset($comprehensive['linkedin_ads']) && is_array($comprehensive['linkedin_ads'])) {
    $facts['linkedin_ads'] = $comprehensive['linkedin_ads'];
  } elseif (isset($comprehensive['marketing']['linkedin_ads']) && is_array($comprehensive['marketing']['linkedin_ads'])) {
    $facts['linkedin_ads'] = $comprehensive['marketing']['linkedin_ads'];
  }
  
  // Add Meta Ads data (when available)
  if (isset($comprehensive['meta_ads']) && is_array($comprehensive['meta_ads'])) {
    $facts['meta_ads'] = $comprehensive['meta_ads'];
  } elseif (isset($comprehensive['marketing']['meta_ads']) && is_array($comprehensive['marketing']['meta_ads'])) {
    $facts['meta_ads'] = $comprehensive['marketing']['meta_ads'];
  } elseif (isset($comprehensive['marketing']['facebook_ads']) && is_array($comprehensive['marketing']['facebook_ads'])) {
    $facts['meta_ads'] = $comprehensive['marketing']['facebook_ads'];
  }
  
  // Add ALL VL Hub data sources
  // AWS S3 Data
  if (isset($comprehensive['aws_s3']) && is_array($comprehensive['aws_s3'])) {
    $facts['aws_s3'] = $comprehensive['aws_s3'];
  }
  
  // Liquid Web Assets
  if (isset($comprehensive['liquidweb']) && is_array($comprehensive['liquidweb'])) {
    $facts['liquidweb'] = $comprehensive['liquidweb'];
  }
  
  // SSL/TLS Status Data (from VL Hub SSL/TLS Status connector)
  if (isset($comprehensive['ssl_tls']) && is_array($comprehensive['ssl_tls'])) {
    $facts['ssl_tls'] = $comprehensive['ssl_tls'];
    error_log('[Luna Widget] Added SSL/TLS data to facts from comprehensive profile');
  }
  
  // Cloudflare Data (from VL Hub Cloudflare connector)
  if (isset($comprehensive['cloudflare']) && is_array($comprehensive['cloudflare'])) {
    $facts['cloudflare'] = $comprehensive['cloudflare'];
    error_log('[Luna Widget] Added Cloudflare data to facts from comprehensive profile');
  }
  
  // Security Data Streams (from VL Hub Security tab - SSL/TLS Status and Cloudflare)
  if (isset($comprehensive['data_streams']) && is_array($comprehensive['data_streams'])) {
    $security_streams = array();
    foreach ($comprehensive['data_streams'] as $stream_id => $stream_data) {
      // Skip removed streams
      if (isset($stream_data['removed']) && $stream_data['removed'] === true) {
        continue;
      }
      if (isset($stream_data['removed_at']) && !empty($stream_data['removed_at'])) {
        continue;
      }
      
      if (isset($stream_data['categories']) && is_array($stream_data['categories']) && in_array('security', $stream_data['categories'])) {
        $security_streams[$stream_id] = $stream_data;
        
        // Extract SSL/TLS data from SSL/TLS Status connector
        if (isset($stream_data['id']) && $stream_data['id'] === 'ssl_tls_status') {
          // Check for ssl_tls_data field
          if (isset($stream_data['ssl_tls_data']) && is_array($stream_data['ssl_tls_data']) && !empty($stream_data['ssl_tls_data'])) {
            $ssl_tls_from_connector = $stream_data['ssl_tls_data'];
            // Always use connector data as it's the most authoritative
            $facts['ssl_tls'] = $ssl_tls_from_connector;
            error_log('[Luna Widget] ✅ Extracted SSL/TLS data from SSL/TLS Status connector: Certificate=' . (isset($ssl_tls_from_connector['certificate']) ? $ssl_tls_from_connector['certificate'] : 'N/A') . ', Expires=' . (isset($ssl_tls_from_connector['expires']) ? $ssl_tls_from_connector['expires'] : 'N/A'));
          } else {
            error_log('[Luna Widget] ⚠️ SSL/TLS Status connector found but ssl_tls_data is missing or empty');
          }
        }
        // Also check by name pattern
        elseif (isset($stream_data['name']) && (stripos($stream_data['name'], 'SSL/TLS') !== false || stripos($stream_data['name'], 'SSL') !== false)) {
          if (isset($stream_data['ssl_tls_data']) && is_array($stream_data['ssl_tls_data']) && !empty($stream_data['ssl_tls_data'])) {
            $ssl_tls_from_connector = $stream_data['ssl_tls_data'];
            // Only set if not already set from id match
            if (!isset($facts['ssl_tls']) || !is_array($facts['ssl_tls']) || empty($facts['ssl_tls'])) {
              $facts['ssl_tls'] = $ssl_tls_from_connector;
              error_log('[Luna Widget] ✅ Extracted SSL/TLS data from connector by name: ' . $stream_data['name']);
            }
          }
        }
        
        // Extract Cloudflare data from Cloudflare connector
        if (strpos($stream_id, 'cloudflare') !== false || (isset($stream_data['name']) && stripos($stream_data['name'], 'Cloudflare') !== false)) {
          // Skip if this is a removed stream
          if (isset($stream_data['removed']) && $stream_data['removed'] === true) {
            error_log('[Luna Widget] Skipping removed Cloudflare stream: ' . $stream_id);
            continue;
          }
          if (isset($stream_data['removed_at']) && !empty($stream_data['removed_at'])) {
            error_log('[Luna Widget] Skipping Cloudflare stream with removed_at: ' . $stream_id);
            continue;
          }
          
          // Build Cloudflare connection data from stream
          $cloudflare_data = array(
            'connected' => isset($stream_data['status']) && $stream_data['status'] === 'active',
            'zone_id' => isset($stream_data['cloudflare_zone_id']) ? $stream_data['cloudflare_zone_id'] : '',
            'zone_name' => isset($stream_data['cloudflare_zone_name']) ? $stream_data['cloudflare_zone_name'] : '',
            'plan' => isset($stream_data['cloudflare_plan']) ? $stream_data['cloudflare_plan'] : '',
            'health_score' => isset($stream_data['health_score']) ? floatval($stream_data['health_score']) : 0,
            'last_updated' => isset($stream_data['last_updated']) ? $stream_data['last_updated'] : '',
          );
          
          // Include full cloudflare_data if available
          if (isset($stream_data['cloudflare_data']) && is_array($stream_data['cloudflare_data'])) {
            $cloudflare_data['cloudflare_data'] = $stream_data['cloudflare_data'];
            // Extract account info
            if (isset($stream_data['cloudflare_data']['account']) && is_array($stream_data['cloudflare_data']['account'])) {
              $cloudflare_data['account_id'] = isset($stream_data['cloudflare_data']['account']['id']) ? $stream_data['cloudflare_data']['account']['id'] : '';
              $cloudflare_data['account_name'] = isset($stream_data['cloudflare_data']['account']['name']) ? $stream_data['cloudflare_data']['account']['name'] : '';
            }
            // Extract permissions
            if (isset($stream_data['cloudflare_data']['permissions']) && is_array($stream_data['cloudflare_data']['permissions'])) {
              $cloudflare_data['permissions'] = $stream_data['cloudflare_data']['permissions'];
            }
            // Extract plan details
            if (isset($stream_data['cloudflare_data']['plan']) && is_array($stream_data['cloudflare_data']['plan'])) {
              $cloudflare_data['plan_details'] = $stream_data['cloudflare_data']['plan'];
            }
          }
          
          // Merge into facts['cloudflare'] - create zones array if needed
          if (!isset($facts['cloudflare']) || !is_array($facts['cloudflare'])) {
            $facts['cloudflare'] = array(
              'connected' => $cloudflare_data['connected'],
              'zones' => array(),
              'zones_count' => 0
            );
          }
          
          // Add zone to zones array
          if (!isset($facts['cloudflare']['zones']) || !is_array($facts['cloudflare']['zones'])) {
            $facts['cloudflare']['zones'] = array();
          }
          
          $zone_data = array(
            'name' => $cloudflare_data['zone_name'],
            'status' => isset($stream_data['status']) ? $stream_data['status'] : 'unknown',
            'plan' => $cloudflare_data['plan'],
            'zone_id' => $cloudflare_data['zone_id'],
            'health_score' => $cloudflare_data['health_score'],
            'last_updated' => $cloudflare_data['last_updated']
          );
          
          // Include full cloudflare_data in zone
          if (isset($cloudflare_data['cloudflare_data'])) {
            $zone_data['cloudflare_data'] = $cloudflare_data['cloudflare_data'];
          }
          
          $facts['cloudflare']['zones'][] = $zone_data;
          $facts['cloudflare']['zones_count'] = count($facts['cloudflare']['zones']);
          $facts['cloudflare']['connected'] = $cloudflare_data['connected'];
          
          // Set account info if available
          if (isset($cloudflare_data['account_id'])) {
            $facts['cloudflare']['account_id'] = $cloudflare_data['account_id'];
          }
          if (isset($cloudflare_data['account_name'])) {
            $facts['cloudflare']['account_name'] = $cloudflare_data['account_name'];
          }
          
          error_log('[Luna Widget] ✅ Extracted Cloudflare data from security stream: ' . $stream_id . ' (Zone: ' . $cloudflare_data['zone_name'] . ', Status: ' . $stream_data['status'] . ')');
        }
      }
    }
    if (!empty($security_streams)) {
      $facts['security_data_streams'] = $security_streams;
      error_log('[Luna Widget] ✅ Added ' . count($security_streams) . ' security data streams to facts');
      error_log('[Luna Widget] Security streams: ' . implode(', ', array_keys($security_streams)));
    } else {
      error_log('[Luna Widget] ⚠️ No security streams found in data_streams');
    }
    
    // Log what we extracted
    if (isset($facts['ssl_tls']) && !empty($facts['ssl_tls'])) {
      error_log('[Luna Widget] ✅ SSL/TLS data in facts: Certificate=' . (isset($facts['ssl_tls']['certificate']) ? $facts['ssl_tls']['certificate'] : 'N/A'));
    } else {
      error_log('[Luna Widget] ⚠️ No SSL/TLS data extracted');
    }
    
    if (isset($facts['cloudflare']) && !empty($facts['cloudflare'])) {
      $cf_zones = isset($facts['cloudflare']['zones_count']) ? $facts['cloudflare']['zones_count'] : 0;
      error_log('[Luna Widget] ✅ Cloudflare data in facts: ' . $cf_zones . ' zone(s), Connected=' . (isset($facts['cloudflare']['connected']) ? ($facts['cloudflare']['connected'] ? 'Yes' : 'No') : 'N/A'));
    } else {
      error_log('[Luna Widget] ⚠️ No Cloudflare data extracted');
    }
  } else {
    error_log('[Luna Widget] ⚠️ comprehensive[data_streams] is not set or not an array');
  }
  
  // Also check connections data for SSL/TLS connectors
  if (isset($hub_collections['connections']) && is_array($hub_collections['connections'])) {
    $connections_data = luna_hub_normalize_payload($hub_collections['connections']);
    
    // Check for streams array in connections data
    if (isset($connections_data['streams']) && is_array($connections_data['streams'])) {
      foreach ($connections_data['streams'] as $stream_id => $stream) {
        // Look for SSL/TLS Status connector
        if (isset($stream['id']) && $stream['id'] === 'ssl_tls_status') {
          if (isset($stream['ssl_tls_data']) && is_array($stream['ssl_tls_data'])) {
            $ssl_tls_from_connector = $stream['ssl_tls_data'];
            if (!isset($facts['ssl_tls']) || !is_array($facts['ssl_tls']) || empty($facts['ssl_tls'])) {
              $facts['ssl_tls'] = $ssl_tls_from_connector;
            } else {
              $facts['ssl_tls'] = array_merge($facts['ssl_tls'], $ssl_tls_from_connector);
            }
            error_log('[Luna Widget] Extracted SSL/TLS data from connections streams');
          }
        }
      }
    }
  }
  
  // GA4 Metrics (if not already added)
  if (isset($comprehensive['ga4_metrics']) && is_array($comprehensive['ga4_metrics']) && !isset($facts['ga4_metrics'])) {
    $facts['ga4_metrics'] = $comprehensive['ga4_metrics'];
    $facts['ga4_last_synced'] = $comprehensive['ga4_last_synced'] ?? null;
    $facts['ga4_date_range'] = $comprehensive['ga4_date_range'] ?? null;
    $facts['ga4_source_url'] = $comprehensive['ga4_source_url'] ?? null;
    $facts['ga4_property_id'] = $comprehensive['ga4_property_id'] ?? null;
    $facts['ga4_measurement_id'] = $comprehensive['ga4_measurement_id'] ?? null;
  }
  
  // GA4 Dimensions (if not already added)
  if (isset($comprehensive['ga4_dimensions']) && is_array($comprehensive['ga4_dimensions']) && !isset($facts['ga4_dimensions'])) {
    $facts['ga4_dimensions'] = $comprehensive['ga4_dimensions'];
  }
  
  // All Data Streams (full data)
  if (isset($comprehensive['data_streams']) && is_array($comprehensive['data_streams'])) {
    $facts['data_streams'] = $comprehensive['data_streams'];
  }
  
  // Competitor Reports (full reports from database)
  if (isset($comprehensive['competitor_reports_full']) && is_array($comprehensive['competitor_reports_full'])) {
    // Always use full reports from database as they are the most complete
    $facts['competitor_reports'] = $comprehensive['competitor_reports_full'];
    $facts['competitor_reports_full'] = $comprehensive['competitor_reports_full']; // Keep both keys for compatibility
    error_log('[Luna Widget] Added competitor_reports_full to facts: ' . count($comprehensive['competitor_reports_full']) . ' reports');
  }
  
  // VLDR Metrics (from database - latest for all domains)
  if (isset($comprehensive['vldr_metrics']) && is_array($comprehensive['vldr_metrics'])) {
    // Merge with existing vldr data
    if (!isset($facts['vldr'])) {
      $facts['vldr'] = array();
    }
    foreach ($comprehensive['vldr_metrics'] as $domain => $vldr_data) {
      $facts['vldr'][$domain] = $vldr_data;
    }
  }

  // Ensure comprehensive payload always has hydrated data streams and security connectors
  luna_enrich_facts_with_streams($facts, $license);

  // Ensure we always return a valid array
  if (!is_array($facts) || empty($facts)) {
    error_log('[Luna] Comprehensive facts array is empty or invalid, falling back to basic facts');
    $fallback = luna_profile_facts();
    $fallback['__source'] = 'error-fallback';
    return $fallback;
  }

  $facts['__source'] = 'comprehensive';

  return $facts;
  
  } catch (Exception $e) {
    error_log('[Luna] Exception in luna_profile_facts_comprehensive: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
    $fallback = luna_profile_facts();
    $fallback['__source'] = 'exception-fallback';
    return $fallback;
  } catch (Error $e) {
    error_log('[Luna] Fatal error in luna_profile_facts_comprehensive: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
    $fallback = luna_profile_facts();
    $fallback['__source'] = 'error-fallback';
    return $fallback;
  }
}

/* Local snapshot used ONLY as fallback when Hub fact missing */
function luna_snapshot_system() {
  global $wp_version; $theme = wp_get_theme();
  if (!function_exists('get_plugins')) { @require_once ABSPATH . 'wp-admin/includes/plugin.php'; }
  $plugins = function_exists('get_plugins') ? (array)get_plugins() : array();
  $active  = (array) get_option('active_plugins', array());
  $up_pl   = get_site_transient('update_plugins');

  $plugins_out = array();
  foreach ($plugins as $slug => $info) {
    $update_available = isset($up_pl->response[$slug]);
    $plugins_out[] = array(
      'slug' => $slug,
      'name' => isset($info['Name']) ? $info['Name'] : $slug,
      'version' => isset($info['Version']) ? $info['Version'] : null,
      'active' => in_array($slug, $active, true),
      'update_available' => (bool)$update_available,
      'new_version' => $update_available ? (isset($up_pl->response[$slug]->new_version) ? $up_pl->response[$slug]->new_version : null) : null,
    );
  }
  $themes = wp_get_themes(); $up_th = get_site_transient('update_themes');
  $themes_out = array();
  foreach ($themes as $stylesheet => $th) {
    $update_available = isset($up_th->response[$stylesheet]);
    $themes_out[] = array(
      'stylesheet' => $stylesheet,
      'name' => $th->get('Name'),
      'version' => $th->get('Version'),
      'is_active' => (wp_get_theme()->get_stylesheet() === $stylesheet),
      'update_available' => (bool)$update_available,
      'new_version' => $update_available ? (isset($up_th->response[$stylesheet]['new_version']) ? $up_th->response[$stylesheet]['new_version'] : null) : null,
    );
  }

  // Check for WordPress core updates
  $core_updates = get_site_transient('update_core');
  $core_update_available = false;
  if (isset($core_updates->updates) && is_array($core_updates->updates)) {
    foreach ($core_updates->updates as $update) {
      if ($update->response === 'upgrade') {
        $core_update_available = true;
        break;
      }
    }
  }

  return array(
    'site' => array('home_url' => home_url('/'), 'https' => (wp_parse_url(home_url('/'), PHP_URL_SCHEME) === 'https')),
    'wordpress' => array(
      'version' => isset($wp_version) ? $wp_version : null,
      'core_update_available' => $core_update_available,
      'theme'   => array(
        'name'       => $theme->get('Name'),
        'version'    => $theme->get('Version'),
        'stylesheet' => $theme->get_stylesheet(),
        'template'   => $theme->get_template(),
      ),
    ),
    'plugins'     => $plugins_out,
    'themes'      => $themes_out,
    'generated_at'=> gmdate('c'),
  );
}

/* ============================================================
 * FRONT-END: Widget/Shortcode + JS (with history hydrate)
 * ============================================================ */
add_action('wp_enqueue_scripts', function () {
  wp_register_script(
    'luna-composer',
    LUNA_WIDGET_ASSET_URL . 'assets/js/luna-composer.js',
    array(),
    LUNA_WIDGET_PLUGIN_VERSION,
    true
  );
});

add_shortcode('luna_chat', function($atts = array(), $content = ''){
  // Parse shortcode attributes properly
  $atts = shortcode_atts(array(
    'vl_key' => '',
  ), $atts, 'luna_chat');
  
  // Check for vl_key parameter (for Supercluster embedding)
  $vl_key = !empty($atts['vl_key']) ? sanitize_text_field($atts['vl_key']) : '';
  
  // If vl_key is provided, validate it and allow shortcode even if widget mode is active
  if ($vl_key !== '') {
    // Validate the license key matches the stored license
    $stored_license = trim((string) get_option(LUNA_WIDGET_OPT_LICENSE, ''));
    if ($stored_license === '' || $stored_license !== $vl_key) {
      // License doesn't match - return empty or error message
      return '<!-- [luna_chat] License key validation failed -->';
    }
    // License matches - proceed with shortcode rendering (works even if widget mode is active)
  } else {
    // No vl_key provided - check widget mode as before
  if (get_option(LUNA_WIDGET_OPT_MODE, 'widget') !== 'shortcode') {
    return '<!-- [luna_chat] disabled: floating widget active -->';
  }
  }
  
  ob_start(); ?>
  <div class="luna-wrap">
    <div class="luna-thread"></div>
    <form class="luna-form" onsubmit="return false;">
      <input class="luna-input" autocomplete="off" placeholder="Ask Luna…" />
      <button class="luna-send" type="submit">Send</button>
    </form>
  </div>
  <?php return ob_get_clean();
});

add_shortcode('luna_composer', function($atts = array(), $content = '') {
  $enabled = get_option(LUNA_WIDGET_OPT_COMPOSER_ENABLED, '1') === '1';
  if (!$enabled) {
    return '<div class="luna-composer-disabled">' . esc_html__('Luna Composer is currently disabled.', 'luna') . '</div>';
  }

  wp_enqueue_script('luna-composer');

  static $composer_localized = false;
  if (!$composer_localized) {
    $prompts = array();
    foreach (luna_composer_default_prompts() as $prompt) {
      $label  = isset($prompt['label']) ? (string) $prompt['label'] : '';
      $prompt_text = isset($prompt['prompt']) ? (string) $prompt['prompt'] : '';
      if ($label === '' || $prompt_text === '') {
        continue;
      }
      $prompts[] = array(
        'label'  => sanitize_text_field($label),
        'prompt' => wp_strip_all_tags($prompt_text),
      );
    }

    wp_localize_script('luna-composer', 'lunaComposerSettings', array(
      'restUrlChat' => esc_url_raw(rest_url('luna_widget/v1/chat')),
      'nonce'       => is_user_logged_in() ? wp_create_nonce('wp_rest') : null,
      'integrated'  => true,
      'prompts'     => $prompts,
    ));
    $composer_localized = true;
  }

  $id = esc_attr(wp_unique_id('luna-composer-'));
  $placeholder = apply_filters('luna_composer_placeholder', __('Describe what you need from Luna…', 'luna'));
  $inner_content = trim($content) !== '' ? do_shortcode($content) : '';

  ob_start();
  ?>
  <div class="luna-composer" data-luna-composer data-luna-composer-id="<?php echo $id; ?>">
    <div class="luna-composer__card">
      <div data-luna-prompts>
        <?php echo $inner_content ? wp_kses_post($inner_content) : ''; ?>
      </div>
      <form class="luna-composer__form" action="#" method="post" novalidate>
        <div
          class="luna-composer__editor is-empty"
          data-luna-composer-editor
          contenteditable="true"
          role="textbox"
          aria-multiline="true"
          spellcheck="true"
          data-placeholder="<?php echo esc_attr($placeholder); ?>"
        ></div>
        <div class="luna-composer__actions">
          <button type="submit" class="luna-composer__submit" data-luna-composer-submit>
            <?php esc_html_e('', 'luna'); ?>
          </button>
        </div>
      </form>
      <div class="luna-composer__response" data-luna-composer-response></div>
    </div>
  </div>
  <?php
  return ob_get_clean();
});

// Demo shortcode - only works on visiblelight.ai
add_shortcode('luna_composer_demo_only', function($atts = array(), $content = '') {
  // Only allow on visiblelight.ai domain
  $current_domain = parse_url(home_url(), PHP_URL_HOST);
  if ($current_domain !== 'visiblelight.ai' && $current_domain !== 'www.visiblelight.ai') {
    return ''; // Return nothing on other domains
  }

  $enabled = get_option(LUNA_WIDGET_OPT_COMPOSER_ENABLED, '1') === '1';
  if (!$enabled) {
    return '<div class="luna-composer-disabled">' . esc_html__('Luna Composer is currently disabled.', 'luna') . '</div>';
  }

  wp_enqueue_script('luna-composer');

  static $composer_demo_localized = false;
  if (!$composer_demo_localized) {
    $prompts = array();
    foreach (luna_composer_default_prompts() as $prompt) {
      $label  = isset($prompt['label']) ? (string) $prompt['label'] : '';
      $prompt_text = isset($prompt['prompt']) ? (string) $prompt['prompt'] : '';
      if ($label === '' || $prompt_text === '') {
        continue;
      }
      $prompts[] = array(
        'label'  => sanitize_text_field($label),
        'prompt' => wp_strip_all_tags($prompt_text),
      );
    }

    // Get demo data file URL
    $demo_data_url = plugin_dir_url(__FILE__) . 'assets/luna-composer-demo-data.json';

    // Use separate localization key for demo to avoid conflicts
    wp_localize_script('luna-composer', 'lunaComposerDemoSettings', array(
      'restUrlChat' => esc_url_raw(rest_url('luna_widget/v1/chat')),
      'nonce'       => is_user_logged_in() ? wp_create_nonce('wp_rest') : null,
      'integrated'  => true,
      'prompts'     => $prompts,
      'demoMode'    => true, // Flag to indicate demo mode
      'demoDataUrl' => esc_url_raw($demo_data_url),
    ));
    $composer_demo_localized = true;
  }

  $id = esc_attr(wp_unique_id('luna-composer-demo-'));
  $placeholder = apply_filters('luna_composer_placeholder', __('Describe what you need from Luna…', 'luna'));
  $inner_content = trim($content) !== '' ? do_shortcode($content) : '';

  ob_start();
  ?>
  <div class="luna-composer luna-composer-demo" data-luna-composer data-luna-composer-id="<?php echo $id; ?>" data-luna-demo-mode="true">
    <div class="luna-composer__card">
      <div data-luna-prompts>
        <?php echo $inner_content ? wp_kses_post($inner_content) : ''; ?>
      </div>
      <form class="luna-composer__form" action="#" method="post" novalidate>
        <div
          class="luna-composer__editor is-empty"
          data-luna-composer-editor
          contenteditable="true"
          role="textbox"
          aria-multiline="true"
          spellcheck="true"
          data-placeholder="<?php echo esc_attr($placeholder); ?>"
        ></div>
        <div class="luna-composer__actions">
          <button type="submit" class="luna-composer__submit" data-luna-composer-submit>
            <?php esc_html_e('', 'luna'); ?>
          </button>
        </div>
      </form>
      <div class="luna-composer__response" data-luna-composer-response></div>
    </div>
  </div>
  <?php
  return ob_get_clean();
});

add_action('wp_footer', function () {
  if (is_admin()) return;

  $mode = get_option(LUNA_WIDGET_OPT_MODE, 'widget');
  $supercluster_only = get_option(LUNA_WIDGET_OPT_SUPERCLUSTER_ONLY, '0') === '1';
  
  // If Supercluster only is enabled, don't render on frontend
  if ($supercluster_only) {
    return;
  }

  $ui   = get_option(LUNA_WIDGET_OPT_SETTINGS, array());
  $pos  = isset($ui['position']) ? $ui['position'] : 'bottom-right';

  if ($mode === 'widget') {
    $pos_css = 'bottom:20px;right:20px;';
    if ($pos === 'top-left') { $pos_css = 'top:20px;left:20px;'; }
    elseif ($pos === 'top-center') { $pos_css = 'top:20px;left:50%;transform:translateX(-50%);'; }
    elseif ($pos === 'top-right') { $pos_css = 'top:20px;right:20px;'; }
    elseif ($pos === 'bottom-left') { $pos_css = 'bottom:20px;left:20px;'; }
    elseif ($pos === 'bottom-center') { $pos_css = 'bottom:20px;left:50%;transform:translateX(-50%);'; }

    $title = esc_html(isset($ui['title']) ? $ui['title'] : 'Luna Chat');
    $avatar= esc_url(isset($ui['avatar_url']) ? $ui['avatar_url'] : '');
    $hdr   = esc_html(isset($ui['header_text']) ? $ui['header_text'] : "Hi, I'm Luna");
    $sub   = esc_html(isset($ui['sub_text']) ? $ui['sub_text'] : 'How can I help today?');

    $panel_anchor = (strpos($pos,'bottom') !== false ? 'bottom:80px;' : 'top:80px;')
                  . (strpos($pos,'right') !== false ? 'right:20px;' : (strpos($pos,'left') !== false ? 'left:20px;' : 'left:50%;transform:translateX(-50%);'));
    ?>
    <style>
      .luna-fab { position:fixed !important; z-index:2147483647 !important; <?php echo $pos_css; ?> }
      .luna-launcher{display:flex;align-items:center;gap:10px;background:#111;color:#fff4e9;border:1px solid #5A5753;border-radius:999px;padding:5px 17px 5px 8px;cursor:pointer;box-shadow:0 8px 24px rgba(0,0,0,.25)}
      .luna-launcher .ava{width:42px;height:42px;border-radius:50%;background:#222;overflow:hidden;display:inline-flex;align-items:center;justify-content:center}
      .luna-launcher .txt{line-height:1.2;display:flex;flex-direction:column;overflow:hidden;position:relative}
      .luna-launcher .txt span{max-width:222px !important;display:inline-block;white-space:nowrap;overflow:hidden}
      .luna-launcher .txt span.luna-scroll-wrapper{overflow:hidden;position:relative;max-width:130px !important;display:inline-block}
      .luna-launcher .txt span.luna-scroll-inner{display:inline-block;white-space:nowrap;animation:lunaInfiniteScroll 10s infinite linear;will-change:transform;vertical-align: -webkit-baseline-middle;}
      .luna-launcher .txt span.luna-scroll-inner span{display:inline-block;white-space:nowrap;margin:0;padding:0;max-width:none !important}
      @keyframes lunaInfiniteScroll{from{transform:translateX(0%)}to{transform:translateX(-50%)}}
      .luna-panel{position: fixed !important;z-index: 2147483647 !important; <?php echo $panel_anchor; ?> width: clamp(320px,92vw,420px);max-height: min(70vh,560px);display: none;flex-direction: column;border-radius: 12px;border: 1px solid #232120;background: #000;color: #fff4e9;overflow: hidden;}
      .luna-panel.show{display:flex !important;z-index: 2147483647 !important;}
      .luna-head{padding:10px 12px;font-weight:600;background:#000;border-bottom:1px solid #333;display:flex;align-items:center;justify-content:space-between}
      .luna-thread{padding:10px 12px;overflow:auto;flex:1 1 auto}
      .luna-form{display:flex;gap:8px;padding:10px 12px;border-top:1px solid #333}
      .luna-input{flex:1 1 auto;background:#111;color:#fff4e9;border:1px solid #333;border-radius:10px;padding:8px 10px}
      .luna-send{background:linear-gradient(270deg, #974C00 0%, #8D8C00 100%) !important;color:#000;border:none;border-radius:10px;padding:8px 12px;cursor:pointer;font-size: .88rem;font-weight: 600}
      .luna-thread .luna-msg{clear:both;margin:6px 0}
      .luna-thread .luna-user{float:right;background:#fff4e9;color:#000;display:inline-block;padding:8px 10px;border-radius:10px;max-width:85%;word-wrap:break-word}
      .luna-thread .luna-assistant{float:left;background:#000000;border:1px solid #2E2C2A;color:#fff4e9;display:inline-block;padding:10px;border-radius:10px;max-width:85%;word-wrap:break-word;line-height:1.25rem;}
      .luna-initial-greeting{display:flex;flex-direction:column;gap:12px}
      .luna-greeting-text{margin-bottom:10px;line-height: 1.25rem;}
      .luna-greeting-buttons{display:flex;flex-direction:column;gap:8px;width:100%}
      .luna-greeting-btn{width:100%;padding:10px 14px;background:#2E2C2A;border:none;border-radius:8px;color:#fff4e9;font-size:0.9rem;font-weight:600;cursor:pointer;transition:all 0.2s ease;text-align:left;display:flex;align-items:center;justify-content:space-between}
      .luna-greeting-btn:hover{background:#3A3836;transform:translateY(-1px)}
      .luna-greeting-btn:active{transform:translateY(0)}
      .luna-greeting-btn-chat{background:linear-gradient(270deg, #974C00 0%, #8D8C00 100%);color:#000;border-color:#5A5753}
      .luna-greeting-btn-chat:hover{background:linear-gradient(270deg, #B85C00 0%, #A5A000 100%)}
      .luna-greeting-btn-report{background:#2E2C2A}
      .luna-greeting-btn-compose{background:#2E2C2A}
      .luna-greeting-btn-automate{background:#2E2C2A}
      .luna-greeting-help{width:20px;height:20px;border-radius:50%;background-color:rgba(255,255,255,.15);display:flex;align-items:center;justify-content:center;font-size:0.85rem;font-weight:600;cursor:help;margin-left:8px;flex-shrink:0;transition:background-color 0.2s ease}
      .luna-greeting-help:hover{background-color:rgba(255,255,255,.25)}
      .luna-greeting-tooltip{position:absolute;background:#000;color:#fff4e9;padding:12px 16px;border-radius:8px;font-size:0.85rem;line-height:1.4;max-width:280px;z-index:999999;box-shadow:0 4px 12px rgba(0,0,0,0.4);pointer-events:none;border:1px solid #5A5753;word-wrap:break-word}
      .luna-thread .luna-session-closure{opacity:.85;font-style:italic}
      .luna-thread .luna-loading{float:left;background:#111;border:1px solid #333;color:#fff4e9;display:inline-block;padding:8px 10px;border-radius:10px;max-width:85%;word-wrap:break-word}
      .luna-loading-text{background:radial-gradient(circle at 0%,#fff4e9,#c2b8ad 50%,#978e86 75%,#fff4e9 75%);font-weight:600;background-size:200% auto;color:#000;background-clip:text;-webkit-text-fill-color:transparent;animation:animatedTextGradient 1.5s linear infinite;height:20px !important;}
      @keyframes animatedTextGradient{from{background-position:0% center}to{background-position:200% center}}
        .luna-session-ended{position:fixed;z-index:999999 !important;left:2rem !important;right:auto !important;width:clamp(320px,92vw,420px);display:none;align-items:center;justify-content:center}
      .luna-session-ended.show{display:flex}
      .luna-session-ended-card{background:#000;border:1px solid #5A5753;border-radius:12px;padding:24px 20px;display:flex;flex-direction:column;gap:12px;align-items:center;text-align:center;box-shadow:0 24px 48px rgba(0,0,0,.4);width:100%}
      .luna-session-ended-card h2{margin:0;font-size:1.25rem}
      .luna-session-ended-card p{margin:0;color:#ccc}
      .luna-session-ended-card .luna-session-restart{background:#2c74ff;color:#fff;border:0;border-radius:8px;padding:10px 18px;font-weight:600;cursor:pointer}
      .luna-session-ended-card .luna-session-restart:hover{background:#4c8bff}
      .luna-session-ended-inline{margin-top:12px;background:#000;border:1px solid #5A5753;border-radius:12px;padding:24px 20px;text-align:center;display:flex;flex-direction:column;gap:12px;align-items:center}
      .luna-session-ended-inline button{background:#2c74ff;color:#fff;border:0;border-radius:8px;padding:10px 18px;font-weight:600;cursor:pointer}
      .luna-session-ended-inline button:hover{background:#4c8bff}
    </style>
    <div class="luna-fab" aria-live="polite">
      <button class="luna-launcher" aria-expanded="false" aria-controls="luna-panel" title="<?php echo $title; ?>">
        <span class="ava">
          <?php if ($avatar): ?><img src="<?php echo $avatar; ?>" alt="" style="width:42px;height:42px;object-fit:cover"><?php else: ?>
            <svg width="24" height="24" viewBox="0 0 36 36" fill="none" aria-hidden="true"><circle cx="18" cy="18" r="18" fill="#222"/><path d="M18 18a6 6 0 100-12 6 6 0 000 12zm0 2c-6 0-10 3.2-10 6v2h20v-2c0-2.8-4-6-10-6z" fill="#666"/></svg>
          <?php endif; ?>
        </span>
        <span class="txt"><strong><?php echo $hdr; ?></strong><span><?php echo $sub; ?></span></span>
      </button>
      <div id="luna-panel" class="luna-panel" role="dialog" aria-label="<?php echo $title; ?>">
        <div class="luna-head"><span><?php echo $title; ?></span><button class="luna-close" style="background:transparent;border:0;color:#fff;cursor:pointer" aria-label="Close">✕</button></div>
        <div class="luna-thread"></div>
        <form class="luna-form"><input class="luna-input" placeholder="Ask Luna…" autocomplete="off"><button type="button" class="luna-send">Send</button></form>
      </div>
    </div>
    <div id="luna-session-ended" class="luna-session-ended" style="<?php echo $panel_anchor; ?> display:none;" role="dialog" aria-modal="true" aria-labelledby="luna-session-ended-title">
      <div class="luna-session-ended-card">
        <h2 id="luna-session-ended-title">Your session has ended</h2>
        <button type="button" class="luna-download-transcript" style="background:#fff4e9;color:#000000;border:1px solid #1f1d1a;border-radius:6px;padding:8px 16px;font-weight:600;cursor:pointer;margin-top:8px;width:100%;">Download Transcript</button>
        <p style="margin-top:12px;">Start another one now.</p>
        <button type="button" class="luna-session-restart">Start New Session</button>
      </div>
    </div>
    <script>
      (function(){
        var fab=document.querySelector('.luna-launcher'), panel=document.querySelector('#luna-panel');
        
        // Setup scrolling text animation for launcher subtitle
        function setupLauncherTextScroll() {
          var txtSpan = fab ? fab.querySelector('.txt span:not(strong)') : null;
          if (txtSpan) {
            // Measure text width
            var tempSpan = document.createElement('span');
            tempSpan.style.visibility = 'hidden';
            tempSpan.style.position = 'absolute';
            tempSpan.style.whiteSpace = 'nowrap';
            tempSpan.textContent = txtSpan.textContent;
            document.body.appendChild(tempSpan);
            var textWidth = tempSpan.offsetWidth;
            document.body.removeChild(tempSpan);
            
            // If text is wider than 135px, add infinite scrolling animation
            if (textWidth > 135) {
              // Store original text
              var originalText = txtSpan.textContent;
              
              // Create wrapper and inner structure for infinite scroll
              var wrapper = document.createElement('span');
              wrapper.className = 'luna-scroll-wrapper';
              
              var inner = document.createElement('span');
              inner.className = 'luna-scroll-inner';
              
              // Duplicate text 4 times for seamless infinite loop
              for (var i = 0; i < 4; i++) {
                var textSpan = document.createElement('span');
                textSpan.textContent = originalText + ' ';
                inner.appendChild(textSpan);
              }
              
              wrapper.appendChild(inner);
              
              // Replace original span with new structure
              txtSpan.parentNode.replaceChild(wrapper, txtSpan);
              
              // Calculate animation duration based on text width
              // Scroll speed ~35px per second (30% slower than 50px/s)
              // We need to scroll by one full text width to reveal the entire text
              var scrollDistance = textWidth; // Scroll distance is the full text width
              var scrollTime = scrollDistance / 35; // Time to scroll one full text width
              var pauseTime = 2; // 2 second pause
              var totalDuration = scrollTime + pauseTime;
              var pausePercent = (pauseTime / totalDuration) * 100; // Percentage for pause
              var scrollStartPercent = pausePercent; // Start scrolling after pause
              
              // Calculate the pixel value to scroll (one full text width)
              var scrollPixels = -textWidth;
              
              // Create unique animation name
              var animName = 'lunaInfiniteScroll_' + Date.now();
              
              // Create dynamic keyframes: pause at start, then scroll by one full text width
              // Since we have 4 copies, scrolling by one width creates seamless loop
              var style = document.createElement('style');
              style.id = 'luna-scroll-animation-' + Date.now();
              style.textContent = '@keyframes ' + animName + '{0%{transform:translateX(0)}' + scrollStartPercent + '%{transform:translateX(0)}100%{transform:translateX(' + scrollPixels + 'px)}}';
              document.head.appendChild(style);
              
              // Apply animation with calculated duration
              inner.style.animation = animName + ' ' + totalDuration + 's infinite linear';
            }
          }
        }
        
        // Initialize text scroll after DOM is ready
        if (fab) {
          setTimeout(setupLauncherTextScroll, 100);
        }
        
        // Function to blur Supercluster elements
        function blurSuperclusterElements(blur) {
          // Blur canvas
          var canvas = document.querySelector('canvas');
          if (canvas) {
            if (blur) {
              canvas.style.setProperty('filter', 'blur(8px)', 'important');
              canvas.style.setProperty('pointer-events', 'none', 'important');
            } else {
              canvas.style.removeProperty('filter');
              canvas.style.setProperty('pointer-events', 'inherit', 'important');
            }
          }
          
          // Blur #vlSuperclusterRoot::after (using a style element)
          var root = document.querySelector('#vlSuperclusterRoot');
          if (root) {
            var styleId = 'luna-blur-root-after';
            var existingStyle = document.getElementById(styleId);
            if (blur) {
              if (!existingStyle) {
                var style = document.createElement('style');
                style.id = styleId;
                style.textContent = '#vlSuperclusterRoot::after { filter: blur(8px) !important; pointer-events: none !important; }';
                document.head.appendChild(style);
              }
            } else {
              if (existingStyle) {
                existingStyle.remove();
              }
            }
          }
          
          // Blur .vl-supercluster-labels
          var labels = document.querySelectorAll('.vl-supercluster-labels');
          if (labels && labels.length > 0) {
            labels.forEach(function(label) {
              if (blur) {
                label.style.setProperty('filter', 'blur(8px)', 'important');
                label.style.setProperty('pointer-events', 'none', 'important');
              } else {
                label.style.removeProperty('filter');
                label.style.setProperty('pointer-events', 'inherit', 'important');
              }
            });
          }
          
          // Blur .vl-header
          var header = document.querySelector('.vl-header');
          if (header) {
            if (blur) {
              header.style.setProperty('filter', 'blur(8px)', 'important');
              header.style.setProperty('pointer-events', 'none', 'important');
            } else {
              header.style.removeProperty('filter');
              header.style.setProperty('pointer-events', 'inherit', 'important');
            }
          }
          
          // Blur .vl-main-menu
          var mainMenu = document.querySelector('.vl-main-menu');
          if (mainMenu) {
            if (blur) {
              mainMenu.style.setProperty('filter', 'blur(8px)', 'important');
              mainMenu.style.setProperty('pointer-events', 'none', 'important');
            } else {
              mainMenu.style.removeProperty('filter');
              mainMenu.style.setProperty('pointer-events', 'inherit', 'important');
            }
          }
          
          // Blur .vl-right-sidebar
          var rightSidebar = document.querySelector('.vl-right-sidebar');
          if (rightSidebar) {
            if (blur) {
              rightSidebar.style.setProperty('filter', 'blur(8px)', 'important');
              rightSidebar.style.setProperty('pointer-events', 'none', 'important');
            } else {
              rightSidebar.style.removeProperty('filter');
              rightSidebar.style.setProperty('pointer-events', 'inherit', 'important');
            }
          }
        }
        
        // Ensure panel parent doesn't create stacking context
        if (panel && panel.parentNode && panel.parentNode !== document.body) {
          var panelParent = panel.parentNode;
          // Check computed styles to see if parent creates stacking context
          var computedStyle = window.getComputedStyle(panelParent);
          if (computedStyle.position !== 'static' || computedStyle.zIndex !== 'auto') {
            // Force parent to not create stacking context
            panelParent.style.setProperty('position', 'static', 'important');
            panelParent.style.setProperty('z-index', 'auto', 'important');
            panelParent.style.setProperty('isolation', 'auto', 'important');
          }
        }
        var closeBtn=document.querySelector('.luna-close');
        var ended=document.querySelector('#luna-session-ended');

        async function hydrate(thread){
          if (!thread || thread.__hydrated) return;
          try{
            const res = await fetch('<?php echo esc_url_raw( rest_url('luna_widget/v1/chat/history') ); ?>');
            if (!res.ok) {
              console.warn('[Luna] Failed to fetch chat history:', res.status, res.statusText);
              thread.__hydrated = true;
              return;
            }
            const contentType = res.headers.get('content-type');
            if (!contentType || !contentType.includes('application/json')) {
              console.warn('[Luna] Response is not JSON, content-type:', contentType);
              thread.__hydrated = true;
              return;
            }
            const data = await res.json().catch(function(err){
              console.error('[Luna] JSON parse error in hydrate:', err);
              return {items: []};
            });
            var hasMessages = false;
            if (data && Array.isArray(data.items)) {
              data.items.forEach(function(turn){
                if (turn.user) { var u=document.createElement('div'); u.className='luna-msg luna-user'; u.textContent=turn.user; thread.appendChild(u); hasMessages = true; }
                if (turn.assistant) { var a=document.createElement('div'); a.className='luna-msg luna-assistant'; a.textContent=turn.assistant; thread.appendChild(a); hasMessages = true; }
              });
              thread.scrollTop = thread.scrollHeight;
            }
            thread.__hydrated = true;
            
            // Auto-send initial greeting if thread is empty
            if (!hasMessages) {
              setTimeout(function(){
                sendInitialGreeting(thread);
              }, 300);
            }
          }catch(e){ 
            console.warn('[Luna] hydrate failed', e);
            // If hydration fails, still try to send greeting if thread is empty
            if (!thread.__hydrated && thread.children.length === 0) {
              setTimeout(function(){
                sendInitialGreeting(thread);
              }, 300);
            }
          }
          finally { thread.__hydrated = true; }
        }
        
        function sendInitialGreeting(thread){
          if (!thread) return;
          // CRITICAL: Ensure chatStarted is false when sending initial greeting
          // This prevents the timer from starting just because the panel opened
          if (sessionState) {
            sessionState.chatStarted = false;
          }
          if (window.LunaChatSession) {
            window.LunaChatSession.chatStarted = false;
          }
          // Cancel any existing timers
          if (sessionState && typeof sessionState.cancelTimers === 'function') {
            sessionState.cancelTimers();
          }
          // Check if thread already has messages (but allow if it's just the session ended message)
          var existingMessages = thread.querySelectorAll('.luna-msg');
          var hasNonEndedMessages = false;
          for (var i = 0; i < existingMessages.length; i++) {
            if (!existingMessages[i].classList.contains('luna-session-closure')) {
              hasNonEndedMessages = true;
              break;
            }
          }
          if (hasNonEndedMessages && existingMessages.length > 0) return;
          
          // Get license key from URL or stored option
          var licenseKey = '';
          var urlParams = new URLSearchParams(window.location.search);
          var urlLicense = urlParams.get('license');
            if (urlLicense) {
              // Extract license key from URL (may include path segments)
              licenseKey = urlLicense.split('/')[0];
          } else {
            // Try to get from stored option (for frontend sites)
            try {
              var storedLicense = '<?php echo esc_js( get_option(LUNA_WIDGET_OPT_LICENSE, '') ); ?>';
              if (storedLicense) {
                licenseKey = storedLicense;
              }
            } catch(e) {
              console.warn('[Luna] Could not get stored license key');
            }
          }
          
          // Create greeting message with buttons
          var greetingEl = document.createElement('div');
          greetingEl.className = 'luna-msg luna-assistant luna-initial-greeting';
          
          var greetingText = document.createElement('div');
          greetingText.className = 'luna-greeting-text';
          greetingText.textContent = 'Hi, there! I\'m Luna, your personal WebOps agent and AI companion. How would you like to continue?';
          greetingEl.appendChild(greetingText);
          
          // Create buttons container
          var buttonsContainer = document.createElement('div');
          buttonsContainer.className = 'luna-greeting-buttons';
          
          // Get button descriptions from settings
          var buttonDescs = {
            chat: '<?php echo esc_js( isset($ui['button_desc_chat']) ? $ui['button_desc_chat'] : 'Start a conversation with Luna to ask questions and get answers about your digital universe.' ); ?>',
            report: '<?php echo esc_js( isset($ui['button_desc_report']) ? $ui['button_desc_report'] : 'Generate comprehensive reports about your site health, performance, and security.' ); ?>',
            compose: '<?php echo esc_js( isset($ui['button_desc_compose']) ? $ui['button_desc_compose'] : 'Access Luna Composer to use canned prompts and responses for quick interactions.' ); ?>',
            automate: '<?php echo esc_js( isset($ui['button_desc_automate']) ? $ui['button_desc_automate'] : 'Set up automated workflows and tasks with Luna to streamline your operations.' ); ?>'
          };
          
          // Helper function to create button with question mark icon
          function createGreetingButton(text, className, description, clickHandler) {
            var btn = document.createElement('button');
            btn.className = 'luna-greeting-btn ' + className;
            btn.style.position = 'relative';
            btn.style.display = 'flex';
            btn.style.alignItems = 'center';
            btn.style.justifyContent = 'space-between';
            btn.style.padding = '10px 14px';
            
            var btnText = document.createElement('span');
            btnText.textContent = text;
            btnText.style.flex = '1';
            btn.appendChild(btnText);
            
            var questionMark = document.createElement('span');
            questionMark.className = 'luna-greeting-help';
            questionMark.textContent = '?';
            questionMark.style.cssText = 'width:20px;height:20px;border-radius:50%;background-color:rgba(255,255,255,.15);display:flex;align-items:center;justify-content:center;font-size:0.85rem;font-weight:600;cursor:help;margin-left:8px;flex-shrink:0;transition:background-color 0.2s ease;';
            questionMark.setAttribute('data-description', description);
            questionMark.setAttribute('aria-label', 'Help');
            questionMark.addEventListener('mouseenter', function(e){
              e.stopPropagation();
              showButtonTooltip(questionMark, description);
            });
            questionMark.addEventListener('mouseleave', function(e){
              e.stopPropagation();
              hideButtonTooltip();
            });
            btn.appendChild(questionMark);
            
            btn.addEventListener('click', clickHandler);
            return btn;
          }
          
          // Luna Chat button
          var chatBtn = createGreetingButton('Luna Chat', 'luna-greeting-btn-chat', buttonDescs.chat, function(e){
            e.preventDefault();
            e.stopPropagation();
            // Remove greeting buttons
            greetingEl.querySelector('.luna-greeting-buttons').remove();
            // Auto-reply with chat message
            var chatMsg = document.createElement('div');
            chatMsg.className = 'luna-msg luna-assistant';
            chatMsg.textContent = 'Let\'s do this! Ask me anything to begin exploring...';
            thread.appendChild(chatMsg);
            thread.scrollTop = thread.scrollHeight;
            // Mark that user has started a chat session - inactivity timer will now be active
            // Set BOTH sessionState and window.LunaChatSession to ensure sync
            // CRITICAL: This is the ONLY place where chatStarted should be set to true
            sessionState.chatStarted = true;
            if (window.LunaChatSession) {
              window.LunaChatSession.chatStarted = true;
            }
            // Now that session has started, mark activity to begin the timer
            // But only after a small delay to ensure state is set
            setTimeout(function() {
              if (sessionState.chatStarted) {
                markActivity();
              }
            }, 100);
            // Start inactivity timer when user sends their first message (via markActivity)
            // The timer will start automatically when user interacts with the chat input
          });
          buttonsContainer.appendChild(chatBtn);
          
          // Luna Report button
          var reportBtn = createGreetingButton('Luna Report', 'luna-greeting-btn-report', buttonDescs.report, function(e){
            e.preventDefault();
            e.stopPropagation();
            // End session and close widget before redirecting
            if (window.LunaChatSession) {
              if (typeof window.LunaChatSession.cancelTimers === 'function') {
                window.LunaChatSession.cancelTimers();
              }
              // Mark session as ended
              window.LunaChatSession.closing = true;
            }
            var panel = document.getElementById('luna-panel');
            if (panel) {
              panel.classList.remove('show');
            }
            var fab = document.querySelector('.luna-launcher');
            if (fab) {
              fab.setAttribute('aria-expanded', 'false');
            }
            if (licenseKey) {
              window.location.href = 'https://supercluster.visiblelight.ai/?license=' + encodeURIComponent(licenseKey) + '/luna/report/';
            } else {
              console.warn('[Luna] License key not available for redirect');
            }
          });
          buttonsContainer.appendChild(reportBtn);
          
          // Luna Composer button
          var composeBtn = createGreetingButton('Luna Compose', 'luna-greeting-btn-compose', buttonDescs.compose, function(e){
            e.preventDefault();
            e.stopPropagation();
            // End session and close widget before redirecting
            if (window.LunaChatSession) {
              if (typeof window.LunaChatSession.cancelTimers === 'function') {
                window.LunaChatSession.cancelTimers();
              }
              // Mark session as ended
              window.LunaChatSession.closing = true;
            }
            var panel = document.getElementById('luna-panel');
            if (panel) {
              panel.classList.remove('show');
            }
            var fab = document.querySelector('.luna-launcher');
            if (fab) {
              fab.setAttribute('aria-expanded', 'false');
            }
            if (licenseKey) {
              window.location.href = 'https://supercluster.visiblelight.ai/?license=' + encodeURIComponent(licenseKey) + '/luna/compose/';
            } else {
              console.warn('[Luna] License key not available for redirect');
            }
          });
          buttonsContainer.appendChild(composeBtn);
          
          // Luna Automate button
          var automateBtn = createGreetingButton('Luna Automate', 'luna-greeting-btn-automate', buttonDescs.automate, function(e){
            e.preventDefault();
            e.stopPropagation();
            // End session and close widget before redirecting
            if (window.LunaChatSession) {
              if (typeof window.LunaChatSession.cancelTimers === 'function') {
                window.LunaChatSession.cancelTimers();
              }
              // Mark session as ended
              window.LunaChatSession.closing = true;
            }
            var panel = document.getElementById('luna-panel');
            if (panel) {
              panel.classList.remove('show');
            }
            var fab = document.querySelector('.luna-launcher');
            if (fab) {
              fab.setAttribute('aria-expanded', 'false');
            }
            if (licenseKey) {
              window.location.href = 'https://supercluster.visiblelight.ai/?license=' + encodeURIComponent(licenseKey) + '/luna/automate/';
            } else {
              console.warn('[Luna] License key not available for redirect');
            }
          });
          buttonsContainer.appendChild(automateBtn);
          
          // Tooltip functions
          var tooltip = null;
          function showButtonTooltip(element, description) {
            if (tooltip) {
              tooltip.remove();
            }
            tooltip = document.createElement('div');
            tooltip.className = 'luna-greeting-tooltip';
            tooltip.textContent = description;
            tooltip.style.cssText = 'position:absolute;background:#000;color:#fff4e9;padding:12px 16px;border-radius:8px;font-size:0.85rem;line-height:1.4;max-width:280px;z-index:999999;box-shadow:0 4px 12px rgba(0,0,0,0.4);pointer-events:none;border:1px solid #5A5753;';
            document.body.appendChild(tooltip);
            
            var rect = element.getBoundingClientRect();
            var tooltipRect = tooltip.getBoundingClientRect();
            var left = rect.left + (rect.width / 2) - (tooltipRect.width / 2);
            var top = rect.top - tooltipRect.height - 8;
            
            if (left < 10) left = 10;
            if (left + tooltipRect.width > window.innerWidth - 10) {
              left = window.innerWidth - tooltipRect.width - 10;
            }
            if (top < 10) {
              top = rect.bottom + 8;
            }
            
            tooltip.style.left = left + 'px';
            tooltip.style.top = top + 'px';
          }
          
          function hideButtonTooltip() {
            if (tooltip) {
              tooltip.remove();
              tooltip = null;
            }
          }
          
          greetingEl.appendChild(buttonsContainer);
          thread.appendChild(greetingEl);
          thread.scrollTop = thread.scrollHeight;
          
          // Log the greeting to the conversation
          try {
            fetch('<?php echo esc_url_raw( rest_url('luna_widget/v1/chat') ); ?>', {
              method: 'POST',
              headers: {'Content-Type':'application/json'},
              body: JSON.stringify({ prompt: '', greeting: true })
            }).catch(function(err){
              console.warn('[Luna] greeting log failed', err);
            });
          } catch(err){
            console.warn('[Luna] greeting fetch error', err);
          }
        }
        function showEnded(){
          if (ended) ended.classList.add('show');
          if (panel) panel.classList.remove('show');
          blurSuperclusterElements(false);
          if (fab) fab.setAttribute('aria-expanded','false');
        }
        function hideEnded(){
          if (ended) ended.classList.remove('show');
        }
        window.__lunaShowSessionEnded = showEnded;
        window.__lunaHideSessionEnded = hideEnded;
        function toggle(open){
          if(!panel||!fab) return;
          var will=(typeof open==='boolean')?open:!panel.classList.contains('show');
          // Only show ended state if explicitly closing and session is actually closing
          if (will && window.LunaChatSession && window.LunaChatSession.closing === true) {
            showEnded();
            return;
          }
          if (will && ended) ended.classList.remove('show');
          
          // Use requestAnimationFrame to ensure smooth display
          requestAnimationFrame(function(){
            // Set z-index BEFORE toggling classes
            if (will) {
              // Ensure fab has highest z-index with !important
              var fabContainer = fab ? (fab.closest('.luna-fab') || fab.parentElement) : null;
              if (fabContainer) {
                fabContainer.style.setProperty('z-index', '2147483647', 'important');
                fabContainer.style.setProperty('position', 'fixed', 'important');
              }
              if (fab) {
                fab.style.setProperty('z-index', '2147483647', 'important');
              }
            }
            
          panel.classList.toggle('show',will);
            
            // Blur/unblur Supercluster elements
            blurSuperclusterElements(will);
          fab.setAttribute('aria-expanded',will?'true':'false');
            
            // Hide/show galaxy labels
            var labels = document.querySelectorAll('.vl-supercluster-labels');
            if (labels && labels.length > 0) {
              labels.forEach(function(label){
          if (will) {
                  label.style.display = 'none';
                  label.style.visibility = 'hidden';
                  label.style.opacity = '0';
                } else {
                  label.style.display = '';
                  label.style.visibility = '';
                  label.style.opacity = '';
                }
              });
            }
            
            if (will) {
              // Force panel to stay visible with highest z-index using !important
              panel.style.setProperty('z-index', '2147483647', 'important');
              panel.style.setProperty('position', 'fixed', 'important');
              panel.style.setProperty('display', 'flex', 'important');
              panel.style.setProperty('visibility', 'visible', 'important');
              panel.style.setProperty('opacity', '1', 'important');
              
              // Ensure fab has highest z-index and is positioned correctly with !important
              var fabContainer = fab ? (fab.closest('.luna-fab') || fab.parentElement) : null;
              if (fabContainer) {
                fabContainer.style.setProperty('z-index', '2147483647', 'important');
                fabContainer.style.setProperty('position', 'fixed', 'important');
              }
              if (fab) {
                fab.style.setProperty('z-index', '2147483647', 'important');
              }
              
              // Hydrate after a small delay to ensure panel is visible
              setTimeout(function(){
            hydrate(panel.querySelector('.luna-thread'));
            if (window.LunaChatSession && typeof window.LunaChatSession.onPanelToggle === 'function') {
              window.LunaChatSession.onPanelToggle(true);
            }
              }, 50);
          } else {
              // Explicitly hide panel when closing
              panel.style.setProperty('display', 'none', 'important');
              panel.style.setProperty('visibility', 'hidden', 'important');
              panel.style.setProperty('opacity', '0', 'important');
            if (window.LunaChatSession && typeof window.LunaChatSession.onPanelToggle === 'function') {
              window.LunaChatSession.onPanelToggle(false);
            }
            hideEnded();
          }
          });
        }
        if(fab) fab.addEventListener('click', function(e){ 
          e.stopPropagation(); 
          // If panel is already showing, close it; otherwise open it
          if (panel && panel.classList.contains('show')) {
            toggle(false);
          } else {
            toggle(true);
          }
        });
        // Use event delegation for close button to ensure it always works
        // Attach to document to catch all close button clicks
        document.addEventListener('click', function(e){
          // Check if clicked element or its parent is the close button
          var closeBtn = e.target;
          if (!closeBtn.classList.contains('luna-close')) {
            closeBtn = e.target.closest('.luna-close');
          }
          
          if (closeBtn && closeBtn.classList.contains('luna-close')) {
            e.preventDefault();
            e.stopPropagation();
            console.log('[Luna] Close button clicked');
            
            // Check if chat session is active
            var thread = document.querySelector('#luna-panel .luna-thread') || document.querySelector('.luna-thread');
            var isActiveSession = thread && (thread.querySelectorAll('.luna-msg.luna-user, .luna-msg.luna-assistant').length > 0);
            
            if (isActiveSession) {
              // Show confirmation popover for active sessions
              // Try to use window.LunaChatSession if available, otherwise use fallback
              var showConfirmation = function() {
                if (window.LunaChatSession && typeof window.LunaChatSession.showCloseConfirmation === 'function') {
                  console.log('[Luna] Using window.LunaChatSession.showCloseConfirmation');
                  window.LunaChatSession.showCloseConfirmation();
                  return true;
                }
                
                // Fallback: create confirmation directly
                if (thread && !thread.querySelector('.luna-close-confirmation')) {
                  console.log('[Luna] Creating fallback confirmation popover');
                  var confirmationEl = document.createElement('div');
                  confirmationEl.className = 'luna-msg luna-assistant luna-close-confirmation';
                  confirmationEl.style.cssText = 'position:fixed;bottom:80px;left:50%;transform:translateX(-50%);z-index:1000001;background:#000;border:1px solid #5A5753;border-radius:12px;padding:20px;min-width:280px;max-width:90%;box-shadow:0 8px 24px rgba(0,0,0,0.4);display:flex;flex-direction:column;gap:16px;';
                  
                  var messageText = document.createElement('div');
                  messageText.textContent = 'Would you like to end your chat session with Luna?';
                  messageText.style.cssText = 'color:#fff4e9;font-size:15px;font-weight:500;text-align:center;margin:0;';
                  confirmationEl.appendChild(messageText);
                  
                  var buttonsContainer = document.createElement('div');
                  buttonsContainer.style.cssText = 'display:flex;gap:10px;justify-content:center;';
                  
                  var yesBtn = document.createElement('button');
                  yesBtn.textContent = 'Yes';
                  yesBtn.style.cssText = 'background:#2c74ff;color:#fff;border:0;border-radius:6px;padding:10px 24px;font-weight:600;cursor:pointer;min-width:80px;';
                  yesBtn.addEventListener('click', function(){
                    if (confirmationEl.parentNode) {
                      confirmationEl.parentNode.removeChild(confirmationEl);
                    }
                    toggle(false);
                    // Try to end session via window.LunaChatSession if available
                    if (window.LunaChatSession && typeof window.LunaChatSession.endSessionManually === 'function') {
                      window.LunaChatSession.endSessionManually();
                    } else {
                      // Fallback: manually end session
                      var message = 'This chat session has been closed.';
                      var endedMsg = document.createElement('div');
                      endedMsg.className = 'luna-msg luna-assistant luna-session-closure';
                      endedMsg.style.cssText = 'display:flex;flex-direction:column;gap:12px;';
                      var endedText = document.createElement('div');
                      endedText.textContent = message;
                      endedMsg.appendChild(endedText);
                      var downloadBtn = document.createElement('button');
                      downloadBtn.className = 'luna-download-transcript';
                      downloadBtn.textContent = 'Download Transcript';
                      downloadBtn.style.cssText = 'background:#fff4e9;color:#000000;border:1px solid #1f1d1a;border-radius:6px;padding:8px 16px;font-weight:600;cursor:pointer;align-self:flex-start;margin-top:8px;';
                      downloadBtn.addEventListener('click', function(e){
                        e.preventDefault();
                        e.stopPropagation();
                        if (typeof window.downloadTranscript === 'function') {
                          window.downloadTranscript();
                        } else if (typeof downloadTranscript === 'function') {
                          downloadTranscript();
                        } else {
                          alert('Please wait for Luna to initialize, then try again.');
                        }
                        return false;
                      });
                      endedMsg.appendChild(downloadBtn);
                      if (thread) {
                        thread.appendChild(endedMsg);
                        thread.scrollTop = thread.scrollHeight;
                      }
                    }
                  });
                  buttonsContainer.appendChild(yesBtn);
                  
                  var noBtn = document.createElement('button');
                  noBtn.textContent = 'No';
                  noBtn.style.cssText = 'background:#2E2C2A;color:#fff4e9;border:1px solid #5A5753;border-radius:6px;padding:10px 24px;font-weight:600;cursor:pointer;min-width:80px;';
                  noBtn.addEventListener('click', function(){
                    if (confirmationEl.parentNode) {
                      confirmationEl.parentNode.removeChild(confirmationEl);
                    }
                  });
                  buttonsContainer.appendChild(noBtn);
                  
                  confirmationEl.appendChild(buttonsContainer);
                  thread.appendChild(confirmationEl);
                  thread.scrollTop = thread.scrollHeight;
                  return true;
                }
                return false;
              };
              
              // Try immediately, then retry after a short delay if needed
              var shown = showConfirmation();
              if (!shown) {
                setTimeout(function(){
                  // Check if confirmation was shown, if not try again
                  if (thread && !thread.querySelector('.luna-close-confirmation')) {
                    showConfirmation();
                  }
                }, 100);
              }
            } else {
              // No active session, just close
              toggle(false);
            }
          }
        });
        if(ended){
          var restartBtn = ended.querySelector('.luna-session-restart');
          if (restartBtn) restartBtn.addEventListener('click', function(){
            if (window.LunaChatSession && typeof window.LunaChatSession.restartSession === 'function') {
              window.LunaChatSession.restartSession();
            }
          });
          var downloadBtn = ended.querySelector('.luna-download-transcript');
          if (downloadBtn) {
            // Remove any existing event listeners by cloning the button
            var newBtn = downloadBtn.cloneNode(true);
            downloadBtn.parentNode.replaceChild(newBtn, downloadBtn);
            downloadBtn = newBtn;
            
            downloadBtn.addEventListener('click', function(e){
              e.preventDefault();
              e.stopPropagation();
              if (typeof window.downloadTranscript === 'function') {
                window.downloadTranscript();
              } else if (typeof downloadTranscript === 'function') {
                downloadTranscript();
              } else {
                console.error('[Luna] downloadTranscript function not found');
                alert('Error: Download transcript function not available. Please refresh the page.');
              }
            });
          }
        }
        document.addEventListener('keydown', function(e){
          if(e.key==='Escape'){
            toggle(false);
            hideEnded();
          }
        });
      })();
    </script>
    <?php
  }
  ?>
  <script>
    (function(){
      if (typeof window.chat_inactive_response !== 'function') {
        window.chat_inactive_response = function () {
          return "I haven't heard from you in a while, are you still there? If not, I'll close out this chat automatically in 3 minutes.";
        };
      }

      if (window.__lunaBoot) return;
      window.__lunaBoot = true;

      const defaultInactivityMessage = "I haven't heard from you in a while, are you still there? If not, I'll close out this chat automatically in 3 minutes.";
      const defaultSessionEndMessage = "This chat session has been closed due to inactivity.";

      const sessionState = {
        inactivityDelay: 120000,
        closureDelay: 180000,
        inactivityTimer: null,
        closureTimer: null,
        closing: false,
        restarting: false,
        _inlineEndedCard: null,
        chatStarted: false // Track if user has clicked "Luna Chat" and started a chat session
      };

      const chatEndpoint = '<?php echo esc_url_raw( rest_url('luna_widget/v1/chat') ); ?>';
      const chatHistoryEndpoint = '<?php echo esc_url_raw( rest_url('luna_widget/v1/chat/history') ); ?>';
      const chatInactiveEndpoint = '<?php echo esc_url_raw( rest_url('luna_widget/v1/chat/inactive') ); ?>';
      const chatSessionEndEndpoint = '<?php echo esc_url_raw( rest_url('luna_widget/v1/chat/session/end') ); ?>';
      const chatSessionResetEndpoint = '<?php echo esc_url_raw( rest_url('luna_widget/v1/chat/session/reset') ); ?>';

      function resolveInactivityMessage() {
        try {
          if (typeof window.chat_inactive_response === 'function') {
            var custom = window.chat_inactive_response();
            if (custom && typeof custom === 'string') {
              return custom;
            }
          }
        } catch (err) {
          console.warn('[Luna] inactive response error', err);
        }
        return defaultInactivityMessage;
      }

      function resolveSessionEndMessage() {
        return defaultSessionEndMessage;
      }

      function getPrimaryThread() {
        return document.querySelector('#luna-panel .luna-thread') || document.querySelector('.luna-thread');
      }

      function appendAssistantMessage(thread, message, extraClass) {
        if (!thread || !message) return null;
        var el = document.createElement('div');
        el.className = 'luna-msg luna-assistant' + (extraClass ? ' ' + extraClass : '');
        el.textContent = message;
        thread.appendChild(el);
        thread.scrollTop = thread.scrollHeight;
        return el;
      }

      function cancelTimers() {
        if (sessionState.inactivityTimer) {
          clearTimeout(sessionState.inactivityTimer);
          sessionState.inactivityTimer = null;
        }
        // Don't clear closure timer here - it should only be cleared when user actively responds
        // The closure timer will be cleared in markActivity() if user responds after warning
      }
      
      function cancelAllTimers() {
        // Cancel all timers including closure timer (used when user actively responds after inactivity warning)
        if (sessionState.inactivityTimer) {
          clearTimeout(sessionState.inactivityTimer);
          sessionState.inactivityTimer = null;
        }
        if (sessionState.closureTimer) {
          clearTimeout(sessionState.closureTimer);
          sessionState.closureTimer = null;
        }
      }

      function setFormsDisabled(disabled) {
        document.querySelectorAll('.luna-form .luna-input').forEach(function(input){
          input.disabled = disabled;
          if (disabled) input.blur();
        });
        document.querySelectorAll('.luna-form .luna-send').forEach(function(button){
          button.disabled = disabled;
        });
      }

      function showSessionEndedUI() {
        if (typeof window.__lunaShowSessionEnded === 'function') {
          window.__lunaShowSessionEnded();
        } else {
          // Try to find panel or wrap
          var panel = document.querySelector('#luna-panel');
          var wrap = document.querySelector('.luna-wrap');
          var container = panel || wrap;
          
          if (container) {
            // Hide thread and form
            var threads = container.querySelectorAll('.luna-thread');
            var forms = container.querySelectorAll('.luna-form');
            threads.forEach(function(el){ el.style.display = 'none'; });
            forms.forEach(function(el){ el.style.display = 'none'; });
            
            // Check if inline card already exists
            var existingCard = container.querySelector('.luna-session-ended-inline');
            if (existingCard) {
              sessionState._inlineEndedCard = existingCard;
              existingCard.style.display = 'block';
              return;
            }
            
            // Create new inline card
            var card = document.createElement('div');
            card.className = 'luna-session-ended-inline';
            card.style.cssText = 'margin-top:12px;background:#000;border:1px solid #5A5753;border-radius:12px;padding:24px 20px;text-align:center;display:flex;flex-direction:column;gap:12px;align-items:center;';
            
            var h2 = document.createElement('h2');
            h2.textContent = 'Your session has ended';
            h2.style.cssText = 'margin:0;font-size:1.25rem;';
            card.appendChild(h2);
            
            var downloadBtn = document.createElement('button');
            downloadBtn.type = 'button';
            downloadBtn.className = 'luna-download-transcript';
            downloadBtn.textContent = 'Download Transcript';
            downloadBtn.style.cssText = 'background:#fff4e9;color:#000000;border:1px solid #1f1d1a;border-radius:6px;padding:8px 16px;font-weight:600;cursor:pointer;width:100%;';
            downloadBtn.addEventListener('click', function(e){
              e.preventDefault();
              e.stopPropagation();
              if (typeof window.downloadTranscript === 'function') {
                window.downloadTranscript();
              } else if (typeof downloadTranscript === 'function') {
                downloadTranscript();
              } else {
                alert('Please wait for Luna to initialize, then try again.');
              }
              return false;
            });
            card.appendChild(downloadBtn);
            
            var p = document.createElement('p');
            p.textContent = 'Start another one now.';
            p.style.cssText = 'margin:12px 0 0 0;color:#ccc;';
            card.appendChild(p);
            
            var restartBtn = document.createElement('button');
            restartBtn.type = 'button';
            restartBtn.className = 'luna-session-restart';
            restartBtn.textContent = 'Start New Session';
            restartBtn.style.cssText = 'background:#2c74ff;color:#fff;border:0;border-radius:8px;padding:10px 18px;font-weight:600;cursor:pointer;';
            restartBtn.addEventListener('click', function(){ restartSession(); });
            card.appendChild(restartBtn);
            
            container.appendChild(card);
            sessionState._inlineEndedCard = card;
          }
        }
      }
      
      function downloadTranscript() {
        // Always fetch full transcript from server to ensure completeness
        var transcript = 'Luna Chat Transcript\n';
        transcript += '====================\n\n';
        transcript += 'Date: ' + new Date().toLocaleString() + '\n\n';
        
        // Fetch full conversation history from server
        fetch(chatHistoryEndpoint)
          .then(function(r){ 
            if (!r.ok) {
              throw new Error('Failed to fetch history: ' + r.status);
            }
            return r.json().catch(function(){return {};}); 
          })
          .then(function(d){
            var hasMessages = false;
            
            // Process server history (most complete source)
            if (d && Array.isArray(d.items) && d.items.length > 0) {
              hasMessages = true;
              d.items.forEach(function(turn){
                if (turn.user && turn.user.trim()) {
                  transcript += 'User: ' + turn.user.trim() + '\n\n';
                }
                if (turn.assistant && turn.assistant.trim()) {
                  transcript += 'Luna: ' + turn.assistant.trim() + '\n\n';
                }
              });
            }
            
            // Also check thread for any messages not yet saved to server
            var thread = getPrimaryThread();
            if (thread) {
              var messages = thread.querySelectorAll('.luna-msg');
              messages.forEach(function(msg) {
                var isUser = msg.classList.contains('luna-user');
                var isAssistant = msg.classList.contains('luna-assistant');
                var isConfirmation = msg.classList.contains('luna-close-confirmation');
                
                // Skip confirmation messages, initial greeting buttons, and session closure messages
                if (isConfirmation || msg.classList.contains('luna-initial-greeting') || msg.classList.contains('luna-session-closure')) {
                  return;
                }
                
                var text = msg.textContent || msg.innerText || '';
                text = text.trim();
                
                // Only add if not already in transcript (check last few lines)
                if (text && !transcript.includes('User: ' + text) && !transcript.includes('Luna: ' + text)) {
                  if (isUser) {
                    transcript += 'User: ' + text + '\n\n';
                    hasMessages = true;
                  } else if (isAssistant) {
                    transcript += 'Luna: ' + text + '\n\n';
                    hasMessages = true;
                  }
                }
              });
            }
            
            if (hasMessages) {
              downloadFile(transcript);
            } else {
              alert('No transcript available. The conversation may not have started yet.');
            }
          })
          .catch(function(err){
            console.error('[Luna] Error fetching history for transcript:', err);
            
            // Fallback: try to get messages from thread
            var thread = getPrimaryThread();
            var hasMessages = false;
            var fallbackTranscript = 'Luna Chat Transcript\n';
            fallbackTranscript += '====================\n\n';
            fallbackTranscript += 'Date: ' + new Date().toLocaleString() + '\n\n';
            fallbackTranscript += 'Note: Full history unavailable, showing visible messages only.\n\n';
            
            if (thread) {
              var messages = thread.querySelectorAll('.luna-msg');
              messages.forEach(function(msg) {
                var isUser = msg.classList.contains('luna-user');
                var isAssistant = msg.classList.contains('luna-assistant');
                var isConfirmation = msg.classList.contains('luna-close-confirmation');
                
                if (isConfirmation || msg.classList.contains('luna-initial-greeting') || msg.classList.contains('luna-session-closure')) {
                  return;
                }
                
                var text = msg.textContent || msg.innerText || '';
                text = text.trim();
                
                if (text) {
                  if (isUser) {
                    fallbackTranscript += 'User: ' + text + '\n\n';
                    hasMessages = true;
                  } else if (isAssistant) {
                    fallbackTranscript += 'Luna: ' + text + '\n\n';
                    hasMessages = true;
                  }
                }
              });
            }
            
            if (hasMessages) {
              downloadFile(fallbackTranscript);
            } else {
              alert('No transcript available. Please try again or refresh the page.');
            }
          });
      }
      
      // Expose downloadTranscript globally so it's accessible from HTML buttons
      window.downloadTranscript = downloadTranscript;
      
      // Setup event listeners for download transcript buttons
      function setupDownloadTranscriptButtons() {
        var buttons = document.querySelectorAll('.luna-download-transcript');
        buttons.forEach(function(btn) {
          // Remove any existing listeners by cloning the button
          var newBtn = btn.cloneNode(true);
          btn.parentNode.replaceChild(newBtn, btn);
          // Add click event listener
          newBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            if (typeof window.downloadTranscript === 'function') {
              window.downloadTranscript();
            } else if (typeof downloadTranscript === 'function') {
              downloadTranscript();
            } else {
              alert('Please wait for Luna to initialize, then try again.');
            }
            return false;
          });
        });
      }
      
      // Setup buttons immediately and also on DOMContentLoaded
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', setupDownloadTranscriptButtons);
      } else {
        setupDownloadTranscriptButtons();
      }
      
      // Also setup buttons after a short delay to catch dynamically added buttons
      setTimeout(setupDownloadTranscriptButtons, 1000);
      
      function downloadFile(transcript) {
        if (!transcript || transcript.trim() === 'Luna Chat Transcript\n====================\n\nDate: ' + new Date().toLocaleString() + '\n\n') {
          alert('No transcript available.');
          return;
        }
        
        try {
          // Create and download file
          var blob = new Blob([transcript], { type: 'text/plain;charset=utf-8' });
          var url = URL.createObjectURL(blob);
          var a = document.createElement('a');
          a.href = url;
          a.download = 'luna-chat-transcript-' + new Date().toISOString().split('T')[0] + '.txt';
          a.style.display = 'none';
          document.body.appendChild(a);
          a.click();
          
          // Clean up after a short delay
          setTimeout(function() {
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
          }, 100);
        } catch (err) {
          console.error('[Luna] Error downloading transcript:', err);
          alert('Error downloading transcript. Please try again.');
        }
      }
      
      // Expose downloadFile globally as well
      window.downloadFile = downloadFile;

      function hideSessionEndedUI() {
        if (typeof window.__lunaHideSessionEnded === 'function') {
          window.__lunaHideSessionEnded();
        }
        if (sessionState._inlineEndedCard) {
          var card = sessionState._inlineEndedCard;
          sessionState._inlineEndedCard = null;
          if (card.parentNode) card.parentNode.removeChild(card);
        }
        document.querySelectorAll('.luna-wrap .luna-thread').forEach(function(el){ el.style.display = ''; });
        document.querySelectorAll('.luna-wrap .luna-form').forEach(function(el){ el.style.display = ''; });
      }

      function markActivity() {
        if (sessionState.closing) return;
        // CRITICAL: Only start inactivity timer if user has clicked a button and started a chat session
        // Do NOT start timer if chatStarted is false (i.e., panel just opened, no button clicked)
        // Check sessionState first, then window.LunaChatSession as fallback
        var isSessionStarted = false;
        if (sessionState && sessionState.chatStarted === true) {
          isSessionStarted = true;
        } else if (window.LunaChatSession && window.LunaChatSession.chatStarted === true) {
          // Sync if window.LunaChatSession says it's started but sessionState doesn't
          if (sessionState) {
            sessionState.chatStarted = true;
          }
          isSessionStarted = true;
        }
        
        // If no session has started, do NOT start the timer
        if (!isSessionStarted) {
          return; // Exit early - no session started, don't start timer
        }
        
        // Only proceed if session is actually started
        // If user is responding after inactivity warning, cancel ALL timers including closure timer
        var thread = getPrimaryThread();
        if (thread && thread.__inactiveWarned) {
          // User responded after inactivity warning - cancel closure timer too
          cancelAllTimers();
          thread.__inactiveWarned = false;
        } else {
          // Normal activity - just cancel inactivity timer, not closure timer
          if (sessionState.inactivityTimer) {
            clearTimeout(sessionState.inactivityTimer);
            sessionState.inactivityTimer = null;
          }
        }
        
        // Restart inactivity timer
        sessionState.inactivityTimer = window.setTimeout(handleInactivityWarning, sessionState.inactivityDelay);
      }

      function handleInactivityWarning() {
        sessionState.inactivityTimer = null;
        if (sessionState.closing) return;
        // Only show inactivity warning if user has started a chat session
        if (!sessionState.chatStarted) return;
        var message = resolveInactivityMessage();
        var thread = getPrimaryThread();
        if (thread && !thread.__inactiveWarned) {
          thread.__inactiveWarned = true;
          appendAssistantMessage(thread, message);
          
          // Set closure timer for 3 minutes (180000ms) after inactivity warning
          // Clear any existing closure timer first
          if (sessionState.closureTimer) {
            clearTimeout(sessionState.closureTimer);
            sessionState.closureTimer = null;
          }
          
          // Set closure timer - this will fire after 3 minutes to close the session
          sessionState.closureTimer = window.setTimeout(function() {
            console.log('[Luna] Closure timer fired - closing session due to inactivity');
            handleSessionClosure();
          }, sessionState.closureDelay);
          
          console.log('[Luna] Inactivity warning shown, closure timer set for ' + (sessionState.closureDelay / 1000) + ' seconds (' + (sessionState.closureDelay / 60000) + ' minutes)');
        }
        try {
          fetch(chatInactiveEndpoint, {
            method: 'POST',
            headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ message: message })
          }).catch(function(err){
            console.warn('[Luna] inactive log failed', err);
          });
        } catch (err) {
          console.warn('[Luna] inactive fetch error', err);
        }
      }

      function handleSessionClosure() {
        sessionState.closureTimer = null;
        if (sessionState.closing) return;
        sessionState.closing = true;
        cancelTimers();
        var message = resolveSessionEndMessage();
        var thread = getPrimaryThread();
        if (thread && !thread.__sessionClosed) {
          thread.__sessionClosed = true;
          
          // Create session closure message with download button
          var endedMsg = document.createElement('div');
          endedMsg.className = 'luna-msg luna-assistant luna-session-closure';
          endedMsg.style.cssText = 'display:flex;flex-direction:column;gap:12px;';
          
          var endedText = document.createElement('div');
          endedText.textContent = message;
          endedMsg.appendChild(endedText);
          
          // Add download transcript button
          var downloadBtn = document.createElement('button');
          downloadBtn.className = 'luna-download-transcript';
          downloadBtn.textContent = 'Download Transcript';
          downloadBtn.style.cssText = 'background:#fff4e9;color:#000000;border:1px solid #1f1d1a;border-radius:6px;padding:8px 16px;font-weight:600;cursor:pointer;align-self:flex-start;margin-top:8px;';
          downloadBtn.addEventListener('click', function(e){
            e.preventDefault();
            e.stopPropagation();
            if (typeof window.downloadTranscript === 'function') {
              window.downloadTranscript();
            } else if (typeof downloadTranscript === 'function') {
              downloadTranscript();
            } else {
              alert('Please wait for Luna to initialize, then try again.');
            }
            return false;
          });
          endedMsg.appendChild(downloadBtn);
          
          thread.appendChild(endedMsg);
          thread.scrollTop = thread.scrollHeight;
        }
        setFormsDisabled(true);
        showSessionEndedUI();
        try {
          fetch(chatSessionEndEndpoint, {
            method: 'POST',
            headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ reason: 'inactivity', message: message })
          }).catch(function(err){
            console.warn('[Luna] session end failed', err);
          });
        } catch (err) {
          console.warn('[Luna] session end error', err);
        }
      }

      function clearThreads() {
        document.querySelectorAll('.luna-thread').forEach(function(thread){
          thread.innerHTML = '';
          thread.__hydrated = false;
          thread.__inactiveWarned = false;
          thread.__sessionClosed = false;
        });
      }

      function restartSession() {
        if (sessionState.restarting) return;
        sessionState.restarting = true;
        cancelTimers();
        // Reset chatStarted flag when session is restarted
        sessionState.chatStarted = false;
        document.querySelectorAll('.luna-session-restart').forEach(function(btn){
          btn.disabled = true;
        });
        try {
          fetch(chatSessionResetEndpoint, {
            method: 'POST',
            headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ reason: 'user_restart' })
          })
          .then(function(){
            sessionState.closing = false;
            setFormsDisabled(false);
            hideSessionEndedUI();
            clearThreads();
            if (typeof window.__lunaHydrateAny === 'function') {
              window.__lunaHydrateAny(true);
            } else {
              hydrateAny(true);
            }
            var panel = document.getElementById('luna-panel');
            if (panel) panel.classList.add('show');
            var fab = document.querySelector('.luna-launcher');
            if (fab) fab.setAttribute('aria-expanded','true');
            var input = document.querySelector('#luna-panel .luna-input') || document.querySelector('.luna-input');
            if (input) input.focus();
          })
          .catch(function(err){
            console.error('[Luna] session reset failed', err);
          })
          .finally(function(){
            sessionState.restarting = false;
            document.querySelectorAll('.luna-session-restart').forEach(function(btn){
              btn.disabled = false;
            });
          });
        } catch (err) {
          console.error('[Luna] session reset error', err);
          sessionState.restarting = false;
          document.querySelectorAll('.luna-session-restart').forEach(function(btn){
            btn.disabled = false;
          });
        }
      }

      function onPanelToggle(open) {
        // When panel opens, reset chatStarted to false UNLESS a button was already clicked
        // This prevents the inactivity timer from starting when the panel just opens
        if (open) {
          var thread = getPrimaryThread();
          
          // Only cancel inactivity timer, NOT closure timer (closure timer should continue if warning was shown)
          // If closure timer is active, it means inactivity warning was shown - keep it running
          if (sessionState.inactivityTimer) {
            clearTimeout(sessionState.inactivityTimer);
            sessionState.inactivityTimer = null;
          }
          
          // Only reset chatStarted if session is not closing and no closure timer is active
          // If closure timer is active, session is in progress of ending due to inactivity
          if (!sessionState.closing && !sessionState.closureTimer) {
            sessionState.chatStarted = false;
            if (window.LunaChatSession) {
              window.LunaChatSession.chatStarted = false;
            }
          }
          
          // Only clear inactivity warning flag if closure timer is not active
          // If closure timer is active, keep the warning state
          if (thread && !sessionState.closureTimer) {
            thread.__inactiveWarned = false;
            // Remove any existing inactivity warning messages only if closure timer is not active
            var inactiveWarnings = thread.querySelectorAll('.luna-msg.luna-assistant');
            inactiveWarnings.forEach(function(msg) {
              var text = msg.textContent || '';
              if (text.includes("I haven't heard from you") || text.includes("are you still there")) {
                // Only remove if closure timer is not active (session not ending)
                if (!sessionState.closureTimer && msg.parentNode) {
                  msg.parentNode.removeChild(msg);
                }
              }
            });
          }
        }
        if (open) {
          if (sessionState.closing) {
            // Show session ended message inline in thread, then show initial greeting
            var thread = getPrimaryThread();
            if (thread) {
              // Check if there's an existing session closure message without a button
              var existingClosure = thread.querySelector('.luna-session-closure');
              if (existingClosure) {
                // Check if it already has a download button
                var existingBtn = existingClosure.querySelector('.luna-download-transcript, button');
                if (!existingBtn) {
                  // Add download button to existing message
                  existingClosure.style.cssText = 'display:flex;flex-direction:column;gap:12px;';
                  
                  var downloadBtn = document.createElement('button');
                  downloadBtn.className = 'luna-download-transcript';
                  downloadBtn.textContent = 'Download Transcript';
                  downloadBtn.style.cssText = 'background:#fff4e9;color:#000000;border:1px solid #1f1d1a;border-radius:6px;padding:8px 16px;font-weight:600;cursor:pointer;align-self:flex-start;margin-top:8px;';
                  downloadBtn.addEventListener('click', function(e){
                    e.preventDefault();
                    e.stopPropagation();
                    if (typeof window.downloadTranscript === 'function') {
                      window.downloadTranscript();
                    } else if (typeof downloadTranscript === 'function') {
                      downloadTranscript();
                    } else {
                      alert('Please wait for Luna to initialize, then try again.');
                    }
                    return false;
                  });
                  existingClosure.appendChild(downloadBtn);
                }
              } else {
                // No existing closure message, create new one
                // Clear thread first
                thread.innerHTML = '';
                thread.__hydrated = false;
                thread.__inactiveWarned = false;
                thread.__sessionClosed = false;
                
                // Show session ended message
                var endedMsg = document.createElement('div');
                endedMsg.className = 'luna-msg luna-assistant luna-session-closure';
                endedMsg.style.cssText = 'display:flex;flex-direction:column;gap:12px;';
                
                var endedText = document.createElement('div');
                endedText.textContent = resolveSessionEndMessage();
                endedMsg.appendChild(endedText);
                
                // Add download transcript button
                var downloadBtn = document.createElement('button');
                downloadBtn.className = 'luna-download-transcript';
                downloadBtn.textContent = 'Download Transcript';
                downloadBtn.style.cssText = 'background:#fff4e9;color:#000000;border:1px solid #1f1d1a;border-radius:6px;padding:8px 16px;font-weight:600;cursor:pointer;align-self:flex-start;margin-top:8px;';
                downloadBtn.addEventListener('click', function(e){
                  e.preventDefault();
                  e.stopPropagation();
                  if (typeof window.downloadTranscript === 'function') {
                    window.downloadTranscript();
                  } else if (typeof downloadTranscript === 'function') {
                    downloadTranscript();
                  } else {
                    alert('Please wait for Luna to initialize, then try again.');
                  }
                  return false;
                });
                endedMsg.appendChild(downloadBtn);
                
                thread.appendChild(endedMsg);
                thread.scrollTop = thread.scrollHeight;
              }
              
              // Show initial greeting after a brief delay
              setTimeout(function(){
                sendInitialGreeting(thread);
              }, 500);
            }
            return;
          }
          markActivity();
        }
      }

      async function hydrateAny(forceAll){
        document.querySelectorAll('.luna-thread').forEach(async function(thread){
          if (!forceAll && thread.closest('#luna-panel')) return;
          if (!thread.__hydrated) {
            try{
              const r = await fetch(chatHistoryEndpoint);
              if (!r.ok) {
                console.warn('[Luna] Failed to fetch chat history:', r.status, r.statusText);
                thread.__hydrated = true;
                return;
              }
              const contentType = r.headers.get('content-type');
              if (!contentType || !contentType.includes('application/json')) {
                console.warn('[Luna] Response is not JSON, content-type:', contentType);
                thread.__hydrated = true;
                return;
              }
              const d = await r.json().catch(function(err){
                console.error('[Luna] JSON parse error in hydrate:', err);
                return {items: []};
              });
              if (d && Array.isArray(d.items)) {
                d.items.forEach(function(turn){
                  if (turn.user) { var u=document.createElement('div'); u.className='luna-msg luna-user'; u.textContent=turn.user; thread.appendChild(u); }
                  if (turn.assistant) { var a=document.createElement('div'); a.className='luna-msg luna-assistant'; a.textContent=turn.assistant; thread.appendChild(a); }
                });
                thread.scrollTop = thread.scrollHeight;
              }
            }catch(e){ console.warn('[Luna] hydrate failed', e); }
            finally { thread.__hydrated = true; }
          }
        });
      }

      function submitFrom(form){
        try{
          if (sessionState.closing) {
            showSessionEndedUI();
            return;
          }
          var input = form.querySelector('.luna-input'); if(!input) return;
          var text = (input.value||'').trim(); if(!text) return;

          markActivity();

          var thread = form.parentElement.querySelector('.luna-thread') || document.querySelector('.luna-thread');
          if (!thread) { thread = document.createElement('div'); thread.className='luna-thread'; form.parentElement.insertBefore(thread, form); }

          var btn = form.querySelector('.luna-send, button[type="submit"]');
          input.disabled=true; if(btn) btn.disabled=true;

          // Clear input immediately to show message was sent
          input.value='';

          // Add user message to thread
          var u=document.createElement('div'); u.className='luna-msg luna-user'; u.textContent=text; thread.appendChild(u); thread.scrollTop=thread.scrollHeight;

          // Add loading message with gradient animation
          var loadingEl=document.createElement('div'); 
          loadingEl.className='luna-msg luna-loading';
          var loadingSpan=document.createElement('span');
          loadingSpan.className='luna-loading-text';
          loadingSpan.textContent='Luna is considering all possibilities...';
          loadingEl.appendChild(loadingSpan);
          thread.appendChild(loadingEl);
          thread.scrollTop=thread.scrollHeight;

          fetch(chatEndpoint, {
            method: 'POST',
            headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ prompt: text })
          })
          .then(function(r){ 
            if (!r.ok) {
              console.error('[Luna] HTTP error:', r.status, r.statusText);
              return {error: 'HTTP ' + r.status + ': ' + r.statusText};
            }
            const contentType = r.headers.get('content-type');
            if (!contentType || !contentType.includes('application/json')) {
              console.error('[Luna] Response is not JSON, content-type:', contentType);
              return r.text().then(function(text){
                console.error('[Luna] Response body:', text.substring(0, 200));
                return {error: 'Invalid response format (not JSON)'};
              });
            }
            return r.json().catch(function(err){
              console.error('[Luna] JSON parse error:', err);
              return r.text().then(function(text){
                console.error('[Luna] Response body that failed to parse:', text.substring(0, 200));
                return {error: 'Invalid response format (JSON parse failed)'};
              });
            }); 
          })
          .then(function(d){
            // Remove loading message
            if (loadingEl && loadingEl.parentNode) {
              loadingEl.parentNode.removeChild(loadingEl);
            }
            console.log('[Luna] Response data:', d);
            var msg = (d && d.answer) ? d.answer : (d.error ? ('Error: '+d.error) : 'Sorry—no response.');
            appendAssistantMessage(thread, msg);
          })
          .catch(function(err){
            // Remove loading message
            if (loadingEl && loadingEl.parentNode) {
              loadingEl.parentNode.removeChild(loadingEl);
            }
            var e=document.createElement('div'); e.className='luna-msg luna-assistant'; e.textContent='Network error. Please try again.'; thread.appendChild(e);
            console.error('[Luna]', err);
          })
          .finally(function(){ 
            input.disabled=false; 
            if(btn) btn.disabled=false; 
            input.focus(); 
            // Only mark activity if session has started (button was clicked)
            if (sessionState.chatStarted || (window.LunaChatSession && window.LunaChatSession.chatStarted)) {
              markActivity();
            }
          });
        }catch(e){ console.error('[Luna unexpected]', e); }
      }

      function bind(form){
        if(!form || form.__bound) return; form.__bound = true;
        form.setAttribute('novalidate','novalidate');
        form.addEventListener('submit', function(e){ e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); submitFrom(form); }, true);
        var input=form.querySelector('.luna-input'), btn=form.querySelector('.luna-send');
        if (input) {
          input.addEventListener('keydown', function(e){
            if (sessionState.closing) { e.preventDefault(); showSessionEndedUI(); return; }
            if(e.key==='Enter' && !e.shiftKey && !e.isComposing){
              e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); submitFrom(form);
            }
            // Only mark activity if session has started (button was clicked)
            if (sessionState.chatStarted || (window.LunaChatSession && window.LunaChatSession.chatStarted)) {
              markActivity();
            }
          }, true);
          // Only mark activity on focus/input if session has started
          input.addEventListener('focus', function(){
            if (sessionState.chatStarted || (window.LunaChatSession && window.LunaChatSession.chatStarted)) {
              markActivity();
            }
          }, true);
          input.addEventListener('input', function(){
            if (sessionState.chatStarted || (window.LunaChatSession && window.LunaChatSession.chatStarted)) {
              markActivity();
            }
          }, true);
        }
        if (btn) { try{btn.type='button';}catch(_){} btn.addEventListener('click', function(e){
          e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); submitFrom(form);
        }, true); }
        // Only mark activity on pointerdown if session has started
        form.addEventListener('pointerdown', function(){
          if (sessionState.chatStarted || (window.LunaChatSession && window.LunaChatSession.chatStarted)) {
            markActivity();
          }
        }, true);
      }

      function scan(){ document.querySelectorAll('.luna-form').forEach(bind); }
      scan(); hydrateAny();
      window.__lunaHydrateAny = hydrateAny;
      function showCloseConfirmation() {
        var thread = getPrimaryThread();
        if (!thread) {
          console.warn('[Luna] Thread not found for close confirmation');
          return;
        }
        
        // Check if confirmation already shown
        if (thread.querySelector('.luna-close-confirmation')) return;
        
        // Create fixed popover confirmation message
        var confirmationEl = document.createElement('div');
        confirmationEl.className = 'luna-msg luna-assistant luna-close-confirmation';
        confirmationEl.style.cssText = 'position:fixed;bottom:80px;left:50%;transform:translateX(-50%);z-index:1000001;background:#000;border:1px solid #5A5753;border-radius:12px;padding:20px;min-width:280px;max-width:90%;box-shadow:0 8px 24px rgba(0,0,0,0.4);display:flex;flex-direction:column;gap:16px;';
        
        var messageText = document.createElement('div');
        messageText.textContent = 'Would you like to end your chat session with Luna?';
        messageText.style.cssText = 'color:#fff4e9;font-size:15px;font-weight:500;text-align:center;margin:0;';
        confirmationEl.appendChild(messageText);
        
        // Create buttons container
        var buttonsContainer = document.createElement('div');
        buttonsContainer.style.cssText = 'display:flex;gap:10px;justify-content:center;';
        
        // Yes button
        var yesBtn = document.createElement('button');
        yesBtn.textContent = 'Yes';
        yesBtn.style.cssText = 'background:#2c74ff;color:#fff;border:0;border-radius:6px;padding:10px 24px;font-weight:600;cursor:pointer;min-width:80px;';
        yesBtn.addEventListener('click', function(){
          // Remove confirmation popover
          if (confirmationEl.parentNode) {
            confirmationEl.parentNode.removeChild(confirmationEl);
          }
          // End session and show final Luna exit message
          endSessionManually();
        });
        buttonsContainer.appendChild(yesBtn);
        
        // No button
        var noBtn = document.createElement('button');
        noBtn.textContent = 'No';
        noBtn.style.cssText = 'background:#2E2C2A;color:#fff4e9;border:1px solid #5A5753;border-radius:6px;padding:10px 24px;font-weight:600;cursor:pointer;min-width:80px;';
        noBtn.addEventListener('click', function(){
          // Close fixed popover and return to chat dialogue
          if (confirmationEl.parentNode) {
            confirmationEl.parentNode.removeChild(confirmationEl);
          }
        });
        buttonsContainer.appendChild(noBtn);
        
        confirmationEl.appendChild(buttonsContainer);
        
        // Append to thread but position it fixed
        thread.appendChild(confirmationEl);
        
        // Ensure it's visible and scroll to it
        thread.scrollTop = thread.scrollHeight;
      }
      
      function endSessionManually() {
        if (sessionState.closing) return;
        sessionState.closing = true;
        cancelAllTimers(); // Cancel all timers when manually ending session
        var message = resolveSessionEndMessage();
        var thread = getPrimaryThread();
        if (thread) {
          // Remove confirmation message if present
          var confirmation = thread.querySelector('.luna-close-confirmation');
          if (confirmation && confirmation.parentNode) {
            confirmation.parentNode.removeChild(confirmation);
          }
          if (!thread.__sessionClosed) {
            thread.__sessionClosed = true;
            
            // Create session closure message with download button
            var endedMsg = document.createElement('div');
            endedMsg.className = 'luna-msg luna-assistant luna-session-closure';
            endedMsg.style.cssText = 'display:flex;flex-direction:column;gap:12px;';
            
            var endedText = document.createElement('div');
            endedText.textContent = message;
            endedMsg.appendChild(endedText);
            
            // Add download transcript button
            var downloadBtn = document.createElement('button');
            downloadBtn.textContent = 'Download Transcript';
            downloadBtn.style.cssText = 'background:#fff4e9;color:#000000;border:1px solid #1f1d1a;border-radius:6px;padding:8px 16px;font-weight:600;cursor:pointer;align-self:flex-start;margin-top:8px;';
            downloadBtn.addEventListener('click', function(){
              downloadTranscript();
            });
            endedMsg.appendChild(downloadBtn);
            
            thread.appendChild(endedMsg);
            thread.scrollTop = thread.scrollHeight;
          }
        }
        setFormsDisabled(true);
        showSessionEndedUI();
        // Close the panel
        var panel = document.getElementById('luna-panel');
        if (panel) {
          panel.classList.remove('show');
        }
        var fab = document.querySelector('.luna-launcher');
        if (fab) {
          fab.setAttribute('aria-expanded', 'false');
        }
        try {
          fetch(chatSessionEndEndpoint, {
            method: 'POST',
            headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ reason: 'user_manual_close', message: message })
          }).catch(function(err){
            console.warn('[Luna] session end failed', err);
          });
        } catch (err) {
          console.warn('[Luna] session end error', err);
        }
      }

      sessionState.markActivity = markActivity;
      sessionState.cancelTimers = cancelTimers;
      sessionState.cancelAllTimers = cancelAllTimers;
      sessionState.restartSession = restartSession;
      sessionState.showSessionEndedUI = showSessionEndedUI;
      sessionState.hideSessionEndedUI = hideSessionEndedUI;
      sessionState.onPanelToggle = onPanelToggle;
      sessionState.showCloseConfirmation = showCloseConfirmation;
      sessionState.endSessionManually = endSessionManually;
      sessionState.downloadTranscript = downloadTranscript;
      window.LunaChatSession = sessionState;

      try{ new MutationObserver(function(){ if (scan.__t) cancelAnimationFrame(scan.__t); scan.__t=requestAnimationFrame(function(){ scan(); hydrateAny(); }); }).observe(document.documentElement,{childList:true,subtree:true}); }catch(_){}
      if (document.readyState==='loading') document.addEventListener('DOMContentLoaded', function(){ scan(); hydrateAny(); }, {once:true});
    })();
  </script>
  <?php
});

/* ============================================================
 * OPENAI HELPERS
 * ============================================================ */
function luna_get_openai_key() {
  if (defined('LUNA_OPENAI_API_KEY') && LUNA_OPENAI_API_KEY) return (string)LUNA_OPENAI_API_KEY;
  $k = get_option('luna_openai_api_key', '');
  return is_string($k) ? trim($k) : '';
}

function luna_openai_messages_with_facts($pid, $user_text, $facts, $is_comprehensive_report = false, $is_composer = false) {
  $site_url = isset($facts['site_url']) ? (string)$facts['site_url'] : home_url('/');
  $https    = isset($facts['https']) ? ($facts['https'] ? 'yes' : 'no') : 'unknown';
  $tls      = isset($facts['tls']) && is_array($facts['tls']) ? $facts['tls'] : array();
  $host     = isset($facts['host']) && $facts['host'] !== '' ? (string)$facts['host'] : 'unknown';
  $wpv      = isset($facts['wp_version']) && $facts['wp_version'] !== '' ? (string)$facts['wp_version'] : 'unknown';
  $theme    = isset($facts['theme']) && $facts['theme'] !== '' ? (string)$facts['theme'] : 'unknown';
  $theme_version = isset($facts['theme_version']) && $facts['theme_version'] !== '' ? (string)$facts['theme_version'] : 'unknown';
  $theme_active  = isset($facts['theme_active']) ? ($facts['theme_active'] ? 'yes' : 'no') : 'unknown';
  $counts  = isset($facts['counts']) && is_array($facts['counts']) ? $facts['counts'] : array();
  $updates = isset($facts['updates']) && is_array($facts['updates']) ? $facts['updates'] : array();

  $count_pages  = isset($counts['pages']) ? (int)$counts['pages'] : 0;
  $count_posts  = isset($counts['posts']) ? (int)$counts['posts'] : 0;
  $count_users  = isset($counts['users']) ? (int)$counts['users'] : 0;
  $count_plugins= isset($counts['plugins']) ? (int)$counts['plugins'] : 0;

  $updates_plugins = isset($updates['plugins']) ? (int)$updates['plugins'] : 0;
  $updates_themes  = isset($updates['themes']) ? (int)$updates['themes'] : 0;
  $updates_core    = isset($updates['core']) ? (int)$updates['core'] : 0;

  // Prioritize new ssl_tls data over old tls data
  $ssl_tls_data = isset($facts['ssl_tls']) && is_array($facts['ssl_tls']) && !empty($facts['ssl_tls']) ? $facts['ssl_tls'] : null;
  $tls_valid_from_ssl = false;
  $tls_issuer_from_ssl = '';
  $tls_expires_from_ssl = '';
  
  if ($ssl_tls_data) {
    $tls_valid_from_ssl = isset($ssl_tls_data['connected']) ? (bool)$ssl_tls_data['connected'] : false;
    $tls_issuer_from_ssl = isset($ssl_tls_data['issuer']) ? $ssl_tls_data['issuer'] : '';
    $tls_expires_from_ssl = isset($ssl_tls_data['expires']) ? $ssl_tls_data['expires'] : (isset($ssl_tls_data['expires_at']) ? $ssl_tls_data['expires_at'] : '');
  }
  
  // Use ssl_tls data if available, otherwise fall back to old tls data
  $tls_valid_display = 'unknown';
  $tls_issuer_display = '';
  $tls_expires_display = '';
  
  if ($ssl_tls_data) {
    $tls_valid_display = $tls_valid_from_ssl ? 'yes (Connected)' : 'no';
    $tls_issuer_display = $tls_issuer_from_ssl;
    $tls_expires_display = $tls_expires_from_ssl;
  } elseif (isset($tls['valid'])) {
    $tls_valid_display = $tls['valid'] ? 'yes' : 'no';
    $tls_issuer_display = isset($tls['issuer']) ? $tls['issuer'] : '';
    $tls_expires_display = isset($tls['expires']) ? $tls['expires'] : '';
  }
  
  $facts_text = "FACTS (from Visible Light Hub)\n"
    . "- Site URL: " . $site_url . "\n"
    . "- HTTPS: " . $https . "\n"
    . "- TLS valid: " . $tls_valid_display
    . (!empty($tls_issuer_display) ? " (issuer: " . $tls_issuer_display . ")" : '')
    . (!empty($tls_expires_display) ? " (expires: " . $tls_expires_display . ")" : '') . "\n"
    . "- Host: " . $host . "\n"
    . "- WordPress: " . $wpv . "\n"
    . "- Theme: " . $theme . " (version: " . $theme_version . ")\n"
    . "- Theme active: " . $theme_active . "\n"
    . "- Counts: pages " . $count_pages . ", posts " . $count_posts . ", users " . $count_users . ", plugins " . $count_plugins . "\n"
    . "- Updates pending: plugins " . $updates_plugins . ", themes " . $updates_themes . ", WordPress Core " . $updates_core . "\n";
    
  // Add comprehensive data if available
  if (isset($facts['comprehensive']) && $facts['comprehensive']) {
    $facts_text .= "\nINSTALLED PLUGINS:\n";
    if (isset($facts['plugins']) && is_array($facts['plugins'])) {
      foreach ($facts['plugins'] as $plugin) {
        $status = !empty($plugin['active']) ? 'active' : 'inactive';
        $update = !empty($plugin['update_available']) ? ' (update available)' : '';
        $facts_text .= "- " . $plugin['name'] . " v" . $plugin['version'] . " (" . $status . ")" . $update . "\n";
      }
    }
    
    $facts_text .= "\nINSTALLED THEMES:\n";
    if (isset($facts['themes']) && is_array($facts['themes'])) {
      foreach ($facts['themes'] as $theme) {
        $status = !empty($theme['is_active']) ? 'active' : 'inactive';
        $update = !empty($theme['update_available']) ? ' (update available)' : '';
        $facts_text .= "- " . $theme['name'] . " v" . $theme['version'] . " (" . $status . ")" . $update . "\n";
      }
    }
    
    $facts_text .= "\nPUBLISHED POSTS:\n";
    if (isset($facts['posts']) && is_array($facts['posts'])) {
      foreach ($facts['posts'] as $post) {
        $facts_text .= "- " . $post['title'] . " (ID: " . $post['id'] . ")\n";
      }
    }
    
    $facts_text .= "\nPAGES:\n";
    if (isset($facts['pages']) && is_array($facts['pages'])) {
      foreach ($facts['pages'] as $page) {
        $status = isset($page['status']) ? $page['status'] : 'published';
        $facts_text .= "- " . $page['title'] . " (" . $status . ", ID: " . $page['id'] . ")\n";
      }
    }
    
    $facts_text .= "\nUSERS:\n";
    if (isset($facts['users']) && is_array($facts['users'])) {
      foreach ($facts['users'] as $user) {
        $facts_text .= "- " . $user['name'] . " (" . $user['username'] . ") - " . $user['email'] . "\n";
      }
    }
  }
  
  // Add SSL/TLS Status Data (from VL Hub SSL/TLS Status connector OR demo data)
  // Check demo data first (security.tls structure)
  $security = isset($facts['security']) && is_array($facts['security']) ? $facts['security'] : array();
  $security_tls = isset($security['tls']) && is_array($security['tls']) ? $security['tls'] : array();
  
  if (isset($facts['ssl_tls']) && is_array($facts['ssl_tls']) && !empty($facts['ssl_tls'])) {
    $ssl_tls = $facts['ssl_tls'];
    $facts_text .= "\n\nSSL/TLS CERTIFICATE STATUS:\n";
    $certificate = isset($ssl_tls['certificate']) ? $ssl_tls['certificate'] : '';
    $issuer = isset($ssl_tls['issuer']) ? $ssl_tls['issuer'] : '';
    $expires = isset($ssl_tls['expires']) ? $ssl_tls['expires'] : (isset($ssl_tls['expires_at']) ? $ssl_tls['expires_at'] : '');
    $days_until_expiry = isset($ssl_tls['days_until_expiry']) ? (int)$ssl_tls['days_until_expiry'] : null;
    $connected = isset($ssl_tls['connected']) ? (bool)$ssl_tls['connected'] : false;
    $status = isset($ssl_tls['status']) ? $ssl_tls['status'] : ($connected ? 'active' : 'inactive');
    $tls_version = isset($ssl_tls['tls_version']) ? $ssl_tls['tls_version'] : '';
    $cipher_suite = isset($ssl_tls['cipher_suite']) ? $ssl_tls['cipher_suite'] : '';
    $valid_from = isset($ssl_tls['valid_from']) ? $ssl_tls['valid_from'] : '';
    $last_checked = isset($ssl_tls['last_checked']) ? $ssl_tls['last_checked'] : '';
    
    if ($connected && !empty($certificate)) {
      $facts_text .= "  - Certificate: " . $certificate . "\n";
      if (!empty($issuer)) {
        $facts_text .= "  - Issuer: " . $issuer . "\n";
      }
      if (!empty($expires)) {
        $facts_text .= "  - Expires: " . $expires;
        if ($days_until_expiry !== null) {
          $facts_text .= " (" . $days_until_expiry . " days until expiry)";
        }
        $facts_text .= "\n";
      }
      if (!empty($valid_from)) {
        $facts_text .= "  - Valid From: " . $valid_from . "\n";
      }
      if (!empty($tls_version)) {
        $facts_text .= "  - TLS Version: " . $tls_version . "\n";
      }
      if (!empty($cipher_suite)) {
        $facts_text .= "  - Cipher Suite: " . $cipher_suite . "\n";
      }
      if (!empty($last_checked)) {
        $facts_text .= "  - Last Checked: " . $last_checked . "\n";
      }
      $facts_text .= "  - Status: " . ucfirst($status) . " (Connected: " . ($connected ? 'Yes' : 'No') . ", Valid: Yes)\n";
      $facts_text .= "  - Certificate Status: ACTIVE AND VALID\n";
    } else {
      $facts_text .= "  - Status: Not configured or not connected\n";
      if (!empty($certificate)) {
        $facts_text .= "  - Certificate: " . $certificate . "\n";
      }
    }
  } elseif (!empty($security_tls)) {
    // Demo data format: security.tls
    $facts_text .= "\n\nSSL/TLS CERTIFICATE STATUS:\n";
    $facts_text .= "  - Status: " . (isset($security_tls['status']) ? $security_tls['status'] : 'active') . "\n";
    if (!empty($security_tls['version'])) {
      $facts_text .= "  - Version: " . $security_tls['version'] . "\n";
    }
    if (!empty($security_tls['issuer'])) {
      $facts_text .= "  - Issuer: " . $security_tls['issuer'] . "\n";
    }
    if (!empty($security_tls['valid_from'])) {
      $facts_text .= "  - Valid from: " . $security_tls['valid_from'] . "\n";
    }
    if (!empty($security_tls['valid_to'])) {
      $facts_text .= "  - Valid to: " . $security_tls['valid_to'] . "\n";
    }
    if (!empty($security_tls['host'])) {
      $facts_text .= "  - Host: " . $security_tls['host'] . "\n";
    }
  }
  
  // Add comprehensive Security Infrastructure data (from demo or real data)
  // Always include Cloudflare if available, even if security array is empty
  $has_cloudflare_in_facts = isset($facts['cloudflare']) && is_array($facts['cloudflare']) && !empty($facts['cloudflare']);
  $has_ssl_tls_in_facts = isset($facts['ssl_tls']) && is_array($facts['ssl_tls']) && !empty($facts['ssl_tls']);
  
  if (!empty($security) || $has_cloudflare_in_facts || $has_ssl_tls_in_facts) {
    $facts_text .= "\n\nSECURITY INFRASTRUCTURE:\n";
    
    // TLS/SSL Summary (from ssl_tls data if available, otherwise from security_tls)
    if ($has_ssl_tls_in_facts) {
      $ssl_tls_summary = $facts['ssl_tls'];
      $ssl_connected = isset($ssl_tls_summary['connected']) && $ssl_tls_summary['connected'];
      $ssl_cert = isset($ssl_tls_summary['certificate']) ? $ssl_tls_summary['certificate'] : '';
      $ssl_issuer = isset($ssl_tls_summary['issuer']) ? $ssl_tls_summary['issuer'] : '';
      $ssl_version = isset($ssl_tls_summary['tls_version']) ? $ssl_tls_summary['tls_version'] : 'TLS';
      $facts_text .= "  - TLS/SSL Certificate: ACTIVE AND VALID";
      if ($ssl_connected) {
        $facts_text .= " (Connected: Yes";
        if ($ssl_cert) $facts_text .= ", Certificate: " . $ssl_cert;
        if ($ssl_issuer) $facts_text .= ", Issuer: " . $ssl_issuer;
        if ($ssl_version) $facts_text .= ", Version: " . $ssl_version;
        $facts_text .= ")";
      }
      $facts_text .= "\n";
    } elseif (!empty($security_tls)) {
      $facts_text .= "  - TLS/SSL: Active (" . (isset($security_tls['version']) ? $security_tls['version'] : 'TLS') . ", Issuer: " . (isset($security_tls['issuer']) ? $security_tls['issuer'] : 'N/A') . ")\n";
    }
    
    // Cloudflare Summary (always include if available)
    if ($has_cloudflare_in_facts) {
      $cf = $facts['cloudflare'];
      $cf_connected = isset($cf['connected']) ? (bool)$cf['connected'] : false;
      $cf_zones_count = isset($cf['zones_count']) ? (int)$cf['zones_count'] : 0;
      $cf_account_name = isset($cf['account_name']) ? $cf['account_name'] : '';
      
      $facts_text .= "  - Cloudflare: CONFIGURED AND ACTIVE";
      if ($cf_connected) {
        $facts_text .= " (Connected: Yes";
        if ($cf_zones_count > 0) {
          $facts_text .= ", Zones: " . $cf_zones_count;
          if (!empty($cf['zones']) && is_array($cf['zones'])) {
            $zone_names = array();
            foreach ($cf['zones'] as $zone) {
              if (isset($zone['name'])) {
                $zone_names[] = $zone['name'];
              }
            }
            if (!empty($zone_names)) {
              $facts_text .= " (" . implode(', ', $zone_names) . ")";
            }
          }
        }
        if ($cf_account_name) {
          $facts_text .= ", Account: " . $cf_account_name;
        }
        $facts_text .= ")";
      }
      $facts_text .= "\n";
      $facts_text .= "    * DDoS Protection: Enabled\n";
      $facts_text .= "    * Web Application Firewall (WAF): Enabled\n";
      $facts_text .= "    * CDN (Content Delivery Network): Enabled\n";
      $facts_text .= "    * DNS Management: Enabled\n";
    }
    
    // WAF (Web Application Firewall)
    if (isset($security['waf']) && is_array($security['waf'])) {
      $waf = $security['waf'];
      $facts_text .= "  - WAF (Web Application Firewall): " . (isset($waf['provider']) ? $waf['provider'] : 'N/A');
      if (isset($waf['last_audit'])) {
        $facts_text .= " (Last audit: " . $waf['last_audit'] . ")";
      }
      $facts_text .= "\n";
    }
    
    // IDS (Intrusion Detection System)
    if (isset($security['ids']) && is_array($security['ids'])) {
      $ids = $security['ids'];
      $facts_text .= "  - IDS (Intrusion Detection): " . (isset($ids['provider']) ? $ids['provider'] : 'N/A');
      if (isset($ids['last_scan'])) {
        $facts_text .= " (Last scan: " . $ids['last_scan'] . ", Result: " . (isset($ids['result']) ? $ids['result'] : 'N/A') . ")";
      }
      if (isset($ids['schedule'])) {
        $facts_text .= " (Schedule: " . $ids['schedule'] . ")";
      }
      $facts_text .= "\n";
    }
    
    // Authentication
    if (isset($security['auth']) && is_array($security['auth'])) {
      $auth = $security['auth'];
      $facts_text .= "  - Authentication:\n";
      if (isset($auth['mfa'])) {
        $facts_text .= "    * MFA: " . $auth['mfa'] . "\n";
      }
      if (isset($auth['password_policy'])) {
        $facts_text .= "    * Password Policy: " . $auth['password_policy'] . "\n";
      }
      if (isset($auth['session_timeout'])) {
        $facts_text .= "    * Session Timeout: " . $auth['session_timeout'] . "\n";
      }
      if (isset($auth['sso_providers'])) {
        $facts_text .= "    * SSO Providers: " . $auth['sso_providers'] . "\n";
      }
    }
    
    // Domain Info
    if (isset($security['domain']) && is_array($security['domain'])) {
      $domain = $security['domain'];
      $facts_text .= "  - Domain Information:\n";
      if (isset($domain['domain'])) {
        $facts_text .= "    * Domain: " . $domain['domain'] . "\n";
      }
      if (isset($domain['registrar'])) {
        $facts_text .= "    * Registrar: " . $domain['registrar'] . "\n";
      }
      if (isset($domain['registered_on'])) {
        $facts_text .= "    * Registered: " . $domain['registered_on'] . "\n";
      }
      if (isset($domain['renewal_date'])) {
        $facts_text .= "    * Renewal Date: " . $domain['renewal_date'] . "\n";
      }
      if (isset($domain['auto_renew'])) {
        $facts_text .= "    * Auto-Renew: " . $domain['auto_renew'] . "\n";
      }
    }
  }
  
  // Add Cloudflare Data (from VL Hub Cloudflare connector)
  if (isset($facts['cloudflare']) && is_array($facts['cloudflare']) && !empty($facts['cloudflare'])) {
    $cloudflare = $facts['cloudflare'];
    $facts_text .= "\n\nCLOUDFLARE CONNECTION:\n";
    $connected = isset($cloudflare['connected']) ? (bool)$cloudflare['connected'] : false;
    $account_id = isset($cloudflare['account_id']) ? $cloudflare['account_id'] : '';
    $account_name = isset($cloudflare['account_name']) ? $cloudflare['account_name'] : '';
    $zones_count = isset($cloudflare['zones_count']) ? (int)$cloudflare['zones_count'] : 0;
    $last_sync = isset($cloudflare['last_sync']) ? $cloudflare['last_sync'] : '';
    $zones = isset($cloudflare['zones']) && is_array($cloudflare['zones']) ? $cloudflare['zones'] : array();
    
    $facts_text .= "  - Connection Status: " . ($connected ? 'Connected' : 'Not connected') . "\n";
    if ($account_id) {
      $facts_text .= "  - Account ID: " . $account_id . "\n";
    }
    if ($account_name) {
      $facts_text .= "  - Account Name: " . $account_name . "\n";
    }
    if ($zones_count > 0) {
      $facts_text .= "  - Zones: " . $zones_count . " zone(s)\n";
    }
    if ($last_sync) {
      $facts_text .= "  - Last Sync: " . $last_sync . "\n";
    }
    if (!empty($zones)) {
      $facts_text .= "  - Configured Zones:\n";
      foreach ($zones as $zone) {
        $zone_name = isset($zone['name']) ? $zone['name'] : 'Unknown';
        $zone_status = isset($zone['status']) ? $zone['status'] : 'unknown';
        $zone_plan = isset($zone['plan']) ? $zone['plan'] : 'Free';
        $zone_id = isset($zone['zone_id']) ? $zone['zone_id'] : '';
        $health_score = isset($zone['health_score']) ? floatval($zone['health_score']) : 0;
        $last_updated = isset($zone['last_updated']) ? $zone['last_updated'] : '';
        
        $facts_text .= "    * " . $zone_name . " (" . ucfirst($zone_status) . " - " . $zone_plan . " Plan)\n";
        if ($zone_id) {
          $facts_text .= "      Zone ID: " . $zone_id . "\n";
        }
        if ($health_score > 0) {
          $facts_text .= "      Health Score: " . number_format($health_score, 1) . "%\n";
        }
        if ($last_updated) {
          $facts_text .= "      Last Updated: " . $last_updated . "\n";
        }
        
        // Include detailed cloudflare_data if available
        if (isset($zone['cloudflare_data']) && is_array($zone['cloudflare_data'])) {
          $cf_data = $zone['cloudflare_data'];
          if (isset($cf_data['type'])) {
            $facts_text .= "      Type: " . ucfirst($cf_data['type']) . "\n";
          }
          if (isset($cf_data['paused'])) {
            $facts_text .= "      Paused: " . ($cf_data['paused'] ? 'Yes' : 'No') . "\n";
          }
          if (isset($cf_data['name_servers']) && is_array($cf_data['name_servers']) && !empty($cf_data['name_servers'])) {
            $facts_text .= "      Name Servers: " . implode(', ', $cf_data['name_servers']) . "\n";
          }
          if (isset($cf_data['permissions']) && is_array($cf_data['permissions'])) {
            $permissions_count = count($cf_data['permissions']);
            $facts_text .= "      Permissions: " . $permissions_count . " permission(s) granted\n";
            // List key permissions
            $key_perms = array();
            foreach ($cf_data['permissions'] as $perm) {
              if (strpos($perm, 'waf') !== false) $key_perms[] = 'WAF';
              if (strpos($perm, 'ssl') !== false) $key_perms[] = 'SSL';
              if (strpos($perm, 'dns') !== false) $key_perms[] = 'DNS';
              if (strpos($perm, 'analytics') !== false) $key_perms[] = 'Analytics';
              if (strpos($perm, 'logs') !== false) $key_perms[] = 'Logs';
            }
            if (!empty($key_perms)) {
              $facts_text .= "      Key Features: " . implode(', ', array_unique($key_perms)) . "\n";
            }
          }
          if (isset($cf_data['plan']) && is_array($cf_data['plan'])) {
            if (isset($cf_data['plan']['name'])) {
              $facts_text .= "      Plan Details: " . $cf_data['plan']['name'];
              if (isset($cf_data['plan']['price'])) {
                $facts_text .= " ($" . number_format($cf_data['plan']['price'], 2) . "/" . ($cf_data['plan']['frequency'] ? $cf_data['plan']['frequency'] : 'month') . ")";
              }
              $facts_text .= "\n";
            }
          }
        }
      }
    }
    $facts_text .= "  - Features: DDoS protection, Web Application Firewall (WAF), CDN caching, DNS management\n";
  }
  
  // Add Security Data Streams (from VL Hub Security tab - SSL/TLS Status and Cloudflare)
  if (isset($facts['security_data_streams']) && is_array($facts['security_data_streams']) && !empty($facts['security_data_streams'])) {
    $facts_text .= "\n\nSECURITY DATA STREAMS:\n";
    foreach ($facts['security_data_streams'] as $stream_id => $stream_data) {
      $stream_name = isset($stream_data['name']) ? $stream_data['name'] : $stream_id;
      $stream_status = isset($stream_data['status']) ? $stream_data['status'] : 'unknown';
      $health_score = isset($stream_data['health_score']) ? floatval($stream_data['health_score']) : 0;
      $facts_text .= "  - " . $stream_name . "\n";
      $facts_text .= "    Status: " . ucfirst($stream_status) . "\n";
      $facts_text .= "    Health Score: " . number_format($health_score, 1) . "%\n";
      
      // SSL/TLS Status connector details
      if (isset($stream_data['id']) && $stream_data['id'] === 'ssl_tls_status' && isset($stream_data['ssl_tls_data']) && is_array($stream_data['ssl_tls_data'])) {
        $ssl_data = $stream_data['ssl_tls_data'];
        $facts_text .= "    Certificate: " . (isset($ssl_data['certificate']) ? $ssl_data['certificate'] : 'N/A') . "\n";
        $facts_text .= "    Issuer: " . (isset($ssl_data['issuer']) ? $ssl_data['issuer'] : 'N/A') . "\n";
        $facts_text .= "    Expires: " . (isset($ssl_data['expires']) ? $ssl_data['expires'] : 'N/A') . "\n";
        if (isset($ssl_data['days_until_expiry'])) {
          $facts_text .= "    Days Until Expiry: " . $ssl_data['days_until_expiry'] . "\n";
        }
        $facts_text .= "    Connected: " . (isset($ssl_data['connected']) && $ssl_data['connected'] ? 'Yes' : 'No') . "\n";
        $facts_text .= "    TLS Version: " . (isset($ssl_data['tls_version']) ? $ssl_data['tls_version'] : 'N/A') . "\n";
        $facts_text .= "    Cipher Suite: " . (isset($ssl_data['cipher_suite']) ? $ssl_data['cipher_suite'] : 'N/A') . "\n";
        if (isset($ssl_data['valid_from'])) {
          $facts_text .= "    Valid From: " . $ssl_data['valid_from'] . "\n";
        }
        if (isset($ssl_data['last_checked'])) {
          $facts_text .= "    Last Checked: " . $ssl_data['last_checked'] . "\n";
        }
      }
      
      // Cloudflare connector details
      if (strpos($stream_id, 'cloudflare') !== false || (isset($stream_data['name']) && stripos($stream_data['name'], 'Cloudflare') !== false)) {
        if (isset($stream_data['cloudflare_zone_name'])) {
          $facts_text .= "    Zone: " . $stream_data['cloudflare_zone_name'] . "\n";
        }
        if (isset($stream_data['cloudflare_zone_id'])) {
          $facts_text .= "    Zone ID: " . $stream_data['cloudflare_zone_id'] . "\n";
        }
        if (isset($stream_data['cloudflare_plan'])) {
          $facts_text .= "    Plan: " . $stream_data['cloudflare_plan'] . "\n";
        }
        if (isset($stream_data['cloudflare_data']) && is_array($stream_data['cloudflare_data'])) {
          $cf_data = $stream_data['cloudflare_data'];
          if (isset($cf_data['account']) && is_array($cf_data['account'])) {
            if (isset($cf_data['account']['name'])) {
              $facts_text .= "    Account: " . $cf_data['account']['name'] . "\n";
            }
          }
          if (isset($cf_data['status'])) {
            $facts_text .= "    Zone Status: " . ucfirst($cf_data['status']) . "\n";
          }
          if (isset($cf_data['type'])) {
            $facts_text .= "    Type: " . ucfirst($cf_data['type']) . "\n";
          }
          if (isset($cf_data['permissions']) && is_array($cf_data['permissions'])) {
            $permissions_count = count($cf_data['permissions']);
            $facts_text .= "    Permissions: " . $permissions_count . " permission(s) granted\n";
            // List key permissions
            $key_perms = array();
            foreach ($cf_data['permissions'] as $perm) {
              if (strpos($perm, 'waf') !== false) $key_perms[] = 'WAF';
              if (strpos($perm, 'ssl') !== false) $key_perms[] = 'SSL';
              if (strpos($perm, 'dns') !== false) $key_perms[] = 'DNS';
              if (strpos($perm, 'analytics') !== false) $key_perms[] = 'Analytics';
            }
            if (!empty($key_perms)) {
              $facts_text .= "    Key Features: " . implode(', ', array_unique($key_perms)) . "\n";
            }
          }
          if (isset($cf_data['plan']) && is_array($cf_data['plan'])) {
            if (isset($cf_data['plan']['name'])) {
              $facts_text .= "    Plan Name: " . $cf_data['plan']['name'] . "\n";
            }
          }
        }
      }
      
      $facts_text .= "\n";
    }
  }
  
  // Add Connections Summary
  if (isset($facts['connections']) && is_array($facts['connections'])) {
    $connections = $facts['connections'];
    $facts_text .= "\n\nACTIVE CONNECTIONS:\n";
    $active_connections = array();
    if (!empty($connections['ssl_tls'])) {
      $active_connections[] = "SSL/TLS Certificate";
    }
    if (!empty($connections['cloudflare'])) {
      $active_connections[] = "Cloudflare";
    }
    if (!empty($connections['aws_s3'])) {
      $active_connections[] = "AWS S3";
    }
    if (!empty($connections['ga4'])) {
      $active_connections[] = "Google Analytics 4";
    }
    if (!empty($connections['liquidweb'])) {
      $active_connections[] = "Liquid Web";
    }
    if (!empty($connections['gsc'])) {
      $active_connections[] = "Google Search Console";
    }
    if (!empty($connections['pagespeed'])) {
      $active_connections[] = "Lighthouse/PageSpeed";
    }
    if (!empty($active_connections)) {
      $facts_text .= "  - Connected Services: " . implode(", ", $active_connections) . "\n";
      $facts_text .= "  - Total Connections: " . count($active_connections) . "\n";
    } else {
      $facts_text .= "  - No active connections configured\n";
    }
  }
  
  // Check if this is demo mode
  $is_demo_mode = isset($facts['__demo_mode']) && $facts['__demo_mode'] === true;
  
  $facts_text .= "\n\nRULES FOR LUNA:\n";
  $facts_text .= "1. You are Luna, an intelligent WebOps assistant with access to ALL Visible Light Hub data";
  if ($is_demo_mode) {
    $facts_text .= " (DEMO MODE - using sample data)";
  }
  $facts_text .= ".\n";
  $facts_text .= "2. ALWAYS use the FACTS provided above when answering questions. Do NOT make up data. ";
  if ($is_demo_mode) {
    $facts_text .= "In demo mode, use the demo data provided in the sections above (SECURITY INFRASTRUCTURE, LIGHTHOUSE PERFORMANCE ANALYSIS, COMPETITIVE INTELLIGENCE, COMPLIANCE & CERTIFICATIONS, etc.). ";
  }
  $facts_text .= "\n";
  $facts_text .= "3. CRITICAL: NEVER use emoticons, emojis, unicode symbols, or special characters (like 🌐, 📊, 🔒, 📈, 📝, 🏗️, 🔄, 💡, 📋, ❌, ✅, etc.) in your responses unless the user specifically requests them. Use plain text only.\n";
  $facts_text .= "4. Write in a personable, professional, enterprise-grade tone suitable for leadership. Use full sentences, proper paragraph breaks, and narrative-style explanations rather than bullet points when appropriate.\n";
  $facts_text .= "5. When asked about SSL/TLS, certificates, HTTPS, or encryption, check the SSL/TLS CERTIFICATE STATUS section above.\n";
  $facts_text .= "6. When asked about Cloudflare, CDN, DDoS protection, or WAF, check the CLOUDFLARE CONNECTION section above.\n";
  $facts_text .= "7. When asked about security, security infrastructure, or security measures, check the SECURITY INFRASTRUCTURE section above (includes TLS/SSL, WAF, IDS, Authentication, Domain Info). Also check SSL/TLS CERTIFICATE STATUS and CLOUDFLARE CONNECTION sections.\n";
  $facts_text .= "8. When asked about competitors, competitive analysis, or domain ranking, check COMPETITIVE INTELLIGENCE and DOMAIN RANKING (VL-DR) DATA sections.\n";
  $facts_text .= "9. When asked about analytics, traffic, or performance, check GOOGLE ANALYTICS 4 (GA4) and PERFORMANCE METRICS sections. The GA4 section includes comprehensive dimensional data:\n";
  $facts_text .= "    - Geographic Data: Use this to answer questions about where visitors come from (countries, regions, cities)\n";
  $facts_text .= "    - Device Data: Use this to answer questions about device types, brands, and browsers used by visitors\n";
  $facts_text .= "    - Traffic Sources: Use this to answer questions about where traffic originates (direct, organic, referral, campaigns)\n";
  $facts_text .= "    - Top Pages: Use this to answer questions about which pages get the most traffic, users, or page views\n";
  $facts_text .= "    - Events: Use this to answer questions about tracked events, event counts, and conversions\n";
  $facts_text .= "    - Page Location Data: Use this to answer questions about which pages are popular in specific locations\n";
  $facts_text .= "10. When asked about Lighthouse, performance scores, Core Web Vitals, or optimization opportunities, check the LIGHTHOUSE PERFORMANCE ANALYSIS section above.\n";
  $facts_text .= "11. When asked about compliance, certifications, GDPR, accessibility, or security standards, check the COMPLIANCE & CERTIFICATIONS section above.\n";
  $facts_text .= "12. When asked about data streams, check DATA STREAMS SUMMARY and ALL DATA STREAMS sections.\n";
  $facts_text .= "13. If data is missing or uncertain, explicitly say so and suggest checking the Visible Light Hub profile.\n";
  $facts_text .= "14. For comprehensive reports, site health reports, or multi-sentence requests:\n";
  $facts_text .= "    - Use full sentences in human-readable, enterprise-grade format\n";
  $facts_text .= "    - Include proper paragraph breaks and formatting\n";
  $facts_text .= "    - Use professional, personable language suitable for leadership\n";
  $facts_text .= "    - Include intro headers, section headers, and official signatures when requested\n";
  $facts_text .= "    - Format data in a way that can be easily copied and pasted into emails\n";
  $facts_text .= "    - Use descriptive, narrative-style explanations rather than bullet points when appropriate\n";
  $facts_text .= "    - For reports, structure with: Title, Introduction, Detailed Findings (by section), Summary, Signature\n";
    $facts_text .= "    - Write in a thoughtful, full-length, professional manner that reads like a human executive report\n";
  $facts_text .= "15. For simple greetings (hi, hello, hey, howdy, hola, etc.), respond instantly with a friendly greeting and brief introduction.\n";
  $facts_text .= "16. Recognize these key terms and map them to the correct sections:\n";
  $facts_text .= "    - SSL/TLS/HTTPS/certificate/cert → SSL/TLS CERTIFICATE STATUS\n";
  $facts_text .= "    - Cloudflare/CDN/DDoS/WAF → CLOUDFLARE CONNECTION\n";
  $facts_text .= "    - Security/security measures → SSL/TLS + Cloudflare + SECURITY DATA STREAMS\n";
  $facts_text .= "    - Competitors/competitive/domain ranking/VLDR → COMPETITOR ANALYSIS + DOMAIN RANKING\n";
  $facts_text .= "    - Analytics/traffic/visitors/geographic/where visitors come from → GOOGLE ANALYTICS 4 (GA4) - Geographic Data\n";
  $facts_text .= "    - Devices/browsers/mobile/desktop → GOOGLE ANALYTICS 4 (GA4) - Device Data\n";
  $facts_text .= "    - Traffic sources/campaigns/organic/direct/referral → GOOGLE ANALYTICS 4 (GA4) - Traffic Sources\n";
  $facts_text .= "    - Top pages/popular pages/most visited → GOOGLE ANALYTICS 4 (GA4) - Top Pages\n";
  $facts_text .= "    - Events/tracked events/conversions → GOOGLE ANALYTICS 4 (GA4) - Events\n";
  $facts_text .= "    - Performance/Lighthouse → PERFORMANCE METRICS\n";
  $facts_text .= "    - SEO/search console → SEO METRICS\n";
  $facts_text .= "    - Data streams/connections → DATA STREAMS SUMMARY + ACTIVE CONNECTIONS\n";

  // Get additional data from VL Hub
  $hub_data = luna_get_hub_data();
  if ($hub_data && isset($hub_data['summary'])) {
    $facts_text .= "\n\nHUB INSIGHTS:\n" . $hub_data['summary'];
    if (isset($hub_data['metrics'])) {
      $facts_text .= "\n\nHUB METRICS:\n";
      foreach ($hub_data['metrics'] as $key => $value) {
        $facts_text .= "- " . ucfirst(str_replace('_', ' ', $key)) . ": " . $value . "\n";
      }
    }
  }
  
  // Add competitor analysis data
  $all_competitor_reports = array();
  if (isset($facts['competitor_reports']) && is_array($facts['competitor_reports'])) {
    $all_competitor_reports = array_merge($all_competitor_reports, $facts['competitor_reports']);
  }
  if (isset($facts['competitor_reports_full']) && is_array($facts['competitor_reports_full'])) {
    $all_competitor_reports = array_merge($all_competitor_reports, $facts['competitor_reports_full']);
  }
  
  $competitor_urls = array();
  if (isset($facts['competitors']) && is_array($facts['competitors'])) {
    $competitor_urls = $facts['competitors'];
  }
  
  // Extract competitor URLs from reports if available
  if (!empty($all_competitor_reports)) {
    foreach ($all_competitor_reports as $report_data) {
      $comp_url = $report_data['url'] ?? '';
      if (!empty($comp_url) && !in_array($comp_url, $competitor_urls)) {
        $competitor_urls[] = $comp_url;
      }
    }
  }
  
  if (!empty($competitor_urls) || !empty($all_competitor_reports)) {
    $facts_text .= "\n\nCOMPETITOR ANALYSIS:\n";
    if (!empty($competitor_urls)) {
      $facts_text .= "Tracked competitors: " . implode(', ', $competitor_urls) . "\n";
    }
    
    if (!empty($all_competitor_reports)) {
      $facts_text .= "\nCompetitor Analysis Reports (" . count($all_competitor_reports) . "):\n";
      foreach ($all_competitor_reports as $report_data) {
        $comp_url = $report_data['url'] ?? '';
        $comp_domain = $report_data['domain'] ?? parse_url($comp_url, PHP_URL_HOST);
        $last_scanned = $report_data['last_scanned'] ?? null;
        $report = $report_data['report'] ?? array();
        
        // Handle both direct report data and nested report_json structure
        $report_data_inner = $report;
        if (isset($report['report_json']) && is_array($report['report_json'])) {
          $report_data_inner = $report['report_json'];
        }
        
        if ($comp_domain) {
          $facts_text .= "\nCompetitor: " . $comp_domain . "\n";
          if ($last_scanned) {
            $facts_text .= "  - Last Scanned: " . $last_scanned . "\n";
          }
          
          // Public Pages
          if (!empty($report_data_inner['public_pages'])) {
            $facts_text .= "  - Public Pages Count: " . $report_data_inner['public_pages'] . "\n";
          }
          
          // Blog Status
          if (!empty($report_data_inner['blog']) && is_array($report_data_inner['blog'])) {
            $blog_status = isset($report_data_inner['blog']['status']) ? $report_data_inner['blog']['status'] : 'Unknown';
            $facts_text .= "  - Blog Status: " . ucfirst($blog_status) . "\n";
          }
          
          // Lighthouse Score
          if (!empty($report_data_inner['lighthouse_score'])) {
            $facts_text .= "  - Lighthouse Score: " . $report_data_inner['lighthouse_score'] . "\n";
          } elseif (isset($report_data_inner['lighthouse']) && is_array($report_data_inner['lighthouse'])) {
            $lh = $report_data_inner['lighthouse'];
            if (!empty($lh['performance'])) {
              $facts_text .= "  - Lighthouse Performance: " . $lh['performance'] . "\n";
            }
            if (!empty($lh['accessibility'])) {
              $facts_text .= "  - Lighthouse Accessibility: " . $lh['accessibility'] . "\n";
            }
            if (!empty($lh['seo'])) {
              $facts_text .= "  - Lighthouse SEO: " . $lh['seo'] . "\n";
            }
            if (!empty($lh['best_practices'])) {
              $facts_text .= "  - Lighthouse Best Practices: " . $lh['best_practices'] . "\n";
            }
          }
          
          // Domain Ranking (VLDR)
          if (isset($facts['vldr'][$comp_domain])) {
            $vldr = $facts['vldr'][$comp_domain];
            if (!empty($vldr['vldr_score'])) {
              $facts_text .= "  - Domain Ranking (VL-DR): " . number_format($vldr['vldr_score'], 2) . "/100\n";
            }
          }
          
          // Meta Description
          if (!empty($report_data_inner['meta_description'])) {
            $facts_text .= "  - Meta Description: " . substr($report_data_inner['meta_description'], 0, 150) . "...\n";
          }
          
          // Keywords
          if (!empty($report_data_inner['keywords']) && is_array($report_data_inner['keywords'])) {
            $top_keywords = array_slice($report_data_inner['keywords'], 0, 10);
            $facts_text .= "  - Top Keywords: " . implode(', ', $top_keywords) . "\n";
          }
          
          // Keyphrases
          if (!empty($report_data_inner['keyphrases']) && is_array($report_data_inner['keyphrases'])) {
            $top_keyphrases = array_slice($report_data_inner['keyphrases'], 0, 10);
            $facts_text .= "  - Top Keyphrases: " . implode(', ', $top_keyphrases) . "\n";
          }
          
          // Page Title
          if (!empty($report_data_inner['title'])) {
            $facts_text .= "  - Page Title: " . $report_data_inner['title'] . "\n";
          }
        }
      }
    }
  }
  
  // Add VLDR (Domain Ranking) data
  if (isset($facts['vldr']) && is_array($facts['vldr']) && !empty($facts['vldr'])) {
    $facts_text .= "\n\nDOMAIN RANKING (VL-DR) DATA:\n";
    foreach ($facts['vldr'] as $domain => $vldr_data) {
      $is_client = isset($vldr_data['is_client']) && $vldr_data['is_client'];
      $label = $is_client ? "Client Domain" : "Competitor";
      $facts_text .= $label . ": " . $domain . "\n";
      if (isset($vldr_data['vldr_score'])) {
        $facts_text .= "  - VL-DR Score: " . number_format($vldr_data['vldr_score'], 1) . " (0-100)\n";
      }
      if (isset($vldr_data['ref_domains'])) {
        $facts_text .= "  - Referring Domains: ~" . number_format($vldr_data['ref_domains'] / 1000, 1) . "k\n";
      }
      if (isset($vldr_data['indexed_pages'])) {
        $facts_text .= "  - Indexed Pages: ~" . number_format($vldr_data['indexed_pages'] / 1000, 1) . "k\n";
      }
      if (isset($vldr_data['lighthouse_avg'])) {
        $facts_text .= "  - Lighthouse Average: " . $vldr_data['lighthouse_avg'] . "\n";
      }
      if (isset($vldr_data['security_grade'])) {
        $facts_text .= "  - Security Grade: " . $vldr_data['security_grade'] . "\n";
      }
      if (isset($vldr_data['domain_age_years'])) {
        $facts_text .= "  - Domain Age: " . number_format($vldr_data['domain_age_years'], 1) . " years\n";
      }
      if (isset($vldr_data['uptime_percent'])) {
        $facts_text .= "  - Uptime: " . number_format($vldr_data['uptime_percent'], 2) . "%\n";
      }
      if (isset($vldr_data['metric_date'])) {
        $facts_text .= "  - Last Updated: " . $vldr_data['metric_date'] . "\n";
      }
      $facts_text .= "\n";
    }
    $facts_text .= "Note: VL-DR (Visible Light Domain Ranking) is computed from public indicators: Common Crawl/Index, Bing Web Search, SecurityHeaders.com, WHOIS, Visible Light Uptime monitoring, and Lighthouse performance scores.\n";
  }
  
  // Add performance metrics
  if (isset($facts['performance']) && is_array($facts['performance'])) {
    $facts_text .= "\n\nPERFORMANCE METRICS:\n";
    if (isset($facts['performance']['lighthouse']) && is_array($facts['performance']['lighthouse'])) {
      $lh = $facts['performance']['lighthouse'];
      $facts_text .= "Lighthouse Scores:\n";
      $facts_text .= "  - Performance: " . ($lh['performance'] ?? 'N/A') . "\n";
      $facts_text .= "  - Accessibility: " . ($lh['accessibility'] ?? 'N/A') . "\n";
      $facts_text .= "  - SEO: " . ($lh['seo'] ?? 'N/A') . "\n";
      $facts_text .= "  - Best Practices: " . ($lh['best_practices'] ?? 'N/A') . "\n";
      if (!empty($lh['last_updated'])) {
        $facts_text .= "  - Last Updated: " . $lh['last_updated'] . "\n";
      }
    }
  }
  
  // Add Lighthouse Data (from demo or real data)
  if (isset($facts['lighthouse']) && is_array($facts['lighthouse']) && !empty($facts['lighthouse'])) {
    $lighthouse = $facts['lighthouse'];
    $facts_text .= "\n\nLIGHTHOUSE PERFORMANCE ANALYSIS:\n";
    if (isset($lighthouse['connected'])) {
      $facts_text .= "  - Connected: " . ($lighthouse['connected'] ? 'Yes' : 'No') . "\n";
    }
    if (isset($lighthouse['url'])) {
      $facts_text .= "  - Analyzed URL: " . $lighthouse['url'] . "\n";
    }
    if (isset($lighthouse['last_analysis'])) {
      $facts_text .= "  - Last Analysis: " . $lighthouse['last_analysis'] . "\n";
    }
    if (isset($lighthouse['analysis_count'])) {
      $facts_text .= "  - Total Analyses: " . $lighthouse['analysis_count'] . "\n";
    }
    
    // Latest scores
    if (isset($lighthouse['latest']) && is_array($lighthouse['latest'])) {
      $latest = $lighthouse['latest'];
      $facts_text .= "  - Latest Scores:\n";
      if (isset($latest['performance'])) {
        $facts_text .= "    * Performance: " . $latest['performance'] . "/100\n";
      }
      if (isset($latest['accessibility'])) {
        $facts_text .= "    * Accessibility: " . $latest['accessibility'] . "/100\n";
      }
      if (isset($latest['best_practices'])) {
        $facts_text .= "    * Best Practices: " . $latest['best_practices'] . "/100\n";
      }
      if (isset($latest['seo'])) {
        $facts_text .= "    * SEO: " . $latest['seo'] . "/100\n";
      }
      if (isset($latest['overall'])) {
        $facts_text .= "    * Overall Score: " . $latest['overall'] . "/100\n";
      }
    }
    
    // Core Web Vitals
    if (isset($lighthouse['metrics']) && is_array($lighthouse['metrics'])) {
      $metrics = $lighthouse['metrics'];
      $facts_text .= "  - Core Web Vitals:\n";
      if (isset($metrics['first_contentful_paint'])) {
        $facts_text .= "    * First Contentful Paint: " . $metrics['first_contentful_paint'] . "s\n";
      }
      if (isset($metrics['largest_contentful_paint'])) {
        $facts_text .= "    * Largest Contentful Paint: " . $metrics['largest_contentful_paint'] . "s\n";
      }
      if (isset($metrics['total_blocking_time'])) {
        $facts_text .= "    * Total Blocking Time: " . $metrics['total_blocking_time'] . "ms\n";
      }
      if (isset($metrics['cumulative_layout_shift'])) {
        $facts_text .= "    * Cumulative Layout Shift: " . $metrics['cumulative_layout_shift'] . "\n";
      }
      if (isset($metrics['speed_index'])) {
        $facts_text .= "    * Speed Index: " . $metrics['speed_index'] . "s\n";
      }
      if (isset($metrics['time_to_interactive'])) {
        $facts_text .= "    * Time to Interactive: " . $metrics['time_to_interactive'] . "s\n";
      }
    }
    
    // Optimization Opportunities
    if (isset($lighthouse['opportunities']) && is_array($lighthouse['opportunities']) && !empty($lighthouse['opportunities'])) {
      $facts_text .= "  - Top Optimization Opportunities:\n";
      foreach (array_slice($lighthouse['opportunities'], 0, 5) as $opp) {
        $facts_text .= "    * " . (isset($opp['title']) ? $opp['title'] : 'N/A');
        if (isset($opp['impact'])) {
          $facts_text .= " (Impact: " . $opp['impact'] . ")";
        }
        if (isset($opp['estimated_savings'])) {
          $facts_text .= " - Potential savings: " . $opp['estimated_savings'];
        }
        $facts_text .= "\n";
      }
    }
  }
  
  // Add Competitive Intelligence Data (from demo or real data)
  if (isset($facts['competitive']) && is_array($facts['competitive']) && !empty($facts['competitive'])) {
    $competitive = $facts['competitive'];
    $facts_text .= "\n\nCOMPETITIVE INTELLIGENCE:\n";
    if (isset($competitive['connected'])) {
      $facts_text .= "  - Connected: " . ($competitive['connected'] ? 'Yes' : 'No') . "\n";
    }
    
    // Competitors list
    if (isset($competitive['competitors']) && is_array($competitive['competitors']) && !empty($competitive['competitors'])) {
      $facts_text .= "  - Tracked Competitors (" . count($competitive['competitors']) . "):\n";
      foreach ($competitive['competitors'] as $competitor) {
        $facts_text .= "    * " . (isset($competitor['name']) ? $competitor['name'] : 'Unknown');
        if (isset($competitor['url'])) {
          $facts_text .= " (" . $competitor['url'] . ")";
        }
        if (isset($competitor['last_analysis'])) {
          $facts_text .= " - Last analyzed: " . $competitor['last_analysis'];
        }
        $facts_text .= "\n";
      }
    }
    
    // Summary
    if (isset($competitive['summary']) && is_array($competitive['summary'])) {
      $summary = $competitive['summary'];
      $facts_text .= "  - Summary:\n";
      if (isset($summary['total_competitors'])) {
        $facts_text .= "    * Total Competitors: " . $summary['total_competitors'] . "\n";
      }
      if (isset($summary['total_reports'])) {
        $facts_text .= "    * Total Reports: " . $summary['total_reports'] . "\n";
      }
      if (isset($summary['last_analysis'])) {
        $facts_text .= "    * Last Analysis: " . $summary['last_analysis'] . "\n";
      }
      if (isset($summary['average_lighthouse_score'])) {
        $facts_text .= "    * Average Lighthouse Score: " . $summary['average_lighthouse_score'] . "\n";
      }
      if (isset($summary['top_performing_competitor'])) {
        $facts_text .= "    * Top Performing Competitor: " . $summary['top_performing_competitor'] . "\n";
      }
      if (isset($summary['trending_keywords']) && is_array($summary['trending_keywords'])) {
        $facts_text .= "    * Trending Keywords: " . implode(', ', array_slice($summary['trending_keywords'], 0, 5)) . "\n";
      }
    }
    
    // Recent Reports
    if (isset($competitive['reports']) && is_array($competitive['reports']) && !empty($competitive['reports'])) {
      $facts_text .= "  - Recent Competitor Reports:\n";
      foreach (array_slice($competitive['reports'], 0, 3) as $report) {
        if (isset($report['competitor_name'])) {
          $facts_text .= "    * " . $report['competitor_name'];
          if (isset($report['analysis_date'])) {
            $facts_text .= " (Analyzed: " . $report['analysis_date'] . ")";
          }
          if (isset($report['lighthouse']) && is_array($report['lighthouse'])) {
            $lh = $report['lighthouse'];
            $facts_text .= " - Lighthouse: " . (isset($lh['overall']) ? $lh['overall'] : 'N/A') . "/100";
          }
          if (isset($report['domain_authority'])) {
            $facts_text .= " - Domain Authority: " . $report['domain_authority'];
          }
          $facts_text .= "\n";
        }
      }
    }
  }
  
  // Add Compliance Data (from demo or real data)
  if (isset($facts['compliance']) && is_array($facts['compliance']) && !empty($facts['compliance'])) {
    $compliance = $facts['compliance'];
    $facts_text .= "\n\nCOMPLIANCE & CERTIFICATIONS:\n";
    
    // Overall compliance
    if (isset($compliance['overall']) && is_array($compliance['overall'])) {
      $overall = $compliance['overall'];
      $facts_text .= "  - Overall Compliance Score: " . (isset($overall['compliance_score']) ? $overall['compliance_score'] : 'N/A') . "/100\n";
      $facts_text .= "  - Status: " . (isset($overall['status']) ? ucfirst($overall['status']) : 'N/A') . "\n";
      if (isset($overall['last_full_audit'])) {
        $facts_text .= "  - Last Full Audit: " . $overall['last_full_audit'] . "\n";
      }
      if (isset($overall['certifications'])) {
        $facts_text .= "  - Active Certifications: " . $overall['certifications'] . "\n";
      }
    }
    
    // GDPR Compliance
    if (isset($compliance['gdpr']) && is_array($compliance['gdpr'])) {
      $gdpr = $compliance['gdpr'];
      $facts_text .= "  - GDPR Compliance:\n";
      $facts_text .= "    * Status: " . (isset($gdpr['status']) ? ucfirst($gdpr['status']) : 'N/A') . "\n";
      $facts_text .= "    * Score: " . (isset($gdpr['score']) ? $gdpr['score'] : 'N/A') . "/100\n";
      if (isset($gdpr['last_audit'])) {
        $facts_text .= "    * Last Audit: " . $gdpr['last_audit'] . "\n";
      }
      if (isset($gdpr['requirements']) && is_array($gdpr['requirements'])) {
        $facts_text .= "    * Requirements Met: Privacy Policy, Cookie Consent, Data Processing Agreements, Right to Erasure, Data Breach Procedures\n";
      }
    }
    
    // Accessibility Compliance (WCAG)
    if (isset($compliance['accessibility']) && is_array($compliance['accessibility'])) {
      $accessibility = $compliance['accessibility'];
      $facts_text .= "  - Accessibility Compliance (WCAG):\n";
      $facts_text .= "    * Status: " . (isset($accessibility['status']) ? str_replace('_', ' ', $accessibility['status']) : 'N/A') . "\n";
      $facts_text .= "    * WCAG Level: " . (isset($accessibility['wcag_level']) ? $accessibility['wcag_level'] : 'N/A') . "\n";
      $facts_text .= "    * Score: " . (isset($accessibility['score']) ? $accessibility['score'] : 'N/A') . "/100\n";
      if (isset($accessibility['last_audit'])) {
        $facts_text .= "    * Last Audit: " . $accessibility['last_audit'] . "\n";
      }
    }
    
    // Security Compliance
    if (isset($compliance['security']) && is_array($compliance['security'])) {
      $sec_compliance = $compliance['security'];
      $facts_text .= "  - Security Compliance:\n";
      $facts_text .= "    * Status: " . (isset($sec_compliance['status']) ? ucfirst($sec_compliance['status']) : 'N/A') . "\n";
      $facts_text .= "    * Score: " . (isset($sec_compliance['score']) ? $sec_compliance['score'] : 'N/A') . "/100\n";
      if (isset($sec_compliance['certifications']) && is_array($sec_compliance['certifications'])) {
        $facts_text .= "    * Certifications:\n";
        foreach ($sec_compliance['certifications'] as $cert) {
          $facts_text .= "      - " . (isset($cert['name']) ? $cert['name'] : 'N/A');
          if (isset($cert['status'])) {
            $facts_text .= " (" . ucfirst($cert['status']) . ")";
          }
          if (isset($cert['expiry_date'])) {
            $facts_text .= " - Expires: " . $cert['expiry_date'];
          }
          $facts_text .= "\n";
        }
      }
    }
    
    // Performance Compliance
    if (isset($compliance['performance']) && is_array($compliance['performance'])) {
      $perf_compliance = $compliance['performance'];
      $facts_text .= "  - Performance Compliance:\n";
      $facts_text .= "    * Status: " . (isset($perf_compliance['status']) ? str_replace('_', ' ', $perf_compliance['status']) : 'N/A') . "\n";
      $facts_text .= "    * Score: " . (isset($perf_compliance['score']) ? $perf_compliance['score'] : 'N/A') . "/100\n";
      if (isset($perf_compliance['core_web_vitals']) && is_array($perf_compliance['core_web_vitals'])) {
        $facts_text .= "    * Core Web Vitals:\n";
        foreach ($perf_compliance['core_web_vitals'] as $metric => $data) {
          if (is_array($data) && isset($data['value']) && isset($data['status'])) {
            $facts_text .= "      - " . strtoupper($metric) . ": " . $data['value'] . " (" . ucfirst($data['status']) . ")\n";
          }
        }
      }
    }
  }
  
  // Add SEO data
  if (isset($facts['seo']) && is_array($facts['seo'])) {
    $facts_text .= "\n\nSEO METRICS:\n";
    $seo = $facts['seo'];
    $facts_text .= "  - Total Clicks: " . ($seo['total_clicks'] ?? 0) . "\n";
    $facts_text .= "  - Total Impressions: " . ($seo['total_impressions'] ?? 0) . "\n";
    $facts_text .= "  - Average CTR: " . number_format(($seo['avg_ctr'] ?? 0) * 100, 2) . "%\n";
    $facts_text .= "  - Average Position: " . number_format($seo['avg_position'] ?? 0, 1) . "\n";
    if (!empty($seo['top_queries']) && is_array($seo['top_queries'])) {
      $facts_text .= "  - Top Search Queries:\n";
      foreach (array_slice($seo['top_queries'], 0, 5) as $query) {
        $facts_text .= "    * " . ($query['query'] ?? '') . " - " . ($query['clicks'] ?? 0) . " clicks, " . number_format(($query['ctr'] ?? 0), 2) . "% CTR\n";
      }
    }
  }
  
  // Add data stream summary
  if (isset($facts['data_streams_summary']) && is_array($facts['data_streams_summary'])) {
    $streams_summary = $facts['data_streams_summary'];
    $facts_text .= "\n\nDATA STREAMS SUMMARY:\n";
    $facts_text .= "  - Total Streams: " . ($streams_summary['total'] ?? 0) . "\n";
    $facts_text .= "  - Active Streams: " . ($streams_summary['active'] ?? 0) . "\n";
    if (!empty($streams_summary['by_category']) && is_array($streams_summary['by_category'])) {
      $facts_text .= "  - Streams by Category:\n";
      foreach ($streams_summary['by_category'] as $category => $count) {
        $facts_text .= "    * " . ucfirst($category) . ": " . $count . "\n";
      }
    }
    if (!empty($streams_summary['recent']) && is_array($streams_summary['recent'])) {
      $facts_text .= "  - Recent Streams:\n";
      foreach ($streams_summary['recent'] as $stream) {
        $facts_text .= "    * " . ($stream['name'] ?? '') . " (" . ($stream['category'] ?? '') . ") - " . ($stream['last_updated'] ?? '') . "\n";
      }
    }
  }
  
  // Add ALL Data Streams (full data)
  if (isset($facts['data_streams']) && is_array($facts['data_streams']) && !empty($facts['data_streams'])) {
    $facts_text .= "\n\nALL DATA STREAMS (Full Details):\n";
    foreach ($facts['data_streams'] as $stream_id => $stream) {
      if (!is_array($stream)) continue;
      $facts_text .= "Stream: " . ($stream['name'] ?? $stream_id) . "\n";
      $facts_text .= "  - ID: " . $stream_id . "\n";
      $facts_text .= "  - Status: " . ($stream['status'] ?? 'unknown') . "\n";
      $facts_text .= "  - Category: " . (isset($stream['categories']) && is_array($stream['categories']) ? implode(', ', $stream['categories']) : 'N/A') . "\n";
      $facts_text .= "  - Health Score: " . ($stream['health_score'] ?? 'N/A') . "\n";
      $facts_text .= "  - Last Updated: " . ($stream['last_updated'] ?? 'N/A') . "\n";
      if (!empty($stream['description'])) {
        $facts_text .= "  - Description: " . substr($stream['description'], 0, 200) . "\n";
      }
      $facts_text .= "\n";
    }
  }
  
  // Add AWS S3 Data
  if (isset($facts['aws_s3']) && is_array($facts['aws_s3'])) {
    $facts_text .= "\n\nAWS S3 CLOUD STORAGE:\n";
    $aws_s3 = $facts['aws_s3'];
    if (!empty($aws_s3['settings'])) {
      $settings = $aws_s3['settings'];
      $facts_text .= "  - Bucket Count: " . ($settings['bucket_count'] ?? 0) . "\n";
      $facts_text .= "  - Object Count: " . ($settings['object_count'] ?? 0) . "\n";
      $facts_text .= "  - Storage Used: " . ($settings['storage_used'] ?? 'N/A') . "\n";
      $facts_text .= "  - Last Sync: " . ($settings['last_sync'] ?? 'Never') . "\n";
    }
    if (!empty($aws_s3['buckets']) && is_array($aws_s3['buckets'])) {
      $facts_text .= "  - Buckets:\n";
      foreach (array_slice($aws_s3['buckets'], 0, 10) as $bucket) {
        $facts_text .= "    * " . ($bucket['name'] ?? 'Unknown') . " - " . ($bucket['object_count'] ?? 0) . " objects, " . ($bucket['size'] ?? '0 B') . "\n";
      }
      if (count($aws_s3['buckets']) > 10) {
        $facts_text .= "    ... and " . (count($aws_s3['buckets']) - 10) . " more buckets\n";
      }
    }
  }
  
  // Add Liquid Web Assets
  if (isset($facts['liquidweb']) && is_array($facts['liquidweb'])) {
    $facts_text .= "\n\nLIQUID WEB HOSTING:\n";
    $liquidweb = $facts['liquidweb'];
    if (!empty($liquidweb['settings'])) {
      $settings = $liquidweb['settings'];
      $facts_text .= "  - Connected: " . (!empty($settings['api_key']) && !empty($settings['account_number']) ? 'Yes' : 'No') . "\n";
      $facts_text .= "  - Account Number: " . ($settings['account_number'] ?? 'N/A') . "\n";
      $facts_text .= "  - Last Sync: " . ($settings['last_sync'] ?? 'Never') . "\n";
    }
    if (!empty($liquidweb['assets']) && is_array($liquidweb['assets'])) {
      $facts_text .= "  - Asset Count: " . count($liquidweb['assets']) . "\n";
      foreach (array_slice($liquidweb['assets'], 0, 5) as $asset) {
        $facts_text .= "    * " . ($asset['name'] ?? 'Unknown') . " - " . ($asset['type'] ?? 'N/A') . "\n";
      }
      if (count($liquidweb['assets']) > 5) {
        $facts_text .= "    ... and " . (count($liquidweb['assets']) - 5) . " more assets\n";
      }
    }
  }
  
  // Add GA4 Metrics (comprehensive - ALL metrics synced to VL Hub)
  if (isset($facts['ga4_metrics']) && is_array($facts['ga4_metrics']) && !empty($facts['ga4_metrics'])) {
    $facts_text .= "\n\nGOOGLE ANALYTICS 4 (GA4) METRICS:\n";
    $ga4 = $facts['ga4_metrics'];
    $facts_text .= "  - Property ID: " . ($facts['ga4_property_id'] ?? ($ga4['property_id'] ?? 'N/A')) . "\n";
    $facts_text .= "  - Measurement ID: " . ($facts['ga4_measurement_id'] ?? ($ga4['measurement_id'] ?? 'N/A')) . "\n";
    $facts_text .= "  - Last Synced: " . ($facts['ga4_last_synced'] ?? ($ga4['last_synced'] ?? 'Never')) . "\n";
    $facts_text .= "  - Date Range: " . ($facts['ga4_date_range'] ?? ($ga4['date_range'] ?? 'N/A')) . "\n";
    $facts_text .= "  - User Metrics:\n";
    $facts_text .= "    * Total Users: " . number_format(isset($ga4['total_users']) ? (int)$ga4['total_users'] : (isset($ga4['users']) ? (int)$ga4['users'] : 0)) . "\n";
    $facts_text .= "    * New Users: " . number_format(isset($ga4['new_users']) ? (int)$ga4['new_users'] : 0) . "\n";
    $facts_text .= "    * Active Users: " . number_format(isset($ga4['active_users']) ? (int)$ga4['active_users'] : 0) . "\n";
    $facts_text .= "  - Session Metrics:\n";
    $facts_text .= "    * Sessions: " . number_format(isset($ga4['sessions']) ? (int)$ga4['sessions'] : 0) . "\n";
    $facts_text .= "    * Page Views: " . number_format(isset($ga4['page_views']) ? (int)$ga4['page_views'] : 0) . "\n";
    $facts_text .= "    * Bounce Rate: " . number_format(isset($ga4['bounce_rate']) ? (float)$ga4['bounce_rate'] * 100 : 0, 2) . "%\n";
    $facts_text .= "    * Avg Session Duration: " . number_format(isset($ga4['avg_session_duration']) ? (float)$ga4['avg_session_duration'] : 0, 0) . " seconds\n";
    $facts_text .= "  - Engagement Metrics:\n";
    $facts_text .= "    * Engagement Rate: " . number_format(isset($ga4['engagement_rate']) ? (float)$ga4['engagement_rate'] * 100 : 0, 2) . "%\n";
    $facts_text .= "    * Engaged Sessions: " . number_format(isset($ga4['engaged_sessions']) ? (int)$ga4['engaged_sessions'] : 0) . "\n";
    $facts_text .= "    * User Engagement Duration: " . number_format(isset($ga4['user_engagement_duration']) ? (float)$ga4['user_engagement_duration'] : 0, 0) . " seconds\n";
    $facts_text .= "  - Event Metrics:\n";
    $facts_text .= "    * Event Count: " . number_format(isset($ga4['event_count']) ? (int)$ga4['event_count'] : 0) . "\n";
    $facts_text .= "  - Conversion Metrics:\n";
    $facts_text .= "    * Conversions: " . number_format(isset($ga4['conversions']) ? (int)$ga4['conversions'] : 0) . "\n";
    $facts_text .= "    * Total Revenue: $" . number_format(isset($ga4['total_revenue']) ? (float)$ga4['total_revenue'] : 0, 2) . "\n";
    $facts_text .= "    * Purchase Revenue: $" . number_format(isset($ga4['purchase_revenue']) ? (float)$ga4['purchase_revenue'] : 0, 2) . "\n";
    $facts_text .= "    * Average Purchase Revenue: $" . number_format(isset($ga4['average_purchase_revenue']) ? (float)$ga4['average_purchase_revenue'] : 0, 2) . "\n";
    $facts_text .= "    * Transactions: " . number_format(isset($ga4['transactions']) ? (int)$ga4['transactions'] : 0) . "\n";
    $facts_text .= "    * Session Conversion Rate: " . number_format(isset($ga4['session_conversion_rate']) ? (float)$ga4['session_conversion_rate'] * 100 : 0, 2) . "%\n";
    $facts_text .= "    * Total Purchasers: " . number_format(isset($ga4['total_purchasers']) ? (int)$ga4['total_purchasers'] : 0) . "\n";
    // Include any additional GA4 metrics
    foreach ($ga4 as $metric_name => $metric_value) {
      if (!in_array($metric_name, array('property_id', 'measurement_id', 'last_synced', 'date_range', 'total_users', 'users', 'new_users', 'active_users', 'sessions', 'page_views', 'bounce_rate', 'avg_session_duration', 'engagement_rate', 'engaged_sessions', 'user_engagement_duration', 'event_count', 'conversions', 'total_revenue', 'purchase_revenue', 'average_purchase_revenue', 'transactions', 'session_conversion_rate', 'total_purchasers'))) {
      if (is_numeric($metric_value)) {
        $facts_text .= "    * " . ucwords(str_replace('_', ' ', $metric_name)) . ": " . number_format($metric_value) . "\n";
      } elseif (is_array($metric_value)) {
        $facts_text .= "    * " . ucwords(str_replace('_', ' ', $metric_name)) . ": " . json_encode($metric_value) . "\n";
      } else {
        $facts_text .= "    * " . ucwords(str_replace('_', ' ', $metric_name)) . ": " . $metric_value . "\n";
        }
      }
    }
    
    // Add GA4 Dimensional Data (geographic, device, traffic, pages, events, page_location)
    if (isset($facts['ga4_dimensions']) && is_array($facts['ga4_dimensions']) && !empty($facts['ga4_dimensions'])) {
      $dimensions = $facts['ga4_dimensions'];
      
      // Geographic Data
      $geographic_data = null;
      if (isset($dimensions['geographic']['rows']) && is_array($dimensions['geographic']['rows'])) {
        $geographic_data = $dimensions['geographic']['rows'];
      } elseif (isset($dimensions['geographic']) && is_array($dimensions['geographic']) && isset($dimensions['geographic'][0])) {
        $geographic_data = $dimensions['geographic'];
      }
      
      if ($geographic_data && !empty($geographic_data)) {
        $facts_text .= "  - Geographic Data (Top " . min(10, count($geographic_data)) . " locations):\n";
        foreach (array_slice($geographic_data, 0, 10) as $row) {
          if (!is_array($row) || empty($row['dimensionValues']) || empty($row['metricValues'])) continue;
          $country = $row['dimensionValues'][0]['value'] ?? '(not set)';
          $region = $row['dimensionValues'][1]['value'] ?? '(not set)';
          $city = $row['dimensionValues'][2]['value'] ?? '(not set)';
          $users = isset($row['metricValues'][0]['value']) ? number_format((int)$row['metricValues'][0]['value']) : '0';
          $sessions = isset($row['metricValues'][2]['value']) ? number_format((int)$row['metricValues'][2]['value']) : '0';
          $page_views = isset($row['metricValues'][3]['value']) ? number_format((int)$row['metricValues'][3]['value']) : '0';
          $facts_text .= "    * " . $city . ", " . $region . ", " . $country . ": " . $users . " users, " . $sessions . " sessions, " . $page_views . " page views\n";
        }
      }
      
      // Device Data
      $device_data = null;
      if (isset($dimensions['device']['rows']) && is_array($dimensions['device']['rows'])) {
        $device_data = $dimensions['device']['rows'];
      } elseif (isset($dimensions['device']) && is_array($dimensions['device']) && isset($dimensions['device'][0])) {
        $device_data = $dimensions['device'];
      }
      
      if ($device_data && !empty($device_data)) {
        $facts_text .= "  - Device Data (" . count($device_data) . " device types):\n";
        foreach ($device_data as $row) {
          if (!is_array($row) || empty($row['dimensionValues']) || empty($row['metricValues'])) continue;
          $device = $row['dimensionValues'][0]['value'] ?? '(not set)';
          $brand = $row['dimensionValues'][1]['value'] ?? '(not set)';
          $browser = $row['dimensionValues'][2]['value'] ?? '(not set)';
          $users = isset($row['metricValues'][0]['value']) ? number_format((int)$row['metricValues'][0]['value']) : '0';
          $sessions = isset($row['metricValues'][2]['value']) ? number_format((int)$row['metricValues'][2]['value']) : '0';
          $page_views = isset($row['metricValues'][3]['value']) ? number_format((int)$row['metricValues'][3]['value']) : '0';
          $facts_text .= "    * " . ucfirst($device) . " (" . $brand . " " . $browser . "): " . $users . " users, " . $sessions . " sessions, " . $page_views . " page views\n";
        }
      }
      
      // Traffic Sources Data
      $traffic_data = null;
      if (isset($dimensions['traffic']['rows']) && is_array($dimensions['traffic']['rows'])) {
        $traffic_data = $dimensions['traffic']['rows'];
      } elseif (isset($dimensions['traffic']) && is_array($dimensions['traffic']) && isset($dimensions['traffic'][0])) {
        $traffic_data = $dimensions['traffic'];
      }
      
      if ($traffic_data && !empty($traffic_data)) {
        $facts_text .= "  - Traffic Sources (" . count($traffic_data) . " sources):\n";
        foreach ($traffic_data as $row) {
          if (!is_array($row) || empty($row['dimensionValues']) || empty($row['metricValues'])) continue;
          $source = $row['dimensionValues'][0]['value'] ?? '(not set)';
          $medium = $row['dimensionValues'][1]['value'] ?? '(not set)';
          $campaign = $row['dimensionValues'][2]['value'] ?? '(not set)';
          $users = isset($row['metricValues'][0]['value']) ? number_format((int)$row['metricValues'][0]['value']) : '0';
          $sessions = isset($row['metricValues'][2]['value']) ? number_format((int)$row['metricValues'][2]['value']) : '0';
          $page_views = isset($row['metricValues'][3]['value']) ? number_format((int)$row['metricValues'][3]['value']) : '0';
          $facts_text .= "    * " . $source . " / " . $medium . ($campaign !== '(not set)' ? " / " . $campaign : "") . ": " . $users . " users, " . $sessions . " sessions, " . $page_views . " page views\n";
        }
      }
      
      // Pages Data
      $pages_data = null;
      if (isset($dimensions['pages']['rows']) && is_array($dimensions['pages']['rows'])) {
        $pages_data = $dimensions['pages']['rows'];
      } elseif (isset($dimensions['pages']) && is_array($dimensions['pages']) && isset($dimensions['pages'][0])) {
        $pages_data = $dimensions['pages'];
      }
      
      if ($pages_data && !empty($pages_data)) {
        $facts_text .= "  - Top Pages (Top " . min(15, count($pages_data)) . " pages):\n";
        foreach (array_slice($pages_data, 0, 15) as $row) {
          if (!is_array($row) || empty($row['dimensionValues']) || empty($row['metricValues'])) continue;
          $path = $row['dimensionValues'][0]['value'] ?? '(not set)';
          $title = $row['dimensionValues'][1]['value'] ?? '(not set)';
          $users = isset($row['metricValues'][0]['value']) ? number_format((int)$row['metricValues'][0]['value']) : '0';
          $sessions = isset($row['metricValues'][2]['value']) ? number_format((int)$row['metricValues'][2]['value']) : '0';
          $page_views = isset($row['metricValues'][3]['value']) ? number_format((int)$row['metricValues'][3]['value']) : '0';
          $facts_text .= "    * " . $title . " (" . $path . "): " . $users . " users, " . $sessions . " sessions, " . $page_views . " page views\n";
        }
      }
      
      // Events Data
      $events_data = null;
      if (isset($dimensions['events']['rows']) && is_array($dimensions['events']['rows'])) {
        $events_data = $dimensions['events']['rows'];
      } elseif (isset($dimensions['events']) && is_array($dimensions['events']) && isset($dimensions['events'][0])) {
        $events_data = $dimensions['events'];
      }
      
      if ($events_data && !empty($events_data)) {
        $facts_text .= "  - Events (" . count($events_data) . " events):\n";
        foreach ($events_data as $row) {
          if (!is_array($row) || empty($row['dimensionValues']) || empty($row['metricValues'])) continue;
          $event_name = $row['dimensionValues'][0]['value'] ?? '(not set)';
          $event_count = isset($row['metricValues'][0]['value']) ? number_format((int)$row['metricValues'][0]['value']) : '0';
          $users = isset($row['metricValues'][1]['value']) ? number_format((int)$row['metricValues'][1]['value']) : '0';
          $conversions = isset($row['metricValues'][2]['value']) ? number_format((int)$row['metricValues'][2]['value']) : '0';
          $facts_text .= "    * " . $event_name . ": " . $event_count . " events, " . $users . " users, " . $conversions . " conversions\n";
        }
      }
      
      // Page Location Data (pageTitle, country, city)
      $page_location_data = null;
      if (isset($dimensions['page_location']['rows']) && is_array($dimensions['page_location']['rows'])) {
        $page_location_data = $dimensions['page_location']['rows'];
      } elseif (isset($dimensions['page_location']) && is_array($dimensions['page_location']) && isset($dimensions['page_location'][0])) {
        $page_location_data = $dimensions['page_location'];
      }
      
      if ($page_location_data && !empty($page_location_data)) {
        $facts_text .= "  - Page Location Data (Top " . min(10, count($page_location_data)) . " page-location combinations):\n";
        foreach (array_slice($page_location_data, 0, 10) as $row) {
          if (!is_array($row) || empty($row['dimensionValues']) || empty($row['metricValues'])) continue;
          $page_title = $row['dimensionValues'][0]['value'] ?? '(not set)';
          $country = $row['dimensionValues'][1]['value'] ?? '(not set)';
          $city = $row['dimensionValues'][2]['value'] ?? '(not set)';
          $active_users = isset($row['metricValues'][0]['value']) ? number_format((int)$row['metricValues'][0]['value']) : '0';
          $page_views = isset($row['metricValues'][1]['value']) ? number_format((int)$row['metricValues'][1]['value']) : '0';
          $facts_text .= "    * " . $page_title . " (" . $city . ", " . $country . "): " . $active_users . " active users, " . $page_views . " page views\n";
        }
      }
    }
  }
  
  // Add Lighthouse Insights Data (from VL Hub)
  if (isset($facts['lighthouse_insights']) && is_array($facts['lighthouse_insights']) && !empty($facts['lighthouse_insights'])) {
    $lighthouse = $facts['lighthouse_insights'];
    $facts_text .= "\n\nLIGHTHOUSE INSIGHTS REPORT:\n";
    $facts_text .= "  - Report Name: " . ($lighthouse['name'] ?? 'Lighthouse Insights Report') . "\n";
    $facts_text .= "  - URL: " . ($lighthouse['url'] ?? ($lighthouse['pagespeed_url'] ?? ($lighthouse['source_url'] ?? 'N/A'))) . "\n";
    $facts_text .= "  - Health Score: " . number_format(isset($lighthouse['health_score']) ? (float)$lighthouse['health_score'] : 0, 0) . "/100\n";
    $facts_text .= "  - Error Count: " . number_format(isset($lighthouse['error_count']) ? (int)$lighthouse['error_count'] : 0) . "\n";
    $facts_text .= "  - Warning Count: " . number_format(isset($lighthouse['warning_count']) ? (int)$lighthouse['warning_count'] : 0) . "\n";
    $facts_text .= "  - Status: " . ($lighthouse['status'] ?? 'N/A') . "\n";
    $facts_text .= "  - Last Updated: " . ($lighthouse['last_updated'] ?? ($lighthouse['created'] ?? 'N/A')) . "\n";
    if (isset($lighthouse['report_data']) && is_array($lighthouse['report_data'])) {
      $report_data = $lighthouse['report_data'];
      $facts_text .= "  - Report Data:\n";
      $facts_text .= "    * Performance Score: " . number_format(isset($report_data['performance_score']) ? (float)$report_data['performance_score'] : 0, 0) . "/100\n";
      $facts_text .= "    * Accessibility Score: " . number_format(isset($report_data['accessibility_score']) ? (float)$report_data['accessibility_score'] : 0, 0) . "/100\n";
      $facts_text .= "    * Best Practices Score: " . number_format(isset($report_data['best_practices_score']) ? (float)$report_data['best_practices_score'] : 0, 0) . "/100\n";
      $facts_text .= "    * SEO Score: " . number_format(isset($report_data['seo_score']) ? (float)$report_data['seo_score'] : 0, 0) . "/100\n";
      $facts_text .= "    * Overall Score: " . number_format(isset($report_data['overall_score']) ? (float)$report_data['overall_score'] : 0, 0) . "/100\n";
      $facts_text .= "    * Strategy: " . ($report_data['strategy'] ?? 'N/A') . "\n";
    }
    if (isset($lighthouse['categories']) && is_array($lighthouse['categories'])) {
      $facts_text .= "  - Categories: " . implode(', ', $lighthouse['categories']) . "\n";
    }
  }
  
  // Add Google Ads Data (when available)
  if (isset($facts['google_ads']) && is_array($facts['google_ads']) && !empty($facts['google_ads'])) {
    $google_ads = $facts['google_ads'];
    $facts_text .= "\n\nGOOGLE ADS:\n";
    $facts_text .= "  - Connection Status: " . (isset($google_ads['connected']) && $google_ads['connected'] ? 'Connected' : 'Not connected') . "\n";
    if (isset($google_ads['account_id'])) {
      $facts_text .= "  - Account ID: " . $google_ads['account_id'] . "\n";
    }
    if (isset($google_ads['campaigns_count'])) {
      $facts_text .= "  - Campaigns: " . number_format((int)$google_ads['campaigns_count']) . "\n";
    }
    if (isset($google_ads['last_sync'])) {
      $facts_text .= "  - Last Sync: " . $google_ads['last_sync'] . "\n";
    }
    if (isset($google_ads['metrics']) && is_array($google_ads['metrics'])) {
      $facts_text .= "  - Metrics:\n";
      foreach ($google_ads['metrics'] as $metric_name => $metric_value) {
        if (is_numeric($metric_value)) {
          $facts_text .= "    * " . ucwords(str_replace('_', ' ', $metric_name)) . ": " . number_format($metric_value) . "\n";
        } else {
          $facts_text .= "    * " . ucwords(str_replace('_', ' ', $metric_name)) . ": " . $metric_value . "\n";
        }
      }
    }
  }
  
  // Add LinkedIn Ads Data (when available)
  if (isset($facts['linkedin_ads']) && is_array($facts['linkedin_ads']) && !empty($facts['linkedin_ads'])) {
    $linkedin_ads = $facts['linkedin_ads'];
    $facts_text .= "\n\nLINKEDIN ADS:\n";
    $facts_text .= "  - Connection Status: " . (isset($linkedin_ads['connected']) && $linkedin_ads['connected'] ? 'Connected' : 'Not connected') . "\n";
    if (isset($linkedin_ads['account_id'])) {
      $facts_text .= "  - Account ID: " . $linkedin_ads['account_id'] . "\n";
    }
    if (isset($linkedin_ads['campaigns_count'])) {
      $facts_text .= "  - Campaigns: " . number_format((int)$linkedin_ads['campaigns_count']) . "\n";
    }
    if (isset($linkedin_ads['last_sync'])) {
      $facts_text .= "  - Last Sync: " . $linkedin_ads['last_sync'] . "\n";
    }
    if (isset($linkedin_ads['metrics']) && is_array($linkedin_ads['metrics'])) {
      $facts_text .= "  - Metrics:\n";
      foreach ($linkedin_ads['metrics'] as $metric_name => $metric_value) {
        if (is_numeric($metric_value)) {
          $facts_text .= "    * " . ucwords(str_replace('_', ' ', $metric_name)) . ": " . number_format($metric_value) . "\n";
        } else {
          $facts_text .= "    * " . ucwords(str_replace('_', ' ', $metric_name)) . ": " . $metric_value . "\n";
        }
      }
    }
  }
  
  // Add Meta Ads Data (when available)
  if (isset($facts['meta_ads']) && is_array($facts['meta_ads']) && !empty($facts['meta_ads'])) {
    $meta_ads = $facts['meta_ads'];
    $facts_text .= "\n\nMETA ADS:\n";
    $facts_text .= "  - Connection Status: " . (isset($meta_ads['connected']) && $meta_ads['connected'] ? 'Connected' : 'Not connected') . "\n";
    if (isset($meta_ads['account_id'])) {
      $facts_text .= "  - Account ID: " . $meta_ads['account_id'] . "\n";
    }
    if (isset($meta_ads['campaigns_count'])) {
      $facts_text .= "  - Campaigns: " . number_format((int)$meta_ads['campaigns_count']) . "\n";
    }
    if (isset($meta_ads['last_sync'])) {
      $facts_text .= "  - Last Sync: " . $meta_ads['last_sync'] . "\n";
    }
    if (isset($meta_ads['metrics']) && is_array($meta_ads['metrics'])) {
      $facts_text .= "  - Metrics:\n";
      foreach ($meta_ads['metrics'] as $metric_name => $metric_value) {
        if (is_numeric($metric_value)) {
          $facts_text .= "    * " . ucwords(str_replace('_', ' ', $metric_name)) . ": " . number_format($metric_value) . "\n";
        } else {
          $facts_text .= "    * " . ucwords(str_replace('_', ' ', $metric_name)) . ": " . $metric_value . "\n";
        }
      }
    }
  }

  // Check if this is a Luna Composer request
  $is_composer_request = $is_composer;
  
  $system_message = "You are Luna, a friendly, conversational WebOps assistant and AI companion with comprehensive access to ALL Visible Light Hub data. You have real-time visibility into SSL/TLS certificates, Cloudflare connections, AWS S3 storage, Google Analytics 4 (GA4) with ALL metrics (Total Users, New Users, Active Users, Sessions, Page Views, Bounce Rate, Avg Session Duration, Engagement Rate, Engaged Sessions, User Engagement Duration, Event Count, Conversions, Total Revenue, Purchase Revenue, Average Purchase Revenue, Transactions, Session Conversion Rate, Total Purchasers) AND comprehensive dimensional data including Geographic Data (countries, regions, cities with user/session/page view counts), Device Data (device types, brands, browsers with metrics), Traffic Sources (sources, mediums, campaigns with metrics), Top Pages (page paths, titles with metrics), Events (event names, counts, users, conversions), and Page Location Data (page-location combinations). Liquid Web hosting, Lighthouse Insights (Performance, Accessibility, Best Practices, SEO scores), Google Ads, LinkedIn Ads, Meta Ads, competitor analysis, domain rankings (VLDR), performance metrics, SEO data, and all data streams.\n\n";
  $system_message .= "YOUR PERSONALITY:\n";
  $system_message .= "You are conversational, helpful, and engaging. You can answer both specific data questions about the user's site AND general web-related questions. When users ask conceptual questions (like 'What is SSL?' or 'Is SSL and TLS the same thing?'), provide educational, conversational answers that help them understand. When they ask about their specific site data, use the FACTS provided below to give accurate, detailed answers. Blend data with context and conversation - don't just dump raw data. Make responses feel natural and human-like, as if you're having a friendly conversation with a colleague. Be helpful, personable, and make the conversation flow naturally.\n\n";
  $system_message .= "CRITICAL RULES:\n";
  $system_message .= "1. NEVER use emoticons, emojis, unicode symbols, or special characters (like 🌐, 📊, 🔒, 📈, 📝, 🏗️, 🔄, 💡, 📋, ❌, ✅, etc.) in your responses unless the user specifically requests them. Use plain text only.\n";
  $system_message .= "2. Write in a personable, professional, conversational tone. Be friendly and helpful. Use full sentences, proper paragraph breaks, and narrative-style explanations. When providing data, add context and explanation - don't just list facts. Make it feel like a natural conversation.\n";
  $system_message .= "3. When asked about ANY VL Hub data, check the corresponding section in FACTS and provide detailed, accurate answers using that data. But also add conversational context - explain what the data means, why it matters, and what the user might want to do with it.\n";
  $system_message .= "4. For general web-related questions (not specific to their site), provide helpful, educational answers that demonstrate your knowledge while staying conversational and engaging.\n";
  
  if ($is_composer_request || $is_comprehensive_report) {
    if ($is_composer_request) {
      $system_message .= "5. You are Luna Composer, generating long-form, thoughtful, and hyper-personal data-driven content. The user is creating editable long-form content, so your response must be comprehensive, well-structured, and suitable for professional editing. Write in a thoughtful, engaging, and personable manner that feels human and authentic, not robotic. Use full sentences, proper paragraph breaks, and narrative-style explanations. CRITICAL: You MUST use the actual VL Hub data provided in the FACTS section below. Reference specific metrics, trends, and insights from the user's actual data (GA4 metrics, Lighthouse scores, competitor analysis, domain rankings, etc.). Weave this real data naturally into a cohesive narrative. Make the content feel personalized and tailored to the user's specific needs and their actual digital presence. Analyze the data, highlight trends, call out risks or opportunities, and provide strategic recommendations or next steps so the user receives meaningful guidance rather than just raw metrics. When data is missing or limited, acknowledge the gap and recommend how to close it. Generate a substantial, detailed response (minimum 300-500 words for simple queries, 800-1200+ words for complex queries) that provides real value and can be edited into polished content. NEVER use emoticons, emojis, unicode symbols, or special characters. Use plain text only.\n";
    } else {
      $system_message .= "5. You are generating a comprehensive, enterprise-grade, leadership-focused report. Write in a thoughtful, full-length, professional manner that reads like a human executive report. Use descriptive, narrative-style explanations with proper paragraph breaks. Include an intro header, detailed findings from ALL data sources (GA4 metrics, Lighthouse Insights, ad platform data, competitor analysis, performance metrics, etc.), and an official signature. Format with proper paragraph breaks and section headers. NEVER use emoticons, emojis, unicode symbols, or special characters. Use plain text only. Ensure the report is comprehensive and includes ALL available data from VL Hub.\n";
    }
  }
  $system_message .= "6. For comprehensive reports, site health reports, or multi-sentence requests, write in a thoughtful, full-length, professional manner that reads like a human executive report. Use descriptive, narrative-style explanations with proper paragraph breaks. Include ALL available data from VL Hub, including GA4 metrics, Lighthouse Insights, ad platform data (Google Ads, LinkedIn Ads, Meta Ads when available), competitor analysis, performance metrics, and SEO data.\n";
  $system_message .= "7. If data is incomplete or missing from VL Hub for any category (GA4, Lighthouse, ad platforms, etc.), still generate a thoughtful, comprehensive response. Explicitly mention what data is missing and provide suggestions on what Visible Light needs to work efficiently in that category. For example, if Google Ads data is not available, mention that Google Ads integration is not currently connected and suggest connecting it in VL Hub for comprehensive ad performance analysis.\n";

  $messages = array(
    array('role'=>'system','content'=>$system_message),
    array('role'=>'system','content'=>$facts_text),
  );
  $t = get_post_meta($pid, 'transcript', true);
  if (!is_array($t)) $t = array();
  $slice = array_slice($t, max(0, count($t)-8));
  foreach ($slice as $row) {
    $u = trim(isset($row['user']) ? (string)$row['user'] : '');
    $a = trim(isset($row['assistant']) ? (string)$row['assistant'] : '');
    if ($u !== '') $messages[] = array('role'=>'user','content'=>$u);
    if ($a !== '') $messages[] = array('role'=>'assistant','content'=>$a);
  }
  if ($user_text !== '') $messages[] = array('role'=>'user','content'=>$user_text);
  return $messages;
}

function luna_generate_openai_answer($pid, $prompt, $facts, $is_comprehensive_report = false) {
  $api_key = luna_get_openai_key();
  if ($api_key === '') {
    return null;
  }

  $model    = apply_filters('luna_openai_model', 'gpt-4o');
  $is_composer_flag = isset($facts['__composer']) ? $facts['__composer'] : false;
  $messages = luna_openai_messages_with_facts($pid, $prompt, $facts, $is_comprehensive_report, $is_composer_flag);
  $payload  = array(
    'model'       => $model,
    'messages'    => $messages,
    'temperature' => 0.7,
    'max_tokens'  => ($is_comprehensive_report || $is_composer_flag) ? 4000 : 2000, // Increase tokens for comprehensive reports and composer
  );

  $response = wp_remote_post('https://api.openai.com/v1/chat/completions', array(
    'timeout' => 30,
    'headers' => array(
      'Content-Type'  => 'application/json',
      'Authorization' => 'Bearer ' . $api_key,
    ),
    'body'    => wp_json_encode($payload),
  ));

  if (is_wp_error($response)) {
    error_log('[Luna Widget] OpenAI request failed: ' . $response->get_error_message());
    return null;
  }

  $status   = (int) wp_remote_retrieve_response_code($response);
  $raw_body = wp_remote_retrieve_body($response);
  if ($status >= 400) {
    error_log('[Luna Widget] OpenAI HTTP ' . $status . ': ' . substr($raw_body, 0, 500));
    return null;
  }

  $decoded = json_decode($raw_body, true);
  if (!is_array($decoded)) {
    error_log('[Luna Widget] OpenAI returned invalid JSON.');
    return null;
  }

  $content = '';
  if (!empty($decoded['choices'][0]['message']['content'])) {
    $content = (string) $decoded['choices'][0]['message']['content'];
  } elseif (!empty($decoded['choices'][0]['text'])) {
    $content = (string) $decoded['choices'][0]['text'];
  }

  $content = trim($content);
  if ($content === '') {
    return null;
  }

  $result = array(
    'answer' => $content,
    'model'  => $model,
  );

  if (!empty($decoded['usage']) && is_array($decoded['usage'])) {
    $result['usage'] = $decoded['usage'];
  }

  return $result;
}

/* ============================================================
 * REST: Chat + History + Hub-facing lists + Utilities
 * ============================================================ */

if (!function_exists('luna_request_value_signals_composer')) {
  function luna_request_value_signals_composer($value) {
    if (is_bool($value)) {
      return $value === true;
    }

    if (is_string($value)) {
      $normalized = strtolower(trim($value));
      if ($normalized === '') {
        return false;
      }

      $normalized = str_replace(array('\\', '/', '-'), ' ', $normalized);

      if (
        strpos($normalized, 'composer') !== false ||
        strpos($normalized, 'luna compose') !== false ||
        strpos($normalized, 'luna composer') !== false
      ) {
        return true;
      }
    }

    if (is_array($value)) {
      foreach ($value as $item) {
        if (luna_request_value_signals_composer($item)) {
          return true;
        }
      }
    }

    return false;
  }
}

if (!function_exists('luna_request_has_composer_signal')) {
  function luna_request_has_composer_signal(WP_REST_Request $req) {
    $params = $req->get_params();
    foreach ($params as $key => $value) {
      if ($key === 'prompt' || $key === 'message') {
        continue;
      }

      if (is_string($key) && luna_request_value_signals_composer($key)) {
        return true;
      }

      if (luna_request_value_signals_composer($value)) {
        return true;
      }
    }

    if (!empty($_SERVER['HTTP_X_LUNA_COMPOSER'])) {
      if (luna_request_value_signals_composer($_SERVER['HTTP_X_LUNA_COMPOSER'])) {
        return true;
      }
    }

    if (!empty($_SERVER['HTTP_REFERER'])) {
      if (luna_request_value_signals_composer($_SERVER['HTTP_REFERER'])) {
        return true;
      }
    }

    return false;
  }
}

if (!function_exists('luna_prompt_requires_comprehensive_data')) {
  function luna_prompt_requires_comprehensive_data($prompt, $lc = null) {
    if ($lc === null) {
      $lc = function_exists('mb_strtolower') ? mb_strtolower($prompt) : strtolower($prompt);
    }

    $lc = trim($lc);
    if ($lc === '') {
      return false;
    }

    $keywords = array(
      'ssl', 'tls', 'certificate', 'cloudflare', 'waf', 'firewall', 'ids', 'mfa', 'security',
      'ga4', 'google analytics', 'analytics', 'session', 'traffic', 'lighthouse', 'pagespeed',
      'performance', 'site health', 'snapshot', 'daily snapshot', 'data stream', 'connector',
      'raw json', 'aws', 's3', 'liquid web', 'hosting', 'domain', 'dns', 'search console',
      'seo', 'vldr', 'competitor', 'meta ads', 'facebook ads', 'linkedin ads', 'google ads',
      'campaign', 'report', 'analysis', 'compose', 'intelligent suggestion', 'webops', 'dataops'
    );

    foreach ($keywords as $keyword) {
      if (strpos($lc, $keyword) !== false) {
        return true;
      }
    }

    if (strlen($prompt) > 140) {
      return true;
    }

    if (substr_count($prompt, '?') >= 2) {
      return true;
    }

    return false;
  }
}

function luna_widget_chat_handler( WP_REST_Request $req ) {
  // Helper function to add CORS headers to a response
  $add_cors_headers = function($response) {
    $origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';
    $allowed_origins = array(
      'https://supercluster.visiblelight.ai',
      'https://visiblelight.ai',
      'http://supercluster.visiblelight.ai',
      'http://visiblelight.ai'
    );
    
    $is_allowed = false;
    if (!empty($origin)) {
      foreach ($allowed_origins as $allowed) {
        if ($origin === $allowed || strpos($origin, $allowed) !== false) {
          $is_allowed = true;
          break;
        }
      }
    }
    
    if ($is_allowed && !empty($origin)) {
      $response->header('Access-Control-Allow-Origin', $origin);
      $response->header('Access-Control-Allow-Credentials', 'true');
    } else {
      $response->header('Access-Control-Allow-Origin', '*');
    }
    $response->header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    $response->header('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With, Accept, X-WP-Nonce, x-wp-nonce, X-Luna-Composer, x-luna-composer');
    return $response;
  };
  
  // Handle preflight OPTIONS request
  if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    $response = new WP_REST_Response(null, 200);
    $response->header('Access-Control-Max-Age', '86400');
    return $add_cors_headers($response);
  }
  
  try {
  $prompt = trim( (string) $req->get_param('prompt') );
  if ($prompt === '') {
    $prompt = trim( (string) $req->get_param('message') );
  }
  $is_greeting = (bool) $req->get_param('greeting');

  $raw_context = $req->get_param('context');
  $context     = is_string($raw_context) ? sanitize_key($raw_context) : '';

  $is_composer = false;
  $composer_markers = array();

  if (is_string($raw_context)) {
    $normalized = strtolower(trim($raw_context));
    if ($normalized !== '') {
      $composer_markers[] = $normalized;
      $composer_markers[] = str_replace(array('/', '\\', '-'), '_', $normalized);
    }
  }

  if ($context !== '') {
    $composer_markers[] = $context;
  }

  $mode_param = $req->get_param('mode');
  if (is_string($mode_param)) {
    $mode_normalized = strtolower(trim($mode_param));
    if ($mode_normalized !== '') {
      $composer_markers[] = $mode_normalized;
      $composer_markers[] = str_replace(array('/', '\\', '-'), '_', $mode_normalized);
    }
  }

  $composer_flag_param = $req->get_param('composer');
  if ($composer_flag_param === true || $composer_flag_param === '1' || $composer_flag_param === 1 || $composer_flag_param === 'true') {
    $is_composer = true;
  }

  if (!$is_composer) {
    foreach ($composer_markers as $marker) {
      if (in_array($marker, array('composer', 'compose', 'luna_composer', 'luna_compose', 'lunacomposer', 'lunacompose'), true)) {
        $is_composer = true;
        break;
      }
    }
  }

  if (!$is_composer && function_exists('luna_request_has_composer_signal') && luna_request_has_composer_signal($req)) {
    $is_composer = true;
  }

  if (!$is_composer && !empty($_SERVER['HTTP_X_LUNA_COMPOSER']) && function_exists('luna_request_value_signals_composer')) {
    if (luna_request_value_signals_composer($_SERVER['HTTP_X_LUNA_COMPOSER'])) {
      $is_composer = true;
    }
  }

  if ($is_composer && $prompt === '') {
    $response = new WP_REST_Response(array(
      'error' => __('Please provide content for Luna Composer to reimagine.', 'luna'),
    ), 400);
    return $add_cors_headers($response);
  }

  // Handle initial greeting for chat-only interactions
  if (!$is_composer && ($is_greeting || $prompt === '')) {
    $greeting = "Hi, there! I'm Luna, your personal WebOps agent and AI companion. How would you like to continue?";
    $pid = luna_conv_id();
    $meta = array('source' => 'system', 'event' => 'initial_greeting');
    if ($pid) {
      $meta['conversation_id'] = $pid;
      luna_log_turn('', $greeting, $meta);
    }
    $response = new WP_REST_Response(array('answer'=>$greeting, 'meta'=>$meta), 200);
    return $add_cors_headers($response);
  }

  // Check for simple greetings AFTER initial greeting (conversation already started)
  $pid = luna_conv_id();
  $has_existing_conversation = false;
  if ($pid) {
    $transcript = get_post_meta($pid, 'transcript', true);
    if (is_array($transcript) && count($transcript) > 0) {
      $has_existing_conversation = true;
    }
  }
  
  $lc = function_exists('mb_strtolower') ? mb_strtolower($prompt) : strtolower($prompt);
  $greeting_patterns = array('/\b(hi|hello|hey|howdy|hola|greetings|good morning|good afternoon|good evening)\b/i');
  $is_simple_greeting = false;
  $is_only_greeting = false;
  foreach ($greeting_patterns as $pattern) {
    if (preg_match($pattern, $lc)) {
      $is_simple_greeting = true;
      // Check if the prompt is ONLY a greeting (no other content)
      $greeting_only = preg_match('/^(hi|hello|hey|howdy|hola|greetings|good morning|good afternoon|good evening)[\s!.,?]*$/i', trim($prompt));
      if ($greeting_only) {
        $is_only_greeting = true;
      }
      break;
    }
  }
  
  // If it's a simple greeting AFTER initial greeting, respond with short friendly message
  if ($is_simple_greeting && $has_existing_conversation && $is_only_greeting) {
    $greeting_response = "Hi there! How can I assist you today?";
    $meta = array('source' => 'deterministic', 'intent' => 'followup_greeting');
    if ($pid) {
      $meta['conversation_id'] = $pid;
      luna_log_turn($prompt, $greeting_response, $meta);
    }
    $response = new WP_REST_Response(array('answer'=>$greeting_response, 'meta'=>$meta), 200);
    return $add_cors_headers($response);
  }
  
  // If greeting is part of a larger question, let it proceed to normal processing

  $composer_enabled = get_option(LUNA_WIDGET_OPT_COMPOSER_ENABLED, '1') === '1';
  if ($is_composer && !$composer_enabled) {
    $response = new WP_REST_Response(array(
      'answer' => __('Luna Composer is currently disabled by an administrator.', 'luna'),
      'meta'   => array('source' => 'system', 'composer' => false),
    ), 200);
    return $add_cors_headers($response);
  }

  $pid   = luna_conv_id();
  
  // Check for demo mode - from request parameter, header, or page context
  $demo_mode = false;
  
  // Check request parameter first
  $demo_mode_param = $req->get_param('demoMode');
  if ($demo_mode_param === true || $demo_mode_param === '1' || $demo_mode_param === 1 || $demo_mode_param === 'true') {
    $demo_mode = true;
  }
  
  // Check HTTP header
  if (!$demo_mode && !empty($_SERVER['HTTP_X_LUNA_DEMO_MODE'])) {
    $demo_mode = true;
  }
  
  // Check if demo shortcode is on the current page
  if (!$demo_mode) {
    global $post;
    if ($post && has_shortcode($post->post_content, 'luna_composer_demo_only')) {
      $demo_mode = true;
    }
  }
  
  // Check referrer for demo page indicators
  if (!$demo_mode && isset($_SERVER['HTTP_REFERER'])) {
    $referer = parse_url($_SERVER['HTTP_REFERER'], PHP_URL_PATH);
    if (strpos($referer, 'anchorToLunaAI') !== false || strpos($referer, 'products/luna') !== false) {
      $demo_mode = true; // Assume demo mode for demo page
    }
  }
  
  $prompt_requires_full_facts = $is_composer || luna_prompt_requires_comprehensive_data($prompt, $lc);

  // Try to get comprehensive facts, with error handling
  $facts = null;
  
  // If demo mode, load demo JSON file instead of real Hub data
  if ($demo_mode) {
    $demo_file_path = plugin_dir_path(__FILE__) . 'assets/luna-composer-demo-data.json';
    if (file_exists($demo_file_path)) {
      $demo_json = file_get_contents($demo_file_path);
      $demo_data = json_decode($demo_json, true);
      if (is_array($demo_data) && !empty($demo_data)) {
        // Convert demo data to facts format
        $facts = array(
          'site_url' => isset($demo_data['site']['url']) ? $demo_data['site']['url'] : 'https://demo.visiblelight.ai',
          'wp_version' => isset($demo_data['wordpress']['version']) ? $demo_data['wordpress']['version'] : '6.4.2',
          'theme' => isset($demo_data['wordpress']['theme']) ? $demo_data['wordpress']['theme'] : 'Twenty Twenty-Four',
          'theme_active' => isset($demo_data['wordpress']['theme_active']) ? $demo_data['wordpress']['theme_active'] : true,
          'security' => isset($demo_data['security']) ? $demo_data['security'] : array(),
          'cloudflare' => isset($demo_data['cloudflare']) ? $demo_data['cloudflare'] : array(),
          'aws_s3' => isset($demo_data['aws_s3']) ? $demo_data['aws_s3'] : array(),
          'liquidweb' => isset($demo_data['liquidweb']) ? $demo_data['liquidweb'] : array(),
          'updates' => isset($demo_data['updates']) ? $demo_data['updates'] : array(),
          'plugins' => isset($demo_data['plugins']) ? $demo_data['plugins'] : array(),
          'users' => isset($demo_data['users']) ? $demo_data['users'] : array(),
          'analytics' => isset($demo_data['analytics']) ? $demo_data['analytics'] : array(),
          'content' => isset($demo_data['content']) ? $demo_data['content'] : array(),
          'lighthouse' => isset($demo_data['lighthouse']) ? $demo_data['lighthouse'] : array(),
          'competitive' => isset($demo_data['competitive']) ? $demo_data['competitive'] : array(),
          'compliance' => isset($demo_data['compliance']) ? $demo_data['compliance'] : array(),
          '__source' => 'demo-data',
          '__demo_mode' => true,
        );
      }
    }
    // If demo file doesn't exist or failed to load, fall through to regular facts
    if (!is_array($facts) || empty($facts)) {
      error_log('[Luna Widget] Demo data file not found or invalid, falling back to regular facts');
    }
  }
  
  // If not demo mode or demo data failed, get real Hub data
  if (!is_array($facts) || empty($facts) || !isset($facts['__demo_mode'])) {
    // OPTIMIZATION: For first message in conversation, use basic facts (fast) instead of comprehensive (slow)
    // This avoids making multiple HTTP requests on the first message, which causes significant latency
    // Subsequent messages will use comprehensive facts (which will be cached by then)
    $is_first_message = !$has_existing_conversation;
    
    if ($is_first_message && !$prompt_requires_full_facts) {
      // First message: Use basic facts for fast response
      // Comprehensive data will be loaded in background for next message
      try {
        $facts = luna_profile_facts(); // Fast - uses cached profile data
        $facts['__source'] = 'basic-first-message';
        error_log('[Luna Widget] Using basic facts for first message (fast response)');
        
        // Pre-warm comprehensive cache in background (non-blocking)
        // This ensures comprehensive data is ready for next message
        if (function_exists('luna_hub_collect_collections')) {
          // Check if cache exists - if not, trigger async collection
          $collections_key = luna_hub_collections_cache_key();
          $cached_collections = get_transient($collections_key);
          if (!is_array($cached_collections) || empty($cached_collections)) {
            // Cache is empty - trigger background collection (non-blocking)
            // Use a short-lived transient to prevent multiple simultaneous requests
            $bg_lock_key = 'luna_bg_collections_' . md5($collections_key);
            $bg_lock = get_transient($bg_lock_key);
            if (!$bg_lock) {
              set_transient($bg_lock_key, true, 30); // 30 second lock
              // Schedule background collection (will happen after response is sent)
              add_action('shutdown', function() use ($collections_key) {
                // This runs after response is sent, so it doesn't block
                try {
                  luna_hub_collect_collections(false);
                } catch (Exception $e) {
                  error_log('[Luna Widget] Background collection failed: ' . $e->getMessage());
                }
              }, 999);
            }
          }
        }
      } catch (Exception $e) {
        error_log('[Luna Widget] Exception in luna_profile_facts: ' . $e->getMessage());
        $facts = null;
      } catch (Error $e) {
        error_log('[Luna Widget] Fatal error in luna_profile_facts: ' . $e->getMessage());
        $facts = null;
      }
    } else {
      // Subsequent messages: Use comprehensive facts (cache should be warm by now)
      try {
        $facts = luna_profile_facts_comprehensive(); // Use comprehensive Hub data
        if ($is_first_message && $prompt_requires_full_facts) {
          $facts['__source'] = 'comprehensive-first-message';
        }
      } catch (Exception $e) {
        error_log('[Luna Widget] Exception in luna_profile_facts_comprehensive: ' . $e->getMessage());
        $facts = null;
      } catch (Error $e) {
        error_log('[Luna Widget] Fatal error in luna_profile_facts_comprehensive: ' . $e->getMessage());
        $facts = null;
      }
    }
    
    // Ensure facts is an array - fallback to basic facts if needed
    if (!is_array($facts) || empty($facts)) {
      error_log('[Luna Widget] Facts invalid or empty, falling back to basic facts');
      try {
        $facts = luna_profile_facts();
      } catch (Exception $e) {
        error_log('[Luna Widget] Even basic facts failed: ' . $e->getMessage());
        // Last resort: minimal facts
        $facts = array(
          'site_url' => home_url('/'),
          'wp_version' => get_bloginfo('version'),
          '__source' => 'minimal-fallback'
        );
      }
      if (!isset($facts['__source'])) {
        $facts['__source'] = 'error-fallback';
      }
    }
  }

  // Ensure facts is always an array
  if (!is_array($facts)) {
    error_log('[Luna Widget] Facts is not an array, initializing empty array');
    $facts = array('site_url' => home_url('/'));
  }
  
  // Get license key for data fetching (needed for enrichment and SSL/TLS queries)
  $license = luna_get_license();
  
  if (!$demo_mode && function_exists('luna_enrich_facts_with_streams')) {
    try {
      luna_enrich_facts_with_streams($facts, $license);
    } catch (Exception $e) {
      error_log('[Luna Widget] Error enriching facts with streams: ' . $e->getMessage());
    } catch (Error $e) {
      error_log('[Luna Widget] Fatal error enriching facts with streams: ' . $e->getMessage());
    }
  }

  if ($is_composer) {
    $facts['__composer'] = true;
  }
  
  $site_url = isset($facts['site_url']) ? (string)$facts['site_url'] : home_url('/');
  $security = isset($facts['security']) && is_array($facts['security']) ? $facts['security'] : array();
  
  // Debug: Log demo mode and security data availability (only in demo mode)
  if (isset($facts['__demo_mode']) && $facts['__demo_mode'] === true) {
    error_log('[Luna Widget Demo] Demo mode active. Security data available: ' . (!empty($security) ? 'YES' : 'NO'));
    if (!empty($security['tls'])) {
      error_log('[Luna Widget Demo] TLS data found: ' . print_r($security['tls'], true));
    }
  }
  $lc    = function_exists('mb_strtolower') ? mb_strtolower($prompt) : strtolower($prompt);
  $answer = '';
  $meta   = array('source' => 'deterministic');
  if ($is_composer) {
    $meta['composer'] = true;
    if (is_array($matched_composer_prompt) && !empty($matched_composer_prompt['id'])) {
      $meta['composer_prompt_id'] = (int) $matched_composer_prompt['id'];
    }
    if (is_array($matched_composer_prompt) && !empty($matched_composer_prompt['source'])) {
      $meta['composer_prompt_source'] = $matched_composer_prompt['source'];
    }
  }
  
  // Check if this is a comprehensive report request (multi-sentence, paragraph format, etc.)
  // Also detect complex questions with multiple parts, split thoughts, or multiple commands
  $is_comprehensive_report = (
    preg_match('/\b(comprehensive|site health|health report|paragraph format|full sentences|human readable|leadership|email|copy.*paste|intro header|official signature)\b/i', $prompt) ||
    preg_match('/\b(generate.*report|create.*report|write.*report|prepare.*report)\b/i', $prompt) ||
    (substr_count($prompt, '.') >= 2 && strlen($prompt) > 100)
  );
  
  // Detect complex questions: multiple sentences, multiple questions, split thoughts, multiple commands
  $is_complex_question = (
    substr_count($prompt, '?') >= 2 || // Multiple questions
    substr_count($prompt, '.') >= 2 || // Multiple sentences
    substr_count($prompt, ' and ') >= 2 || // Multiple "and" clauses
    preg_match('/\b(and|also|plus|additionally|furthermore|moreover|in addition)\b/i', $prompt) && strlen($prompt) > 50 || // Multiple thoughts
    preg_match('/\b(tell me|show me|give me|provide me|explain|describe|list|compare|analyze)\b.*\b(and|also|plus|additionally)\b.*\b(tell me|show me|give me|provide me|explain|describe|list|compare|analyze)\b/i', $prompt) || // Multiple commands
    (strlen($prompt) > 150 && (substr_count($prompt, ',') >= 3 || substr_count($prompt, ' and ') >= 1)) // Long prompt with multiple clauses
  );

  if (!$is_composer) {
  // Detect if this is a conceptual/general question vs. a specific data request
  // BUT: If we have demo data or specific site data, prioritize that over conceptual answers
  $is_conceptual_question = (
    preg_match('/\b(is|are|what|how|why|when|where|can|could|would|should|does|do|did|will|was|were)\b.*\b(the|a|an|same|different|difference|between|versus|vs)\b/i', $prompt) ||
    (preg_match('/\b(explain|describe|tell me about|what is|what are|how does|how do)\b/i', $prompt) && !preg_match('/\b(tls|ssl|certificate|cert|my|your|site|website)\b/i', $prompt)) ||
    (preg_match('/\?$/', $prompt) && (strlen($prompt) > 30 || substr_count($prompt, ' ') > 4) && !preg_match('/\b(do i|do you|have|has|my|your|site|website)\b/i', $prompt))
  );
  
  // Check if question is about user's specific site data (even if conceptual)
  $is_site_specific_question = preg_match('/\b(do i|do you|have|has|my|your|site|website|i have|you have)\b.*\b(tls|ssl|certificate|cert)\b/i', $lc) ||
                               preg_match('/\b(tls|ssl|certificate|cert)\b.*\b(do i|do you|have|has|my|your|site|website|installed|configured|active)\b/i', $lc);
  
  // Deterministic intents using comprehensive Hub data
  // Use deterministic matching for SSL/TLS queries if we have data OR if it's site-specific
  // Improved pattern to catch "do i have ssl" and similar queries
  if ((!$is_conceptual_question || $is_site_specific_question) && preg_match('/\b(tls|ssl|https|certificate|cert|encryption|encrypted|secure.*connection|ssl.*cert|tls.*cert|https.*cert|do i have ssl)\b/i', $lc)) {
    // Check for SSL/TLS data from VL Hub first (most reliable source)
    // Check multiple possible locations in facts array
    $ssl_tls = isset($facts['ssl_tls']) && is_array($facts['ssl_tls']) ? $facts['ssl_tls'] : array();
    $tls = isset($facts['tls']) && is_array($facts['tls']) ? $facts['tls'] : array();
    $security_tls = isset($security['tls']) && is_array($security['tls']) ? $security['tls'] : array();
    
    // Also check security array directly
    if (empty($ssl_tls) && isset($facts['security']['ssl_tls']) && is_array($facts['security']['ssl_tls'])) {
      $ssl_tls = $facts['security']['ssl_tls'];
    }
    if (empty($ssl_tls) && isset($facts['security']['tls']) && is_array($facts['security']['tls'])) {
      $security_tls = $facts['security']['tls'];
    }
    
    // Check security_data_streams directly for SSL/TLS Status connector
    if (empty($ssl_tls) && isset($facts['security_data_streams']) && is_array($facts['security_data_streams'])) {
      error_log('[Luna Widget] Checking security_data_streams for SSL/TLS data: ' . count($facts['security_data_streams']) . ' streams');
      foreach ($facts['security_data_streams'] as $stream_id => $stream_data) {
        // Look for SSL/TLS Status connector by ID or name
        if ((isset($stream_data['id']) && $stream_data['id'] === 'ssl_tls_status') ||
            (isset($stream_data['name']) && (stripos($stream_data['name'], 'SSL/TLS') !== false || stripos($stream_data['name'], 'SSL') !== false))) {
          error_log('[Luna Widget] Found SSL/TLS connector: ' . $stream_id . ', has ssl_tls_data: ' . (isset($stream_data['ssl_tls_data']) ? 'YES' : 'NO'));
          // Extract ssl_tls_data field
          if (isset($stream_data['ssl_tls_data']) && is_array($stream_data['ssl_tls_data']) && !empty($stream_data['ssl_tls_data'])) {
            $ssl_tls = $stream_data['ssl_tls_data'];
            error_log('[Luna Widget] Found SSL/TLS data in security_data_streams: ' . $stream_id . ', certificate: ' . (isset($ssl_tls['certificate']) ? $ssl_tls['certificate'] : 'N/A'));
            break;
          }
        }
      }
    }
    
    // Also check data_streams directly (in case security_data_streams wasn't populated)
    if (empty($ssl_tls) && isset($facts['data_streams']) && is_array($facts['data_streams'])) {
      error_log('[Luna Widget] Checking data_streams for SSL/TLS data: ' . count($facts['data_streams']) . ' streams');
      foreach ($facts['data_streams'] as $stream_id => $stream_data) {
        if ((isset($stream_data['id']) && $stream_data['id'] === 'ssl_tls_status') ||
            (isset($stream_data['name']) && (stripos($stream_data['name'], 'SSL/TLS') !== false || stripos($stream_data['name'], 'SSL') !== false))) {
          error_log('[Luna Widget] Found SSL/TLS connector in data_streams: ' . $stream_id . ', has ssl_tls_data: ' . (isset($stream_data['ssl_tls_data']) ? 'YES' : 'NO'));
          if (isset($stream_data['ssl_tls_data']) && is_array($stream_data['ssl_tls_data']) && !empty($stream_data['ssl_tls_data'])) {
            $ssl_tls = $stream_data['ssl_tls_data'];
            error_log('[Luna Widget] Found SSL/TLS data in data_streams: ' . $stream_id . ', certificate: ' . (isset($ssl_tls['certificate']) ? $ssl_tls['certificate'] : 'N/A'));
            break;
          }
        }
      }
    }
    
    // If still empty, try to fetch data streams on-the-fly for SSL/TLS queries
    if (empty($ssl_tls) && !empty($license)) {
      try {
        error_log('[Luna Widget] SSL/TLS data not found in facts, attempting to fetch from Hub directly');
        // Try to get data streams directly from Hub
        $streams_data = null;
        
        // Try direct access first (if VL Hub Profile is available)
        if (class_exists('VL_Hub_Profile')) {
          try {
            $hub_profile = VL_Hub_Profile::get_instance();
            if ($hub_profile && method_exists($hub_profile, 'data_streams_store_get')) {
              $all_streams_store = $hub_profile->data_streams_store_get();
              if (is_array($all_streams_store) && isset($all_streams_store[$license])) {
                $streams_data = $all_streams_store[$license];
                error_log('[Luna Widget] Got data streams via direct access');
              }
            }
          } catch (Exception $e) {
            error_log('[Luna Widget] Error accessing VL Hub Profile directly: ' . $e->getMessage());
          } catch (Error $e) {
            error_log('[Luna Widget] Fatal error accessing VL Hub Profile: ' . $e->getMessage());
          }
        }
        
        // Fallback to HTTP request
        if (empty($streams_data)) {
          try {
            $streams_data = luna_fetch_hub_data_streams($license);
          } catch (Exception $e) {
            error_log('[Luna Widget] Error fetching data streams via HTTP: ' . $e->getMessage());
            $streams_data = null;
          } catch (Error $e) {
            error_log('[Luna Widget] Fatal error fetching data streams: ' . $e->getMessage());
            $streams_data = null;
          }
        }
        
        // Search for SSL/TLS Status connector
        if (is_array($streams_data) && !empty($streams_data)) {
          foreach ($streams_data as $stream_id => $stream_data) {
            if ((isset($stream_data['id']) && $stream_data['id'] === 'ssl_tls_status') ||
                (isset($stream_data['name']) && (stripos($stream_data['name'], 'SSL/TLS') !== false || stripos($stream_data['name'], 'SSL') !== false))) {
              if (isset($stream_data['ssl_tls_data']) && is_array($stream_data['ssl_tls_data']) && !empty($stream_data['ssl_tls_data'])) {
                $ssl_tls = $stream_data['ssl_tls_data'];
                error_log('[Luna Widget] Found SSL/TLS data from on-the-fly fetch: ' . $stream_id);
                // Also update facts for future use
                if (!isset($facts['ssl_tls']) || !is_array($facts['ssl_tls']) || empty($facts['ssl_tls'])) {
                  $facts['ssl_tls'] = $ssl_tls;
                }
                break;
              }
            }
          }
        }
      } catch (Exception $e) {
        error_log('[Luna Widget] Exception in on-the-fly SSL/TLS fetch: ' . $e->getMessage());
        // Continue without SSL/TLS data - will fall through to HTTPS check or OpenAI
      } catch (Error $e) {
        error_log('[Luna Widget] Fatal error in on-the-fly SSL/TLS fetch: ' . $e->getMessage());
        // Continue without SSL/TLS data - will fall through to HTTPS check or OpenAI
      }
    }
    
    // Check if we have SSL/TLS data from VL Hub
    if (!empty($ssl_tls)) {
      $certificate = isset($ssl_tls['certificate']) ? $ssl_tls['certificate'] : '';
      $issuer = isset($ssl_tls['issuer']) ? $ssl_tls['issuer'] : '';
      $expires = isset($ssl_tls['expires']) ? $ssl_tls['expires'] : '';
      $days_until_expiry = isset($ssl_tls['days_until_expiry']) ? $ssl_tls['days_until_expiry'] : null;
      $connected = isset($ssl_tls['connected']) ? (bool)$ssl_tls['connected'] : false;
      
      // Check for valid/active status even if connected is false
      $is_valid = $connected;
      if (!$is_valid && isset($ssl_tls['valid'])) {
        $is_valid = (bool)$ssl_tls['valid'];
      }
      if (!$is_valid && isset($ssl_tls['status'])) {
        $status_lower = strtolower($ssl_tls['status']);
        $is_valid = ($status_lower === 'active' || $status_lower === 'valid' || $status_lower === 'enabled' || $status_lower === 'connected');
      }
      
      if ($is_valid || !empty($certificate) || !empty($issuer) || !empty($expires)) {
        $answer = "**Yes, you have an SSL/TLS certificate configured:**\n\n";
        
        // Certificate name/domain
        if (!empty($certificate)) {
          $answer .= "**Certificate:** " . $certificate . "\n";
        }
        
        // Issuer
        if (!empty($issuer)) {
          $answer .= "**Issuer:** " . $issuer . "\n";
        }
        
        // Expiration date
        if (!empty($expires)) {
          $answer .= "**Expires:** " . $expires;
          if ($days_until_expiry !== null) {
            $answer .= " (" . intval($days_until_expiry) . " days until expiry)";
          }
          $answer .= "\n";
        } elseif (isset($ssl_tls['expires_at']) && !empty($ssl_tls['expires_at'])) {
          $answer .= "**Expires:** " . $ssl_tls['expires_at'];
          if ($days_until_expiry !== null) {
            $answer .= " (" . intval($days_until_expiry) . " days until expiry)";
          }
          $answer .= "\n";
        }
        
        // Status
        $status_text = '';
        if ($connected) {
          $status_text = "Connected";
        } elseif ($is_valid) {
          $status_text = "Active";
        } elseif (isset($ssl_tls['status'])) {
          $status_text = ucfirst(strtolower($ssl_tls['status']));
        }
        if (!empty($status_text)) {
          $answer .= "**Status:** " . $status_text . "\n";
        }
        
        // TLS Version
        if (isset($ssl_tls['tls_version']) && !empty($ssl_tls['tls_version'])) {
          $answer .= "**TLS Version:** " . $ssl_tls['tls_version'] . "\n";
        }
        
        // Cipher Suite
        if (isset($ssl_tls['cipher_suite']) && !empty($ssl_tls['cipher_suite'])) {
          $answer .= "**Cipher Suite:** " . $ssl_tls['cipher_suite'] . "\n";
        }
        
        // Valid From
        if (isset($ssl_tls['valid_from']) && !empty($ssl_tls['valid_from'])) {
          $answer .= "**Valid From:** " . $ssl_tls['valid_from'] . "\n";
        }
        
        // Last Checked
        if (isset($ssl_tls['last_checked']) && !empty($ssl_tls['last_checked'])) {
          $answer .= "**Last Checked:** " . $ssl_tls['last_checked'] . "\n";
        }
        
        // Check for Cloudflare connection (which also provides SSL/TLS)
        $has_cloudflare = false;
        if (isset($facts['cloudflare']) && is_array($facts['cloudflare']) && !empty($facts['cloudflare'])) {
          $has_cloudflare = true;
        } elseif (isset($facts['security_data_streams']) && is_array($facts['security_data_streams'])) {
          foreach ($facts['security_data_streams'] as $stream_id => $stream_data) {
            if (isset($stream_data['name']) && stripos($stream_data['name'], 'Cloudflare') !== false) {
              $has_cloudflare = true;
              break;
            }
          }
        }
        
        if ($has_cloudflare) {
          $answer .= "\n**Note:** Your site is also protected by Cloudflare, which provides additional SSL/TLS encryption and security features.\n";
        }
      }
    }
    
    // Fallback to other TLS data sources (including demo data and basic facts)
    // For demo data, check if status is "active" to determine validity
    $tls_valid = false;
    if (isset($tls['valid'])) {
      $tls_valid = (bool)$tls['valid'];
    } elseif (isset($security_tls['status'])) {
      // Demo data uses "status": "active" instead of "valid": true
      $status_lower = strtolower($security_tls['status']);
      $tls_valid = ($status_lower === 'active' || $status_lower === 'valid' || $status_lower === 'enabled' || $status_lower === 'connected');
    } elseif (isset($security_tls['valid'])) {
      $tls_valid = (bool)$security_tls['valid'];
    } elseif (isset($security_tls['connected'])) {
      $tls_valid = (bool)$security_tls['connected'];
    }
    
    $tls_status = isset($security_tls['status']) ? $security_tls['status'] : '';
    $tls_version = isset($security_tls['version']) ? $security_tls['version'] : '';
    $tls_issuer = isset($security_tls['issuer']) ? $security_tls['issuer'] : (isset($tls['issuer']) ? $tls['issuer'] : '');
    $tls_provider = isset($security_tls['provider_guess']) ? $security_tls['provider_guess'] : '';
    $tls_valid_from = isset($security_tls['valid_from']) ? $security_tls['valid_from'] : '';
    $tls_valid_to = isset($security_tls['valid_to']) ? $security_tls['valid_to'] : (isset($tls['expires']) ? $tls['expires'] : (isset($tls['expires_at']) ? $tls['expires_at'] : ''));
    $tls_host = isset($security_tls['host']) ? $security_tls['host'] : '';

    // If we have any TLS data (valid status, issuer, expiry, or connected status), provide answer
    // Only set answer if we haven't already set it from ssl_tls data above
    if (empty($answer) && ($tls_valid || !empty($tls_status) || !empty($tls_issuer) || !empty($tls_valid_to) || !empty($tls_host))) {
      $details = array();
      if ($tls_status) $details[] = "Status: ".$tls_status;
      if ($tls_version) $details[] = "Version: ".$tls_version;
      if ($tls_issuer) $details[] = "Issuer: ".$tls_issuer;
      if ($tls_provider) $details[] = "Provider: ".$tls_provider;
      if ($tls_valid_from) $details[] = "Valid from: ".$tls_valid_from;
      if ($tls_valid_to) $details[] = "Valid to: ".$tls_valid_to;
      if ($tls_host) $details[] = "Host: ".$tls_host;

      if (!empty($details)) {
        $answer = "Yes—TLS/SSL is active for ".$site_url." (".implode(', ', $details).").";
      } elseif ($tls_valid) {
        $answer = "Yes, you have SSL/TLS configured and active for ".$site_url.".";
      }
      
      // If it's a conceptual question but we have data, add educational context
      if ($is_conceptual_question && $is_site_specific_question && !empty($answer)) {
        $answer .= " TLS (Transport Layer Security) is the modern standard for encrypting data between your website and visitors, ensuring secure communication. Your certificate is properly configured and active.";
      }
    }
    
    // If we still don't have an answer, check if site URL uses HTTPS (basic indicator)
    if (empty($answer)) {
      $site_url_lower = strtolower($site_url);
      if (strpos($site_url_lower, 'https://') === 0) {
        $answer = "Yes, your site is using HTTPS, which indicates SSL/TLS is configured. However, I don't have detailed certificate information in your Visible Light Hub profile. You can check the SSL/TLS Status connector in the All Connections tab for more details.";
      } else {
        // Only say "unknown" if we truly don't have data AND it's not a conceptual question
        if (!$is_conceptual_question) {
          $answer = "I don't see SSL/TLS certificate information configured in your Visible Light Hub. Please check the SSL/TLS Status connector in the All Connections tab to ensure your certificate is properly configured.";
        }
        // If it's conceptual and no data, let it fall through to OpenAI for educational answer
      }
    }
  }
  elseif (preg_match('/\bwordpress\b.*\bversion\b|\bwp\b.*\bversion\b/', $lc)) {
    $v = isset($facts['wp_version']) ? trim((string)$facts['wp_version']) : '';
    $answer = $v ? ("Your WordPress version is ".$v.".") : "I don't see a confirmed WordPress version in the Hub profile.";
  }
  elseif (preg_match('/\btheme\b.*\bactive\b|\bis.*theme.*active\b/', $lc)) {
    $theme_active = isset($facts['theme_active']) ? (bool)$facts['theme_active'] : true;
    $theme_name = isset($facts['theme']) ? (string)$facts['theme'] : '';
    if ($theme_name) {
      $answer = $theme_active ? ("Yes, the ".$theme_name." theme is currently active.") : ("No, the ".$theme_name." theme is not active.");
    } else {
      $answer = "I don't have confirmation on whether the current theme is active.";
    }
  }
  elseif (preg_match('/\bwhat.*theme|\btheme.*name|\bcurrent.*theme\b/', $lc)) {
    $theme_name = isset($facts['theme']) ? (string)$facts['theme'] : '';
    $answer = $theme_name ? ("You are using the ".$theme_name." theme.") : "I don't see a confirmed theme in the Hub profile.";
  }
  elseif (preg_match('/\bhello\b|\bhi\b|\bhey\b/', $lc)) {
    $answer = "Hello! I'm Luna, your friendly WebOps assistant. I have access to all your site data from Visible Light Hub. I can help you with WordPress version, themes, plugins, SSL status, and more. What would you like to know?";
  }
  elseif (preg_match('/\bup.*to.*date|\boutdated|\bupdate.*available\b/', $lc)) {
    $updates = isset($facts['updates']) && is_array($facts['updates']) ? $facts['updates'] : array();
    $core_updates = isset($updates['core']) ? (int)$updates['core'] : 0;
    $plugin_updates = isset($updates['plugins']) ? (int)$updates['plugins'] : 0;
    $theme_updates = isset($updates['themes']) ? (int)$updates['themes'] : 0;

    if ($core_updates > 0 || $plugin_updates > 0 || $theme_updates > 0) {
      $answer = "You have updates available: WordPress Core: ".$core_updates.", Plugins: ".$plugin_updates.", Themes: ".$theme_updates.". I recommend updating for security and performance.";
    } else {
      $answer = "Your WordPress installation appears to be up to date. No core, plugin, or theme updates are currently available.";
    }
  }
  elseif (preg_match('/\bthreat.*protection|\bsecurity.*scan|\bmalware.*protection|\bthreat.*detection\b/', $lc)) {
    $security_ids = isset($security['ids']) && is_array($security['ids']) ? $security['ids'] : array();
    $ids_provider = isset($security_ids['provider']) ? $security_ids['provider'] : '';
    $last_scan = isset($security_ids['last_scan']) ? $security_ids['last_scan'] : '';
    $last_result = isset($security_ids['result']) ? $security_ids['result'] : '';
    $scan_schedule = isset($security_ids['schedule']) ? $security_ids['schedule'] : '';

    if ($ids_provider) {
      $details = array();
      $details[] = "Provider: ".$ids_provider;
      if ($last_scan) $details[] = "Last scan: ".$last_scan;
      if ($last_result) $details[] = "Last result: ".$last_result;
      if ($scan_schedule) $details[] = "Schedule: ".$scan_schedule;

      $answer = "Yes, you have threat protection set up (".implode(', ', $details)."). This helps protect against malware and security threats.";
    } else {
      $answer = "I don't see specific threat protection details in your security profile. You may want to consider adding a security plugin like Wordfence or Sucuri for malware protection.";
    }
  }
  elseif (preg_match('/\bfirewall\b/', $lc)) {
    $security_waf = isset($security['waf']) && is_array($security['waf']) ? $security['waf'] : array();
    $waf_provider = isset($security_waf['provider']) ? $security_waf['provider'] : '';
    $last_audit = isset($security_waf['last_audit']) ? $security_waf['last_audit'] : '';
    if ($waf_provider) {
      $answer = "Yes, you have a firewall configured. Your WAF provider is ".$waf_provider." with the last audit on ".$last_audit.". This helps block malicious traffic before it reaches your site.";
    } else {
      $answer = "I don't see a specific firewall configuration in your security profile. Consider adding a Web Application Firewall (WAF) for additional protection.";
    }
  }
  // Enhanced keyword matching for AWS S3 queries
  elseif (preg_match('/\b(aws.*s3|s3.*bucket|s3.*storage|amazon.*s3|bucket.*count|object.*count|storage.*used)\b/i', $lc)) {
    $aws_s3 = isset($facts['aws_s3']) && is_array($facts['aws_s3']) ? $facts['aws_s3'] : array();
    $connected = isset($aws_s3['connected']) ? (bool)$aws_s3['connected'] : false;
    $bucket_count = isset($aws_s3['bucket_count']) ? (int)$aws_s3['bucket_count'] : 0;
    $object_count = isset($aws_s3['object_count']) ? (int)$aws_s3['object_count'] : 0;
    $storage_used = isset($aws_s3['storage_used']) ? $aws_s3['storage_used'] : 'N/A';
    $last_sync = isset($aws_s3['last_sync']) ? $aws_s3['last_sync'] : '';
    
    if ($connected) {
      $answer = "**Yes, you have AWS S3 configured!**\n\n";
      $answer .= "**Connection Status:** Connected\n";
      if ($bucket_count > 0) {
        $answer .= "**Buckets:** " . $bucket_count . " bucket(s)\n";
      }
      if ($object_count > 0) {
        $answer .= "**Objects:** " . number_format($object_count) . " objects\n";
      }
      if ($storage_used !== 'N/A') {
        $answer .= "**Storage Used:** " . $storage_used . "\n";
      }
      if ($last_sync) {
        $answer .= "**Last Sync:** " . date('M j, Y g:i A', strtotime($last_sync)) . "\n";
      }
      
      if (!empty($aws_s3['buckets']) && is_array($aws_s3['buckets'])) {
        $answer .= "\n**Buckets:**\n";
        foreach (array_slice($aws_s3['buckets'], 0, 10) as $bucket) {
          $bucket_name = isset($bucket['name']) ? $bucket['name'] : 'Unknown';
          $bucket_objects = isset($bucket['object_count']) ? (int)$bucket['object_count'] : 0;
          $bucket_size = isset($bucket['size']) ? $bucket['size'] : '0 B';
          $answer .= "• " . $bucket_name . " - " . number_format($bucket_objects) . " objects, " . $bucket_size . "\n";
        }
        if (count($aws_s3['buckets']) > 10) {
          $answer .= "... and " . (count($aws_s3['buckets']) - 10) . " more buckets\n";
        }
      }
    } else {
      $answer = "I don't see AWS S3 configured in your Visible Light Hub. AWS S3 is Amazon's cloud storage service that can be used for backups, media storage, and static asset hosting. You can connect AWS S3 in your Visible Light Hub profile.";
    }
  }
  // Enhanced keyword matching for Liquid Web queries
  elseif (preg_match('/\b(liquid.*web|liquidweb|hosting.*assets|server.*assets)\b/i', $lc)) {
    $liquidweb = isset($facts['liquidweb']) && is_array($facts['liquidweb']) ? $facts['liquidweb'] : array();
    $connected = isset($liquidweb['connected']) ? (bool)$liquidweb['connected'] : false;
    $assets_count = isset($liquidweb['assets_count']) ? (int)$liquidweb['assets_count'] : 0;
    $last_sync = isset($liquidweb['last_sync']) ? $liquidweb['last_sync'] : '';
    
    if ($connected) {
      $answer = "**Yes, you have Liquid Web hosting configured!**\n\n";
      $answer .= "**Connection Status:** Connected\n";
      if ($assets_count > 0) {
        $answer .= "**Assets:** " . $assets_count . " asset(s)\n";
      }
      if ($last_sync) {
        $answer .= "**Last Sync:** " . date('M j, Y g:i A', strtotime($last_sync)) . "\n";
      }
      
      if (!empty($liquidweb['assets']) && is_array($liquidweb['assets'])) {
        $answer .= "\n**Assets:**\n";
        foreach (array_slice($liquidweb['assets'], 0, 10) as $asset) {
          $asset_name = isset($asset['name']) ? $asset['name'] : 'Unknown';
          $asset_type = isset($asset['type']) ? $asset['type'] : 'N/A';
          $asset_status = isset($asset['status']) ? $asset['status'] : 'unknown';
          $answer .= "• " . $asset_name . " (" . $asset_type . ") - " . ucfirst($asset_status) . "\n";
        }
        if (count($liquidweb['assets']) > 10) {
          $answer .= "... and " . (count($liquidweb['assets']) - 10) . " more assets\n";
        }
      }
    } else {
      $answer = "I don't see Liquid Web hosting configured in your Visible Light Hub. Liquid Web is a managed hosting provider. You can connect Liquid Web in your Visible Light Hub profile.";
    }
  }
  elseif (preg_match('/\bcdn\b/', $lc)) {
    // Check if Cloudflare is connected (which provides CDN)
    $cloudflare_data = isset($facts['cloudflare']) && is_array($facts['cloudflare']) ? $facts['cloudflare'] : array();
    $cloudflare_connected = isset($cloudflare_data['connected']) ? (bool)$cloudflare_data['connected'] : false;
    
    if ($cloudflare_connected) {
      $answer = "Yes, you have a CDN configured through Cloudflare! Cloudflare provides a Content Delivery Network (CDN) that serves your content from locations closer to your visitors, improving performance and reducing load times.";
    } else {
      $answer = "I don't see a specific CDN configuration in your current profile. A CDN (Content Delivery Network) can improve your site's performance by serving content from locations closer to your visitors. Popular options include Cloudflare, MaxCDN, or KeyCDN.";
    }
  }
  elseif (preg_match('/\bauthentication|\bmfa|\bpassword.*policy|\bsession.*timeout|\bsso\b/', $lc)) {
    $security_auth = isset($security['auth']) && is_array($security['auth']) ? $security['auth'] : array();
    $mfa = isset($security_auth['mfa']) ? $security_auth['mfa'] : '';
    $password_policy = isset($security_auth['password_policy']) ? $security_auth['password_policy'] : '';
    $session_timeout = isset($security_auth['session_timeout']) ? $security_auth['session_timeout'] : '';
    $sso_providers = isset($security_auth['sso_providers']) ? $security_auth['sso_providers'] : '';

    $details = array();
    if ($mfa) $details[] = "MFA: ".$mfa;
    if ($password_policy) $details[] = "Password Policy: ".$password_policy;
    if ($session_timeout) $details[] = "Session Timeout: ".$session_timeout;
    if ($sso_providers) $details[] = "SSO Providers: ".$sso_providers;

    if (!empty($details)) {
      $answer = "Your authentication settings (".implode(', ', $details).").";
    } else {
      $answer = "I don't see specific authentication details in your security profile. Consider setting up MFA, strong password policies, and appropriate session timeouts for better security.";
    }
  }
  elseif (preg_match('/\bdomain.*registrar|\bwho.*registered|\bdomain.*registered.*with\b/', $lc)) {
    $security_domain = isset($security['domain']) && is_array($security['domain']) ? $security['domain'] : array();
    $domain_name = isset($security_domain['domain']) ? $security_domain['domain'] : '';
    $registrar = isset($security_domain['registrar']) ? $security_domain['registrar'] : '';
    $registered_on = isset($security_domain['registered_on']) ? $security_domain['registered_on'] : '';
    $renewal_date = isset($security_domain['renewal_date']) ? $security_domain['renewal_date'] : '';
    $auto_renew = isset($security_domain['auto_renew']) ? $security_domain['auto_renew'] : '';
    $dns_records = isset($security_domain['dns_records']) ? $security_domain['dns_records'] : '';

    if ($registrar) {
      $details = array();
      if ($domain_name) $details[] = "Domain: ".$domain_name;
      $details[] = "Registrar: ".$registrar;
      if ($registered_on) $details[] = "Registered: ".$registered_on;
      if ($renewal_date) $details[] = "Renewal: ".$renewal_date;
      if ($auto_renew) $details[] = "Auto-renew: ".$auto_renew;
      if ($dns_records) $details[] = "DNS Records: ".$dns_records;

      $answer = "Your domain information (".implode(', ', $details).").";
    } else {
      $answer = "I don't have the domain registrar information in your current profile. You can check this in your domain management panel.";
    }
  }
  // REMOVED: Blog title deterministic pattern - now handled by GPT-4o with full context
  // Blog title requests should use GPT-4o to generate thoughtful, data-driven responses
  // based on VL Hub Profile data and user's specific requirements
  // (No deterministic answer for blog titles - let GPT-4o handle with full context)
  
  elseif (preg_match('/\bwhat.*can.*you.*do|\bwhat.*do.*you.*do|\bhelp.*with\b/', $lc)) {
    $answer = "I can help you with information about your WordPress site, including themes, plugins, SSL status, pages, posts, users, security settings, domain information, analytics data (page views, users, sessions, bounce rate, engagement), and more. All data comes from your Visible Light Hub profile. What would you like to know?";
  }
  elseif (preg_match('/\b(web.*intelligence.*report|intelligence.*report|comprehensive.*report|full.*report|detailed.*report|complete.*analysis)\b/', $lc)) {
    $answer = luna_generate_web_intelligence_report($facts);
  }
  elseif (preg_match('/\b(page.*views|pageviews|analytics|traffic|visitors|users|sessions|bounce.*rate|engagement)\b/', $lc)) {
    $answer = luna_handle_analytics_request($prompt, $facts);
  }
  // Enhanced keyword matching for Cloudflare queries
  elseif (preg_match('/\b(cloudflare|cdn|ddos|waf|web.*application.*firewall|content.*delivery.*network|cloudflare.*zone|cloudflare.*plan)\b/i', $lc)) {
    // Check for Cloudflare data from comprehensive profile
    $cloudflare_data = isset($facts['cloudflare']) && is_array($facts['cloudflare']) ? $facts['cloudflare'] : array();
    $cloudflare_connected = isset($cloudflare_data['connected']) ? (bool)$cloudflare_data['connected'] : false;
    
    if ($cloudflare_connected) {
      $zones_count = isset($cloudflare_data['zones_count']) ? (int)$cloudflare_data['zones_count'] : 0;
      $account_id = isset($cloudflare_data['account_id']) ? $cloudflare_data['account_id'] : '';
      $last_sync = isset($cloudflare_data['last_sync']) ? $cloudflare_data['last_sync'] : null;
      $zones = isset($cloudflare_data['zones']) && is_array($cloudflare_data['zones']) ? $cloudflare_data['zones'] : array();
      
      $answer = "**Yes, you have Cloudflare configured!**\n\n";
      $answer .= "**Connection Status:** Connected\n";
      if ($account_id) {
        $answer .= "**Account ID:** " . $account_id . "\n";
      }
      if ($zones_count > 0) {
        $answer .= "**Zones:** " . $zones_count . " zone(s)\n";
      }
      if ($last_sync) {
        $answer .= "**Last Sync:** " . date('M j, Y g:i A', strtotime($last_sync)) . "\n";
      }
      
      if (!empty($zones)) {
        $answer .= "\n**Configured Zones:**\n";
        foreach ($zones as $zone) {
          $zone_name = isset($zone['name']) ? $zone['name'] : 'Unknown';
          $zone_status = isset($zone['status']) ? $zone['status'] : 'unknown';
          $zone_plan = isset($zone['plan']) ? $zone['plan'] : 'Free';
          $answer .= "• " . $zone_name . " (" . ucfirst($zone_status) . " - " . $zone_plan . " Plan)\n";
        }
      }
      
      $answer .= "\nCloudflare provides DDoS protection, Web Application Firewall (WAF), CDN caching, and DNS management for enhanced security and performance.";
    } else {
      // Check security data streams for Cloudflare
      $security_streams = isset($facts['security_data_streams']) && is_array($facts['security_data_streams']) ? $facts['security_data_streams'] : array();
      $cloudflare_streams = array();
      foreach ($security_streams as $stream_id => $stream_data) {
        if (strpos($stream_id, 'cloudflare') !== false || (isset($stream_data['name']) && strpos(strtolower($stream_data['name']), 'cloudflare') !== false)) {
          $cloudflare_streams[$stream_id] = $stream_data;
        }
      }
      
      if (!empty($cloudflare_streams)) {
        $answer = "**Cloudflare Data Streams Found:**\n\n";
        foreach ($cloudflare_streams as $stream_id => $stream_data) {
          $stream_name = isset($stream_data['name']) ? $stream_data['name'] : 'Cloudflare Zone';
          $stream_status = isset($stream_data['status']) ? $stream_data['status'] : 'unknown';
          $health_score = isset($stream_data['health_score']) ? floatval($stream_data['health_score']) : 0;
          $answer .= "• **" . $stream_name . "**\n";
          $answer .= "  Status: " . ucfirst($stream_status) . "\n";
          $answer .= "  Health Score: " . number_format($health_score, 1) . "%\n";
          if (isset($stream_data['cloudflare_zone_name'])) {
            $answer .= "  Zone: " . $stream_data['cloudflare_zone_name'] . "\n";
          }
          if (isset($stream_data['cloudflare_plan'])) {
            $answer .= "  Plan: " . $stream_data['cloudflare_plan'] . "\n";
          }
          $answer .= "\n";
        }
      } else {
    $answer = "Cloudflare is a popular CDN (Content Delivery Network) and security service that can improve your website's performance and protect it from threats. I don't see Cloudflare specifically configured in your current setup, but it's a great option to consider for faster loading times and enhanced security.";
      }
    }
  }
  elseif (preg_match('/\bdns.*records|\bdns\b/', $lc)) {
    $security_domain = isset($security['domain']) && is_array($security['domain']) ? $security['domain'] : array();
    $dns_records = isset($security_domain['dns_records']) ? $security_domain['dns_records'] : '';
    if ($dns_records) {
      $answer = "Here are your DNS records: ".$dns_records.". These control how your domain points to your hosting server and other services.";
    } else {
      $answer = "I don't have your DNS records in the current profile. You can check these in your domain registrar's control panel or hosting provider's DNS management section.";
    }
  }
  elseif (preg_match('/\blogin.*authenticator|\bauthenticator\b/', $lc)) {
    $security_auth = isset($security['auth']) && is_array($security['auth']) ? $security['auth'] : array();
    $mfa = isset($security_auth['mfa']) ? $security_auth['mfa'] : '';
    if ($mfa) {
      $answer = "Your login authentication is handled by ".$mfa.". This provides an extra layer of security beyond just passwords.";
    } else {
      $answer = "I don't see a specific authenticator configured in your security profile. Consider setting up two-factor authentication (2FA) for enhanced security.";
    }
  }
  elseif (preg_match('/\bquestion\b/', $lc)) {
    $answer = "Of course! I'm here to help. What would you like to know about your website?";
  }
  elseif (preg_match('/\bno\b/', $lc)) {
    $answer = "No problem! Is there anything else I can help you with regarding your website?";
  }
  elseif (preg_match('/\b(thank\s?you|thanks|great|awesome|excellent|perfect)\b/', $lc)) {
    $answer = "Glad I could help! Feel free to ask if you have any other questions about your site.";
  }
  elseif (preg_match('/\b(help|support|issue|problem|error|bug|broken|not working|trouble|stuck|confused|need assistance)\b/', $lc)) {
    $answer = luna_analyze_help_request($prompt, $facts);
  }
  elseif (preg_match('/\b(support email|send email|email support)\b/', $lc)) {
    $answer = luna_handle_help_option('support_email', $prompt, $facts);
  }
  elseif (preg_match('/\b(notify vl|notify visible light|alert vl|alert visible light)\b/', $lc)) {
    $answer = luna_handle_help_option('notify_vl', $prompt, $facts);
  }
  elseif (preg_match('/\b(report bug|bug report|report as bug)\b/', $lc)) {
    $answer = luna_handle_help_option('report_bug', $prompt, $facts);
  }
  elseif (preg_match('/\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b/', $prompt)) {
    // Email address detected - send support email
    $email = luna_extract_email($prompt);
    if ($email) {
      $success = luna_send_support_email($email, $prompt, $facts);
      if ($success) {
        $answer = "✅ Perfect! I've sent a detailed snapshot of our conversation and your site data to " . $email . ". You should receive it shortly. Is there anything else I can help you with?";
      } else {
        $answer = "I encountered an issue sending the email. Let me try notifying the Visible Light team instead - would you like me to do that?";
      }
    } else {
      $answer = "I couldn't find a valid email address in your message. Could you please provide the email address where you'd like me to send the support snapshot?";
    }
  }
  elseif (preg_match("/\bhow.*many.*inactive.*themes|\binactive.*themes\b/", $lc)) {
    $inactive_themes = array();
    if (isset($facts["themes"]) && is_array($facts["themes"])) {
      foreach ($facts["themes"] as $theme) {
        if (empty($theme["is_active"])) {
          $inactive_themes[] = $theme["name"] . " v" . $theme["version"];
        }
      }
    }
    if (!empty($inactive_themes)) {
      $answer = "You have " . count($inactive_themes) . " inactive themes: " . implode(", ", $inactive_themes) . ".";
    } else {
      $answer = "You have no inactive themes. All installed themes are currently active.";
    }
  }
  elseif (preg_match("/\bhow.*many.*plugins|\bplugin.*count\b/", $lc)) {
    $plugin_count = isset($facts["counts"]["plugins"]) ? (int)$facts["counts"]["plugins"] : 0;
    $answer = "You currently have " . $plugin_count . " plugins installed.";
  }
  elseif (preg_match("/\b(list|names|show).*(pages|posts|content)\b|\b(pages|posts).*(list|names|show)\b/", $lc)) {
    // List pages and/or posts with names
    $pages_list = array();
    $posts_list = array();
    
    if (isset($facts['pages']) && is_array($facts['pages']) && !empty($facts['pages'])) {
      foreach ($facts['pages'] as $page) {
        if (is_array($page)) {
          $title = isset($page['title']) ? $page['title'] : (isset($page['name']) ? $page['name'] : 'Untitled Page');
          $pages_list[] = $title;
        } elseif (is_string($page)) {
          $pages_list[] = $page;
        }
      }
    }
    
    if (isset($facts['posts']) && is_array($facts['posts']) && !empty($facts['posts'])) {
      foreach ($facts['posts'] as $post) {
        if (is_array($post)) {
          $title = isset($post['title']) ? $post['title'] : (isset($post['name']) ? $post['name'] : 'Untitled Post');
          $posts_list[] = $title;
        } elseif (is_string($post)) {
          $posts_list[] = $post;
        }
      }
    }
    
    $parts = array();
    if (!empty($pages_list)) {
      $pages_count = count($pages_list);
      $parts[] = "**Pages (" . $pages_count . "):**\n" . implode("\n", array_map(function($title) { return "  • " . $title; }, array_slice($pages_list, 0, 50))); // Limit to 50 for readability
      if ($pages_count > 50) {
        $parts[count($parts) - 1] .= "\n  ... and " . ($pages_count - 50) . " more pages";
      }
    }
    
    if (!empty($posts_list)) {
      $posts_count = count($posts_list);
      $parts[] = "**Posts (" . $posts_count . "):**\n" . implode("\n", array_map(function($title) { return "  • " . $title; }, array_slice($posts_list, 0, 50))); // Limit to 50 for readability
      if ($posts_count > 50) {
        $parts[count($parts) - 1] .= "\n  ... and " . ($posts_count - 50) . " more posts";
      }
    }
    
    if (!empty($parts)) {
      $answer = implode("\n\n", $parts);
    } else {
      $pages_count = isset($facts['counts']['pages']) ? (int)$facts['counts']['pages'] : 0;
      $posts_count = isset($facts['counts']['posts']) ? (int)$facts['counts']['posts'] : 0;
      $answer = "You have " . $pages_count . " pages and " . $posts_count . " posts on your site. However, I don't have the specific names of those pages and posts in the current data. If you need that information, you can check directly in your WordPress dashboard.";
    }
  }
  elseif (preg_match("/\bwhat.*plugins|\blist.*plugins\b/", $lc)) {
    if (isset($facts["plugins"]) && is_array($facts["plugins"]) && !empty($facts["plugins"])) {
      $plugin_list = array();
      foreach ($facts["plugins"] as $plugin) {
        $status = !empty($plugin["active"]) ? "active" : "inactive";
        $plugin_list[] = $plugin["name"] . " v" . $plugin["version"] . " (" . $status . ")";
      }
      $answer = "Your installed plugins are: " . implode(", ", $plugin_list) . ".";
    } else {
      $answer = "I don't see any plugins installed on your site.";
    }
  }
  elseif (preg_match('/\b(do.*i.*have.*posts|posts.*published|published.*posts|how.*many.*posts|any.*posts|have.*posts|posts.*on.*site)\b/i', $lc)) {
    // Posts query - check facts for posts data
    $posts = isset($facts['posts']) && is_array($facts['posts']) ? $facts['posts'] : array();
    $posts_count = isset($facts['counts']['posts']) ? (int)$facts['counts']['posts'] : (isset($facts['posts_count']) ? (int)$facts['posts_count'] : count($posts));
    
    if ($posts_count > 0) {
      if (!empty($posts) && count($posts) > 0) {
        // Get first post details for conversational response
        $first_post = $posts[0];
        $post_title = isset($first_post['title']) ? $first_post['title'] : (isset($first_post['name']) ? $first_post['name'] : 'Untitled');
        
        // Get categories if available
        $categories = array();
        if (isset($first_post['categories']) && is_array($first_post['categories'])) {
          foreach ($first_post['categories'] as $cat) {
            $cat_name = is_array($cat) ? (isset($cat['name']) ? $cat['name'] : '') : (string)$cat;
            if (!empty($cat_name)) {
              $categories[] = $cat_name;
            }
          }
        }
        
        // Build conversational, hybrid response
        if ($posts_count === 1) {
          $answer = "Yes, you have one post published titled, \"" . $post_title . "\"";
        } else {
          $answer = "Yes, you have " . $posts_count . " published posts on your site";
          if ($post_title !== 'Untitled') {
            $answer .= ", including \"" . $post_title . "\"";
          }
        }
        
        // Add categories if available
        if (!empty($categories)) {
          $answer .= ". Assigned categories include \"" . implode('", "', $categories) . "\"";
        } else {
          $answer .= ".";
        }
        
        // Offer follow-up help (conversational, hybrid approach)
        $answer .= " Do you need any further information about the content or performance of " . ($posts_count === 1 ? "this post" : "these posts") . "?";
        
        // Mark this as a hybrid response - deterministic data + conversational AI
        $meta['source'] = 'hybrid_deterministic';
        $meta['has_followup_offer'] = true;
      } else {
        // We have count but no post details
        $answer = "Yes, you have " . $posts_count . " published post" . ($posts_count !== 1 ? 's' : '') . " on your site. Do you need any further information about the content or performance of " . ($posts_count === 1 ? "this post" : "these posts") . "?";
        $meta['source'] = 'hybrid_deterministic';
        $meta['has_followup_offer'] = true;
      }
    } else {
      $answer = "No, I don't see any published posts on your site. You can create posts in your WordPress dashboard under Posts > Add New.";
    }
  }
  elseif (preg_match('/\b(competitor|competitors|competitor.*analysis|competitor.*report|domain.*ranking|vldr|vl.*dr|dr.*score|competitive.*analysis)\b/', $lc)) {
    // Competitor analysis and domain ranking queries
    error_log('[Luna Widget] Competitor query detected: ' . $prompt);
    error_log('[Luna Widget] Checking facts for competitors: ' . print_r(isset($facts['competitors']) ? $facts['competitors'] : 'NOT SET', true));
    error_log('[Luna Widget] Checking facts for competitor_reports: ' . print_r(isset($facts['competitor_reports']) ? count($facts['competitor_reports']) . ' reports' : 'NOT SET', true));
    error_log('[Luna Widget] Checking facts for competitor_reports_full: ' . print_r(isset($facts['competitor_reports_full']) ? count($facts['competitor_reports_full']) . ' reports' : 'NOT SET', true));
    error_log('[Luna Widget] Full facts keys: ' . print_r(array_keys($facts), true));
    
    // Collect ALL competitor data sources
    $all_competitor_urls = array();
    $all_competitor_reports = array();
    
    // Get competitor URLs from multiple sources
    if (isset($facts['competitors']) && is_array($facts['competitors']) && !empty($facts['competitors'])) {
      $all_competitor_urls = array_merge($all_competitor_urls, $facts['competitors']);
    }
    
    // Get competitor reports from multiple sources
    if (isset($facts['competitor_reports']) && is_array($facts['competitor_reports'])) {
      $all_competitor_reports = array_merge($all_competitor_reports, $facts['competitor_reports']);
    }
    if (isset($facts['competitor_reports_full']) && is_array($facts['competitor_reports_full'])) {
      $all_competitor_reports = array_merge($all_competitor_reports, $facts['competitor_reports_full']);
    }
    
    // Extract competitor URLs from reports if available
    if (!empty($all_competitor_reports)) {
      foreach ($all_competitor_reports as $report_data) {
        $comp_url = $report_data['url'] ?? '';
        if (!empty($comp_url) && !in_array($comp_url, $all_competitor_urls)) {
          $all_competitor_urls[] = $comp_url;
        }
      }
    }
    
    // Try to extract a specific domain from the query
    $query_domain = null;
    if (preg_match('/\b([a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9]*\.(?:[a-zA-Z]{2,}|[a-zA-Z]{2,}\.[a-zA-Z]{2,}))\b/i', $prompt, $matches)) {
      $query_domain = strtolower($matches[1]);
      // Remove www. prefix if present
      $query_domain = preg_replace('/^www\./', '', $query_domain);
    }
    
    // If a specific domain was mentioned, search for it
    if ($query_domain) {
      error_log('[Luna Widget] Searching for specific domain: ' . $query_domain);
      
      // Search in competitor reports (check all sources)
      $found_report = null;
      $reports_to_search = $all_competitor_reports;
      
      foreach ($reports_to_search as $report_data) {
        $comp_url = $report_data['url'] ?? '';
        $comp_domain = $report_data['domain'] ?? '';
        if (empty($comp_domain) && !empty($comp_url)) {
          $comp_domain = parse_url($comp_url, PHP_URL_HOST);
        }
        if ($comp_domain) {
          $comp_domain = strtolower(preg_replace('/^www\./', '', $comp_domain));
          if ($comp_domain === $query_domain) {
            $found_report = $report_data;
            break;
          }
        }
      }
      
      // Search in competitors list (check all sources)
      $found_competitor = false;
      foreach ($all_competitor_urls as $competitor_url) {
        $domain = parse_url($competitor_url, PHP_URL_HOST);
        if ($domain) {
          $domain = strtolower(preg_replace('/^www\./', '', $domain));
          if ($domain === $query_domain) {
            $found_competitor = true;
            break;
          }
        }
      }
      
      // If we found a report, return detailed data
      if ($found_report) {
        $comp_url = $found_report['url'] ?? '';
        $comp_domain = $found_report['domain'] ?? parse_url($comp_url, PHP_URL_HOST);
        $report = $found_report['report'] ?? array();
        $last_scanned = $found_report['last_scanned'] ?? null;
        
        $answer = "**Competitor Analysis Report for " . $comp_domain . ":**\n\n";
        
        if ($last_scanned) {
          $answer .= "**Last Scanned:** " . date('M j, Y g:i A', strtotime($last_scanned)) . "\n\n";
        }
        
        if (!empty($report)) {
          // Handle both direct report data and nested report_json structure
          $report_data = $report;
          if (isset($report['report_json']) && is_array($report['report_json'])) {
            $report_data = $report['report_json'];
          }
          
          // Extract all available data from the report
          if (!empty($report_data['lighthouse_score'])) {
            $answer .= "**Lighthouse Score:** " . $report_data['lighthouse_score'] . "\n";
          } elseif (isset($report_data['lighthouse']) && is_array($report_data['lighthouse'])) {
            $lh = $report_data['lighthouse'];
            if (!empty($lh['performance'])) {
              $answer .= "**Lighthouse Performance Score:** " . $lh['performance'] . "\n";
            }
            if (!empty($lh['accessibility'])) {
              $answer .= "**Lighthouse Accessibility Score:** " . $lh['accessibility'] . "\n";
            }
            if (!empty($lh['seo'])) {
              $answer .= "**Lighthouse SEO Score:** " . $lh['seo'] . "\n";
            }
            if (!empty($lh['best_practices'])) {
              $answer .= "**Lighthouse Best Practices Score:** " . $lh['best_practices'] . "\n";
            }
          }
          
          if (!empty($report_data['public_pages'])) {
            $answer .= "**Public Pages Count:** " . $report_data['public_pages'] . "\n";
          }
          
          if (!empty($report_data['blog']) && is_array($report_data['blog'])) {
            $blog_status = isset($report_data['blog']['status']) ? $report_data['blog']['status'] : 'Unknown';
            $answer .= "**Blog Status:** " . ucfirst($blog_status) . "\n";
          }
          
          if (!empty($report_data['title'])) {
            $answer .= "**Page Title:** " . $report_data['title'] . "\n";
          }
          
          if (!empty($report_data['meta_description'])) {
            $answer .= "**Meta Description:** " . substr($report_data['meta_description'], 0, 200) . "...\n";
          }
          
          if (!empty($report_data['keywords']) && is_array($report_data['keywords'])) {
            $top_keywords = array_slice($report_data['keywords'], 0, 10);
            $answer .= "\n**Top Keywords:** " . implode(", ", $top_keywords) . "\n";
          }
          
          if (!empty($report_data['keyphrases']) && is_array($report_data['keyphrases'])) {
            $top_keyphrases = array_slice($report_data['keyphrases'], 0, 10);
            $answer .= "**Top Keyphrases:** " . implode(", ", $top_keyphrases) . "\n";
          }
        }
        
        // Add VLDR data if available for this domain
        if (isset($facts['vldr'][$query_domain])) {
          $vldr_data = $facts['vldr'][$query_domain];
          $answer .= "\n**Domain Ranking (VL-DR) Metrics:**\n";
          if (isset($vldr_data['vldr_score'])) {
            $score = (float) $vldr_data['vldr_score'];
            $color = $score >= 80 ? "excellent" : ($score >= 60 ? "good" : ($score >= 40 ? "fair" : "needs improvement"));
            $answer .= "  - VL-DR Score: **" . number_format($score, 1) . "/100** (" . $color . ")\n";
          }
          if (isset($vldr_data['ref_domains'])) {
            $answer .= "  - Referring Domains: ~" . number_format($vldr_data['ref_domains'] / 1000, 1) . "k\n";
          }
          if (isset($vldr_data['indexed_pages'])) {
            $answer .= "  - Indexed Pages: ~" . number_format($vldr_data['indexed_pages'] / 1000, 1) . "k\n";
          }
          if (isset($vldr_data['lighthouse_avg'])) {
            $answer .= "  - Lighthouse Average: " . $vldr_data['lighthouse_avg'] . "\n";
          }
          if (isset($vldr_data['security_grade'])) {
            $answer .= "  - Security Grade: **" . $vldr_data['security_grade'] . "**\n";
          }
          if (isset($vldr_data['domain_age_years'])) {
            $answer .= "  - Domain Age: " . number_format($vldr_data['domain_age_years'], 1) . " years\n";
          }
          if (isset($vldr_data['uptime_percent'])) {
            $answer .= "  - Uptime: " . number_format($vldr_data['uptime_percent'], 2) . "%\n";
          }
          if (isset($vldr_data['metric_date'])) {
            $answer .= "  - Last Updated: " . date('M j, Y', strtotime($vldr_data['metric_date'])) . "\n";
          }
        }
      } elseif ($found_competitor) {
        // Domain is in competitors list but no report found - try to fetch VLDR data
        if (isset($facts['vldr'][$query_domain])) {
          $vldr_data = $facts['vldr'][$query_domain];
          $answer = "**Competitor Analysis for " . $query_domain . ":**\n\n";
          if (isset($vldr_data['vldr_score'])) {
            $score = (float) $vldr_data['vldr_score'];
            $color = $score >= 80 ? "excellent" : ($score >= 60 ? "good" : ($score >= 40 ? "fair" : "needs improvement"));
            $answer .= "**VL-DR Score: " . number_format($score, 1) . "/100** (" . $color . ")\n\n";
          }
          $answer .= "**Detailed Metrics:**\n";
          if (isset($vldr_data['ref_domains'])) {
            $answer .= "• Referring Domains: ~" . number_format($vldr_data['ref_domains'] / 1000, 1) . "k\n";
          }
          if (isset($vldr_data['indexed_pages'])) {
            $answer .= "• Indexed Pages: ~" . number_format($vldr_data['indexed_pages'] / 1000, 1) . "k\n";
          }
          if (isset($vldr_data['lighthouse_avg'])) {
            $answer .= "• Lighthouse Average: " . $vldr_data['lighthouse_avg'] . "\n";
          }
          if (isset($vldr_data['security_grade'])) {
            $answer .= "• Security Grade: **" . $vldr_data['security_grade'] . "**\n";
          }
          if (isset($vldr_data['domain_age_years'])) {
            $answer .= "• Domain Age: " . number_format($vldr_data['domain_age_years'], 1) . " years\n";
          }
          if (isset($vldr_data['uptime_percent'])) {
            $answer .= "• Uptime: " . number_format($vldr_data['uptime_percent'], 2) . "%\n";
          }
          if (isset($vldr_data['metric_date'])) {
            $answer .= "\n*Last Updated: " . date('M j, Y', strtotime($vldr_data['metric_date'])) . "*\n";
          }
          $answer .= "\n*Note: A detailed competitor analysis report may not be available. You can run a new analysis in your Visible Light Hub profile.*";
        } else {
          $answer = "I found " . $query_domain . " in your competitor list, but I don't have a detailed analysis report for it yet. You can run a new competitor analysis for this domain in your Visible Light Hub profile.";
        }
      }
    } else {
      // No specific domain mentioned - check if we have ANY competitor data
      // Check for competitor reports first (most reliable source)
      if (!empty($all_competitor_reports)) {
        $competitor_list = array();
        $competitor_details = array();
        
        foreach ($all_competitor_reports as $report_data) {
          $comp_url = $report_data['url'] ?? '';
          $comp_domain = $report_data['domain'] ?? '';
          if (empty($comp_domain) && !empty($comp_url)) {
            $comp_domain = parse_url($comp_url, PHP_URL_HOST);
          }
          if ($comp_domain && !in_array($comp_domain, $competitor_list)) {
            $competitor_list[] = $comp_domain;
            
            // Extract report details
            $report = $report_data['report'] ?? array();
            $report_data_inner = $report;
            if (isset($report['report_json']) && is_array($report['report_json'])) {
              $report_data_inner = $report['report_json'];
            }
            
            $details = array();
            if (!empty($report_data_inner['public_pages'])) {
              $details['public_pages'] = $report_data_inner['public_pages'];
            }
            if (!empty($report_data_inner['blog']) && is_array($report_data_inner['blog'])) {
              $blog_status = isset($report_data_inner['blog']['status']) ? $report_data_inner['blog']['status'] : 'Unknown';
              $details['blog_status'] = ucfirst($blog_status);
            }
            if (!empty($report_data_inner['lighthouse_score'])) {
              $details['lighthouse'] = $report_data_inner['lighthouse_score'];
            } elseif (isset($report_data_inner['lighthouse']) && is_array($report_data_inner['lighthouse'])) {
              $details['lighthouse'] = isset($report_data_inner['lighthouse']['performance']) ? $report_data_inner['lighthouse']['performance'] : 'N/A';
            }
            if (!empty($report_data['last_scanned'])) {
              $details['last_scanned'] = $report_data['last_scanned'];
            }
            
            // Get VLDR score if available
            if (isset($facts['vldr'][$comp_domain])) {
              $details['vldr_score'] = $facts['vldr'][$comp_domain]['vldr_score'] ?? null;
            }
            
            $competitor_details[$comp_domain] = $details;
          }
        }
        
        if (!empty($competitor_list)) {
          $answer = "**Yes, you have " . count($competitor_list) . " competitor(s) listed with analysis reports:**\n\n";
          
          foreach ($competitor_list as $domain) {
            $answer .= "**" . $domain . "**\n";
            $details = $competitor_details[$domain] ?? array();
            
            if (!empty($details['public_pages'])) {
              $answer .= "  • Public Pages: " . $details['public_pages'] . "\n";
            }
            if (!empty($details['blog_status'])) {
              $answer .= "  • Blog Status: " . $details['blog_status'] . "\n";
            }
            if (!empty($details['lighthouse'])) {
              $answer .= "  • Lighthouse Score: " . $details['lighthouse'] . "\n";
            }
            if (!empty($details['vldr_score'])) {
              $answer .= "  • Domain Ranking (VL-DR): " . number_format($details['vldr_score'], 2) . "/100\n";
            }
            if (!empty($details['last_scanned'])) {
              $answer .= "  • Last Scanned: " . date('M j, Y g:i A', strtotime($details['last_scanned'])) . "\n";
            }
            $answer .= "\n";
          }
          
          $first_competitor = !empty($competitor_list) ? $competitor_list[0] : 'your competitor';
          $answer .= "You can ask me about a specific competitor by mentioning their domain name, for example: \"What's the competitor analysis for " . $first_competitor . "?\"\n\n";
          
          // Add VLDR data if available
          if (isset($facts['vldr']) && is_array($facts['vldr']) && !empty($facts['vldr'])) {
            $answer .= "**Domain Ranking (VL-DR) Scores:**\n";
            foreach ($facts['vldr'] as $domain => $vldr_data) {
              $is_client = isset($vldr_data['is_client']) && $vldr_data['is_client'];
              $label = $is_client ? "Your Domain" : "Competitor";
              $answer .= "\n" . $label . ": **" . $domain . "**\n";
              if (isset($vldr_data['vldr_score'])) {
                $score = (float) $vldr_data['vldr_score'];
                $color = $score >= 80 ? "excellent" : ($score >= 60 ? "good" : ($score >= 40 ? "fair" : "needs improvement"));
                $answer .= "  - VL-DR Score: **" . number_format($score, 1) . "/100** (" . $color . ")\n";
              }
              if (isset($vldr_data['ref_domains'])) {
                $answer .= "  - Referring Domains: ~" . number_format($vldr_data['ref_domains'] / 1000, 1) . "k\n";
              }
              if (isset($vldr_data['indexed_pages'])) {
                $answer .= "  - Indexed Pages: ~" . number_format($vldr_data['indexed_pages'] / 1000, 1) . "k\n";
              }
              if (isset($vldr_data['lighthouse_avg'])) {
                $answer .= "  - Lighthouse Average: " . $vldr_data['lighthouse_avg'] . "\n";
              }
              if (isset($vldr_data['security_grade'])) {
                $answer .= "  - Security Grade: **" . $vldr_data['security_grade'] . "**\n";
              }
              if (isset($vldr_data['domain_age_years'])) {
                $answer .= "  - Domain Age: " . number_format($vldr_data['domain_age_years'], 1) . " years\n";
              }
              if (isset($vldr_data['uptime_percent'])) {
                $answer .= "  - Uptime: " . number_format($vldr_data['uptime_percent'], 2) . "%\n";
              }
              if (isset($vldr_data['metric_date'])) {
                $answer .= "  - Last Updated: " . date('M j, Y', strtotime($vldr_data['metric_date'])) . "\n";
              }
            }
            $answer .= "\n*VL-DR is computed from public indicators: Common Crawl/Index, Bing Web Search, SecurityHeaders.com, WHOIS, Visible Light Uptime monitoring, and Lighthouse performance scores.*\n";
          }
        } elseif (!empty($all_competitor_urls)) {
          // Have competitor URLs but no reports yet
          $competitor_list = array();
          foreach ($all_competitor_urls as $competitor_url) {
            $domain = parse_url($competitor_url, PHP_URL_HOST);
            if ($domain) {
              $competitor_list[] = $domain;
            }
          }
          
          if (!empty($competitor_list)) {
            $answer = "You have " . count($competitor_list) . " competitor(s) listed: " . implode(", ", $competitor_list) . ".\n\n";
            $answer .= "However, I don't have detailed analysis reports for them yet. You can run a competitor analysis in your Visible Light Hub profile to generate reports with Lighthouse scores, keywords, and domain rankings.\n\n";
            
            // Add VLDR data if available
            if (isset($facts['vldr']) && is_array($facts['vldr']) && !empty($facts['vldr'])) {
              $answer .= "**Domain Ranking (VL-DR) Scores Available:**\n";
              foreach ($facts['vldr'] as $domain => $vldr_data) {
                if (in_array($domain, $competitor_list)) {
                  $answer .= "\n**" . $domain . ":**\n";
                  if (isset($vldr_data['vldr_score'])) {
                    $score = (float) $vldr_data['vldr_score'];
                    $color = $score >= 80 ? "excellent" : ($score >= 60 ? "good" : ($score >= 40 ? "fair" : "needs improvement"));
                    $answer .= "  - VL-DR Score: **" . number_format($score, 1) . "/100** (" . $color . ")\n";
                  }
                  if (isset($vldr_data['ref_domains'])) {
                    $answer .= "  - Referring Domains: ~" . number_format($vldr_data['ref_domains'] / 1000, 1) . "k\n";
                  }
                  if (isset($vldr_data['indexed_pages'])) {
                    $answer .= "  - Indexed Pages: ~" . number_format($vldr_data['indexed_pages'] / 1000, 1) . "k\n";
                  }
                  if (isset($vldr_data['lighthouse_avg'])) {
                    $answer .= "  - Lighthouse Average: " . $vldr_data['lighthouse_avg'] . "\n";
                  }
                  if (isset($vldr_data['security_grade'])) {
                    $answer .= "  - Security Grade: **" . $vldr_data['security_grade'] . "**\n";
                  }
                }
              }
            }
          } else {
            $answer = "I don't see any competitor analysis data configured. You can set up competitor analysis in your Visible Light Hub profile to track competitor domains and their performance metrics.";
          }
        } else {
          $answer = "I don't see any competitor analysis data configured. You can set up competitor analysis in your Visible Light Hub profile to track competitor domains and their performance metrics.";
        }
      }
    }
  }
  elseif (preg_match('/\b(domain.*rank|vldr|vl.*dr|dr.*score|ranking.*score)\b/', $lc) && preg_match('/\b(astronomer|siteassembly|nvidia|competitor|competitors)\b/i', $prompt)) {
    // Specific domain ranking query
    $domain_match = null;
    if (preg_match('/\b(astronomer\.io|siteassembly\.com|nvidia\.com)\b/i', $prompt, $matches)) {
      $domain_match = strtolower($matches[1]);
    } elseif (preg_match('/\b(astronomer|siteassembly|nvidia)\b/i', $prompt, $matches)) {
      $domain_lookup = array(
        'astronomer' => 'astronomer.io',
        'siteassembly' => 'siteassembly.com',
        'nvidia' => 'nvidia.com',
      );
      $key = strtolower($matches[1]);
      if (isset($domain_lookup[$key])) {
        $domain_match = $domain_lookup[$key];
      }
    }
    
    if ($domain_match && isset($facts['vldr'][$domain_match])) {
      $vldr_data = $facts['vldr'][$domain_match];
      $answer = "**Domain Ranking for " . $domain_match . ":**\n\n";
      if (isset($vldr_data['vldr_score'])) {
        $score = (float) $vldr_data['vldr_score'];
        $color = $score >= 80 ? "excellent" : ($score >= 60 ? "good" : ($score >= 40 ? "fair" : "needs improvement"));
        $answer .= "**VL-DR Score: " . number_format($score, 1) . "/100** (" . $color . ")\n\n";
      }
      $answer .= "**Detailed Metrics:**\n";
      if (isset($vldr_data['ref_domains'])) {
        $answer .= "• Referring Domains: ~" . number_format($vldr_data['ref_domains'] / 1000, 1) . "k\n";
      }
      if (isset($vldr_data['indexed_pages'])) {
        $answer .= "• Indexed Pages: ~" . number_format($vldr_data['indexed_pages'] / 1000, 1) . "k\n";
      }
      if (isset($vldr_data['lighthouse_avg'])) {
        $answer .= "• Lighthouse Average: " . $vldr_data['lighthouse_avg'] . "\n";
      }
      if (isset($vldr_data['security_grade'])) {
        $answer .= "• Security Grade: **" . $vldr_data['security_grade'] . "**\n";
      }
      if (isset($vldr_data['domain_age_years'])) {
        $answer .= "• Domain Age: " . number_format($vldr_data['domain_age_years'], 1) . " years\n";
      }
      if (isset($vldr_data['uptime_percent'])) {
        $answer .= "• Uptime: " . number_format($vldr_data['uptime_percent'], 2) . "%\n";
      }
      if (isset($vldr_data['metric_date'])) {
        $answer .= "\n*Last Updated: " . date('M j, Y', strtotime($vldr_data['metric_date'])) . "*\n";
      }
      $answer .= "\n*VL-DR is computed from public indicators: Common Crawl/Index, Bing Web Search, SecurityHeaders.com, WHOIS, Visible Light Uptime monitoring, and Lighthouse performance scores.*";
    } else {
      $answer = "I don't have domain ranking data for that domain. Make sure competitor analysis is set up in your Visible Light Hub profile for the domain you're asking about.";
    }
  }

  }

  // If no deterministic answer was found, check for canned responses (only for basic facts)
  // Then fall through to OpenAI for intelligent responses
  if ($answer === '' && !$is_composer) {
    $facts_source = isset($facts['__source']) ? $facts['__source'] : ((isset($facts['comprehensive']) && $facts['comprehensive']) ? 'comprehensive' : 'basic');
    if ($facts_source !== 'comprehensive') {
      $canned = luna_widget_find_canned_response($prompt);
      if (is_array($canned) && !empty($canned['content'])) {
        $answer = $canned['content'];
        $meta['source'] = 'canned_response';
        $meta['canned_id'] = $canned['id'];
        if (!empty($canned['title'])) {
          $meta['canned_title'] = $canned['title'];
        }
      }
      // If no canned response found, leave $answer empty to fall through to OpenAI
    }
  }

  // For Luna Composer, ALWAYS use OpenAI to generate long-form, thoughtful, hyper-personal responses
  // Skip deterministic answers AND canned responses for composer requests to ensure all responses are AI-generated
  // Even if a deterministic answer was found, override it for composer requests
  if ($is_composer) {
    // Reset answer to empty to force OpenAI generation
    $answer = '';
    // For Luna Composer, ALWAYS generate long-form, thoughtful, hyper-personal responses
    // CRITICAL: Use actual VL Hub data from the FACTS section - reference specific metrics, trends, and insights
    $enhanced_prompt = "You are Luna Composer, a sophisticated AI writing assistant that generates long-form, thoughtful, and hyper-personal data-driven content. The user is using Luna Composer to create editable long-form content, so your response must be comprehensive, well-structured, and suitable for professional editing. Write in a thoughtful, engaging, and personable manner that feels human and authentic, not robotic. Use full sentences, proper paragraph breaks, and narrative-style explanations.\n\nCRITICAL INSTRUCTIONS:\n1. You MUST use the actual VL Hub data provided in the FACTS section below. Reference specific metrics, trends, and insights from the user's actual data (GA4 metrics, Lighthouse scores, competitor analysis, domain rankings, SSL/TLS status, Cloudflare connections, AWS S3 storage, ad platform data, etc.).\n2. Weave this real data naturally into a cohesive narrative. Make the content feel personalized and tailored to the user's specific needs and their actual digital presence.\n3. Analyze the data, highlight trends, call out risks or opportunities, and provide strategic recommendations or next steps so the user receives meaningful guidance rather than just raw metrics.\n4. When data is missing or limited, acknowledge the gap and recommend how to close it.\n5. Generate a substantial, detailed response (minimum 300-500 words for simple queries, 800-1200+ words for complex queries) that provides real value and can be edited into polished content.\n6. NEVER use emoticons, emojis, unicode symbols, or special characters. Use plain text only.\n\nUser request: " . $prompt;
    
    // Mark this as a composer request in facts for the OpenAI function
    $facts['__composer'] = true;
    $openai = luna_generate_openai_answer($pid, $enhanced_prompt, $facts, true); // Force comprehensive mode for composer
    if (is_array($openai) && !empty($openai['answer'])) {
      $answer = $openai['answer'];
      $meta['source'] = 'openai';
      $meta['composer'] = true;
      if (!empty($openai['model'])) {
        $meta['model'] = $openai['model'];
      }
      if (!empty($openai['usage']) && is_array($openai['usage'])) {
        $meta['usage'] = $openai['usage'];
      }
    } else {
      // Last resort: generic helpful message
      $answer = "I can help you with information about your WordPress site, including themes, plugins, SSL/TLS certificates, Cloudflare connections, AWS S3 storage, Google Analytics 4, Liquid Web hosting, competitor analysis, domain rankings (VLDR), performance metrics, SEO data, data streams, and more. All data comes from your Visible Light Hub profile. What would you like to know?";
      $meta['source'] = 'default';
    }
  } elseif ($answer === '' || ($is_conceptual_question && empty($answer))) {
    // If no deterministic answer was found, OR if it's a conceptual question AND we don't have an answer, use OpenAI
    // This ensures that if we have demo data or site-specific data, we use it instead of overwriting with OpenAI
    // The facts text already includes ALL VL Hub data, so GPT-4o can intelligently answer
    // For comprehensive reports or complex questions, add additional context to the prompt
    
    // Check if this is a follow-up to a previous hybrid response by checking conversation history
    $is_followup_request = false;
    if ($pid) {
      $transcript = get_post_meta($pid, 'transcript', true);
      if (is_array($transcript) && count($transcript) > 0) {
        // Get the last assistant message to see if it had a follow-up offer
        $last_turn = end($transcript);
        if (isset($last_turn['assistant']) && is_string($last_turn['assistant'])) {
          $last_assistant = strtolower($last_turn['assistant']);
          // Check if last response had a follow-up offer pattern
          if (preg_match('/\b(do you need|need any|further information|more information|would you like|can i help|anything else)\b/i', $last_assistant)) {
            // Check if current prompt is a positive response
            if (preg_match('/\b(yes|yeah|yep|sure|please|ok|okay|go ahead|continue|more|further|details|information|review|analysis|performance|content|improve|improvement|suggestions|supply|provide|give)\b/i', $lc)) {
              $is_followup_request = true;
            }
          }
        }
      }
    }
    
    // Also check if the current prompt itself contains follow-up request keywords (even without previous context)
    if (!$is_followup_request && preg_match('/\b(review|analysis|performance|content|improve|improvement|suggestions|supply|provide|give|details|information)\b/i', $lc) && preg_match('/\b(yes|yeah|yep|sure|please|ok|okay)\b/i', $lc)) {
      $is_followup_request = true;
    }
    
    // Check if this is a blog title or content creation request
    $is_blog_title_request = preg_match('/\b(blog.*title|create.*title|write.*title|content.*idea|suggest.*blog|blog.*suggest)\b/i', $lc);
    
    $enhanced_prompt = $prompt;
    
    // For follow-up requests, enhance the prompt to create hybrid responses
    if ($is_followup_request) {
      $enhanced_prompt = "The user is asking for more detailed information following up on a previous response. CRITICAL: You MUST use the actual VL Hub Profile data provided in the FACTS section below to generate a thoughtful, data-driven, and human-readable response. Combine deterministic data (post titles, categories, counts, etc.) with intelligent analysis and suggestions.\n\n1. Start with a friendly, conversational opening (e.g., 'Sounds great! Let's dive in.')\n2. Use the actual data from FACTS (post details, categories, performance metrics if available, etc.)\n3. Provide thoughtful analysis, insights, and actionable suggestions\n4. Write in a natural, human-readable manner with proper paragraph breaks\n5. Reference specific data points from the FACTS section\n6. If performance data (GA4, Lighthouse, etc.) is available, include it in your analysis\n7. Provide concrete, actionable suggestions for improvement\n8. NEVER use emoticons, emojis, unicode symbols, or special characters. Use plain text only.\n\nUser request: " . $prompt;
    }
    if ($is_blog_title_request) {
      // For blog title/content requests, use GPT-4o with full VL Hub context and user requirements
      $enhanced_prompt = "The user is requesting blog titles or content ideas. CRITICAL: You MUST use the actual VL Hub Profile data provided in the FACTS section below to generate thoughtful, data-driven, and contextually relevant blog titles. Analyze the user's specific requirements, their business data (GA4 metrics, CloudOps connections, data streams, security status, etc.), and generate blog titles that are:\n\n1. SPECIFIC to their request and requirements (e.g., if they mention 'AI + CloudOps', focus on those topics)\n2. DATA-DRIVEN using actual metrics and insights from their VL Hub Profile\n3. HIGHLIGHT Visible Light's capabilities (centralization, harmonization, real-time data interaction) when relevant\n4. HUMAN-READABLE and engaging, not generic or templated\n5. Tailored to their actual business context and data\n\nIMPORTANT: Do NOT provide generic blog title suggestions. Instead, create thoughtful, personalized titles based on their specific request and actual VL Hub data. Reference specific metrics, trends, or insights when relevant. If the user mentions specific topics (like 'AI + CloudOps' or 'centralize, harmonize, and interact with data'), ensure your suggestions directly address those topics.\n\nUser request: " . $prompt;
    } elseif ($is_comprehensive_report) {
      $enhanced_prompt = "Generate a comprehensive, enterprise-grade site health report in paragraph format with full sentences that can be easily copied and pasted into an email. Write in a thoughtful, full-length, professional manner that reads like a human executive report. Use personable, professional language suitable for leadership. Format with proper paragraph breaks and section headers. Use descriptive, narrative-style explanations rather than bullet points. Include an intro header, detailed findings from all data sources, and an official signature. NEVER use emoticons, emojis, unicode symbols, or special characters. Use plain text only.\n\nUser request: " . $prompt;
    } elseif ($is_complex_question) {
      $enhanced_prompt = "The user has asked a complex question with multiple parts, split thoughts, or multiple commands. Please address ALL parts of the question comprehensively. Break down the response into clear sections if needed, but ensure every aspect of the question is answered thoroughly. Use full sentences and proper paragraph breaks. NEVER use emoticons, emojis, unicode symbols, or special characters. Use plain text only.\n\nUser request: " . $prompt;
    } elseif ($is_conceptual_question) {
      // For conceptual questions, emphasize conversational, educational responses
      // BUT: If we have site-specific data in facts, prioritize that data in the response
      $enhanced_prompt = "The user has asked a conceptual or general question. Provide a friendly, conversational, and educational answer. IMPORTANT: If the question relates to their site data (like SSL/TLS certificates, WordPress version, themes, etc.), FIRST check the FACTS provided below and use that specific data. Then add educational context. If it's a general web-related question with no site-specific data, provide helpful information. Be conversational and engaging - this is a dialogue, not just data output. Use full sentences and natural language. NEVER use emoticons, emojis, unicode symbols, or special characters. Use plain text only.\n\nUser request: " . $prompt;
    }
    $openai = luna_generate_openai_answer($pid, $enhanced_prompt, $facts, $is_comprehensive_report || $is_complex_question || $is_conceptual_question);
    if (is_array($openai) && !empty($openai['answer'])) {
      $answer = $openai['answer'];
      $meta['source'] = 'openai';
      if ($is_comprehensive_report) {
        $meta['report_type'] = 'comprehensive';
      }
      if (!empty($openai['model'])) {
        $meta['model'] = $openai['model'];
      }
      if (!empty($openai['usage']) && is_array($openai['usage'])) {
        $meta['usage'] = $openai['usage'];
      }
    } else {
      // Last resort: generic helpful message
      $answer = "I can help you with information about your WordPress site, including themes, plugins, SSL/TLS certificates, Cloudflare connections, AWS S3 storage, Google Analytics 4, Liquid Web hosting, competitor analysis, domain rankings (VLDR), performance metrics, SEO data, data streams, and more. All data comes from your Visible Light Hub profile. What would you like to know?";
      $meta['source'] = 'default';
    }
  }

  if ($pid) {
    $meta['conversation_id'] = $pid;
  }
  luna_log_turn($prompt, $answer, $meta);

  if ($is_composer) {
    luna_composer_log_entry($prompt, $answer, $meta, $pid);
  }

  // Ensure answer is never empty
  if (empty($answer) || trim($answer) === '') {
    error_log('[Luna Widget Chat Handler] Warning: Empty answer generated, using fallback');
    $answer = "I can help you with information about your WordPress site, including themes, plugins, SSL/TLS certificates, Cloudflare connections, AWS S3 storage, Google Analytics 4, Liquid Web hosting, competitor analysis, domain rankings (VLDR), performance metrics, SEO data, data streams, and more. All data comes from your Visible Light Hub profile. What would you like to know?";
    $meta['source'] = 'fallback';
  }
  
  $response = new WP_REST_Response(array('answer'=>$answer, 'meta'=>$meta), 200);
  return $add_cors_headers($response);
  
  } catch (Exception $e) {
    $error_message = $e->getMessage();
    error_log('[Luna Widget Chat Handler] Exception: ' . $error_message);
    error_log('[Luna Widget Chat Handler] Stack trace: ' . $e->getTraceAsString());
    
    // Check if it's a 403 or permission error
    $is_permission_error = (strpos($error_message, '403') !== false || 
                            strpos($error_message, 'forbidden') !== false || 
                            strpos($error_message, 'permission') !== false ||
                            strpos($error_message, 'HTTP 403') !== false);
    
    if ($is_permission_error) {
      $response = new WP_REST_Response(array(
        'answer' => 'I encountered an access permission error. Please check your license key configuration and ensure Luna Chat has proper permissions to access VL Hub data. Error: ' . substr($error_message, 0, 100),
        'meta' => array('source' => 'error', 'error_type' => 'permission_denied', 'error' => $error_message)
      ), 403);
    } else {
      $response = new WP_REST_Response(array(
        'answer' => 'I encountered an error processing your request. Please try again.',
        'meta' => array('source' => 'error', 'error' => $error_message)
      ), 500);
    }
    return $add_cors_headers($response);
  } catch (Error $e) {
    $error_message = $e->getMessage();
    error_log('[Luna Widget Chat Handler] Fatal error: ' . $error_message);
    error_log('[Luna Widget Chat Handler] Stack trace: ' . $e->getTraceAsString());
    
    // Check if it's a 403 or permission error
    $is_permission_error = (strpos($error_message, '403') !== false || 
                            strpos($error_message, 'forbidden') !== false || 
                            strpos($error_message, 'permission') !== false ||
                            strpos($error_message, 'HTTP 403') !== false);
    
    if ($is_permission_error) {
      $response = new WP_REST_Response(array(
        'answer' => 'I encountered an access permission error. Please check your license key configuration and ensure Luna Chat has proper permissions to access VL Hub data. Error: ' . substr($error_message, 0, 100),
        'meta' => array('source' => 'error', 'error_type' => 'permission_denied', 'fatal' => true, 'error' => $error_message)
      ), 403);
    } else {
      $response = new WP_REST_Response(array(
        'answer' => 'I encountered a fatal error processing your request. Please try again.',
        'meta' => array('source' => 'error', 'fatal' => true, 'error' => $error_message)
      ), 500);
    }
    return $add_cors_headers($response);
  }
}

function luna_widget_rest_chat_inactive( WP_REST_Request $req ) {
  $default_message = "I haven't heard from you in a while, are you still there? If not, I'll close out this chat automatically in 3 minutes.";
  $message = $req->get_param('message');
  if (!is_string($message) || trim($message) === '') {
    $message = $default_message;
  } else {
    $message = sanitize_text_field($message);
  }

  $pid = luna_conv_id();
  $meta = array('source' => 'system', 'event' => 'inactive_warning');
  if ($pid) {
    $meta['conversation_id'] = $pid;
    update_post_meta($pid, 'last_inactive_warning', time());
  }

  luna_log_turn('', $message, $meta);

  return new WP_REST_Response(array('message' => $message), 200);
}

function luna_widget_rest_chat_end_session( WP_REST_Request $req ) {
  $pid = luna_conv_id();
  $default_message = 'This chat session has been closed due to inactivity.';
  $message = $req->get_param('message');
  if (!is_string($message) || trim($message) === '') {
    $message = $default_message;
  } else {
    $message = sanitize_text_field($message);
  }

  $reason = $req->get_param('reason');
  if (!is_string($reason) || trim($reason) === '') {
    $reason = 'manual';
  } else {
    $reason = sanitize_text_field($reason);
  }

  $already_closed = $pid ? (bool) get_post_meta($pid, 'session_closed', true) : false;
  if ($pid && !$already_closed) {
    luna_widget_close_conversation($pid, $reason);
    $meta = array(
      'source' => 'system',
      'event'  => 'session_end',
      'reason' => $reason,
      'conversation_id' => $pid,
    );
    luna_log_turn('', $message, $meta);
  }

  return new WP_REST_Response(array(
    'closed' => (bool) $pid,
    'already_closed' => $already_closed,
    'message' => $message,
  ), 200);
}

function luna_widget_rest_chat_reset_session( WP_REST_Request $req ) {
  $reason = $req->get_param('reason');
  if (!is_string($reason) || trim($reason) === '') {
    $reason = 'reset';
  } else {
    $reason = sanitize_text_field($reason);
  }

  $current = luna_widget_current_conversation_id();
  if ($current) {
    luna_widget_close_conversation($current, $reason);
  }

  $pid = luna_conv_id(true);
  if ($pid) {
    return new WP_REST_Response(array('reset' => true, 'conversation_id' => $pid), 200);
  }

  return new WP_REST_Response(array('reset' => false), 500);
}
// Allow unauthenticated requests for chat endpoint
add_filter('rest_authentication_errors', function($result) {
  // Check if this is a request to the Luna Widget chat endpoint
  $rest_route = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
  $rest_route_lower = strtolower($rest_route);
  
  // Check multiple possible patterns for chat endpoint
  if (strpos($rest_route_lower, '/wp-json/luna_widget/v1/chat') !== false || 
      strpos($rest_route_lower, 'luna_widget/v1/chat') !== false ||
      strpos($rest_route_lower, '/luna_widget/v1/chat') !== false ||
      (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'OPTIONS' && strpos($rest_route_lower, 'luna_widget') !== false)) {
    // Allow unauthenticated requests for chat endpoint
    // Return null to indicate no authentication error (request is allowed)
    return null;
  }
  
  // For all other endpoints, use the default authentication
  return $result;
}, 20);

// Also add filter for REST pre-dispatch to ensure chat endpoint is accessible
add_filter('rest_pre_dispatch', function($result, $server, $request) {
  $route = $request->get_route();
  if (strpos($route, '/luna_widget/v1/chat') !== false) {
    // Ensure chat endpoint is always accessible
    return null; // null means continue with normal processing
  }
  return $result;
}, 10, 3);

add_action('rest_api_init', function () {

  /* --- CHAT --- */
  register_rest_route('luna_widget/v1', '/chat', array(
    'methods'  => array('POST', 'OPTIONS'),
    'permission_callback' => '__return_true',
    'callback' => 'luna_widget_chat_handler',
  ));

  /* --- TEST CHAT --- */
  register_rest_route('luna_widget/v1', '/test-chat', array(
    'methods'  => 'POST',
    'permission_callback' => '__return_true',
    'callback' => function( WP_REST_Request $req ){
      return new WP_REST_Response(array('answer'=>'Test successful!'), 200);
    },
  ));

  register_rest_route('luna_widget/v1', '/chat/inactive', array(
    'methods'  => 'POST',
    'permission_callback' => '__return_true',
    'callback' => 'luna_widget_rest_chat_inactive',
  ));

  register_rest_route('luna_widget/v1', '/chat/session/end', array(
    'methods'  => 'POST',
    'permission_callback' => '__return_true',
    'callback' => 'luna_widget_rest_chat_end_session',
  ));

  register_rest_route('luna_widget/v1', '/chat/session/reset', array(
    'methods'  => 'POST',
    'permission_callback' => '__return_true',
    'callback' => 'luna_widget_rest_chat_reset_session',
  ));

  /* --- COMPOSER DOCUMENT FETCH (for 30 days) --- */
  register_rest_route('luna_widget/v1', '/composer/fetch', array(
    'methods'  => 'GET',
    'permission_callback' => '__return_true',
    'callback' => function( WP_REST_Request $req ){
      $license = trim((string) $req->get_param('license'));
      $document_id = trim((string) $req->get_param('document_id'));
      
      if (!$license) {
        return new WP_REST_Response(array('error' => 'Missing license parameter'), 400);
      }
      
      // Fetch documents from last 30 days
      $thirty_days_ago = time() - (30 * 24 * 60 * 60);
      
      $args = array(
        'post_type' => 'luna_compose',
        'post_status' => 'publish',
        'meta_query' => array(
          'relation' => 'AND',
          array(
            'key' => 'license',
            'value' => $license,
            'compare' => '='
          ),
          array(
            'key' => 'timestamp',
            'value' => $thirty_days_ago,
            'compare' => '>='
          )
        ),
        'posts_per_page' => 50,
        'orderby' => 'meta_value_num',
        'meta_key' => 'timestamp',
        'order' => 'DESC'
      );
      
      // If document_id is provided, fetch specific document
      if ($document_id) {
        $args['meta_query'][] = array(
          'key' => 'document_id',
          'value' => $document_id,
          'compare' => '='
        );
        $args['posts_per_page'] = 1;
      }
      
      $posts = get_posts($args);
      
      if (empty($posts)) {
        return new WP_REST_Response(array('documents' => array()), 200);
      }
      
      $documents = array();
      foreach ($posts as $post) {
        $doc_id = get_post_meta($post->ID, 'document_id', true);
        $prompt = get_post_meta($post->ID, 'prompt', true);
        $content = get_post_meta($post->ID, 'answer', true);
        $timestamp = (int) get_post_meta($post->ID, 'timestamp', true);
        $feedback = get_post_meta($post->ID, 'feedback', true); // Get current feedback state
        
        $documents[] = array(
          'id' => $doc_id,
          'prompt' => $prompt,
          'content' => $content,
          'timestamp' => $timestamp * 1000, // Convert to milliseconds for JavaScript
          'post_id' => $post->ID,
          'feedback' => $feedback ? $feedback : 'dislike' // Default to 'dislike' if no feedback set
        );
      }
      
      return new WP_REST_Response(array('documents' => $documents), 200);
    },
  ));
  
  /* --- COMPOSER DOCUMENT SHARE (CREATE SHARE LINK) --- */
  register_rest_route('luna_widget/v1', '/composer/share', array(
    'methods'  => 'POST',
    'permission_callback' => '__return_true',
    'callback' => function( WP_REST_Request $req ){
      $license = trim((string) $req->get_param('license'));
      $document_id = trim((string) $req->get_param('document_id'));
      $share_id = trim((string) $req->get_param('share_id'));
      $content = trim((string) $req->get_param('content'));
      $prompt = trim((string) $req->get_param('prompt'));
      
      if (!$license || !$document_id || !$share_id || !$content) {
        return new WP_REST_Response(array('error' => 'Missing required parameters'), 400);
      }
      
      // Find document by document_id
      $existing = get_posts(array(
        'post_type' => 'luna_compose',
        'post_status' => 'publish',
        'meta_query' => array(
          array(
            'key' => 'document_id',
            'value' => $document_id,
            'compare' => '='
          ),
          array(
            'key' => 'license',
            'value' => $license,
            'compare' => '='
          )
        ),
        'posts_per_page' => 1,
        'fields' => 'ids'
      ));
      
      if (empty($existing)) {
        return new WP_REST_Response(array('error' => 'Document not found'), 404);
      }
      
      $post_id = $existing[0];
      
      // Store share ID and make document shareable
      update_post_meta($post_id, 'share_id', $share_id);
      update_post_meta($post_id, 'share_content', $content); // Store content snapshot for sharing
      update_post_meta($post_id, 'share_prompt', $prompt);
      update_post_meta($post_id, 'share_timestamp', time());
      update_post_meta($post_id, 'share_enabled', true);
      
      // Track share creation in VL Hub
      $hub_url = 'https://visiblelight.ai/wp-json/vl-hub/v1/composer-share';
      $hub_response = wp_remote_post($hub_url, array(
        'method' => 'POST',
        'timeout' => 10,
        'headers' => array(
          'Content-Type' => 'application/json',
        ),
        'body' => wp_json_encode(array(
          'license' => $license,
          'document_id' => $document_id,
          'share_id' => $share_id,
          'timestamp' => time()
        )),
        'sslverify' => true
      ));
      
      if (is_wp_error($hub_response)) {
        error_log('[Luna Widget] VL Hub share sync error: ' . $hub_response->get_error_message());
      } else {
        $hub_code = wp_remote_retrieve_response_code($hub_response);
        if ($hub_code !== 200) {
          error_log('[Luna Widget] VL Hub share sync failed with HTTP ' . $hub_code);
        }
      }
      
      return new WP_REST_Response(array(
        'success' => true,
        'post_id' => $post_id,
        'share_id' => $share_id
      ), 200);
    },
  ));
  
  /* --- COMPOSER SHARED DOCUMENT FETCH (PUBLIC ACCESS) --- */
  register_rest_route('luna_widget/v1', '/composer/shared', array(
    'methods'  => 'GET',
    'permission_callback' => '__return_true',
    'callback' => function( WP_REST_Request $req ){
      $share_id = trim((string) $req->get_param('share_id'));
      
      if (!$share_id) {
        return new WP_REST_Response(array('error' => 'Missing share_id parameter'), 400);
      }
      
      // Find document by share_id
      $posts = get_posts(array(
        'post_type' => 'luna_compose',
        'post_status' => 'publish',
        'meta_query' => array(
          array(
            'key' => 'share_id',
            'value' => $share_id,
            'compare' => '='
          ),
          array(
            'key' => 'share_enabled',
            'value' => '1',
            'compare' => '='
          )
        ),
        'posts_per_page' => 1
      ));
      
      if (empty($posts)) {
        return new WP_REST_Response(array('error' => 'Shared document not found or access disabled'), 404);
      }
      
      $post = $posts[0];
      $license = get_post_meta($post->ID, 'license', true);
      $document_id = get_post_meta($post->ID, 'document_id', true);
      $content = get_post_meta($post->ID, 'share_content', true); // Use shared content snapshot
      $prompt = get_post_meta($post->ID, 'share_prompt', true);
      $timestamp = (int) get_post_meta($post->ID, 'share_timestamp', true);
      
      // Track view in WordPress
      $view_count = (int) get_post_meta($post->ID, 'share_view_count', true);
      $view_count++;
      update_post_meta($post->ID, 'share_view_count', $view_count);
      
      // Track view in VL Hub
      $hub_url = 'https://visiblelight.ai/wp-json/vl-hub/v1/composer-share-view';
      $hub_response = wp_remote_post($hub_url, array(
        'method' => 'POST',
        'timeout' => 10,
        'headers' => array(
          'Content-Type' => 'application/json',
        ),
        'body' => wp_json_encode(array(
          'license' => $license,
          'document_id' => $document_id,
          'share_id' => $share_id,
          'view_count' => $view_count,
          'timestamp' => time(),
          'ip' => $_SERVER['REMOTE_ADDR'] ?? '',
          'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
        )),
        'sslverify' => true
      ));
      
      if (is_wp_error($hub_response)) {
        error_log('[Luna Widget] VL Hub view tracking error: ' . $hub_response->get_error_message());
      } else {
        $hub_code = wp_remote_retrieve_response_code($hub_response);
        if ($hub_code !== 200) {
          error_log('[Luna Widget] VL Hub view tracking failed with HTTP ' . $hub_code);
        }
      }
      
      return new WP_REST_Response(array(
        'document' => array(
          'id' => $document_id,
          'share_id' => $share_id,
          'prompt' => $prompt,
          'content' => $content,
          'timestamp' => $timestamp * 1000, // Convert to milliseconds
          'view_count' => $view_count
        )
      ), 200);
    },
  ));
  
  /* --- COMPOSER DOCUMENT DELETE --- */
  register_rest_route('luna_widget/v1', '/composer/delete', array(
    'methods'  => 'POST',
    'permission_callback' => '__return_true',
    'callback' => function( WP_REST_Request $req ){
      $license = trim((string) $req->get_param('license'));
      $document_id = trim((string) $req->get_param('document_id'));
      
      if (!$license || !$document_id) {
        return new WP_REST_Response(array('error' => 'Missing required parameters'), 400);
      }
      
      // Find document by document_id
      $existing = get_posts(array(
        'post_type' => 'luna_compose',
        'post_status' => 'publish',
        'meta_query' => array(
          array(
            'key' => 'document_id',
            'value' => $document_id,
            'compare' => '='
          ),
          array(
            'key' => 'license',
            'value' => $license,
            'compare' => '='
          )
        ),
        'posts_per_page' => 1,
        'fields' => 'ids'
      ));
      
      if (!empty($existing)) {
        // Delete the post (trash it)
        $post_id = $existing[0];
        wp_delete_post($post_id, true); // true = force delete (bypass trash)
        
        return new WP_REST_Response(array('success' => true, 'post_id' => $post_id, 'deleted' => true), 200);
      } else {
        return new WP_REST_Response(array('error' => 'Document not found'), 404);
      }
    },
  ));
  
  /* --- COMPOSER FEEDBACK (LIKE/DISLIKE) --- */
  register_rest_route('luna_widget/v1', '/composer/feedback', array(
    'methods'  => 'POST',
    'permission_callback' => '__return_true',
    'callback' => function( WP_REST_Request $req ){
      $license = trim((string) $req->get_param('license'));
      $document_id = trim((string) $req->get_param('document_id'));
      $feedback_type = trim((string) $req->get_param('feedback_type')); // 'like' or 'dislike'
      $prompt = trim((string) $req->get_param('prompt'));
      $content = trim((string) $req->get_param('content'));
      
      if (!$license || !$document_id || !$feedback_type) {
        return new WP_REST_Response(array('error' => 'Missing required parameters'), 400);
      }
      
      if (!in_array($feedback_type, array('like', 'dislike'))) {
        return new WP_REST_Response(array('error' => 'Invalid feedback type'), 400);
      }
      
      // Find document by document_id
      $existing = get_posts(array(
        'post_type' => 'luna_compose',
        'post_status' => 'publish',
        'meta_query' => array(
          array(
            'key' => 'document_id',
            'value' => $document_id,
            'compare' => '='
          ),
          array(
            'key' => 'license',
            'value' => $license,
            'compare' => '='
          )
        ),
        'posts_per_page' => 1,
        'fields' => 'ids'
      ));
      
      $post_id = null;
      if (!empty($existing)) {
        $post_id = $existing[0];
      } else {
        // Create a new post if document doesn't exist
        $title = $prompt ? wp_trim_words($prompt, 12, '…') : __('Composer Entry', 'luna');
        $post_id = wp_insert_post(array(
          'post_type'   => 'luna_compose',
          'post_title'  => $title,
          'post_status' => 'publish',
        ));
        
        if (!$post_id || is_wp_error($post_id)) {
          return new WP_REST_Response(array('error' => 'Failed to create document'), 500);
        }
        
        update_post_meta($post_id, 'document_id', $document_id);
        update_post_meta($post_id, 'license', $license);
        update_post_meta($post_id, 'prompt', $prompt);
        update_post_meta($post_id, 'answer', $content);
        update_post_meta($post_id, 'timestamp', time());
      }
      
      // Store feedback counts
      $feedback_key = 'feedback_' . $feedback_type;
      $existing_feedback = get_post_meta($post_id, $feedback_key, true);
      $feedback_count = is_numeric($existing_feedback) ? (int) $existing_feedback : 0;
      $feedback_count++;
      update_post_meta($post_id, $feedback_key, $feedback_count);
      
      // Store feedback timestamp
      update_post_meta($post_id, $feedback_key . '_last', time());
      
      // Store current feedback state (most recent feedback type)
      // This is the critical piece that persists the state
      update_post_meta($post_id, 'feedback', $feedback_type);
      
      // Store feedback data for VL Hub sync
      $feedback_data = array(
        'document_id' => $document_id,
        'license' => $license,
        'feedback_type' => $feedback_type,
        'prompt' => $prompt,
        'content_preview' => $content,
        'timestamp' => time()
      );
      
      // Add to feedback log
      $feedback_log = get_post_meta($post_id, 'feedback_log', true);
      if (!is_array($feedback_log)) {
        $feedback_log = array();
      }
      $feedback_log[] = $feedback_data;
      // Keep only last 100 feedback entries
      if (count($feedback_log) > 100) {
        $feedback_log = array_slice($feedback_log, -100);
      }
      update_post_meta($post_id, 'feedback_log', $feedback_log);
      
      // Sync to VL Hub
      $hub_url = 'https://visiblelight.ai/wp-json/vl-hub/v1/composer-feedback';
      $hub_response = wp_remote_post($hub_url, array(
        'method' => 'POST',
        'timeout' => 10,
        'headers' => array(
          'Content-Type' => 'application/json',
        ),
        'body' => wp_json_encode($feedback_data),
        'sslverify' => true
      ));
      
      if (is_wp_error($hub_response)) {
        error_log('[Luna Widget] VL Hub sync error: ' . $hub_response->get_error_message());
      } else {
        $hub_code = wp_remote_retrieve_response_code($hub_response);
        if ($hub_code !== 200) {
          error_log('[Luna Widget] VL Hub sync failed with HTTP ' . $hub_code);
        }
      }
      
      return new WP_REST_Response(array(
        'success' => true,
        'post_id' => $post_id,
        'feedback_type' => $feedback_type,
        'feedback_count' => $feedback_count
      ), 200);
    },
  ));
  
  /* --- COMPOSER DOCUMENT SAVE --- */
  register_rest_route('luna_widget/v1', '/composer/create-post', array(
    'methods'  => 'POST',
    'permission_callback' => '__return_true',
    'callback' => function( WP_REST_Request $req ){
      // Add CORS headers
      $add_cors_headers = function($response) {
        $origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';
        $allowed_origins = array(
          'https://supercluster.visiblelight.ai',
          'https://visiblelight.ai',
          'http://supercluster.visiblelight.ai',
          'http://visiblelight.ai'
        );
        
        $is_allowed = false;
        if (!empty($origin)) {
          foreach ($allowed_origins as $allowed) {
            if ($origin === $allowed || strpos($origin, $allowed) !== false) {
              $is_allowed = true;
              break;
            }
          }
        }
        
        if ($is_allowed && !empty($origin)) {
          $response->header('Access-Control-Allow-Origin', $origin);
          $response->header('Access-Control-Allow-Credentials', 'true');
        } else {
          $response->header('Access-Control-Allow-Origin', '*');
        }
        $response->header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
        $response->header('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With, Accept, X-WP-Nonce, x-wp-nonce, X-Luna-Composer, x-luna-composer');
        return $response;
      };
      
      $license = trim((string) $req->get_param('license'));
      $document_id = trim((string) $req->get_param('document_id'));
      $title = trim((string) $req->get_param('title'));
      $content = (string) $req->get_param('content'); // Don't trim content as it may contain HTML formatting
      $status = trim((string) $req->get_param('status')) ?: 'draft';
      
      // Log received parameters for debugging
      error_log('[Luna Composer Create Post] Received params: license=' . ($license ? 'present' : 'missing') . ', document_id=' . ($document_id ? 'present' : 'missing') . ', content_length=' . strlen($content));
      
      // Validate required parameters
      if (!$license) {
        $response = new WP_REST_Response(array('error' => 'Missing required parameter: license'), 400);
        return $add_cors_headers($response);
      }
      
      if (!$document_id) {
        $response = new WP_REST_Response(array('error' => 'Missing required parameter: document_id'), 400);
        return $add_cors_headers($response);
      }
      
      // Content can be HTML, so check if it's not empty (even if just whitespace after stripping tags)
      $content_stripped = strip_tags($content);
      $content_trimmed = trim($content_stripped);
      
      if (empty($content_trimmed)) {
        // If content is empty, use a default
        $content = '<p>New post from Luna Composer</p>';
        error_log('[Luna Composer Create Post] Content was empty, using default');
      }
      
      // Validate status
      if (!in_array($status, array('draft', 'publish', 'pending', 'private'))) {
        $status = 'draft';
      }
      
      // Get client site information from license
      $client_site_url = null;
      $client_site_id = null;
      try {
        $hub_response = wp_remote_get('https://visiblelight.ai/wp-json/vl-hub/v1/client-sites?license=' . urlencode($license), array(
          'timeout' => 10,
          'headers' => array('Content-Type' => 'application/json')
        ));
        
        if (!is_wp_error($hub_response) && wp_remote_retrieve_response_code($hub_response) === 200) {
          $hub_data = json_decode(wp_remote_retrieve_body($hub_response), true);
          if (isset($hub_data['sites']) && is_array($hub_data['sites']) && !empty($hub_data['sites'])) {
            // Get the first site URL and ID
            $client_site_url = isset($hub_data['sites'][0]['url']) ? $hub_data['sites'][0]['url'] : null;
            $client_site_id = isset($hub_data['sites'][0]['id']) ? $hub_data['sites'][0]['id'] : null;
          }
        }
      } catch (Exception $e) {
        error_log('[Luna Composer Create Post] Error fetching client site: ' . $e->getMessage());
      }
      
      // If we have a client site URL, try to create the post on that site via REST API
      if ($client_site_url && $client_site_url !== get_site_url()) {
        // Try to create post on remote WordPress site
        // This requires the remote site to have REST API enabled and proper authentication
        // For now, we'll fall back to creating on current site if remote creation fails
        $remote_post_data = array(
          'title' => $title ?: 'New Post from Luna Composer',
          'content' => $content,
          'status' => $status
        );
        
        // Attempt to create post on remote site (would need authentication token)
        // For now, we'll create on the current site and note the client site in metadata
      }
      
      // Create WordPress post on current site (or remote if implemented)
      $post_title = $title ?: 'New Post from Luna Composer';
      $post_id = wp_insert_post(array(
        'post_title'   => $post_title,
        'post_content' => $content,
        'post_status'  => $status,
        'post_type'    => 'post',
        'post_author'  => 1, // Default to admin user, could be enhanced to use current user
      ));
      
      if (is_wp_error($post_id)) {
        $response = new WP_REST_Response(array('error' => 'Failed to create post: ' . $post_id->get_error_message()), 500);
        return $add_cors_headers($response);
      }
      
      // Store metadata linking to Luna Composer document and client site
      update_post_meta($post_id, 'luna_composer_document_id', $document_id);
      update_post_meta($post_id, 'luna_composer_license', $license);
      update_post_meta($post_id, 'luna_composer_created', time());
      if ($client_site_url) {
        update_post_meta($post_id, 'luna_composer_client_site_url', $client_site_url);
      }
      if ($client_site_id) {
        update_post_meta($post_id, 'luna_composer_client_site_id', $client_site_id);
      }
      
      // Generate edit URL
      $edit_url = admin_url('post.php?action=edit&post=' . $post_id);
      
      $response = new WP_REST_Response(array(
        'success' => true,
        'post_id' => $post_id,
        'edit_url' => $edit_url,
        'status' => $status,
        'client_site_url' => $client_site_url
      ), 200);
      return $add_cors_headers($response);
    },
  ));

  register_rest_route('luna_widget/v1', '/composer/save', array(
    'methods'  => 'POST',
    'permission_callback' => '__return_true',
    'callback' => function( WP_REST_Request $req ){
      $license = trim((string) $req->get_param('license'));
      $document_id = trim((string) $req->get_param('document_id'));
      $prompt = trim((string) $req->get_param('prompt'));
      $content = trim((string) $req->get_param('content'));
      
      if (!$license || !$document_id || !$content) {
        return new WP_REST_Response(array('error' => 'Missing required parameters'), 400);
      }
      
      // Check if document already exists (by document_id in meta)
      $existing = get_posts(array(
        'post_type' => 'luna_compose',
        'post_status' => 'publish',
        'meta_query' => array(
          array(
            'key' => 'document_id',
            'value' => $document_id,
            'compare' => '='
          )
        ),
        'posts_per_page' => 1,
        'fields' => 'ids'
      ));
      
      if (!empty($existing)) {
        // Update existing document
        $post_id = $existing[0];
        wp_update_post(array(
          'ID' => $post_id,
          'post_title' => $prompt ? wp_trim_words($prompt, 12, '…') : __('Composer Entry', 'luna'),
        ));
        update_post_meta($post_id, 'prompt', $prompt);
        update_post_meta($post_id, 'answer', $content);
        update_post_meta($post_id, 'document_id', $document_id);
        update_post_meta($post_id, 'license', $license);
        update_post_meta($post_id, 'timestamp', time());
        
        return new WP_REST_Response(array('success' => true, 'post_id' => $post_id, 'updated' => true), 200);
      } else {
        // Create new document
        $title = $prompt ? wp_trim_words($prompt, 12, '…') : __('Composer Entry', 'luna');
        $post_id = wp_insert_post(array(
          'post_type'   => 'luna_compose',
          'post_title'  => $title,
          'post_status' => 'publish',
        ));
        
        if (!$post_id || is_wp_error($post_id)) {
          return new WP_REST_Response(array('error' => 'Failed to save document'), 500);
        }
        
        update_post_meta($post_id, 'prompt', $prompt);
        update_post_meta($post_id, 'answer', $content);
        update_post_meta($post_id, 'document_id', $document_id);
        update_post_meta($post_id, 'license', $license);
        update_post_meta($post_id, 'timestamp', time());
        
        return new WP_REST_Response(array('success' => true, 'post_id' => $post_id, 'updated' => false), 200);
      }
    },
  ));

  /* --- HISTORY (hydrate UI after reloads) --- */
  /* --- WIDGET HTML FOR EMBEDDING --- */
  register_rest_route('luna_widget/v1', '/widget/html', array(
    'methods'  => 'GET',
    'permission_callback' => '__return_true',
    'callback' => function( WP_REST_Request $req ){
      // Add CORS headers for Supercluster embedding
      header('Access-Control-Allow-Origin: *');
      header('Access-Control-Allow-Methods: GET, OPTIONS');
      header('Access-Control-Allow-Headers: Content-Type, X-Requested-With');
      
      // Handle preflight OPTIONS request
      if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        status_header(200);
        exit;
      }
      
      // Check for vl_key parameter (for Supercluster embedding with shortcode)
      $vl_key = $req->get_param('vl_key');
      $vl_key = $vl_key ? sanitize_text_field($vl_key) : '';
      
      // Check if plugin is active and has license
      $license = trim((string) get_option(LUNA_WIDGET_OPT_LICENSE, ''));
      
      // If vl_key is provided, validate it matches the stored license
      if ($vl_key !== '') {
        if ($license === '' || $license !== $vl_key) {
          return new WP_REST_Response(array('ok' => false, 'error' => 'License key validation failed'), 403);
        }
        // License matches - proceed even if widget mode is not active
      } else {
        // No vl_key provided - check license and widget mode as before
        if ($license === '') {
          return new WP_REST_Response(array('ok' => false, 'error' => 'No license configured'), 403);
        }
        
        $mode = get_option(LUNA_WIDGET_OPT_MODE, 'widget');
        if ($mode !== 'widget') {
          return new WP_REST_Response(array('ok' => false, 'error' => 'Widget mode not enabled'), 403);
        }
      }
      
      // Get widget settings
      $ui = get_option(LUNA_WIDGET_OPT_SETTINGS, array());
      $pos = isset($ui['position']) ? $ui['position'] : 'bottom-right';
      
      // Generate widget HTML (same as wp_footer)
      $pos_css = 'bottom:20px;right:20px;';
      if ($pos === 'top-left') { $pos_css = 'top:20px;left:20px;'; }
      elseif ($pos === 'top-center') { $pos_css = 'top:20px;left:50%;transform:translateX(-50%);'; }
      elseif ($pos === 'top-right') { $pos_css = 'top:20px;right:20px;'; }
      elseif ($pos === 'bottom-left') { $pos_css = 'bottom:20px;left:20px;'; }
      elseif ($pos === 'bottom-center') { $pos_css = 'bottom:20px;left:50%;transform:translateX(-50%);'; }
      
      $title = esc_html(isset($ui['title']) ? $ui['title'] : 'Luna Chat');
      $avatar = esc_url(isset($ui['avatar_url']) ? $ui['avatar_url'] : '');
      $hdr = esc_html(isset($ui['header_text']) ? $ui['header_text'] : "Hi, I'm Luna");
      $sub = esc_html(isset($ui['sub_text']) ? $ui['sub_text'] : 'How can I help today?');
      
      // For Supercluster embedding, always position panel on the left
      $panel_anchor = (strpos($pos,'bottom') !== false ? 'bottom:80px;' : 'top:80px;')
                    . 'left:2rem;right:auto;';
      
      // Generate CSS
      $css = "
        .luna-fab { position:relative !important; z-index:2147483646 !important; {$pos_css} }
        .luna-launcher{display:flex;align-items:center;gap:10px;background:#111;color:#fff4e9;border:1px solid #5A5753;border-radius:999px;padding:5px 17px 5px 8px;cursor:pointer;box-shadow:0 8px 24px rgba(0,0,0,.25);width:100%;max-width:215px;}
        .luna-launcher .ava{width:42px;height:42px;border-radius:50%;background:#222;overflow:hidden;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;}
        .luna-launcher .txt{line-height:1.2;display:flex;flex-direction:column;flex:1;min-width:0;overflow:hidden;position:relative}
        .luna-launcher .txt span{max-width:222px !important;display:inline-block;white-space:nowrap;overflow:hidden}
        .luna-launcher .txt span.luna-scroll-wrapper{overflow:hidden;position:relative;max-width:130px !important;display:inline-block}
        .luna-launcher .txt span.luna-scroll-inner{display:inline-block;white-space:nowrap;animation:lunaInfiniteScroll 10s infinite linear;will-change:transform;vertical-align: -webkit-baseline-middle;}
        .luna-launcher .txt span.luna-scroll-inner span{display:inline-block;white-space:nowrap;margin:0;padding:0;max-width:none !important}
        @keyframes lunaInfiniteScroll{from{transform:translateX(0%)}to{transform:translateX(-50%)}}
      .luna-overlay{position:fixed !important;top:0 !important;left:0 !important;right:0 !important;bottom:0 !important;background:rgba(0,0,0,0.6) !important;backdrop-filter:blur(8px) !important;-webkit-backdrop-filter:blur(8px) !important;z-index:2147483645 !important;display:none !important;visibility:hidden !important;opacity:0 !important;pointer-events:auto !important;}
      .luna-overlay.show{display:block !important;visibility:visible !important;opacity:1 !important;}
      .luna-panel{position: fixed !important;z-index: 2147483647 !important; {$panel_anchor} width: clamp(320px,92vw,420px);max-height: min(70vh,560px);display: none;flex-direction: column;border-radius: 12px;border: 1px solid #232120;background: #000;color: #fff4e9;overflow: hidden;}
      .luna-panel.show{display:flex !important;z-index: 2147483647 !important;}
        .luna-head{padding:10px 12px;font-weight:600;background:#000;border-bottom:1px solid #333;display:flex;align-items:center;justify-content:space-between}
        .luna-thread{padding:10px 12px;overflow:auto;flex:1 1 auto}
        .luna-form{display:flex;gap:8px;padding:10px 12px;border-top:1px solid #333}
        .luna-input{flex:1 1 auto;background:#111;color:#fff4e9;border:1px solid #333;border-radius:10px;padding:8px 10px}
        .luna-send{background:linear-gradient(270deg, #974C00 0%, #8D8C00 100%) !important;color:#000;border:none;border-radius:10px;padding:8px 12px;cursor:pointer;font-size: .88rem;font-weight: 600}
        .luna-thread .luna-msg{clear:both;margin:6px 0}
        .luna-thread .luna-user{float:right;background:#fff4e9;color:#000;display:inline-block;padding:8px 10px;border-radius:10px;max-width:85%;word-wrap:break-word}
        .luna-thread .luna-assistant{float:left;background:#000000;border:1px solid #1f1d1a;color:#fff4e9;display:inline-block;padding:10px;border-radius:10px;max-width:85%;word-wrap:break-word;line-height:1.25rem;}
        .luna-initial-greeting{display:flex;flex-direction:column;gap:12px}
        .luna-greeting-text{margin-bottom:10px;line-height: 1.25rem;}
        .luna-greeting-buttons{display:flex;flex-direction:column;gap:8px;width:100%}
        .luna-greeting-btn{width:100%;padding:10px 14px;background:#2E2C2A;border:none;border-radius:8px;color:#fff4e9;font-size:0.9rem;font-weight:600;cursor:pointer;transition:all 0.2s ease;text-align:left;display:flex;align-items:center;justify-content:space-between}
        .luna-greeting-btn:hover{background:#3A3836;transform:translateY(-1px)}
        .luna-greeting-btn:active{transform:translateY(0)}
        .luna-greeting-btn-chat{background:linear-gradient(270deg, #974C00 0%, #8D8C00 100%);color:#000;border-color:#5A5753}
        .luna-greeting-btn-chat:hover{background:linear-gradient(270deg, #B85C00 0%, #A5A000 100%)}
        .luna-greeting-btn-report{background:#2E2C2A}
        .luna-greeting-btn-compose{background:#2E2C2A}
        .luna-greeting-btn-automate{background:#2E2C2A}
        .luna-greeting-help{width:20px;height:20px;border-radius:50%;background-color:rgba(255,255,255,.15);display:flex;align-items:center;justify-content:center;font-size:0.85rem;font-weight:600;cursor:help;margin-left:8px;flex-shrink:0;transition:background-color 0.2s ease}
        .luna-greeting-help:hover{background-color:rgba(255,255,255,.25)}
        .luna-greeting-tooltip{position:absolute;background:#000;color:#fff4e9;padding:12px 16px;border-radius:8px;font-size:0.85rem;line-height:1.4;max-width:280px;z-index:999999;box-shadow:0 4px 12px rgba(0,0,0,0.4);pointer-events:none;border:1px solid #5A5753;word-wrap:break-word}
        .luna-thread .luna-session-closure{opacity:.85;font-style:italic}
        .luna-thread .luna-loading{float:left;background:#111;border:1px solid #333;color:#fff4e9;display:inline-block;padding:8px 10px;border-radius:10px;max-width:85%;word-wrap:break-word}
        .luna-loading-text{background:radial-gradient(circle at 0%,#fff4e9,#c2b8ad 50%,#978e86 75%,#fff4e9 75%);font-weight:600;background-size:200% auto;color:#000;background-clip:text;-webkit-text-fill-color:transparent;animation:animatedTextGradient 1.5s linear infinite;height:20px !important;}
        @keyframes animatedTextGradient{from{background-position:0% center}to{background-position:200% center}}
        .luna-session-ended{position:fixed;z-index:999999 !important;left:2rem !important;right:auto !important;width:clamp(320px,92vw,420px);display:none;align-items:center;justify-content:center}
        .luna-session-ended.show{display:flex}
        .luna-session-ended-card{background:#000;border:1px solid #5A5753;border-radius:12px;padding:24px 20px;display:flex;flex-direction:column;gap:12px;align-items:center;text-align:center;box-shadow:0 24px 48px rgba(0,0,0,.4);width:100%}
        .luna-session-ended-card h2{margin:0;font-size:1.25rem}
        .luna-session-ended-card p{margin:0;color:#ccc}
        .luna-session-ended-card .luna-session-restart{background:#2c74ff;color:#fff;border:0;border-radius:8px;padding:10px 18px;font-weight:600;cursor:pointer}
        .luna-session-ended-card .luna-session-restart:hover{background:#4c8bff}
      ";
      
      // Generate HTML
      $html = '
        <div class="luna-fab" aria-live="polite">
          <button class="luna-launcher" aria-expanded="false" aria-controls="luna-panel" title="' . $title . '">
            <span class="ava">
              ' . ($avatar ? '<img src="' . $avatar . '" alt="" style="width:42px;height:42px;object-fit:cover">' : '
                <svg width="24" height="24" viewBox="0 0 36 36" fill="none" aria-hidden="true"><circle cx="18" cy="18" r="18" fill="#222"/><path d="M18 18a6 6 0 100-12 6 6 0 000 12zm0 2c-6 0-10 3.2-10 6v2h20v-2c0-2.8-4-6-10-6z" fill="#666"/></svg>
              ') . '
            </span>
            <span class="txt"><strong>' . $hdr . '</strong><span>' . $sub . '</span></span>
          </button>
          <div id="luna-panel" class="luna-panel" role="dialog" aria-label="' . $title . '">
            <div class="luna-head"><span>' . $title . '</span><button class="luna-close" style="background:transparent;border:0;color:#fff;cursor:pointer" aria-label="Close">✕</button></div>
            <div class="luna-thread"></div>
            <form class="luna-form"><input class="luna-input" placeholder="Ask Luna…" autocomplete="off"><button type="button" class="luna-send">Send</button></form>
          </div>
        </div>
        <div id="luna-session-ended" class="luna-session-ended" style="' . $panel_anchor . ' display:none;" role="dialog" aria-modal="true" aria-labelledby="luna-session-ended-title">
          <div class="luna-session-ended-card">
            <h2 id="luna-session-ended-title">Your session has ended</h2>
            <p>Start another one now.</p>
            <button type="button" class="luna-session-restart">Start New Session</button>
          </div>
        </div>
      ';
      
      // Generate JavaScript - full widget functionality
      $chat_endpoint = rest_url('luna_widget/v1/chat');
      $history_endpoint = rest_url('luna_widget/v1/chat/history');
      $inactive_endpoint = rest_url('luna_widget/v1/chat/inactive');
      $session_end_endpoint = rest_url('luna_widget/v1/chat/session/end');
      $session_reset_endpoint = rest_url('luna_widget/v1/chat/session/reset');
      $nonce = wp_create_nonce('wp_rest');
      $stored_license_key = esc_js( get_option(LUNA_WIDGET_OPT_LICENSE, '') );
      
      // Get button descriptions
      $button_desc_chat = esc_js( isset($ui['button_desc_chat']) ? $ui['button_desc_chat'] : 'Start a conversation with Luna to ask questions and get answers about your digital universe.' );
      $button_desc_report = esc_js( isset($ui['button_desc_report']) ? $ui['button_desc_report'] : 'Generate comprehensive reports about your site health, performance, and security.' );
      $button_desc_compose = esc_js( isset($ui['button_desc_compose']) ? $ui['button_desc_compose'] : 'Access Luna Composer to use canned prompts and responses for quick interactions.' );
      $button_desc_automate = esc_js( isset($ui['button_desc_automate']) ? $ui['button_desc_automate'] : 'Set up automated workflows and tasks with Luna to streamline your operations.' );
      
      $widget_js = "
        (function(){
          var fab=document.querySelector('.luna-launcher');
          var panel=document.querySelector('#luna-panel');
          
          // Setup scrolling text animation for launcher subtitle
          function setupLauncherTextScroll() {
            var txtSpan = fab ? fab.querySelector('.txt span:not(strong)') : null;
            if (txtSpan) {
              // Measure text width
              var tempSpan = document.createElement('span');
              tempSpan.style.visibility = 'hidden';
              tempSpan.style.position = 'absolute';
              tempSpan.style.whiteSpace = 'nowrap';
              tempSpan.textContent = txtSpan.textContent;
              document.body.appendChild(tempSpan);
              var textWidth = tempSpan.offsetWidth;
              document.body.removeChild(tempSpan);
              
              // If text is wider than 135px, add infinite scrolling animation
              if (textWidth > 135) {
                // Store original text
                var originalText = txtSpan.textContent;
                
                // Create wrapper and inner structure for infinite scroll
                var wrapper = document.createElement('span');
                wrapper.className = 'luna-scroll-wrapper';
                
                var inner = document.createElement('span');
                inner.className = 'luna-scroll-inner';
                
                // Duplicate text 4 times for seamless infinite loop
                for (var i = 0; i < 4; i++) {
                  var textSpan = document.createElement('span');
                  textSpan.textContent = originalText + ' ';
                  inner.appendChild(textSpan);
                }
                
                wrapper.appendChild(inner);
                
                // Replace original span with new structure
                txtSpan.parentNode.replaceChild(wrapper, txtSpan);
                
                // Calculate animation duration based on text width
                // Scroll speed ~35px per second (30% slower than 50px/s)
                // We need to scroll by one full text width to reveal the entire text
                var scrollDistance = textWidth; // Scroll distance is the full text width
                var scrollTime = scrollDistance / 35; // Time to scroll one full text width
                var pauseTime = 2; // 2 second pause
                var totalDuration = scrollTime + pauseTime;
                var pausePercent = (pauseTime / totalDuration) * 100; // Percentage for pause
                var scrollStartPercent = pausePercent; // Start scrolling after pause
                
                // Calculate the pixel value to scroll (one full text width)
                var scrollPixels = -textWidth;
                
                // Create unique animation name
                var animName = 'lunaInfiniteScroll_' + Date.now();
                
                // Create dynamic keyframes: pause at start, then scroll by one full text width
                // Since we have 4 copies, scrolling by one width creates seamless loop
                var style = document.createElement('style');
                style.id = 'luna-scroll-animation-' + Date.now();
                style.textContent = '@keyframes ' + animName + '{0%{transform:translateX(0)}' + scrollStartPercent + '%{transform:translateX(0)}100%{transform:translateX(' + scrollPixels + 'px)}}';
                document.head.appendChild(style);
                
                // Apply animation with calculated duration
                inner.style.animation = animName + ' ' + totalDuration + 's infinite linear';
              }
            }
          }
          
          // Initialize text scroll after DOM is ready
          if (fab) {
            setTimeout(setupLauncherTextScroll, 100);
          }
          
          // Function to blur Supercluster elements
          function blurSuperclusterElements(blur) {
            // Blur canvas
            var canvas = document.querySelector('canvas');
            if (canvas) {
              if (blur) {
                canvas.style.setProperty('filter', 'blur(8px)', 'important');
                canvas.style.setProperty('pointer-events', 'none', 'important');
              } else {
                canvas.style.removeProperty('filter');
                canvas.style.setProperty('pointer-events', 'inherit', 'important');
              }
            }
            
            // Blur #vlSuperclusterRoot::after (using a style element)
            var root = document.querySelector('#vlSuperclusterRoot');
            if (root) {
              var styleId = 'luna-blur-root-after';
              var existingStyle = document.getElementById(styleId);
              if (blur) {
                if (!existingStyle) {
                  var style = document.createElement('style');
                  style.id = styleId;
                  style.textContent = '#vlSuperclusterRoot::after { filter: blur(8px) !important; pointer-events: none !important; }';
                  document.head.appendChild(style);
                }
              } else {
                if (existingStyle) {
                  existingStyle.remove();
                }
              }
            }
            
            // Blur .vl-supercluster-labels
            var labels = document.querySelectorAll('.vl-supercluster-labels');
            if (labels && labels.length > 0) {
              labels.forEach(function(label) {
                if (blur) {
                  label.style.setProperty('filter', 'blur(8px)', 'important');
                  label.style.setProperty('pointer-events', 'none', 'important');
                } else {
                  label.style.removeProperty('filter');
                  label.style.setProperty('pointer-events', 'inherit', 'important');
                }
              });
            }
            
            // Blur .vl-header
            var header = document.querySelector('.vl-header');
            if (header) {
              if (blur) {
                header.style.setProperty('filter', 'blur(8px)', 'important');
                header.style.setProperty('pointer-events', 'none', 'important');
              } else {
                header.style.removeProperty('filter');
                header.style.setProperty('pointer-events', 'inherit', 'important');
              }
            }
            
            // Blur .vl-main-menu
            var mainMenu = document.querySelector('.vl-main-menu');
            if (mainMenu) {
              if (blur) {
                mainMenu.style.setProperty('filter', 'blur(8px)', 'important');
                mainMenu.style.setProperty('pointer-events', 'none', 'important');
              } else {
                mainMenu.style.removeProperty('filter');
                mainMenu.style.setProperty('pointer-events', 'inherit', 'important');
              }
            }
            
            // Blur .vl-right-sidebar
            var rightSidebar = document.querySelector('.vl-right-sidebar');
            if (rightSidebar) {
              if (blur) {
                rightSidebar.style.setProperty('filter', 'blur(8px)', 'important');
                rightSidebar.style.setProperty('pointer-events', 'none', 'important');
              } else {
                rightSidebar.style.removeProperty('filter');
                rightSidebar.style.setProperty('pointer-events', 'inherit', 'important');
              }
            }
          }
          
          // Ensure panel parent doesn't create stacking context
          if (panel && panel.parentNode && panel.parentNode !== document.body) {
            var panelParent = panel.parentNode;
            // Check computed styles to see if parent creates stacking context
            var computedStyle = window.getComputedStyle(panelParent);
            if (computedStyle.position !== 'static' || computedStyle.zIndex !== 'auto') {
              // Force parent to not create stacking context
              panelParent.style.setProperty('position', 'static', 'important');
              panelParent.style.setProperty('z-index', 'auto', 'important');
              panelParent.style.setProperty('isolation', 'auto', 'important');
            }
          }
          var closeBtn=document.querySelector('.luna-close');
          var ended=document.querySelector('#luna-session-ended');
          var thread=panel ? panel.querySelector('.luna-thread') : null;
          var form=panel ? panel.querySelector('.luna-form') : null;
          var input=form ? form.querySelector('.luna-input') : null;
          var sendBtn=form ? form.querySelector('.luna-send') : null;

          async function hydrate(thread){
            if (!thread || thread.__hydrated) return;
            try{
              const res = await fetch('{$history_endpoint}');
              if (!res.ok) {
                console.warn('[Luna] Failed to fetch chat history:', res.status, res.statusText);
                thread.__hydrated = true;
                return;
              }
              const contentType = res.headers.get('content-type');
              if (!contentType || !contentType.includes('application/json')) {
                console.warn('[Luna] Response is not JSON, content-type:', contentType);
                thread.__hydrated = true;
                return;
              }
              const data = await res.json().catch(function(err){
                console.error('[Luna] JSON parse error in hydrate:', err);
                return {items: []};
              });
              var hasMessages = false;
              if (data && Array.isArray(data.items)) {
                data.items.forEach(function(turn){
                  if (turn.user) { var u=document.createElement('div'); u.className='luna-msg luna-user'; u.textContent=turn.user; thread.appendChild(u); hasMessages = true; }
                  if (turn.assistant) { var a=document.createElement('div'); a.className='luna-msg luna-assistant'; a.textContent=turn.assistant; thread.appendChild(a); hasMessages = true; }
                });
                thread.scrollTop = thread.scrollHeight;
              }
              thread.__hydrated = true;
              
              // Auto-send initial greeting if thread is empty
              if (!hasMessages) {
                setTimeout(function(){
                  sendInitialGreeting(thread);
                }, 300);
              }
            }catch(e){ 
              console.warn('[Luna] hydrate failed', e);
              // If hydration fails, still try to send greeting if thread is empty
              if (!thread.__hydrated && thread.children.length === 0) {
                setTimeout(function(){
                  sendInitialGreeting(thread);
                }, 300);
              }
            }
            finally { thread.__hydrated = true; }
          }
          
          function sendInitialGreeting(thread){
            if (!thread) return;
            // Check if thread already has messages
            if (thread.querySelectorAll('.luna-msg').length > 0) return;
            
            // Get license key from URL or stored option
            var licenseKey = '';
            var urlParams = new URLSearchParams(window.location.search);
            var urlLicense = urlParams.get('license');
            if (urlLicense) {
              // Extract license key from URL (may include path segments)
              licenseKey = urlLicense.split('/')[0];
            } else {
              // Try to get from stored option (for frontend sites)
              try {
                var storedLicense = '{$stored_license_key}';
                if (storedLicense && storedLicense !== '') {
                  licenseKey = storedLicense;
                }
              } catch(e) {
                console.warn('[Luna] Could not get stored license key');
              }
            }
            
            // Create greeting message with buttons
            var greetingEl = document.createElement('div');
            greetingEl.className = 'luna-msg luna-assistant luna-initial-greeting';
            
            var greetingText = document.createElement('div');
            greetingText.className = 'luna-greeting-text';
            greetingText.textContent = 'Hi, there! I\'m Luna, your personal WebOps agent and AI companion. How would you like to continue?';
            greetingEl.appendChild(greetingText);
            
            // Create buttons container
            var buttonsContainer = document.createElement('div');
            buttonsContainer.className = 'luna-greeting-buttons';
            
            // Get button descriptions from settings
            var buttonDescs = {
              chat: '{$button_desc_chat}',
              report: '{$button_desc_report}',
              compose: '{$button_desc_compose}',
              automate: '{$button_desc_automate}'
            };
            
            // Helper function to create button with question mark icon
            function createGreetingButton(text, className, description, clickHandler) {
              var btn = document.createElement('button');
              btn.className = 'luna-greeting-btn ' + className;
              btn.style.position = 'relative';
              btn.style.display = 'flex';
              btn.style.alignItems = 'center';
              btn.style.justifyContent = 'space-between';
              btn.style.padding = '10px 14px';
              
              var btnText = document.createElement('span');
              btnText.textContent = text;
              btnText.style.flex = '1';
              btn.appendChild(btnText);
              
              var questionMark = document.createElement('span');
              questionMark.className = 'luna-greeting-help';
              questionMark.textContent = '?';
              questionMark.style.cssText = 'width:20px;height:20px;border-radius:50%;background-color:rgba(255,255,255,.15);display:flex;align-items:center;justify-content:center;font-size:0.85rem;font-weight:600;cursor:help;margin-left:8px;flex-shrink:0;transition:background-color 0.2s ease;';
              questionMark.setAttribute('data-description', description);
              questionMark.setAttribute('aria-label', 'Help');
              questionMark.addEventListener('mouseenter', function(e){
                e.stopPropagation();
                showButtonTooltip(questionMark, description);
              });
              questionMark.addEventListener('mouseleave', function(e){
                e.stopPropagation();
                hideButtonTooltip();
              });
              btn.appendChild(questionMark);
              
              btn.addEventListener('click', clickHandler);
              return btn;
            }
            
            // Luna Chat button
            var chatBtn = createGreetingButton('Luna Chat', 'luna-greeting-btn-chat', buttonDescs.chat, function(e){
              e.preventDefault();
              e.stopPropagation();
              // Remove greeting buttons
              greetingEl.querySelector('.luna-greeting-buttons').remove();
              // Auto-reply with chat message
              var chatMsg = document.createElement('div');
              chatMsg.className = 'luna-msg luna-assistant';
              chatMsg.textContent = 'Let\'s do this! Ask me anything to begin exploring...';
              thread.appendChild(chatMsg);
              thread.scrollTop = thread.scrollHeight;
            });
            buttonsContainer.appendChild(chatBtn);
            
            // Luna Report button
            var reportBtn = createGreetingButton('Luna Report', 'luna-greeting-btn-report', buttonDescs.report, function(e){
              e.preventDefault();
              e.stopPropagation();
              if (licenseKey) {
                window.location.href = 'https://supercluster.visiblelight.ai/?license=' + encodeURIComponent(licenseKey) + '/luna/report/';
              } else {
                console.warn('[Luna] License key not available for redirect');
              }
            });
            buttonsContainer.appendChild(reportBtn);
            
            // Luna Composer button
            var composeBtn = createGreetingButton('Luna Compose', 'luna-greeting-btn-compose', buttonDescs.compose, function(e){
              e.preventDefault();
              e.stopPropagation();
              if (licenseKey) {
                window.location.href = 'https://supercluster.visiblelight.ai/?license=' + encodeURIComponent(licenseKey) + '/luna/compose/';
              } else {
                console.warn('[Luna] License key not available for redirect');
              }
            });
            buttonsContainer.appendChild(composeBtn);
            
            // Luna Automate button
            var automateBtn = createGreetingButton('Luna Automate', 'luna-greeting-btn-automate', buttonDescs.automate, function(e){
              e.preventDefault();
              e.stopPropagation();
              if (licenseKey) {
                window.location.href = 'https://supercluster.visiblelight.ai/?license=' + encodeURIComponent(licenseKey) + '/luna/automate/';
              } else {
                console.warn('[Luna] License key not available for redirect');
              }
            });
            buttonsContainer.appendChild(automateBtn);
            
            // Tooltip functions
            var tooltip = null;
            function showButtonTooltip(element, description) {
              if (tooltip) {
                tooltip.remove();
              }
              tooltip = document.createElement('div');
              tooltip.className = 'luna-greeting-tooltip';
              tooltip.textContent = description;
              tooltip.style.cssText = 'position:absolute;background:#000;color:#fff4e9;padding:12px 16px;border-radius:8px;font-size:0.85rem;line-height:1.4;max-width:280px;z-index:999999;box-shadow:0 4px 12px rgba(0,0,0,0.4);pointer-events:none;border:1px solid #5A5753;';
              document.body.appendChild(tooltip);
              
              var rect = element.getBoundingClientRect();
              var tooltipRect = tooltip.getBoundingClientRect();
              var left = rect.left + (rect.width / 2) - (tooltipRect.width / 2);
              var top = rect.top - tooltipRect.height - 8;
              
              if (left < 10) left = 10;
              if (left + tooltipRect.width > window.innerWidth - 10) {
                left = window.innerWidth - tooltipRect.width - 10;
              }
              if (top < 10) {
                top = rect.bottom + 8;
              }
              
              tooltip.style.left = left + 'px';
              tooltip.style.top = top + 'px';
            }
            
            function hideButtonTooltip() {
              if (tooltip) {
                tooltip.remove();
                tooltip = null;
              }
            }
            
            greetingEl.appendChild(buttonsContainer);
            thread.appendChild(greetingEl);
            thread.scrollTop = thread.scrollHeight;
            
            // Log the greeting to the conversation
            try {
              fetch('{$chat_endpoint}', {
                method: 'POST',
                headers: {'Content-Type':'application/json'},
                body: JSON.stringify({ prompt: '', greeting: true })
              }).catch(function(err){
                console.warn('[Luna] greeting log failed', err);
              });
            } catch(err){
              console.warn('[Luna] greeting fetch error', err);
            }
          }
          function showEnded(){
            if (ended) ended.classList.add('show');
            if (panel) panel.classList.remove('show');
            blurSuperclusterElements(false);
            if (fab) fab.setAttribute('aria-expanded','false');
          }
          function hideEnded(){
            if (ended) ended.classList.remove('show');
          }
          window.__lunaShowSessionEnded = showEnded;
          window.__lunaHideSessionEnded = hideEnded;
          function toggle(open){
            if(!panel||!fab) return;
            var will=(typeof open==='boolean')?open:!panel.classList.contains('show');
            // Only show ended state if explicitly closing and session is actually closing
            if (will && window.LunaChatSession && window.LunaChatSession.closing === true) {
              showEnded();
              return;
            }
            if (will && ended) ended.classList.remove('show');
            
            // Use requestAnimationFrame to ensure smooth display
            requestAnimationFrame(function(){
              // Set z-index BEFORE toggling classes
              if (will) {
                // Ensure fab has highest z-index
                var fabContainer = fab ? (fab.closest('.luna-fab') || fab.parentElement) : null;
                if (fabContainer) {
                  fabContainer.style.setProperty('z-index', '2147483647', 'important');
                  fabContainer.style.setProperty('position', 'fixed', 'important');
                }
                if (fab) {
                  fab.style.setProperty('z-index', '2147483647', 'important');
                }
              }
              
              panel.classList.toggle('show',will);
              
              // Blur/unblur Supercluster elements
              blurSuperclusterElements(will);
              fab.setAttribute('aria-expanded',will?'true':'false');
              
              // Hide/show galaxy labels
              var labels = document.querySelectorAll('.vl-supercluster-labels');
              if (labels && labels.length > 0) {
                labels.forEach(function(label){
                  if (will) {
                    label.style.display = 'none';
                    label.style.visibility = 'hidden';
                    label.style.opacity = '0';
                  } else {
                    label.style.display = '';
                    label.style.visibility = '';
                    label.style.opacity = '';
                  }
                });
              }
              
              if (will) {
                // Force panel to stay visible with highest z-index using !important
                panel.style.setProperty('z-index', '2147483647', 'important');
                panel.style.setProperty('position', 'fixed', 'important');
                panel.style.setProperty('display', 'flex', 'important');
                panel.style.setProperty('visibility', 'visible', 'important');
                panel.style.setProperty('opacity', '1', 'important');
                
                // Ensure fab has highest z-index and is positioned correctly with !important
                var fabContainer = fab ? (fab.closest('.luna-fab') || fab.parentElement) : null;
                if (fabContainer) {
                  fabContainer.style.setProperty('z-index', '2147483647', 'important');
                  fabContainer.style.setProperty('position', 'fixed', 'important');
                }
                if (fab) {
                  fab.style.setProperty('z-index', '2147483647', 'important');
                }
                
                // Hydrate after a small delay to ensure panel is visible
                setTimeout(function(){
                  hydrate(panel.querySelector('.luna-thread'));
                  if (window.LunaChatSession && typeof window.LunaChatSession.onPanelToggle === 'function') {
                    window.LunaChatSession.onPanelToggle(true);
                  }
                }, 50);
              } else {
                // Explicitly hide panel when closing
                panel.style.setProperty('display', 'none', 'important');
                panel.style.setProperty('visibility', 'hidden', 'important');
                panel.style.setProperty('opacity', '0', 'important');
                if (window.LunaChatSession && typeof window.LunaChatSession.onPanelToggle === 'function') {
                  window.LunaChatSession.onPanelToggle(false);
                }
                hideEnded();
              }
            });
          }
          // Prevent panel clicks from bubbling to overlay (but allow close button)
          if(panel) panel.addEventListener('click', function(e){
            // Don't stop propagation if clicking the close button
            if (!e.target.closest('.luna-close')) {
              e.stopPropagation();
            }
          });
          
          if(fab) fab.addEventListener('click', function(e){ 
            e.stopPropagation(); 
            // If panel is already showing, close it; otherwise open it
            if (panel && panel.classList.contains('show')) {
              toggle(false);
            } else {
              toggle(true);
            }
          });
          // Use event delegation for close button to ensure it always works
          document.addEventListener('click', function(e){
            if (e.target && e.target.classList.contains('luna-close')) {
              e.preventDefault();
              e.stopPropagation();
              console.log('[Luna] Close button clicked');
              toggle(false);
            }
          });
          if(ended){
            var restartBtn = ended.querySelector('.luna-session-restart');
            if (restartBtn) restartBtn.addEventListener('click', function(){
              if (window.LunaChatSession && typeof window.LunaChatSession.restartSession === 'function') {
                window.LunaChatSession.restartSession();
              }
            });
          }
          document.addEventListener('keydown', function(e){
            if(e.key==='Escape'){
              toggle(false);
              hideEnded();
            }
          });
          
          // Full chat functionality with session management
          var sessionState = {
            inactivityDelay: 120000,
            closureDelay: 180000,
            inactivityTimer: null,
            closureTimer: null,
            closing: false,
            restarting: false
          };
          
          function markActivity() {
            if (sessionState.closing) return;
            if (sessionState.inactivityTimer) clearTimeout(sessionState.inactivityTimer);
            if (sessionState.closureTimer) clearTimeout(sessionState.closureTimer);
            if (thread) thread.__inactiveWarned = false;
            sessionState.inactivityTimer = setTimeout(handleInactivityWarning, sessionState.inactivityDelay);
          }
          
          function handleInactivityWarning() {
            sessionState.inactivityTimer = null;
            if (sessionState.closing) return;
            var message = 'I haven\\'t heard from you in a while, are you still there? If not, I\\'ll close out this chat automatically in 3 minutes.';
            if (thread && !thread.__inactiveWarned) {
              thread.__inactiveWarned = true;
              var warning = document.createElement('div');
              warning.className = 'luna-msg luna-assistant';
              warning.textContent = message;
              thread.appendChild(warning);
              thread.scrollTop = thread.scrollHeight;
            }
            try {
              fetch('{$inactive_endpoint}', {
                method: 'POST',
                headers: {'Content-Type':'application/json'},
                body: JSON.stringify({ message: message })
              }).catch(function(err){ console.warn('[Luna] inactive log failed', err); });
            } catch (err) { console.warn('[Luna] inactive fetch error', err); }
            sessionState.closureTimer = setTimeout(handleSessionClosure, sessionState.closureDelay);
          }
          
          function handleSessionClosure() {
            sessionState.closureTimer = null;
            if (sessionState.closing) return;
            sessionState.closing = true;
            if (sessionState.inactivityTimer) clearTimeout(sessionState.inactivityTimer);
            var message = 'This chat session has been closed due to inactivity.';
            if (thread && !thread.__sessionClosed) {
              thread.__sessionClosed = true;
              
              // Create session closure message with download button
              var closure = document.createElement('div');
              closure.className = 'luna-msg luna-assistant luna-session-closure';
              closure.style.cssText = 'display:flex;flex-direction:column;gap:12px;';
              
              var messageText = document.createElement('div');
              messageText.textContent = message;
              closure.appendChild(messageText);
              
              // Add download transcript button
              var downloadBtn = document.createElement('button');
              downloadBtn.textContent = 'Download Transcript';
              downloadBtn.style.cssText = 'background:#fff4e9;color:#000000;border:1px solid #1f1d1a;border-radius:6px;padding:8px 16px;font-weight:600;cursor:pointer;align-self:flex-start;margin-top:8px;';
              downloadBtn.addEventListener('click', function(){
                if (typeof downloadTranscript === 'function') {
                  downloadTranscript();
                } else if (window.LunaChatSession && typeof window.LunaChatSession.downloadTranscript === 'function') {
                  window.LunaChatSession.downloadTranscript();
                }
              });
              closure.appendChild(downloadBtn);
              
              thread.appendChild(closure);
              thread.scrollTop = thread.scrollHeight;
            }
            if (input) input.disabled = true;
            if (sendBtn) sendBtn.disabled = true;
            showEnded();
            try {
              fetch('{$session_end_endpoint}', {
                method: 'POST',
                headers: {'Content-Type':'application/json'},
                body: JSON.stringify({ reason: 'inactivity', message: message })
              }).catch(function(err){ console.warn('[Luna] session end failed', err); });
            } catch (err) { console.warn('[Luna] session end error', err); }
          }
          
          function restartSession() {
            if (sessionState.restarting) return;
            sessionState.restarting = true;
            if (sessionState.inactivityTimer) clearTimeout(sessionState.inactivityTimer);
            if (sessionState.closureTimer) clearTimeout(sessionState.closureTimer);
            var restartBtn = ended ? ended.querySelector('.luna-session-restart') : null;
            if (restartBtn) restartBtn.disabled = true;
            try {
              fetch('{$session_reset_endpoint}', {
                method: 'POST',
                headers: {'Content-Type':'application/json'},
                body: JSON.stringify({ reason: 'user_restart' })
              })
              .then(function(){
                sessionState.closing = false;
                if (input) input.disabled = false;
                if (sendBtn) sendBtn.disabled = false;
                hideEnded();
                if (thread) {
                  thread.innerHTML = '';
                  thread.__hydrated = false;
                  thread.__inactiveWarned = false;
                  thread.__sessionClosed = false;
                }
                if (panel) panel.classList.add('show');
                if (fab) fab.setAttribute('aria-expanded','true');
                if (input) input.focus();
                markActivity();
              })
              .catch(function(err){ console.error('[Luna] session reset failed', err); })
              .finally(function(){
                sessionState.restarting = false;
                if (restartBtn) restartBtn.disabled = false;
              });
            } catch (err) {
              console.error('[Luna] session reset error', err);
              sessionState.restarting = false;
              if (restartBtn) restartBtn.disabled = false;
            }
          }
          
          function submitFrom(input, thread){
            if (!input || !thread) return;
            if (sessionState.closing) {
              showEnded();
              return;
            }
            var msg = (input.value || '').trim();
            if (!msg) return;
            
            markActivity();
            
            // Clear input and display user message
            input.value = '';
            input.disabled = true;
            if (sendBtn) sendBtn.disabled = true;
            
            var userMsg = document.createElement('div');
            userMsg.className = 'luna-msg luna-user';
            userMsg.textContent = msg;
            thread.appendChild(userMsg);
            thread.scrollTop = thread.scrollHeight;
            
            // Show loading animation
            var loading = document.createElement('div');
            loading.className = 'luna-msg luna-loading';
            var loadingText = document.createElement('span');
            loadingText.className = 'luna-loading-text';
            loadingText.textContent = 'Luna is considering all possibilities...';
            loading.appendChild(loadingText);
            thread.appendChild(loading);
            thread.scrollTop = thread.scrollHeight;
            
            // Send to API
            fetch('{$chat_endpoint}', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'X-WP-Nonce': '{$nonce}'
              },
              credentials: 'same-origin',
              body: JSON.stringify({ prompt: msg })
            })
            .then(function(r){ 
              if (!r.ok) {
                console.error('[Luna] HTTP error:', r.status, r.statusText);
                return {error: 'HTTP ' + r.status + ': ' + r.statusText};
              }
              const contentType = r.headers.get('content-type');
              if (!contentType || !contentType.includes('application/json')) {
                console.error('[Luna] Response is not JSON, content-type:', contentType);
                return r.text().then(function(text){
                  console.error('[Luna] Response body:', text.substring(0, 200));
                  return {error: 'Invalid response format (not JSON)'};
                });
              }
              return r.json().catch(function(err){
                console.error('[Luna] JSON parse error:', err);
                return r.text().then(function(text){
                  console.error('[Luna] Response body that failed to parse:', text.substring(0, 200));
                  return {error: 'Invalid response format (JSON parse failed)'};
                });
              }); 
            })
            .then(function(data){
              loading.remove();
              console.log('[Luna] Response data:', data);
              var msg = (data && data.answer) ? data.answer : (data.error ? ('Error: '+data.error) : 'Sorry—no response.');
              var assistantMsg = document.createElement('div');
              assistantMsg.className = 'luna-msg luna-assistant';
              assistantMsg.textContent = msg;
              thread.appendChild(assistantMsg);
              thread.scrollTop = thread.scrollHeight;
            })
            .catch(function(err){
              loading.remove();
              var errorMsg = document.createElement('div');
              errorMsg.className = 'luna-msg luna-assistant';
              errorMsg.textContent = 'Network error. Please try again.';
              thread.appendChild(errorMsg);
              thread.scrollTop = thread.scrollHeight;
              console.error('[Luna]', err);
            })
            .finally(function(){
              input.disabled = false;
              if (sendBtn) sendBtn.disabled = false;
              input.focus();
              markActivity();
            });
          }
          
          if (form && input && sendBtn) {
            form.addEventListener('submit', function(e){
              e.preventDefault();
              e.stopPropagation();
              submitFrom(input, thread);
            });
            sendBtn.addEventListener('click', function(e){
              e.preventDefault();
              e.stopPropagation();
              submitFrom(input, thread);
            });
            input.addEventListener('keydown', function(e){
              if (sessionState.closing) {
                e.preventDefault();
                showEnded();
                return;
              }
              if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
                e.preventDefault();
                e.stopPropagation();
                submitFrom(input, thread);
              }
              markActivity();
            });
            input.addEventListener('focus', markActivity);
            input.addEventListener('input', markActivity);
            form.addEventListener('pointerdown', markActivity);
          }
          
          // Initialize activity tracking
          markActivity();
          
          // Make session management available globally
          window.LunaChatSession = sessionState;
          window.LunaChatSession.restartSession = restartSession;
          window.LunaChatSession.onPanelToggle = function(open) {
            if (open && !sessionState.closing) {
              markActivity();
            }
          };
        })();
      ";
      
      return new WP_REST_Response(array(
        'ok' => true,
        'html' => $html,
        'css' => $css,
        'js' => $widget_js,
        'rest_url' => rest_url('luna_widget/v1/'),
        'nonce' => wp_create_nonce('wp_rest')
      ), 200);
    },
  ));

  register_rest_route('luna_widget/v1', '/chat/history', array(
    'methods'  => 'GET',
    'permission_callback' => '__return_true',
    'callback' => function( WP_REST_Request $req ){
      // Add CORS headers
      $add_cors_headers = function($response) {
        $origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';
        $allowed_origins = array(
          'https://supercluster.visiblelight.ai',
          'https://visiblelight.ai',
          'http://supercluster.visiblelight.ai',
          'http://visiblelight.ai'
        );
        
        $is_allowed = false;
        if (!empty($origin)) {
          foreach ($allowed_origins as $allowed) {
            if ($origin === $allowed || strpos($origin, $allowed) !== false) {
              $is_allowed = true;
              break;
            }
          }
        }
        
        if ($is_allowed && !empty($origin)) {
          $response->header('Access-Control-Allow-Origin', $origin);
          $response->header('Access-Control-Allow-Credentials', 'true');
        } else {
          $response->header('Access-Control-Allow-Origin', '*');
        }
        $response->header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
        $response->header('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With, Accept');
        return $response;
      };
      
      try {
        $pid = luna_conv_id();
        if (!$pid) {
          $response = new WP_REST_Response(array('items'=>array()), 200);
          return $add_cors_headers($response);
        }
        $t = get_post_meta($pid, 'transcript', true); 
        if (!is_array($t)) $t = array();
        $limit = max(1, min(50, (int)$req->get_param('limit') ? (int)$req->get_param('limit') : 20));
        $slice = array_slice($t, -$limit);
        $items = array();
        foreach ($slice as $row) {
          $items[] = array(
            'ts'        => isset($row['ts']) ? (int)$row['ts'] : 0,
            'ts_iso'    => !empty($row['ts']) ? gmdate('c', (int)$row['ts']) : null,
            'user'      => isset($row['user']) ? wp_strip_all_tags((string)$row['user']) : '',
            'assistant' => isset($row['assistant']) ? wp_strip_all_tags((string)$row['assistant']) : '',
          );
        }
        $response = new WP_REST_Response(array('items'=>$items), 200);
        return $add_cors_headers($response);
      } catch (Exception $e) {
        error_log('[Luna] Chat history error: ' . $e->getMessage());
        $response = new WP_REST_Response(array('items'=>array(), 'error' => 'Failed to fetch history'), 500);
        return $add_cors_headers($response);
      }
    },
  ));

  /* --- Hub-facing list endpoints (license-gated) --- */
  $secure_cb = function(){ return true; };

  // System snapshot (plugins/themes summary here)
  register_rest_route('luna_widget/v1', '/system/site', array(
    'methods'  => 'GET',
    'permission_callback' => $secure_cb,
    'callback' => function( WP_REST_Request $req ){
      if (!luna_license_ok($req)) return luna_forbidden();
      return new WP_REST_Response( luna_snapshot_system(), 200 );
    },
  ));
  // Aliases some hubs expect
  register_rest_route('vl-hub/v1', '/system/site', array(
    'methods'  => 'GET',
    'permission_callback' => $secure_cb,
    'callback' => function( WP_REST_Request $req ){
      if (!luna_license_ok($req)) return luna_forbidden();
      return new WP_REST_Response( luna_snapshot_system(), 200 );
    },
  ));

  // Enhanced Posts endpoint with SEO scores, meta data, and detailed author info
  $posts_cb = function( WP_REST_Request $req ){
    if (!luna_license_ok($req)) return luna_forbidden();
    $per  = max(1, min(200, (int)$req->get_param('per_page') ?: 50));
    $page = max(1, (int)$req->get_param('page') ?: 1);
    $q = new WP_Query(array(
      'post_type'      => 'post',
      'post_status'    => 'publish',
      'posts_per_page' => $per,
      'paged'          => $page,
      'orderby'        => 'date',
      'order'          => 'DESC',
      'fields'         => 'ids',
    ));
    $items = array();
    foreach ($q->posts as $pid) {
      $cats = wp_get_post_terms($pid, 'category', array('fields'=>'names'));
      $tags = wp_get_post_terms($pid, 'post_tag', array('fields'=>'names'));
      $author_id = get_post_field('post_author', $pid);
      $author = get_user_by('id', $author_id);
      
      // Get meta data
      $meta_data = get_post_meta($pid);
      
      // Calculate SEO score (basic implementation)
      $seo_score = luna_calculate_seo_score($pid);
      
      $items[] = array(
        'id'        => $pid,
        'title'     => get_the_title($pid),
        'slug'      => get_post_field('post_name', $pid),
        'date'      => get_post_time('c', true, $pid),
        'author'    => array(
          'id' => $author_id,
          'username' => $author ? $author->user_login : 'Unknown',
          'email' => $author ? $author->user_email : '',
          'display_name' => $author ? $author->display_name : 'Unknown'
        ),
        'categories'=> array_values($cats ?: array()),
        'tags'      => array_values($tags ?: array()),
        'permalink' => get_permalink($pid),
        'meta_data' => $meta_data,
        'seo_score' => $seo_score,
        'status'    => get_post_status($pid),
        'comment_count' => get_comments_number($pid),
        'featured_image' => get_the_post_thumbnail_url($pid, 'full')
      );
    }
    return new WP_REST_Response(array('total'=>(int)$q->found_posts,'page'=>$page,'per_page'=>$per,'items'=>$items), 200);
  };
  register_rest_route('luna_widget/v1', '/content/posts', array('methods'=>'GET','permission_callback'=>$secure_cb,'callback'=>$posts_cb));
  register_rest_route('vl-hub/v1',      '/posts',         array('methods'=>'GET','permission_callback'=>$secure_cb,'callback'=>$posts_cb));

  // Enhanced Pages endpoint with SEO scores, meta data, and detailed author info
  $pages_cb = function( WP_REST_Request $req ){
    if (!luna_license_ok($req)) return luna_forbidden();
    $per  = max(1, min(200, (int)$req->get_param('per_page') ?: 50));
    $page = max(1, (int)$req->get_param('page') ?: 1);
    $q = new WP_Query(array(
      'post_type'      => 'page',
      'post_status'    => array('publish', 'draft', 'private', 'pending'),
      'posts_per_page' => $per,
      'paged'          => $page,
      'orderby'        => 'date',
      'order'          => 'DESC',
      'fields'         => 'ids',
    ));
    $items = array();
    foreach ($q->posts as $pid) {
      $author_id = get_post_field('post_author', $pid);
      $author = get_user_by('id', $author_id);
      
      // Get meta data
      $meta_data = get_post_meta($pid);
      
      // Calculate SEO score (basic implementation)
      $seo_score = luna_calculate_seo_score($pid);
      
      $items[] = array(
        'id'        => $pid,
        'title'     => get_the_title($pid),
        'slug'      => get_post_field('post_name', $pid),
        'status'    => get_post_status($pid),
        'date'      => get_post_time('c', true, $pid),
        'author'    => array(
          'id' => $author_id,
          'username' => $author ? $author->user_login : 'Unknown',
          'email' => $author ? $author->user_email : '',
          'display_name' => $author ? $author->display_name : 'Unknown'
        ),
        'permalink' => get_permalink($pid),
        'meta_data' => $meta_data,
        'seo_score' => $seo_score,
        'comment_count' => get_comments_number($pid),
        'featured_image' => get_the_post_thumbnail_url($pid, 'full'),
        'parent' => get_post_field('post_parent', $pid)
      );
    }
    return new WP_REST_Response(array('total'=>(int)$q->found_posts,'page'=>$page,'per_page'=>$per,'items'=>$items), 200);
  };
  register_rest_route('luna_widget/v1', '/content/pages', array('methods'=>'GET','permission_callback'=>$secure_cb,'callback'=>$pages_cb));
  register_rest_route('vl-hub/v1',      '/pages',         array('methods'=>'GET','permission_callback'=>$secure_cb,'callback'=>$pages_cb));

  // Enhanced Users endpoint with detailed user information
  $users_cb = function( WP_REST_Request $req ){
    if (!luna_license_ok($req)) return luna_forbidden();
    $per    = max(1, min(200, (int)$req->get_param('per_page') ?: 100));
    $page   = max(1, (int)$req->get_param('page') ?: 1);
    $offset = ($page-1)*$per;
    $u = get_users(array(
      'number' => $per,
      'offset' => $offset,
      'fields' => array('user_login','user_email','display_name','ID','user_registered','user_url'),
      'orderby'=> 'ID',
      'order'  => 'ASC',
    ));
    $items = array();
    foreach ($u as $row) {
      $user_meta = get_user_meta($row->ID);
      $items[] = array(
        'id'       => (int)$row->ID,
        'username' => $row->user_login,
        'email'    => $row->user_email,
        'name'     => $row->display_name,
        'url'      => $row->user_url,
        'registered' => $row->user_registered,
        'roles'    => get_userdata($row->ID)->roles,
        'last_login' => get_user_meta($row->ID, 'last_login', true),
        'post_count' => count_user_posts($row->ID),
        'meta_data' => $user_meta
      );
    }
    $counts = count_users();
    $total  = isset($counts['total_users']) ? (int)$counts['total_users'] : (int)($offset + count($items));
    return new WP_REST_Response(array('total'=>$total,'page'=>$page,'per_page'=>$per,'items'=>$items), 200);
  };
  register_rest_route('luna_widget/v1', '/users', array('methods'=>'GET','permission_callback'=>$secure_cb,'callback'=>$users_cb));
  register_rest_route('vl-hub/v1',      '/users', array('methods'=>'GET','permission_callback'=>$secure_cb,'callback'=>$users_cb));

  // Plugins
  register_rest_route('luna_widget/v1', '/plugins', array(
    'methods'  => 'GET',
    'permission_callback' => $secure_cb,
    'callback' => function( WP_REST_Request $req ){
      if (!luna_license_ok($req)) return luna_forbidden();
      if (!function_exists('get_plugins')) { @require_once ABSPATH . 'wp-admin/includes/plugin.php'; }
      $plugins = function_exists('get_plugins') ? (array)get_plugins() : array();
      $active  = (array) get_option('active_plugins', array());
      $up_pl   = get_site_transient('update_plugins');
      $items = array();
      foreach ($plugins as $slug => $info) {
        $update_available = isset($up_pl->response[$slug]);
        $items[] = array(
          'slug'            => $slug,
          'name'            => isset($info['Name']) ? $info['Name'] : $slug,
          'version'         => isset($info['Version']) ? $info['Version'] : null,
          'active'          => in_array($slug, $active, true),
          'update_available'=> (bool)$update_available,
          'new_version'     => $update_available ? (isset($up_pl->response[$slug]->new_version) ? $up_pl->response[$slug]->new_version : null) : null,
        );
      }
      return new WP_REST_Response(array('items'=>$items), 200);
    },
  ));

  // Themes
  register_rest_route('luna_widget/v1', '/themes', array(
    'methods'  => 'GET',
    'permission_callback' => $secure_cb,
    'callback' => function( WP_REST_Request $req ){
      if (!luna_license_ok($req)) return luna_forbidden();
      $themes = wp_get_themes();
      $up_th  = get_site_transient('update_themes');
      $active_stylesheet = wp_get_theme()->get_stylesheet();
      $items = array();
      foreach ($themes as $stylesheet => $th) {
        $update_available = isset($up_th->response[$stylesheet]);
        $items[] = array(
          'stylesheet'      => $stylesheet,
          'name'            => $th->get('Name'),
          'version'         => $th->get('Version'),
          'is_active'       => ($active_stylesheet === $stylesheet),
          'update_available'=> (bool)$update_available,
          'new_version'     => $update_available ? (isset($up_th->response[$stylesheet]['new_version']) ? $up_th->response[$stylesheet]['new_version'] : null) : null,
        );
      }
      return new WP_REST_Response(array('items'=>$items), 200);
    },
  ));

  /* Utilities: manual pings */
  register_rest_route('luna_widget/v1', '/ping-hub', array(
    'methods'  => 'POST',
    'permission_callback' => function(){ return current_user_can('manage_options'); },
    'callback' => function(){
      luna_widget_try_activation();
      $last = get_option(LUNA_WIDGET_OPT_LAST_PING, array());
      return new WP_REST_Response(array('ok'=>true,'last'=>$last), 200);
    },
  ));
  register_rest_route('luna_widget/v1', '/heartbeat-now', array(
    'methods'  => 'POST',
    'permission_callback' => function(){ return current_user_can('manage_options'); },
    'callback' => function(){
      luna_widget_send_heartbeat();
      $last = get_option(LUNA_WIDGET_OPT_LAST_PING, array());
      return new WP_REST_Response(array('ok'=>true,'last'=>$last), 200);
    },
  ));

  /* --- Purge profile cache (Hub → client after Security edits) --- */
  register_rest_route('luna_widget/v1', '/purge-profile-cache', array(
    'methods'  => 'POST',
    'permission_callback' => '__return_true',
    'callback' => function (WP_REST_Request $req) {
      if (!luna_license_ok($req)) return new WP_REST_Response(array('ok'=>false,'error'=>'forbidden'), 403);
      luna_profile_cache_bust(true);
      return new WP_REST_Response(array('ok'=>true,'message'=>'Profile cache purged'), 200);
    },
  ));

  /* --- Debug endpoint to test Hub connection --- */
  register_rest_route('luna_widget/v1', '/debug-hub', array(
    'methods'  => 'GET',
    'permission_callback' => '__return_true',
    'callback' => function (WP_REST_Request $req) {
      $license = luna_get_license();
      $hub_url = luna_widget_hub_base();
      $endpoint = $hub_url . '/wp-json/luna_widget/v1/system/comprehensive';
      
      $response = wp_remote_get($endpoint, array(
        'headers' => array('X-Luna-License' => $license),
        'timeout' => 10
      ));
      
      $debug_info = array(
        'license' => $license ? substr($license, 0, 8) . '...' : 'NOT SET',
        'hub_url' => $hub_url,
        'endpoint' => $endpoint,
        'is_error' => is_wp_error($response),
        'error_message' => is_wp_error($response) ? $response->get_error_message() : null,
        'response_code' => is_wp_error($response) ? null : wp_remote_retrieve_response_code($response),
        'response_body' => is_wp_error($response) ? null : wp_remote_retrieve_body($response),
      );
      
      return new WP_REST_Response($debug_info, 200);
    },
  ));

  /* --- Debug endpoint to see comprehensive facts --- */
  register_rest_route('luna_widget/v1', '/debug-facts', array(
    'methods'  => 'GET',
    'permission_callback' => '__return_true',
    'callback' => function (WP_REST_Request $req) {
      $facts = luna_profile_facts_comprehensive();
      
      $debug_info = array(
        'comprehensive_facts' => $facts,
        'has_pages' => isset($facts['pages']) && is_array($facts['pages']) ? count($facts['pages']) : 0,
        'has_themes' => isset($facts['themes']) && is_array($facts['themes']) ? count($facts['themes']) : 0,
        'updates' => $facts['updates'] ?? array(),
        'counts' => $facts['counts'] ?? array(),
      );
      
      return new WP_REST_Response($debug_info, 200);
    },
  ));

  /* --- Debug endpoint to test regex patterns --- */
  register_rest_route('luna_widget/v1', '/debug-regex', array(
    'methods'  => 'GET',
    'permission_callback' => '__return_true',
    'callback' => function (WP_REST_Request $req) {
      $test_phrases = array(
        'What are the names of the pages?',
        'What are the names of the posts?',
        'Do I have any inactive pages?',
        'What themes do I have?'
      );
      
      $results = array();
      foreach ($test_phrases as $phrase) {
        $lc = strtolower($phrase);
        $results[$phrase] = array(
          'lowercase' => $lc,
          'page_names_match' => preg_match('/\bnames.*of.*pages|page.*names|what.*are.*the.*names.*of.*pages\b/', $lc),
          'post_names_match' => preg_match('/\bnames.*of.*posts|post.*names|what.*are.*the.*names.*of.*posts\b/', $lc),
          'inactive_pages_match' => preg_match('/\binactive.*page|page.*inactive|draft.*page|page.*draft\b/', $lc),
          'theme_list_match' => preg_match('/\binactive.*theme|theme.*inactive|what.*themes|list.*themes|all.*themes\b/', $lc)
        );
      }
      
      return new WP_REST_Response($results, 200);
    },
  ));

  /* --- Debug endpoint for keyword mappings --- */
  register_rest_route('luna_widget/v1', '/debug-keywords', array(
    'methods'  => 'GET',
    'permission_callback' => '__return_true',
    'callback' => function (WP_REST_Request $req) {
      $test_input = $req->get_param('input') ?: 'hey Lu';
      $mappings = luna_get_keyword_mappings();
      $keyword_match = luna_check_keyword_mappings($test_input);
      
      return new WP_REST_Response(array(
        'test_input' => $test_input,
        'mappings' => $mappings,
        'keyword_match' => $keyword_match,
        'mapping_count' => count($mappings)
      ), 200);
    },
  ));

  /* --- Canned Responses Endpoint for Luna Composer --- */
  register_rest_route('luna_widget/v1', '/canned-responses', array(
    'methods'  => 'GET',
    'permission_callback' => $secure_cb,
    'callback' => function( WP_REST_Request $req ){
      if (!luna_license_ok($req)) return luna_forbidden();
      
      $posts = get_posts(array(
        'post_type'        => 'luna_canned_response',
        'post_status'      => 'publish',
        'numberposts'      => -1,
        'orderby'          => array('menu_order' => 'ASC', 'title' => 'ASC'),
        'order'            => 'ASC',
        'suppress_filters' => false,
      ));
      
      $items = array();
      foreach ($posts as $post) {
        $content = luna_widget_prepare_canned_response_content($post->post_content);
        
        // Get sprite metadata if this is a sprite
        $sprite_id = get_post_meta($post->ID, '_luna_sprite_id', true);
        $sprite_data = null;
        if ($sprite_id) {
          $sprite_data = array(
            'sprite_id' => $sprite_id,
            'sprite_name' => get_post_meta($post->ID, '_luna_sprite_name', true),
            'department' => get_post_meta($post->ID, '_luna_sprite_department', true),
            'intent' => get_post_meta($post->ID, '_luna_sprite_intent', true),
            'tags' => get_post_meta($post->ID, '_luna_sprite_tags', true),
            'priority' => get_post_meta($post->ID, '_luna_sprite_priority', true),
            'prompt_template' => get_post_meta($post->ID, '_luna_sprite_prompt_template', true),
            'output' => get_post_meta($post->ID, '_luna_sprite_output', true),
            'inputs' => get_post_meta($post->ID, '_luna_sprite_inputs', true),
            'data_bindings' => get_post_meta($post->ID, '_luna_sprite_data_bindings', true),
            'style' => get_post_meta($post->ID, '_luna_sprite_style', true),
            'constraints' => get_post_meta($post->ID, '_luna_sprite_constraints', true),
          );
        }
        
        // Use sprite prompt if available, otherwise use title
        $prompt = get_post_meta($post->ID, '_luna_sprite_prompt', true);
        if (empty($prompt)) {
          $prompt = $post->post_title;
        }
        
        // Generate excerpt and ensure no trailing newlines
        $excerpt = wp_trim_words($content, 30, '…');
        // Remove any trailing newlines, whitespace, and \n\n patterns
        $excerpt = preg_replace('/\s+$/', '', $excerpt);
        $excerpt = rtrim($excerpt, "\n\r");
        $excerpt = trim($excerpt);
        
        $items[] = array(
          'id'      => $post->ID,
          'title'   => $post->post_title,
          'prompt'  => $prompt,
          'content' => $content,
          'excerpt' => $excerpt,
          'sprite'  => $sprite_data, // Include sprite metadata if available
        );
      }
      
      return new WP_REST_Response(array('items' => $items), 200);
    },
  ));

  /* --- Sprite Library Management Endpoint --- */
  register_rest_route('luna_widget/v1', '/sprite-library/ingest', array(
    'methods'  => 'POST',
    'permission_callback' => function() {
      return current_user_can('manage_options');
    },
    'callback' => function( WP_REST_Request $req ){
      $library_json = $req->get_param('library');
      
      if (empty($library_json)) {
        // Use seed library if none provided
        $library_data = luna_get_seed_sprite_library();
      } else {
        // Decode provided JSON
        $library_data = json_decode($library_json, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
          return new WP_REST_Response(array(
            'success' => false,
            'error' => 'Invalid JSON: ' . json_last_error_msg()
          ), 400);
        }
      }
      
      $result = luna_ingest_sprite_library($library_data);
      
      return new WP_REST_Response($result, $result['success'] ? 200 : 400);
    },
  ));

  /* --- Comprehensive WordPress Data Collection Endpoints --- */
  
  // Comments endpoint
  register_rest_route('luna_widget/v1', '/comments', array(
    'methods'  => 'GET',
    'permission_callback' => $secure_cb,
    'callback' => function( WP_REST_Request $req ){
      if (!luna_license_ok($req)) return luna_forbidden();
      $per_page = max(1, min(200, (int)$req->get_param('per_page') ?: 50));
      $page = max(1, (int)$req->get_param('page') ?: 1);
      $comments = get_comments(array(
        'number' => $per_page,
        'offset' => ($page - 1) * $per_page,
        'status' => 'approve'
      ));
      $items = array();
      foreach ($comments as $comment) {
        $items[] = array(
          'id' => $comment->comment_ID,
          'post_id' => $comment->comment_post_ID,
          'author' => $comment->comment_author,
          'author_email' => $comment->comment_author_email,
          'author_url' => $comment->comment_author_url,
          'content' => $comment->comment_content,
          'date' => $comment->comment_date,
          'approved' => $comment->comment_approved,
          'type' => $comment->comment_type,
          'parent' => $comment->comment_parent
        );
      }
      return new WP_REST_Response(array('items'=>$items), 200);
    },
  ));

  // Media endpoint
  register_rest_route('luna_widget/v1', '/media', array(
    'methods'  => 'GET',
    'permission_callback' => $secure_cb,
    'callback' => function( WP_REST_Request $req ){
      if (!luna_license_ok($req)) return luna_forbidden();
      $per_page = max(1, min(200, (int)$req->get_param('per_page') ?: 50));
      $page = max(1, (int)$req->get_param('page') ?: 1);
      $query = new WP_Query(array(
        'post_type' => 'attachment',
        'post_status' => 'inherit',
        'posts_per_page' => $per_page,
        'paged' => $page,
        'orderby' => 'date',
        'order' => 'DESC'
      ));
      $items = array();
      foreach ($query->posts as $attachment) {
        $file_path = get_attached_file($attachment->ID);
        $items[] = array(
          'id' => $attachment->ID,
          'title' => $attachment->post_title,
          'filename' => basename($file_path),
          'mime_type' => $attachment->post_mime_type,
          'url' => wp_get_attachment_url($attachment->ID),
          'date' => $attachment->post_date,
          'author' => get_the_author_meta('user_login', $attachment->post_author),
          'file_size' => $file_path && file_exists($file_path) ? filesize($file_path) : 0
        );
      }
      return new WP_REST_Response(array('items'=>$items), 200);
    },
  ));

  // Categories endpoint
  register_rest_route('luna_widget/v1', '/categories', array(
    'methods'  => 'GET',
    'permission_callback' => $secure_cb,
    'callback' => function( WP_REST_Request $req ){
      if (!luna_license_ok($req)) return luna_forbidden();
      $categories = get_categories(array('hide_empty' => false));
      $items = array();
      foreach ($categories as $category) {
        $items[] = array(
          'id' => $category->term_id,
          'name' => $category->name,
          'slug' => $category->slug,
          'description' => $category->description,
          'count' => $category->count,
          'parent' => $category->parent
        );
      }
      return new WP_REST_Response(array('items'=>$items), 200);
    },
  ));

  // Tags endpoint
  register_rest_route('luna_widget/v1', '/tags', array(
    'methods'  => 'GET',
    'permission_callback' => $secure_cb,
    'callback' => function( WP_REST_Request $req ){
      if (!luna_license_ok($req)) return luna_forbidden();
      $tags = get_tags(array('hide_empty' => false));
      $items = array();
      foreach ($tags as $tag) {
        $items[] = array(
          'id' => $tag->term_id,
          'name' => $tag->name,
          'slug' => $tag->slug,
          'description' => $tag->description,
          'count' => $tag->count
        );
      }
      return new WP_REST_Response(array('items'=>$items), 200);
    },
  ));

  // Custom post types endpoint
  register_rest_route('luna_widget/v1', '/custom-post-types', array(
    'methods'  => 'GET',
    'permission_callback' => $secure_cb,
    'callback' => function( WP_REST_Request $req ){
      if (!luna_license_ok($req)) return luna_forbidden();
      $post_types = get_post_types(array('public' => true), 'objects');
      $items = array();
      foreach ($post_types as $post_type) {
        if ($post_type->name === 'attachment') continue;
        $count = wp_count_posts($post_type->name);
        $items[] = array(
          'name' => $post_type->name,
          'label' => $post_type->label,
          'description' => $post_type->description,
          'public' => $post_type->public,
          'hierarchical' => $post_type->hierarchical,
          'count' => array(
            'publish' => $count->publish,
            'draft' => $count->draft,
            'private' => $count->private,
            'trash' => $count->trash
          )
        );
      }
      return new WP_REST_Response(array('items'=>$items), 200);
    },
  ));

  // Menus endpoint
  register_rest_route('luna_widget/v1', '/menus', array(
    'methods'  => 'GET',
    'permission_callback' => $secure_cb,
    'callback' => function( WP_REST_Request $req ){
      if (!luna_license_ok($req)) return luna_forbidden();
      $menus = wp_get_nav_menus();
      $items = array();
      foreach ($menus as $menu) {
        $items[] = array(
          'id' => $menu->term_id,
          'name' => $menu->name,
          'slug' => $menu->slug,
          'description' => $menu->description,
          'count' => $menu->count
        );
      }
      return new WP_REST_Response(array('items'=>$items), 200);
    },
  ));

  // Widgets endpoint
  register_rest_route('luna_widget/v1', '/widgets', array(
    'methods'  => 'GET',
    'permission_callback' => $secure_cb,
    'callback' => function( WP_REST_Request $req ){
      if (!luna_license_ok($req)) return luna_forbidden();
      global $wp_registered_widgets;
      $items = array();
      foreach ($wp_registered_widgets as $widget_id => $widget) {
        $items[] = array(
          'id' => $widget_id,
          'name' => $widget['name'],
          'class' => $widget['classname'],
          'description' => $widget['description']
        );
      }
      return new WP_REST_Response(array('items'=>$items), 200);
    },
  ));

  // Sidebars endpoint
  register_rest_route('luna_widget/v1', '/sidebars', array(
    'methods'  => 'GET',
    'permission_callback' => $secure_cb,
    'callback' => function( WP_REST_Request $req ){
      if (!luna_license_ok($req)) return luna_forbidden();
      global $wp_registered_sidebars;
      $items = array();
      foreach ($wp_registered_sidebars as $sidebar_id => $sidebar) {
        $items[] = array(
          'id' => $sidebar_id,
          'name' => $sidebar['name'],
          'description' => $sidebar['description'],
          'class' => $sidebar['class'],
          'before_widget' => $sidebar['before_widget'],
          'after_widget' => $sidebar['after_widget'],
          'before_title' => $sidebar['before_title'],
          'after_title' => $sidebar['after_title']
        );
      }
      return new WP_REST_Response(array('items'=>$items), 200);
    },
  ));

  // Options endpoint
  register_rest_route('luna_widget/v1', '/options', array(
    'methods'  => 'GET',
    'permission_callback' => $secure_cb,
    'callback' => function( WP_REST_Request $req ){
      if (!luna_license_ok($req)) return luna_forbidden();
      $options = array(
        'site_name' => get_option('blogname'),
        'site_description' => get_option('blogdescription'),
        'admin_email' => get_option('admin_email'),
        'timezone' => get_option('timezone_string'),
        'date_format' => get_option('date_format'),
        'time_format' => get_option('time_format'),
        'start_of_week' => get_option('start_of_week'),
        'language' => get_option('WPLANG'),
        'permalink_structure' => get_option('permalink_structure'),
        'default_category' => get_option('default_category'),
        'default_post_format' => get_option('default_post_format'),
        'users_can_register' => get_option('users_can_register'),
        'default_role' => get_option('default_role'),
        'comment_moderation' => get_option('comment_moderation'),
        'comment_registration' => get_option('comment_registration'),
        'close_comments_for_old_posts' => get_option('close_comments_for_old_posts'),
        'close_comments_days_old' => get_option('close_comments_days_old'),
        'thread_comments' => get_option('thread_comments'),
        'thread_comments_depth' => get_option('thread_comments_depth'),
        'page_comments' => get_option('page_comments'),
        'comments_per_page' => get_option('comments_per_page'),
        'default_comments_page' => get_option('default_comments_page'),
        'comment_order' => get_option('comment_order')
      );
      return new WP_REST_Response(array('options'=>$options), 200);
    },
  ));

  // Database tables endpoint
  register_rest_route('luna_widget/v1', '/database-tables', array(
    'methods'  => 'GET',
    'permission_callback' => $secure_cb,
    'callback' => function( WP_REST_Request $req ){
      if (!luna_license_ok($req)) return luna_forbidden();
      global $wpdb;
      $tables = $wpdb->get_results("SHOW TABLES", ARRAY_N);
      $items = array();
      foreach ($tables as $table) {
        $table_name = $table[0];
        $count = $wpdb->get_var("SELECT COUNT(*) FROM `$table_name`");
        $items[] = array(
          'name' => $table_name,
          'count' => (int)$count
        );
      }
      return new WP_REST_Response(array('items'=>$items), 200);
    },
  ));

  // WordPress Core Status endpoint
  register_rest_route('luna_widget/v1', '/wp-core-status', array(
    'methods'  => 'GET',
    'permission_callback' => $secure_cb,
    'callback' => function( WP_REST_Request $req ){
      if (!luna_license_ok($req)) return luna_forbidden();
      
      global $wp_version;
      $core_updates = get_site_transient('update_core');
      $is_update_available = !empty($core_updates->updates) && $core_updates->updates[0]->response === 'upgrade';
      
      $status = array(
        'version' => $wp_version,
        'update_available' => $is_update_available,
        'latest_version' => $is_update_available ? $core_updates->updates[0]->version : $wp_version,
        'php_version' => PHP_VERSION,
        'mysql_version' => $GLOBALS['wpdb']->db_version(),
        'memory_limit' => ini_get('memory_limit'),
        'max_execution_time' => ini_get('max_execution_time'),
        'upload_max_filesize' => ini_get('upload_max_filesize'),
        'post_max_size' => ini_get('post_max_size'),
        'max_input_vars' => ini_get('max_input_vars'),
        'is_multisite' => is_multisite(),
        'site_url' => get_site_url(),
        'home_url' => get_home_url(),
        'admin_email' => get_option('admin_email'),
        'timezone' => get_option('timezone_string'),
        'date_format' => get_option('date_format'),
        'time_format' => get_option('time_format'),
        'start_of_week' => get_option('start_of_week'),
        'language' => get_option('WPLANG'),
        'permalink_structure' => get_option('permalink_structure'),
        'users_can_register' => get_option('users_can_register'),
        'default_role' => get_option('default_role'),
        'comment_moderation' => get_option('comment_moderation'),
        'comment_registration' => get_option('comment_registration'),
        'close_comments_for_old_posts' => get_option('close_comments_for_old_posts'),
        'close_comments_days_old' => get_option('close_comments_days_old'),
        'thread_comments' => get_option('thread_comments'),
        'thread_comments_depth' => get_option('thread_comments_depth'),
        'page_comments' => get_option('page_comments'),
        'comments_per_page' => get_option('comments_per_page'),
        'default_comments_page' => get_option('default_comments_page'),
        'comment_order' => get_option('comment_order')
      );
      
      return new WP_REST_Response($status, 200);
    },
  ));

  // Comments count endpoint
  register_rest_route('luna_widget/v1', '/comments-count', array(
    'methods'  => 'GET',
    'permission_callback' => $secure_cb,
    'callback' => function( WP_REST_Request $req ){
      if (!luna_license_ok($req)) return luna_forbidden();
      
      $counts = wp_count_comments();
      $total = $counts->total_comments;
      $approved = $counts->approved;
      $pending = $counts->moderated;
      $spam = $counts->spam;
      $trash = $counts->trash;
      
      return new WP_REST_Response(array(
        'total' => $total,
        'approved' => $approved,
        'pending' => $pending,
        'spam' => $spam,
        'trash' => $trash
      ), 200);
    },
  ));

  // All WordPress data endpoint (comprehensive collection)
  register_rest_route('luna_widget/v1', '/all-wp-data', array(
    'methods'  => 'GET',
    'permission_callback' => $secure_cb,
    'callback' => function( WP_REST_Request $req ){
      if (!luna_license_ok($req)) return luna_forbidden();
      
      $data = array();
      
      // System info
      $data['system'] = luna_snapshot_system();
      
      // Posts (limited to 100 most recent)
      $posts_query = new WP_Query(array(
        'post_type' => 'post',
        'post_status' => 'publish',
        'posts_per_page' => 100,
        'orderby' => 'date',
        'order' => 'DESC',
        'fields' => 'ids'
      ));
      $data['posts'] = array();
      foreach ($posts_query->posts as $pid) {
        $data['posts'][] = array(
          'id' => $pid,
          'title' => get_the_title($pid),
          'excerpt' => get_the_excerpt($pid),
          'date' => get_the_date('c', $pid),
          'author' => get_the_author_meta('user_login', get_post_field('post_author', $pid)),
          'categories' => wp_get_post_terms($pid, 'category', array('fields'=>'names')),
          'tags' => wp_get_post_terms($pid, 'post_tag', array('fields'=>'names'))
        );
      }
      
      // Pages (limited to 100 most recent)
      $pages_query = new WP_Query(array(
        'post_type' => 'page',
        'post_status' => 'publish',
        'posts_per_page' => 100,
        'orderby' => 'date',
        'order' => 'DESC',
        'fields' => 'ids'
      ));
      $data['pages'] = array();
      foreach ($pages_query->posts as $pid) {
        $data['pages'][] = array(
          'id' => $pid,
          'title' => get_the_title($pid),
          'excerpt' => get_the_excerpt($pid),
          'date' => get_the_date('c', $pid),
          'author' => get_the_author_meta('user_login', get_post_field('post_author', $pid)),
          'parent' => get_post_field('post_parent', $pid)
        );
      }
      
      // Users (limited to 50 most recent)
      $users = get_users(array('number' => 50, 'orderby' => 'registered', 'order' => 'DESC'));
      $data['users'] = array();
      foreach ($users as $user) {
        $data['users'][] = array(
          'id' => $user->ID,
          'login' => $user->user_login,
          'email' => $user->user_email,
          'display_name' => $user->display_name,
          'roles' => $user->roles,
          'registered' => $user->user_registered,
          'last_login' => get_user_meta($user->ID, 'last_login', true)
        );
      }
      
      // Comments (limited to 100 most recent)
      $comments = get_comments(array('number' => 100, 'status' => 'approve'));
      $data['comments'] = array();
      foreach ($comments as $comment) {
        $data['comments'][] = array(
          'id' => $comment->comment_ID,
          'post_id' => $comment->comment_post_ID,
          'author' => $comment->comment_author,
          'content' => $comment->comment_content,
          'date' => $comment->comment_date,
          'approved' => $comment->comment_approved
        );
      }
      
      // Media (limited to 100 most recent)
      $media_query = new WP_Query(array(
        'post_type' => 'attachment',
        'post_status' => 'inherit',
        'posts_per_page' => 100,
        'orderby' => 'date',
        'order' => 'DESC'
      ));
      $data['media'] = array();
      foreach ($media_query->posts as $attachment) {
        $data['media'][] = array(
          'id' => $attachment->ID,
          'title' => $attachment->post_title,
          'filename' => basename(get_attached_file($attachment->ID)),
          'mime_type' => $attachment->post_mime_type,
          'url' => wp_get_attachment_url($attachment->ID),
          'date' => $attachment->post_date
        );
      }
      
      // Categories
      $categories = get_categories(array('hide_empty' => false));
      $data['categories'] = array();
      foreach ($categories as $category) {
        $data['categories'][] = array(
          'id' => $category->term_id,
          'name' => $category->name,
          'slug' => $category->slug,
          'count' => $category->count
        );
      }
      
      // Tags
      $tags = get_tags(array('hide_empty' => false));
      $data['tags'] = array();
      foreach ($tags as $tag) {
        $data['tags'][] = array(
          'id' => $tag->term_id,
          'name' => $tag->name,
          'slug' => $tag->slug,
          'count' => $tag->count
        );
      }
      
      // Custom post types
      $post_types = get_post_types(array('public' => true), 'objects');
      $data['custom_post_types'] = array();
      foreach ($post_types as $post_type) {
        if ($post_type->name === 'attachment') continue;
        $count = wp_count_posts($post_type->name);
        $data['custom_post_types'][] = array(
          'name' => $post_type->name,
          'label' => $post_type->label,
          'count' => array(
            'publish' => $count->publish,
            'draft' => $count->draft,
            'private' => $count->private
          )
        );
      }
      
      // Menus
      $menus = wp_get_nav_menus();
      $data['menus'] = array();
      foreach ($menus as $menu) {
        $data['menus'][] = array(
          'id' => $menu->term_id,
          'name' => $menu->name,
          'count' => $menu->count
        );
      }
      
      // Site options
      $data['options'] = array(
        'site_name' => get_option('blogname'),
        'site_description' => get_option('blogdescription'),
        'admin_email' => get_option('admin_email'),
        'timezone' => get_option('timezone_string'),
        'language' => get_option('WPLANG'),
        'permalink_structure' => get_option('permalink_structure'),
        'users_can_register' => get_option('users_can_register'),
        'default_role' => get_option('default_role')
      );
      
      return new WP_REST_Response($data, 200);
    },
  ));

  /* --- Sync to Hub endpoint --- */
  register_rest_route('luna_widget/v1', '/sync-to-hub', array(
    'methods'  => 'POST',
    'permission_callback' => function(){ return current_user_can('manage_options'); },
    'callback' => function(){
      $license = luna_get_license();
      if (!$license) {
        return new WP_REST_Response(array('ok'=>false,'error'=>'No license found'), 400);
      }
      
      // Sync all data to Hub
      $settings_data = array(
        'license' => $license,
        'hub_url' => luna_widget_hub_base(),
        'mode' => get_option(LUNA_WIDGET_OPT_MODE, 'widget'),
        'ui_settings' => get_option(LUNA_WIDGET_OPT_SETTINGS, array()),
        'wp_version' => get_bloginfo('version'),
        'plugin_version' => LUNA_WIDGET_PLUGIN_VERSION,
        'site_url' => home_url('/'),
        'last_sync' => current_time('mysql')
      );
      
      luna_sync_settings_to_hub($settings_data);
      
      // Sync keywords
      $keywords = luna_get_keyword_mappings();
      luna_sync_keywords_to_hub($keywords);
      
      // Sync analytics settings
      $analytics = get_option('luna_ga4_settings', array());
      if (!empty($analytics)) {
        luna_sync_analytics_to_hub($analytics);
      }
      
      return new WP_REST_Response(array('ok'=>true,'message'=>'All data synced to Hub'), 200);
    },
  ));
});

// AJAX handler for Luna Widget chat transcript
add_action('wp_ajax_luna_get_chat_transcript', function() {
  check_ajax_referer('luna_chat_transcript_nonce', 'nonce');
  
  $license_key = sanitize_text_field($_POST['license_key'] ?? '');
  if (empty($license_key)) {
    wp_send_json_error('License key required');
    return;
  }
  
  $transcript = luna_get_chat_transcript($license_key);
  wp_send_json_success(array('transcript' => $transcript));
});

/* ============================================================
 * KEYWORD MAPPING SYSTEM
 * ============================================================ */

// Default keyword mappings with response templates
function luna_get_default_keywords() {
  return [
    'business' => [
      'appointment' => [
        'enabled' => 'on',
        'keywords' => ['booking', 'schedule', 'visit', 'consultation'],
        'template' => 'To schedule an appointment, please call our office or use our online booking system. You can find our contact information on our website.',
        'data_source' => 'custom'
      ],
      'contact' => [
        'enabled' => 'on',
        'keywords' => ['phone', 'email', 'reach', 'get in touch'],
        'template' => 'You can reach us through our contact page or by calling our main office number. Our contact information is available on our website.',
        'data_source' => 'custom'
      ],
      'hours' => [
        'enabled' => 'on',
        'keywords' => ['open', 'closed', 'business hours', 'availability'],
        'template' => 'Our business hours are typically Monday through Friday, 9 AM to 5 PM. Please check our website for the most current hours and holiday schedules.',
        'data_source' => 'custom'
      ],
      'location' => [
        'enabled' => 'on',
        'keywords' => ['address', 'where', 'directions', 'find us'],
        'template' => 'You can find our address and directions on our website\'s contact page. We\'re located in a convenient area with parking available.',
        'data_source' => 'custom'
      ],
      'services' => [
        'enabled' => 'on',
        'keywords' => ['what we do', 'offerings', 'treatments', 'care'],
        'template' => 'We offer a comprehensive range of services. Please visit our services page on our website for detailed information about what we provide.',
        'data_source' => 'custom'
      ],
      'providers' => [
        'enabled' => 'on',
        'keywords' => ['doctors', 'staff', 'team', 'physicians'],
        'template' => 'Our team of experienced providers is dedicated to your care. You can learn more about our staff on our website\'s team page.',
        'data_source' => 'custom'
      ],
      'insurance' => [
        'enabled' => 'on',
        'keywords' => ['coverage', 'accepted', 'billing', 'payment'],
        'template' => 'We accept most major insurance plans. Please contact our billing department to verify your coverage and discuss payment options.',
        'data_source' => 'custom'
      ],
      'forms' => [
        'enabled' => 'on',
        'keywords' => ['paperwork', 'documents', 'download', 'patient forms'],
        'template' => 'You can download patient forms from our website or pick them up at our office. Please complete them before your visit to save time.',
        'data_source' => 'custom'
      ]
    ],
    'wp_rest' => [
      'pages' => [
        'enabled' => 'on',
        'keywords' => ['page names', 'what pages', 'list pages', 'site pages'],
        'template' => 'Your pages are: {pages_list}.',
        'data_source' => 'wp_rest'
      ],
      'posts' => [
        'enabled' => 'on',
        'keywords' => ['blog posts', 'articles', 'news', 'content'],
        'template' => 'Your posts are: {posts_list}.',
        'data_source' => 'wp_rest'
      ],
      'themes' => [
        'enabled' => 'on',
        'keywords' => ['theme info', 'design', 'appearance', 'look'],
        'template' => 'Your themes are: {themes_list}.',
        'data_source' => 'wp_rest'
      ],
      'plugins' => [
        'enabled' => 'on',
        'keywords' => ['add-ons', 'extensions', 'tools', 'features'],
        'template' => 'Your plugins are: {plugins_list}.',
        'data_source' => 'wp_rest'
      ],
      'users' => [
        'enabled' => 'on',
        'keywords' => ['admin', 'administrators', 'who can login'],
        'template' => 'You have {user_count} user{user_plural} with access to your site.',
        'data_source' => 'wp_rest'
      ],
      'updates' => [
        'enabled' => 'on',
        'keywords' => ['outdated', 'new version', 'upgrade', 'patches'],
        'template' => 'Updates pending — plugins: {plugin_updates}, themes: {theme_updates}, WordPress Core: {core_updates}.',
        'data_source' => 'wp_rest'
      ],
      'media' => [
        'enabled' => 'on',
        'keywords' => ['images', 'files', 'uploads', 'gallery'],
        'template' => 'Media information is available in your WordPress dashboard under Media.',
        'data_source' => 'custom'
      ]
    ],
    'security' => [
      'ssl' => [
        'enabled' => 'on',
        'keywords' => ['certificate', 'https', 'secure', 'encrypted'],
        'template' => '{ssl_status}',
        'data_source' => 'security'
      ],
      'firewall' => [
        'enabled' => 'on',
        'keywords' => ['protection', 'security', 'blocking', 'defense'],
        'template' => 'Firewall protection status is available in your security settings. Please check the Security tab in Visible Light for detailed firewall information.',
        'data_source' => 'security'
      ],
      'backup' => [
        'enabled' => 'on',
        'keywords' => ['backup', 'restore', 'recovery', 'safety'],
        'template' => 'Backup information is available in your security profile. Please check the Security tab in Visible Light for backup status and schedules.',
        'data_source' => 'security'
      ],
      'monitoring' => [
        'enabled' => 'on',
        'keywords' => ['scan', 'threats', 'vulnerabilities', 'alerts'],
        'template' => 'Security monitoring details are available in your security profile. Please check the Security tab in Visible Light for scan results and alerts.',
        'data_source' => 'security'
      ],
      'access' => [
        'enabled' => 'on',
        'keywords' => ['login', 'authentication', 'permissions', 'users'],
        'template' => 'You have {user_count} user{user_plural} with access to your site.',
        'data_source' => 'wp_rest'
      ],
      'compliance' => [
        'enabled' => 'on',
        'keywords' => ['hipaa', 'gdpr', 'standards', 'regulations'],
        'template' => 'Compliance information is available in your security profile. Please check the Security tab in Visible Light for compliance status and requirements.',
        'data_source' => 'security'
      ]
    ]
  ];
}

// Get current keyword mappings
function luna_get_keyword_mappings() {
  $custom = get_option('luna_keyword_mappings', []);
  
  // If we have custom data, return it directly
  if (!empty($custom)) {
    return $custom;
  }
  
  // Otherwise, return defaults
  return luna_get_default_keywords();
}

// Save keyword mappings
function luna_save_keyword_mappings($mappings) {
  // Debug: Log what's being processed
  error_log('Luna Keywords: Processing mappings: ' . print_r($mappings, true));
  
  // Process the new data structure
  $processed_mappings = array();
  
  foreach ($mappings as $category => $actions) {
    foreach ($actions as $action => $config) {
      // Skip if no keywords or empty config
      if (empty($config['keywords']) || !is_array($config['keywords'])) {
        continue;
      }
      
      $processed_config = array(
        'enabled' => $config['enabled'] ?? 'on',
        'keywords' => $config['keywords'] ?? array(),
        'data_source' => $config['data_source'] ?? 'custom',
        'response_type' => $config['response_type'] ?? 'simple'
      );
      
      // Only process active keywords for template processing
      if ($processed_config['enabled'] === 'on') {
        // Handle different data sources
        switch ($config['data_source']) {
          case 'wp_rest':
            $processed_config['wp_template'] = $config['wp_template'] ?? '';
            break;
          case 'security':
            $processed_config['security_template'] = $config['security_template'] ?? '';
            break;
          case 'custom':
          default:
            if ($config['response_type'] === 'advanced') {
              $processed_config['initial_response'] = $config['initial_response'] ?? '';
              $processed_config['branches'] = $config['branches'] ?? array();
            } else {
              $processed_config['template'] = $config['template'] ?? '';
            }
            break;
        }
      } else {
        // For disabled keywords, just store basic info without templates
        error_log("Luna Keywords: Storing disabled keyword - {$category}.{$action}");
      }
      
      $processed_mappings[$category][$action] = $processed_config;
    }
  }
  
  // Debug: Log what's being stored
  error_log('Luna Keywords: Final processed mappings: ' . print_r($processed_mappings, true));
  
  // Visual debug - show what's being processed
  echo '<div class="notice notice-info"><p><strong>DEBUG:</strong> Final processed mappings: ' . esc_html(print_r($processed_mappings, true)) . '</p></div>';
  
  update_option('luna_keyword_mappings', $processed_mappings);
  
  // Debug: Verify what was stored
  $stored = get_option('luna_keyword_mappings', array());
  error_log('Luna Keywords: Verified stored data: ' . print_r($stored, true));
  
  // Visual debug - show what was stored
  echo '<div class="notice notice-info"><p><strong>DEBUG:</strong> Verified stored data: ' . esc_html(print_r($stored, true)) . '</p></div>';
  
  // Send to Hub
  luna_sync_keywords_to_hub($processed_mappings);
}

// Sync keywords to Hub
function luna_sync_keywords_to_hub($mappings) {
  $license = luna_get_license();
  if (!$license) return;
  
  $response = wp_remote_post('https://visiblelight.ai/wp-json/luna_widget/v1/keywords/sync', [
    'timeout' => 10,
    'headers' => ['X-Luna-License' => $license, 'Content-Type' => 'application/json'],
    'body' => json_encode(['keywords' => $mappings])
  ]);
  
  if (is_wp_error($response)) {
    error_log('[Luna] Failed to sync keywords to Hub: ' . $response->get_error_message());
  }
}

// Sync analytics data to Hub
function luna_sync_analytics_to_hub($analytics_data) {
  $license = luna_get_license();
  if (!$license) return;

  $endpoint = luna_widget_hub_base() . '/wp-json/vl-hub/v1/sync-client-data';
  delete_transient('luna_ga4_metrics_' . md5($license));

  $response = wp_remote_post($endpoint, [
    'timeout' => 10,
    'headers' => ['X-Luna-License' => $license, 'Content-Type' => 'application/json'],
    'body' => json_encode([
      'license' => $license,
      'category' => 'analytics',
      'analytics_data' => $analytics_data
    ])
  ]);

  if (is_wp_error($response)) {
    error_log('[Luna] Failed to sync analytics to Hub: ' . $response->get_error_message());
  }
}

// Fetch data streams from Hub and extract GA4 metrics
function luna_fetch_hub_data_streams_direct($license = null) {
  if (!$license) {
    $license = luna_get_license();
  }
  if (!$license) {
    return array();
  }

  $streams = array();

  // Try pulling directly from the Hub/License manager if it's available locally
  if (class_exists('VL_License_Manager') && method_exists('VL_License_Manager', 'get_license_streams')) {
    try {
      $direct_streams = VL_License_Manager::get_license_streams($license);
      if (is_array($direct_streams) && !empty($direct_streams)) {
        $streams = $direct_streams;
      }
    } catch (Throwable $e) {
      error_log('[Luna] Direct stream fetch via VL_License_Manager failed: ' . $e->getMessage());
    }
  }

  // Some Hub installs expose a helper object instead of the license manager class
  if (empty($streams) && class_exists('VL_Hub_Profile')) {
    try {
      $hub_profile = VL_Hub_Profile::get_instance();
      if ($hub_profile && method_exists($hub_profile, 'get_license_streams')) {
        $direct_streams = $hub_profile->get_license_streams($license);
        if (is_array($direct_streams) && !empty($direct_streams)) {
          $streams = $direct_streams;
        }
      } elseif ($hub_profile && method_exists($hub_profile, 'data_streams_store_get')) {
        $store = $hub_profile->data_streams_store_get();
        if (is_array($store) && isset($store[$license]) && is_array($store[$license])) {
          $streams = $store[$license];
        }
      }
    } catch (Throwable $e) {
      error_log('[Luna] Direct stream fetch via VL_Hub_Profile failed: ' . $e->getMessage());
    }
  }

  // Fallback: read the raw option the Hub uses to store streams (if present)
  if (empty($streams)) {
    $store = get_option('vl_data_streams', array());
    if (is_array($store) && isset($store[$license]) && is_array($store[$license])) {
      $streams = $store[$license];
    }
  }

  if (!is_array($streams) || empty($streams)) {
    return array();
  }

  // Normalize to a simple indexed array and ensure each stream has a stable identifier
  $normalized = array();
  foreach ($streams as $stream_id => $stream_data) {
    if (!is_array($stream_data)) {
      continue;
    }

    if (!isset($stream_data['_id'])) {
      if (isset($stream_data['id'])) {
        $stream_data['_id'] = $stream_data['id'];
      } elseif (isset($stream_data['stream_id'])) {
        $stream_data['_id'] = $stream_data['stream_id'];
      } elseif (is_string($stream_id) || is_numeric($stream_id)) {
        $stream_data['_id'] = (string) $stream_id;
      }
    }

    $normalized[] = $stream_data;
  }

  return $normalized;
}

function luna_fetch_hub_data_streams($license = null) {
  if (!$license) {
    $license = luna_get_license();
  }
  if (!$license) return null;

  $base = luna_widget_hub_base();
  
  // Try all-connections endpoint first (primary source for GA4 and other streams)
  $url = add_query_arg(array('license' => $license), $base . '/wp-json/vl-hub/v1/all-connections');
  $response = wp_remote_get($url, array(
    'timeout' => 12,
    'headers' => array(
      'X-Luna-License' => $license,
      'X-Luna-Site'    => home_url('/'),
      'Accept'         => 'application/json',
    ),
    'sslverify' => true,
  ));

  $streams = array();
  
  if (!is_wp_error($response)) {
    $code = (int) wp_remote_retrieve_response_code($response);
    if ($code >= 200 && $code < 300) {
      $body = json_decode(wp_remote_retrieve_body($response), true);
      if (is_array($body)) {
        $body = luna_hub_normalize_payload($body);
        if (is_array($body)) {
          // Extract streams from all-connections endpoint
          if (isset($body['streams']) && is_array($body['streams'])) {
            foreach ($body['streams'] as $stream_id => $stream_data) {
              if (is_array($stream_data)) {
                if (!isset($stream_data['_id'])) {
                  $stream_data['_id'] = is_string($stream_id) ? $stream_id : null;
                }
                $streams[] = $stream_data;
              }
            }
          } elseif (is_array($body) && !isset($body['streams'])) {
            // If body is directly an array of streams
            foreach ($body as $stream_id => $stream_data) {
              if (is_array($stream_data) && (isset($stream_data['ga4_metrics']) || isset($stream_data['categories']) || isset($stream_data['status']))) {
                if (!isset($stream_data['_id'])) {
                  $stream_data['_id'] = is_string($stream_id) ? $stream_id : null;
                }
                $streams[] = $stream_data;
              }
            }
          }
        }
      }
    }
  }
  
  // If no streams found from all-connections, fallback to data-streams endpoint
  if (empty($streams)) {
    $url = add_query_arg(array('license' => $license), $base . '/wp-json/vl-hub/v1/data-streams');
    $response = wp_remote_get($url, array(
      'timeout' => 12,
      'headers' => array(
        'X-Luna-License' => $license,
        'X-Luna-Site'    => home_url('/'),
        'Accept'         => 'application/json',
      ),
      'sslverify' => true,
    ));

    if (is_wp_error($response)) {
      error_log('[Luna] Error fetching Hub data streams: ' . $response->get_error_message());
      return $streams; // Return empty array or whatever we found from all-connections
    }

    $code = (int) wp_remote_retrieve_response_code($response);
    if ($code >= 200 && $code < 300) {
      $raw_body = wp_remote_retrieve_body($response);
      $body = json_decode($raw_body, true);
      if (is_array($body)) {
        error_log('[Luna] ✅ Received data-streams response with keys: ' . implode(', ', array_keys($body)));
        
        // CRITICAL: The data-streams endpoint returns {"success":true,"client_streams":{...}}
        // We MUST extract client_streams, not just look for 'streams'
        $streams_raw = array();
        
        if (isset($body['client_streams']) && is_array($body['client_streams'])) {
          // This is the correct structure from /wp-json/vl-hub/v1/data-streams
          $streams_raw = $body['client_streams'];
          error_log('[Luna] ✅ Extracted client_streams: ' . count($streams_raw) . ' streams found');
        } elseif (isset($body['streams']) && is_array($body['streams'])) {
          // Fallback for other endpoint structures
          $streams_raw = $body['streams'];
          error_log('[Luna] ✅ Extracted streams: ' . count($streams_raw) . ' streams found');
        } elseif (is_array($body) && !isset($body['success']) && !isset($body['client_streams']) && !isset($body['streams'])) {
          // Body is directly an array of streams
          $streams_raw = $body;
          error_log('[Luna] ✅ Body is directly streams array: ' . count($streams_raw) . ' streams found');
        } else {
          error_log('[Luna] ⚠️ Unexpected data-streams response structure. Keys: ' . implode(', ', array_keys($body)));
        }

        if (!empty($streams_raw)) {
          foreach ($streams_raw as $stream_id => $stream_data) {
            if (is_array($stream_data)) {
              // Skip removed streams (they have removed_at field)
              if (isset($stream_data['removed_at']) && !empty($stream_data['removed_at'])) {
                continue;
              }
              
              if (!isset($stream_data['_id'])) {
                $stream_data['_id'] = is_string($stream_id) ? $stream_id : null;
              }
              // Preserve the stream_id as the key
              if (!isset($stream_data['stream_id'])) {
                $stream_data['stream_id'] = is_string($stream_id) ? $stream_id : null;
              }
              $streams[] = $stream_data;
            }
          }
          error_log('[Luna] ✅ Processed ' . count($streams) . ' active streams from data-streams endpoint');
        } else {
          error_log('[Luna] ⚠️ No streams found in data-streams response');
        }
      } else {
        error_log('[Luna] ❌ Invalid JSON response from data-streams endpoint: ' . substr($raw_body, 0, 200));
      }
    } else {
      error_log('[Luna] ❌ HTTP ' . $code . ' error from data-streams endpoint');
    }
  }

  return $streams;
}

function luna_extract_ga4_metrics_from_streams($streams) {
  if (!is_array($streams)) return null;

  foreach ($streams as $stream) {
    if (!is_array($stream)) continue;

    if (!empty($stream['ga4_metrics']) && is_array($stream['ga4_metrics'])) {
      $result = array(
        'metrics'        => $stream['ga4_metrics'],
        'last_synced'    => isset($stream['ga4_last_synced']) ? $stream['ga4_last_synced'] : (isset($stream['last_updated']) ? $stream['last_updated'] : null),
        'date_range'     => isset($stream['ga4_date_range']) ? $stream['ga4_date_range'] : null,
        'source_url'     => isset($stream['source_url']) ? $stream['source_url'] : null,
        'property_id'    => isset($stream['ga4_property_id']) ? $stream['ga4_property_id'] : null,
        'measurement_id' => isset($stream['ga4_measurement_id']) ? $stream['ga4_measurement_id'] : null,
      );
      
      // Extract GA4 dimensional data if available
      // Check for nested structure first (ga4_dimensions.geographic.rows)
      if (isset($stream['ga4_dimensions']) && is_array($stream['ga4_dimensions']) && !empty($stream['ga4_dimensions'])) {
        $result['dimensions'] = $stream['ga4_dimensions'];
        error_log('[Luna] GA4 dimensions extracted from stream (nested structure): ' . count($stream['ga4_dimensions']) . ' types');
      }
      // Also check for legacy flat arrays (ga4_geographic, ga4_device, etc.)
      elseif (isset($stream['ga4_geographic']) || isset($stream['ga4_device']) || isset($stream['ga4_traffic']) || isset($stream['ga4_pages']) || isset($stream['ga4_events'])) {
        $result['dimensions'] = array();
        if (isset($stream['ga4_geographic']) && is_array($stream['ga4_geographic'])) {
          $result['dimensions']['geographic'] = array('rows' => $stream['ga4_geographic']);
        }
        if (isset($stream['ga4_device']) && is_array($stream['ga4_device'])) {
          $result['dimensions']['device'] = array('rows' => $stream['ga4_device']);
        }
        if (isset($stream['ga4_traffic']) && is_array($stream['ga4_traffic'])) {
          $result['dimensions']['traffic'] = array('rows' => $stream['ga4_traffic']);
        }
        if (isset($stream['ga4_pages']) && is_array($stream['ga4_pages'])) {
          $result['dimensions']['pages'] = array('rows' => $stream['ga4_pages']);
        }
        if (isset($stream['ga4_events']) && is_array($stream['ga4_events'])) {
          $result['dimensions']['events'] = array('rows' => $stream['ga4_events']);
        }
        if (isset($stream['ga4_page_location']) && is_array($stream['ga4_page_location'])) {
          $result['dimensions']['page_location'] = array('rows' => $stream['ga4_page_location']);
        }
        error_log('[Luna] GA4 dimensions built from legacy flat arrays: ' . count($result['dimensions']) . ' types');
      }
      
      return $result;
    }
  }

  return null;
}

function luna_fetch_ga4_metrics_from_hub($license = null) {
  if (!$license) {
    $license = luna_get_license();
  }
  if (!$license) return null;

  $cache_key = 'luna_ga4_metrics_' . md5($license);
  $cached    = get_transient($cache_key);
  if (is_array($cached)) {
    return $cached;
  }

  $streams = luna_fetch_hub_data_streams($license);
  if (!$streams) {
    return null;
  }

  $ga4_info = luna_extract_ga4_metrics_from_streams($streams);
  if ($ga4_info) {
    set_transient($cache_key, $ga4_info, 5 * MINUTE_IN_SECONDS);
  }

  return $ga4_info;
}

// Sync security data to Hub
function luna_sync_security_to_hub($security_data) {
  $license = luna_get_license();
  if (!$license) return;

  $endpoint = luna_widget_hub_base() . '/wp-json/vl-hub/v1/sync-client-data';
  $response = wp_remote_post($endpoint, [
    'timeout' => 10,
    'headers' => ['X-Luna-License' => $license, 'Content-Type' => 'application/json'],
    'body' => json_encode([
      'license' => $license,
      'category' => 'security',
      'security_data' => $security_data
    ])
  ]);
  
  if (is_wp_error($response)) {
    error_log('[Luna] Failed to sync security to Hub: ' . $response->get_error_message());
  }
}

// Sync settings data to Hub
function luna_sync_settings_to_hub($settings_data) {
  $license = luna_get_license();
  if (!$license) return;

  $endpoint = luna_widget_hub_base() . '/wp-json/vl-hub/v1/sync-client-data';
  $response = wp_remote_post($endpoint, [
    'timeout' => 10,
    'headers' => ['X-Luna-License' => $license, 'Content-Type' => 'application/json'],
    'body' => json_encode([
      'license' => $license,
      'category' => 'infrastructure',
      'settings_data' => $settings_data
    ])
  ]);
  
  if (is_wp_error($response)) {
    error_log('[Luna] Failed to sync settings to Hub: ' . $response->get_error_message());
  }
}

// Get data from Hub for Luna Chat Widget
function luna_get_hub_data($category = null) {
  $license = luna_get_license();
  if (!$license) return null;
  
  // Get profile data from VL Hub which includes GA4 analytics
  $url = luna_widget_hub_base() . '/wp-json/vl-hub/v1/profile';
  $args = ['license' => $license];
  if ($category) {
    $args['category'] = $category;
  }
  
  $response = wp_remote_get(add_query_arg($args, $url), [
    'timeout' => 10,
    'headers' => ['X-Luna-License' => $license]
  ]);
  
  if (is_wp_error($response)) {
    error_log('[Luna] Failed to get data from Hub: ' . $response->get_error_message());
    return null;
  }
  
  $body = wp_remote_retrieve_body($response);
  $data = json_decode($body, true);
  
  // Extract GA4 metrics if available
  if (isset($data['ga4_metrics'])) {
    $data['analytics'] = $data['ga4_metrics'];
  }
  
  return $data;
}

/**
 * Fetch competitor analysis data from Hub.
 * 
 * @param string|null $license License key
 * @return array|null Competitor data or null on failure
 */
function luna_fetch_competitor_data($license = null) {
  if (!$license) {
    $license = luna_get_license();
  }
  if (!$license) return null;

  $hub_url = luna_widget_hub_base();
  $url = $hub_url . '/wp-json/vl-hub/v1/competitor-report';
  
  // First, get competitor URLs from settings
  $competitor_urls = array();
  $response = wp_remote_get($hub_url . '/wp-json/vl-hub/v1/profile?license=' . rawurlencode($license), array(
    'timeout' => 10,
    'headers' => array('X-Luna-License' => $license),
  ));

  if (!is_wp_error($response)) {
    $code = wp_remote_retrieve_response_code($response);
    if ($code === 200) {
      $body = wp_remote_retrieve_body($response);
      $profile = json_decode($body, true);
      if (is_array($profile)) {
        $profile = luna_hub_normalize_payload($profile);
      } else {
        $profile = null;
      }

      // Extract competitor URLs from enriched profile
      if (is_array($profile) && isset($profile['competitors']) && is_array($profile['competitors'])) {
        foreach ($profile['competitors'] as $competitor) {
          if (!empty($competitor['url'])) {
            $competitor_urls[] = $competitor['url'];
          } elseif (!empty($competitor['domain'])) {
            $competitor_urls[] = 'https://' . $competitor['domain'];
          }
        }
      }
    }
  }

  if (!empty($competitor_urls)) {
    $competitor_urls = array_values(array_unique(array_filter($competitor_urls)));
  }

  // Fetch reports for each competitor
  $competitor_reports = array();
  foreach ($competitor_urls as $competitor_url) {
    $report_url = add_query_arg(array(
      'license' => $license,
      'competitor_url' => $competitor_url,
    ), $url);

    $report_response = wp_remote_get($report_url, array(
      'timeout' => 10,
      'headers' => array('X-Luna-License' => $license),
    ));
    
    if (!is_wp_error($report_response)) {
      $report_code = wp_remote_retrieve_response_code($report_response);
      if ($report_code === 200) {
        $report_body = wp_remote_retrieve_body($report_response);
        $report_data = json_decode($report_body, true);
        
        if (!is_array($report_data)) {
          continue;
        }

        $report_payload = null;
        if (isset($report_data['success']) && $report_data['success'] && isset($report_data['report']) && is_array($report_data['report'])) {
          $report_payload = $report_data['report'];
        } elseif (isset($report_data['ok']) && $report_data['ok'] && isset($report_data['data']) && is_array($report_data['data'])) {
          $report_payload = $report_data['data'];
        }

        if ($report_payload === null) {
          continue;
        }

        $domain = parse_url($competitor_url, PHP_URL_HOST);
        if (!$domain) {
          $domain = $competitor_url;
        }

        $competitor_reports[] = array(
          'url' => $competitor_url,
          'domain' => $domain,
          'report' => $report_payload,
          'last_scanned' => $report_data['last_scanned'] ?? null,
          'status' => $report_data['status'] ?? null,
        );
      }
    }
  }
  
  return !empty($competitor_reports) ? array(
    'competitors' => $competitor_urls,
    'reports' => $competitor_reports,
  ) : null;
}

/**
 * Fetch VLDR (Domain Ranking) data from Hub with caching.
 * 
 * @param string $domain Domain to check
 * @param string|null $license License key
 * @return array|null VLDR data or null on failure
 */
function luna_fetch_vldr_data($domain, $license = null) {
  if (!$license) {
    $license = luna_get_license();
  }
  if (!$license || empty($domain)) return null;

  // Clean domain
  $domain = preg_replace('/^https?:\/\//', '', $domain);
  $domain = preg_replace('/^www\./', '', $domain);
  $domain = rtrim($domain, '/');
  $domain = strtolower($domain);

  // Cache key with 30-minute TTL
  $cache_key = 'luna_vldr_' . md5($license . '|' . $domain);
  $cached = get_transient($cache_key);
  if ($cached !== false && is_array($cached)) {
    return $cached;
  }

  // Fetch from Hub REST API
  $hub_url = luna_widget_hub_base();
  $url = $hub_url . '/wp-json/vl-hub/v1/vldr?license=' . rawurlencode($license) . '&domain=' . rawurlencode($domain);

  $response = wp_remote_get($url, array(
    'timeout' => 15,
    'sslverify' => true,
    'headers' => array(
      'Accept' => 'application/json',
      'X-Luna-License' => $license,
    ),
  ));

  if (is_wp_error($response)) {
    error_log('[Luna VLDR] Error fetching from Hub: ' . $response->get_error_message());
    return null;
  }

  $code = wp_remote_retrieve_response_code($response);
  if ($code !== 200) {
    error_log('[Luna VLDR] HTTP ' . $code . ' from Hub for domain: ' . $domain);
    return null;
  }

  $body = wp_remote_retrieve_body($response);
  $data = json_decode($body, true);

  if (!is_array($data)) {
    error_log('[Luna VLDR] Invalid JSON response from Hub');
    return null;
  }

  // Check for success response
  if (!empty($data['ok']) && !empty($data['data']) && is_array($data['data'])) {
    $vldr_data = $data['data'];
    
    // Cache for 30 minutes
    set_transient($cache_key, $vldr_data, 30 * MINUTE_IN_SECONDS);
    
    return $vldr_data;
  }

  // Check for direct data structure (if no wrapper)
  if (!empty($data['domain']) && isset($data['vldr_score'])) {
    set_transient($cache_key, $data, 30 * MINUTE_IN_SECONDS);
    return $data;
  }

  return null;
}

// Get interactions count for Luna Widget
function luna_get_interactions_count() {
  $license = luna_get_license();
  if (!$license) return 0;
  
  // Get interactions count from stored data
  $interactions_data = get_option('luna_interactions_' . $license, array());
  return isset($interactions_data['total_interactions']) ? (int)$interactions_data['total_interactions'] : 0;
}

function luna_get_ai_chat_metrics() {
  // Get all conversations
  $all_conversations = get_posts(array(
    'post_type'      => 'luna_widget_convo',
    'post_status'    => 'publish',
    'posts_per_page' => -1,
    'orderby'        => 'date',
    'order'          => 'DESC',
    'fields'         => 'ids',
  ));
  
  $metrics = array(
    'total_conversations' => 0,
    'total_messages' => 0,
    'active_conversations' => 0,
    'closed_conversations' => 0,
    'conversations_today' => 0,
    'conversations_this_week' => 0,
    'conversations_this_month' => 0,
    'average_messages_per_conversation' => 0,
    'total_user_messages' => 0,
    'total_assistant_messages' => 0,
  );
  
  if (empty($all_conversations)) {
    return $metrics;
  }
  
  $today = strtotime('today');
  $week_ago = strtotime('-7 days');
  $month_ago = strtotime('-30 days');
  
  $total_messages = 0;
  $total_user = 0;
  $total_assistant = 0;
  
  foreach ($all_conversations as $post_id) {
    $post_date = get_post_time('U', false, $post_id);
    $transcript = get_post_meta($post_id, 'transcript', true);
    $session_closed = get_post_meta($post_id, 'session_closed', true);
    
    if (!is_array($transcript)) {
      $transcript = array();
    }
    
    $message_count = count($transcript);
    $total_messages += $message_count;
    
    // Count user and assistant messages
    foreach ($transcript as $turn) {
      if (!empty($turn['user'])) {
        $total_user++;
      }
      if (!empty($turn['assistant'])) {
        $total_assistant++;
      }
    }
    
    // Count conversations by time period
    if ($post_date >= $today) {
      $metrics['conversations_today']++;
    }
    if ($post_date >= $week_ago) {
      $metrics['conversations_this_week']++;
    }
    if ($post_date >= $month_ago) {
      $metrics['conversations_this_month']++;
    }
    
    // Count active vs closed
    if ($session_closed) {
      $metrics['closed_conversations']++;
    } else {
      $metrics['active_conversations']++;
    }
  }
  
  $metrics['total_conversations'] = count($all_conversations);
  $metrics['total_messages'] = $total_messages;
  $metrics['total_user_messages'] = $total_user;
  $metrics['total_assistant_messages'] = $total_assistant;
  
  if ($metrics['total_conversations'] > 0) {
    $metrics['average_messages_per_conversation'] = round($total_messages / $metrics['total_conversations'], 1);
  }
  
  wp_reset_postdata();
  
  return $metrics;
}

// Get chat transcript for Luna Widget
function luna_get_chat_transcript($license_key) {
  if (empty($license_key)) return array();
  
  // Get chat transcript from stored data
  $transcript_data = get_option('luna_chat_transcript_' . $license_key, array());
  return $transcript_data;
}

// Calculate SEO score for posts and pages
function luna_calculate_seo_score($post_id) {
  $score = 0;
  $max_score = 100;
  
  // Title (20 points)
  $title = get_the_title($post_id);
  if (!empty($title)) {
    $score += 20;
    if (strlen($title) >= 30 && strlen($title) <= 60) {
      $score += 5; // Bonus for optimal length
    }
  }
  
  // Content (20 points)
  $content = get_post_field('post_content', $post_id);
  if (!empty($content)) {
    $score += 20;
    if (str_word_count($content) >= 300) {
      $score += 10; // Bonus for substantial content
    }
  }
  
  // Excerpt (10 points)
  $excerpt = get_the_excerpt($post_id);
  if (!empty($excerpt)) {
    $score += 10;
  }
  
  // Featured image (10 points)
  if (has_post_thumbnail($post_id)) {
    $score += 10;
  }
  
  // Categories/Tags (10 points)
  $categories = wp_get_post_terms($post_id, 'category');
  $tags = wp_get_post_terms($post_id, 'post_tag');
  if (!empty($categories) || !empty($tags)) {
    $score += 10;
  }
  
  // Meta description (10 points)
  $meta_description = get_post_meta($post_id, '_yoast_wpseo_metadesc', true);
  if (empty($meta_description)) {
    $meta_description = get_post_meta($post_id, '_aioseo_description', true);
  }
  if (!empty($meta_description)) {
    $score += 10;
  }
  
  // Focus keyword (10 points)
  $focus_keyword = get_post_meta($post_id, '_yoast_wpseo_focuskw', true);
  if (empty($focus_keyword)) {
    $focus_keyword = get_post_meta($post_id, '_aioseo_keywords', true);
  }
  if (!empty($focus_keyword)) {
    $score += 10;
  }
  
  // Internal links (5 points)
  if (strpos($content, '<a href="' . home_url()) !== false) {
    $score += 5;
  }
  
  // External links (5 points)
  if (preg_match('/<a href="(?!' . preg_quote(home_url(), '/') . ')/', $content)) {
    $score += 5;
  }
  
  return min($score, $max_score);
}

// Track keyword usage and performance
function luna_track_keyword_usage($keyword_match, $response_success = true) {
  $usage_stats = get_option('luna_keyword_usage', []);
  
  $key = $keyword_match['category'] . '.' . $keyword_match['action'];
  
  if (!isset($usage_stats[$key])) {
    $usage_stats[$key] = [
      'total_uses' => 0,
      'successful_uses' => 0,
      'failed_uses' => 0,
      'last_used' => current_time('mysql'),
      'keywords' => $keyword_match['matched_term']
    ];
  }
  
  $usage_stats[$key]['total_uses']++;
  $usage_stats[$key]['last_used'] = current_time('mysql');
  
  if ($response_success) {
    $usage_stats[$key]['successful_uses']++;
  } else {
    $usage_stats[$key]['failed_uses']++;
  }
  
  update_option('luna_keyword_usage', $usage_stats);
}

// Get keyword performance statistics
function luna_get_keyword_performance() {
  $usage_stats = get_option('luna_keyword_usage', []);
  $performance = [];
  
  foreach ($usage_stats as $key => $stats) {
    $success_rate = $stats['total_uses'] > 0 ? ($stats['successful_uses'] / $stats['total_uses']) * 100 : 0;
    
    $performance[$key] = [
      'total_uses' => $stats['total_uses'],
      'success_rate' => round($success_rate, 1),
      'last_used' => $stats['last_used'],
      'keywords' => $stats['keywords']
    ];
  }
  
  // Sort by total uses (most popular first)
  uasort($performance, function($a, $b) {
    return $b['total_uses'] - $a['total_uses'];
  });
  
  return $performance;
}

// Check if user input matches any keywords
function luna_check_keyword_mappings($user_input) {
  $mappings = luna_get_keyword_mappings();
  $lc_input = strtolower(trim($user_input));
  
  // Debug: Log what we're checking
  error_log('Luna Keywords: Checking input: "' . $lc_input . '"');
  
  foreach ($mappings as $category => $keywords) {
    foreach ($keywords as $action => $config) {
      // Skip disabled keywords
      if (isset($config['enabled']) && $config['enabled'] !== 'on') {
        continue;
      }
      
      // Handle both old format (array of terms) and new format (config object)
      $terms = is_array($config) && isset($config['keywords']) ? $config['keywords'] : $config;
      
      if (!is_array($terms)) {
        continue;
      }
      
      foreach ($terms as $term) {
        $lc_term = strtolower(trim($term));
        if (empty($lc_term)) continue;
        
        // Use word boundary matching for more precise matching
        if (preg_match('/\b' . preg_quote($lc_term, '/') . '\b/', $lc_input)) {
          error_log('Luna Keywords: Matched term "' . $lc_term . '" for ' . $category . '.' . $action);
          return [
            'category' => $category,
            'action' => $action,
            'matched_term' => $term,
            'config' => is_array($config) && isset($config['template']) ? $config : null
          ];
        }
      }
    }
  }
  
  error_log('Luna Keywords: No keyword matches found');
  return null;
}

// Handle keyword-based responses using templates
function luna_handle_keyword_response($keyword_match, $facts) {
  $category = $keyword_match['category'];
  $action = $keyword_match['action'];
  $matched_term = $keyword_match['matched_term'];
  $config = $keyword_match['config'];
  
  // If we have a template config, use it
  if ($config) {
    $data_source = $config['data_source'] ?? 'custom';
    $response_type = $config['response_type'] ?? 'simple';
    
    switch ($data_source) {
      case 'wp_rest':
        return luna_process_response_template($config['wp_template'] ?? '', 'wp_rest', $facts);
      case 'security':
        return luna_process_response_template($config['security_template'] ?? '', 'security', $facts);
      case 'custom':
      default:
        if ($response_type === 'advanced') {
          // For advanced responses, we'll return the initial response
          // The branching logic would be handled in a more complex conversation flow
          return luna_process_response_template($config['initial_response'] ?? '', 'custom', $facts);
        } else {
          return luna_process_response_template($config['template'] ?? '', 'custom', $facts);
        }
    }
  }
  
  // Fallback to old system for backward compatibility
  switch ($category) {
    case 'business':
      return luna_handle_business_keyword($action, $facts);
      
    case 'wp_rest':
      return luna_handle_wp_rest_keyword($action, $facts);
      
    case 'security':
      return luna_handle_security_keyword($action, $facts);
      
    default:
      return null;
  }
}

// Process response templates with dynamic data
function luna_process_response_template($template, $data_source, $facts) {
  $response = $template;
  
  // Replace template variables based on data source
  switch ($data_source) {
    case 'wp_rest':
      $response = luna_replace_wp_rest_variables($response, $facts);
      break;
      
    case 'security':
      $response = luna_replace_security_variables($response, $facts);
      break;
      
    case 'custom':
      $response = luna_replace_custom_shortcodes($response, $facts);
      break;
  }
  
  return $response;
}

// Replace WP REST API variables in templates
function luna_replace_wp_rest_variables($template, $facts) {
  $replacements = [];
  
  // Pages list
  if (strpos($template, '{pages_list}') !== false) {
    if (isset($facts['pages']) && is_array($facts['pages']) && !empty($facts['pages'])) {
      $page_names = array();
      foreach ($facts['pages'] as $page) {
        $status = isset($page['status']) ? $page['status'] : 'published';
        $page_names[] = $page['title'] . " (" . $status . ")";
      }
      $replacements['{pages_list}'] = implode(", ", $page_names);
    } else {
      $replacements['{pages_list}'] = "No pages found";
    }
  }
  
  // Posts list
  if (strpos($template, '{posts_list}') !== false) {
    if (isset($facts['posts']) && is_array($facts['posts']) && !empty($facts['posts'])) {
      $post_names = array();
      foreach ($facts['posts'] as $post) {
        $status = isset($post['status']) ? $post['status'] : 'published';
        $post_names[] = $post['title'] . " (" . $status . ")";
      }
      $replacements['{posts_list}'] = implode(", ", $post_names);
    } else {
      $replacements['{posts_list}'] = "No posts found";
    }
  }
  
  // Themes list
  if (strpos($template, '{themes_list}') !== false) {
    if (isset($facts['themes']) && is_array($facts['themes']) && !empty($facts['themes'])) {
      $active_themes = array();
      $inactive_themes = array();
      foreach ($facts['themes'] as $theme) {
        if (isset($theme['is_active']) && $theme['is_active']) {
          $active_themes[] = $theme['name'] . " (Active)";
        } else {
          $inactive_themes[] = $theme['name'] . " (Inactive)";
        }
      }
      $all_themes = array_merge($active_themes, $inactive_themes);
      $replacements['{themes_list}'] = implode(", ", $all_themes);
    } else {
      $replacements['{themes_list}'] = "No themes found";
    }
  }
  
  // Plugins list
  if (strpos($template, '{plugins_list}') !== false) {
    if (isset($facts['plugins']) && is_array($facts['plugins']) && !empty($facts['plugins'])) {
      $plugin_names = array();
      foreach ($facts['plugins'] as $plugin) {
        $status = isset($plugin['active']) && $plugin['active'] ? 'Active' : 'Inactive';
        $plugin_names[] = $plugin['name'] . " (" . $status . ")";
      }
      $replacements['{plugins_list}'] = implode(", ", $plugin_names);
    } else {
      $replacements['{plugins_list}'] = "No plugins found";
    }
  }
  
  // User count
  if (strpos($template, '{user_count}') !== false) {
    $user_count = isset($facts['users']) && is_array($facts['users']) ? count($facts['users']) : 0;
    $replacements['{user_count}'] = $user_count;
    $replacements['{user_plural}'] = $user_count === 1 ? '' : 's';
  }
  
  // Update counts
  if (strpos($template, '{plugin_updates}') !== false) {
    $replacements['{plugin_updates}'] = (int)($facts['updates']['plugins'] ?? 0);
  }
  if (strpos($template, '{theme_updates}') !== false) {
    $replacements['{theme_updates}'] = (int)($facts['updates']['themes'] ?? 0);
  }
  if (strpos($template, '{core_updates}') !== false) {
    $replacements['{core_updates}'] = (int)($facts['updates']['core'] ?? 0);
  }
  
  // Apply all replacements
  foreach ($replacements as $placeholder => $value) {
    $template = str_replace($placeholder, $value, $template);
  }
  
  return $template;
}

// Replace security variables in templates
function luna_replace_security_variables($template, $facts) {
  if (strpos($template, '{ssl_status}') !== false) {
    if (!empty($facts['tls']['valid'])) {
      $extras = array();
      if (!empty($facts['tls']['issuer'])) $extras[] = "issuer: " . $facts['tls']['issuer'];
      if (!empty($facts['tls']['expires'])) $extras[] = "expires: " . $facts['tls']['expires'];
      $ssl_status = "Yes—TLS/SSL is active for " . $facts['site_url'] . ($extras ? " (" . implode(', ', $extras) . ")." : ".");
    } else {
      $ssl_status = "Hub shows TLS/SSL is not confirmed active for " . $facts['site_url'] . ". Please review the Security tab in Visible Light.";
    }
    $template = str_replace('{ssl_status}', $ssl_status, $template);
  }
  
  return $template;
}

// Replace custom shortcodes in templates
function luna_replace_custom_shortcodes($template, $facts) {
  $replacements = [];
  
  // Contact page link
  if (strpos($template, '[contact_page]') !== false) {
    $contact_url = get_permalink(get_page_by_path('contact'));
    if (!$contact_url) {
      $contact_url = home_url('/contact/');
    }
    $replacements['[contact_page]'] = '<a href="' . esc_url($contact_url) . '" target="_blank">Contact Page</a>';
  }
  
  // Booking link
  if (strpos($template, '[booking_link]') !== false) {
    $booking_url = get_permalink(get_page_by_path('book'));
    if (!$booking_url) {
      $booking_url = home_url('/book/');
    }
    $replacements['[booking_link]'] = '<a href="' . esc_url($booking_url) . '" target="_blank">Book Appointment</a>';
  }
  
  // Phone number
  if (strpos($template, '[phone_number]') !== false) {
    $phone = get_option('luna_business_phone', '(555) 123-4567');
    $replacements['[phone_number]'] = '<a href="tel:' . esc_attr($phone) . '">' . esc_html($phone) . '</a>';
  }
  
  // Email link
  if (strpos($template, '[email_link]') !== false) {
    $email = get_option('luna_business_email', 'info@example.com');
    $replacements['[email_link]'] = '<a href="mailto:' . esc_attr($email) . '">' . esc_html($email) . '</a>';
  }
  
  // Site URL
  if (strpos($template, '[site_url]') !== false) {
    $replacements['[site_url]'] = '<a href="' . esc_url(home_url()) . '" target="_blank">' . esc_html(get_bloginfo('name')) . '</a>';
  }
  
  // Business name
  if (strpos($template, '[business_name]') !== false) {
    $business_name = get_option('luna_business_name', get_bloginfo('name'));
    $replacements['[business_name]'] = esc_html($business_name);
  }
  
  return str_replace(array_keys($replacements), array_values($replacements), $template);
}

// Handle business-specific keywords
function luna_handle_business_keyword($action, $facts) {
  switch ($action) {
    case 'appointment':
      return "To schedule an appointment, please call our office or use our online booking system. You can find our contact information on our website.";
      
    case 'contact':
      return "You can reach us through our contact page or by calling our main office number. Our contact information is available on our website.";
      
    case 'hours':
      return "Our business hours are typically Monday through Friday, 9 AM to 5 PM. Please check our website for the most current hours and holiday schedules.";
      
    case 'location':
      return "You can find our address and directions on our website's contact page. We're located in a convenient area with parking available.";
      
    case 'services':
      return "We offer a comprehensive range of services. Please visit our services page on our website for detailed information about what we provide.";
      
    case 'providers':
      return "Our team of experienced providers is dedicated to your care. You can learn more about our staff on our website's team page.";
      
    case 'insurance':
      return "We accept most major insurance plans. Please contact our billing department to verify your coverage and discuss payment options.";
      
    case 'forms':
      return "You can download patient forms from our website or pick them up at our office. Please complete them before your visit to save time.";
      
    default:
      return null;
  }
}

// Handle WP REST API keywords
function luna_handle_wp_rest_keyword($action, $facts) {
  switch ($action) {
    case 'pages':
      if (isset($facts['pages']) && is_array($facts['pages']) && !empty($facts['pages'])) {
        $page_names = array();
        foreach ($facts['pages'] as $page) {
          $status = isset($page['status']) ? $page['status'] : 'published';
          $page_names[] = $page['title'] . " (" . $status . ")";
        }
        return "Your pages are: " . implode(", ", $page_names) . ".";
      }
      return "I don't see any pages in your site data.";
      
    case 'posts':
      if (isset($facts['posts']) && is_array($facts['posts']) && !empty($facts['posts'])) {
        $post_names = array();
        foreach ($facts['posts'] as $post) {
          $status = isset($post['status']) ? $post['status'] : 'published';
          $post_names[] = $post['title'] . " (" . $status . ")";
        }
        return "Your posts are: " . implode(", ", $post_names) . ".";
      }
      return "I don't see any posts in your site data.";
      
    case 'themes':
      if (isset($facts['themes']) && is_array($facts['themes']) && !empty($facts['themes'])) {
        $active_themes = array();
        $inactive_themes = array();
        foreach ($facts['themes'] as $theme) {
          if (isset($theme['is_active']) && $theme['is_active']) {
            $active_themes[] = $theme['name'] . " (Active)";
          } else {
            $inactive_themes[] = $theme['name'] . " (Inactive)";
          }
        }
        $all_themes = array_merge($active_themes, $inactive_themes);
        return "Your themes are: " . implode(", ", $all_themes) . ".";
      }
      return "I don't see any themes in your site data.";
      
    case 'plugins':
      if (isset($facts['plugins']) && is_array($facts['plugins']) && !empty($facts['plugins'])) {
        $plugin_names = array();
        foreach ($facts['plugins'] as $plugin) {
          $status = isset($plugin['active']) && $plugin['active'] ? 'Active' : 'Inactive';
          $plugin_names[] = $plugin['name'] . " (" . $status . ")";
        }
        return "Your plugins are: " . implode(", ", $plugin_names) . ".";
      }
      return "I don't see any plugins in your site data.";
      
    case 'updates':
      $pu = (int)($facts['updates']['plugins'] ?? 0);
      $tu = (int)($facts['updates']['themes'] ?? 0);
      $cu = (int)($facts['updates']['core'] ?? 0);
      return "Updates pending — plugins: " . $pu . ", themes: " . $tu . ", WordPress Core: " . $cu . ".";
      
    default:
      return null;
  }
}

// Handle security keywords
function luna_handle_security_keyword($action, $facts) {
  switch ($action) {
    case 'ssl':
      if (!empty($facts['tls']['valid'])) {
        $extras = array();
        if (!empty($facts['tls']['issuer'])) $extras[] = "issuer: " . $facts['tls']['issuer'];
        if (!empty($facts['tls']['expires'])) $extras[] = "expires: " . $facts['tls']['expires'];
        return "Yes—TLS/SSL is active for " . $facts['site_url'] . ($extras ? " (" . implode(', ', $extras) . ")." : ".");
      }
      return "Hub shows TLS/SSL is not confirmed active for " . $facts['site_url'] . ". Please review the Security tab in Visible Light.";
      
    case 'firewall':
      return "Firewall protection status is available in your security settings. Please check the Security tab in Visible Light for detailed firewall information.";
      
    case 'backup':
      return "Backup information is available in your security profile. Please check the Security tab in Visible Light for backup status and schedules.";
      
    case 'monitoring':
      return "Security monitoring details are available in your security profile. Please check the Security tab in Visible Light for scan results and alerts.";
      
    case 'access':
      if (isset($facts['users']) && is_array($facts['users']) && !empty($facts['users'])) {
        $user_count = count($facts['users']);
        return "You have " . $user_count . " user" . ($user_count === 1 ? '' : 's') . " with access to your site.";
      }
      return "User access information is available in your security profile.";
      
    case 'compliance':
      return "Compliance information is available in your security profile. Please check the Security tab in Visible Light for compliance status and requirements.";
      
    default:
      return null;
  }
}

// Keywords admin page with enhanced template system
function luna_widget_keywords_admin_page() {
  if (isset($_POST['save_keywords'])) {
    check_admin_referer('luna_keywords_nonce');
    
    // Debug: Show what's being submitted (temporarily disabled)
    // echo '<div style="background: #e7f3ff; padding: 10px; margin: 10px 0; border: 1px solid #0073aa;">';
    // echo '<h4>Debug: POST Data Received</h4>';
    // echo '<pre>' . print_r($_POST, true) . '</pre>';
    // echo '</div>';
    
    // Process the form data properly
    if (isset($_POST['keywords'])) {
      $processed_keywords = array();
      
      foreach ($_POST['keywords'] as $category => $actions) {
        $processed_keywords[$category] = array();
        
        foreach ($actions as $action => $config) {
          // Skip if no keywords provided
          if (empty($config['keywords'])) {
            continue;
          }
          
          // Process keywords - split by comma and trim
          $keywords_array = array_map('trim', explode(',', $config['keywords']));
          $keywords_array = array_filter($keywords_array); // Remove empty values
          
          if (empty($keywords_array)) {
            continue;
          }
          
          $processed_config = array(
            'enabled' => isset($config['enabled']) ? 'on' : 'off',
            'keywords' => $keywords_array,
            'template' => sanitize_textarea_field($config['template'] ?? ''),
            'data_source' => sanitize_text_field($config['data_source'] ?? 'custom'),
            'response_type' => sanitize_text_field($config['response_type'] ?? 'simple')
          );
          
          // Add additional fields if they exist
          if (isset($config['wp_template'])) {
            $processed_config['wp_template'] = sanitize_textarea_field($config['wp_template']);
          }
          if (isset($config['security_template'])) {
            $processed_config['security_template'] = sanitize_textarea_field($config['security_template']);
          }
          if (isset($config['initial_response'])) {
            $processed_config['initial_response'] = sanitize_textarea_field($config['initial_response']);
          }
          if (isset($config['branches'])) {
            $processed_config['branches'] = $config['branches'];
          }
          
          $processed_keywords[$category][$action] = $processed_config;
        }
      }
      
      // Save the processed keywords
      update_option('luna_keyword_mappings', $processed_keywords);
      
      // Debug: Show what was saved (temporarily disabled)
      // echo '<div style="background: #d4edda; padding: 10px; margin: 10px 0; border: 1px solid #c3e6cb;">';
      // echo '<h4>Debug: Processed and Saved Keywords</h4>';
      // echo '<pre>' . print_r($processed_keywords, true) . '</pre>';
      // echo '</div>';
      
      // Sync to Hub
      luna_sync_keywords_to_hub();
      
      echo '<div class="notice notice-success"><p>Keywords saved and synced to Hub!</p></div>';
    }
  }
  
  // Load mappings for display - merge with defaults to show all keywords
  $saved_mappings = get_option('luna_keyword_mappings', []);
  $default_mappings = luna_get_default_keywords();
  $mappings = [];
  
  // Start with defaults
  foreach ($default_mappings as $category => $keywords) {
    $mappings[$category] = [];
    foreach ($keywords as $action => $default_config) {
      // Use saved data if it exists, otherwise use default
      if (isset($saved_mappings[$category][$action])) {
        $mappings[$category][$action] = $saved_mappings[$category][$action];
      } else {
        $mappings[$category][$action] = $default_config;
      }
    }
  }
  
  // Add any custom keywords that aren't in defaults
  foreach ($saved_mappings as $category => $keywords) {
    if (!isset($mappings[$category])) {
      $mappings[$category] = [];
    }
    foreach ($keywords as $action => $config) {
      if (!isset($mappings[$category][$action])) {
        $mappings[$category][$action] = $config;
      }
    }
  }
  
  // Debug: Show what we're working with (temporarily disabled)
  // echo '<div style="background: #f0f0f0; padding: 10px; margin: 10px 0; border: 1px solid #ccc;">';
  // echo '<h4>Debug: Current Mappings</h4>';
  // echo '<pre>' . print_r($mappings, true) . '</pre>';
  // echo '</div>';
  ?>
    <div class="wrap">
      <h1>Luna Chat Keywords & Templates</h1>
      <p>Configure keyword mappings and response templates to help Luna understand your business terminology and respond more accurately.</p>
      
      <div style="margin: 20px 0;">
        <button type="button" id="add-new-keyword" class="button button-primary">+ Add New Keyword</button>
        <button type="button" id="add-new-category" class="button">+ Add New Category</button>
        <button type="button" id="manage-keywords" class="button">Manage Existing Keywords</button>
      </div>
      
      <!-- Modal for adding new keyword -->
      <div id="keyword-modal" class="luna-modal" style="display: none;">
        <div class="luna-modal-content">
          <div class="luna-modal-header">
            <h2>Add New Keyword</h2>
            <span class="luna-modal-close">&times;</span>
          </div>
          <div class="luna-modal-body">
            <table class="form-table">
              <tr>
                <th scope="row">Category</th>
                <td>
                  <select id="new-keyword-category" class="regular-text">
                    <option value="business">Business</option>
                    <option value="wp_rest">WordPress Data</option>
                    <option value="security">Security</option>
                    <option value="custom">Custom</option>
                  </select>
                  <p class="description">Select the category for this keyword</p>
                </td>
              </tr>
              <tr>
                <th scope="row">Keyword Name</th>
                <td>
                  <input type="text" id="new-keyword-name" class="regular-text" placeholder="e.g., pricing, hours, support">
                  <p class="description">Enter a unique name for this keyword</p>
                </td>
              </tr>
              <tr>
                <th scope="row">Keywords</th>
                <td>
                  <input type="text" id="new-keyword-terms" class="regular-text" placeholder="Enter keywords separated by commas">
                  <p class="description">Words or phrases that will trigger this response</p>
                </td>
              </tr>
              <tr>
                <th scope="row">Data Source</th>
                <td>
                  <select id="new-keyword-data-source" class="regular-text">
                    <option value="custom">Custom Response</option>
                    <option value="wp_rest">WordPress Data</option>
                    <option value="security">Security Data</option>
                  </select>
                </td>
              </tr>
              <tr>
                <th scope="row">Response Template</th>
                <td>
                  <textarea id="new-keyword-template" class="large-text" rows="3" placeholder="Enter your response template..."></textarea>
                </td>
              </tr>
            </table>
          </div>
          <div class="luna-modal-footer">
            <button type="button" id="save-new-keyword" class="button button-primary">Add Keyword</button>
            <button type="button" id="cancel-new-keyword" class="button">Cancel</button>
          </div>
        </div>
      </div>
      
      <!-- Modal for adding new category -->
      <div id="category-modal" class="luna-modal" style="display: none;">
        <div class="luna-modal-content">
          <div class="luna-modal-header">
            <h2>Add New Category</h2>
            <span class="luna-modal-close">&times;</span>
          </div>
          <div class="luna-modal-body">
            <table class="form-table">
              <tr>
                <th scope="row">Category Name</th>
                <td>
                  <input type="text" id="new-category-name" class="regular-text" placeholder="e.g., products, services, support">
                  <p class="description">Enter a name for the new category</p>
                </td>
              </tr>
              <tr>
                <th scope="row">Description</th>
                <td>
                  <input type="text" id="new-category-description" class="regular-text" placeholder="Brief description of this category">
                  <p class="description">Optional description for this category</p>
                </td>
              </tr>
            </table>
          </div>
          <div class="luna-modal-footer">
            <button type="button" id="save-new-category" class="button button-primary">Add Category</button>
            <button type="button" id="cancel-new-category" class="button">Cancel</button>
          </div>
        </div>
      </div>
      
      <!-- Modal for managing existing keywords -->
      <div id="manage-modal" class="luna-modal" style="display: none;">
        <div class="luna-modal-content" style="width: 80%; max-width: 800px;">
          <div class="luna-modal-header">
            <h2>Manage Existing Keywords</h2>
            <span class="luna-modal-close">&times;</span>
          </div>
          <div class="luna-modal-body">
            <p>Move existing keywords to different categories:</p>
            <div id="keyword-management-list"></div>
          </div>
          <div class="luna-modal-footer">
            <button type="button" id="save-keyword-changes" class="button button-primary">Save Changes</button>
            <button type="button" id="cancel-keyword-changes" class="button">Cancel</button>
          </div>
        </div>
      </div>
    
    <div class="luna-keywords-help">
      <h3>Template Variables</h3>
      <p>Use these variables in your response templates:</p>
      <ul>
        <li><code>{pages_list}</code> - List of pages with status</li>
        <li><code>{posts_list}</code> - List of posts with status</li>
        <li><code>{themes_list}</code> - List of themes with active status</li>
        <li><code>{plugins_list}</code> - List of plugins with active status</li>
        <li><code>{user_count}</code> - Number of users</li>
        <li><code>{user_plural}</code> - "s" if multiple users, "" if single</li>
        <li><code>{plugin_updates}</code> - Number of plugin updates available</li>
        <li><code>{theme_updates}</code> - Number of theme updates available</li>
        <li><code>{core_updates}</code> - Number of WordPress core updates available</li>
        <li><code>{ssl_status}</code> - SSL certificate status</li>
      </ul>
    </div>
    
    <form method="post">
      <?php wp_nonce_field('luna_keywords_nonce'); ?>
      
      <div class="luna-keywords-container">
        <?php foreach ($mappings as $category => $keywords): ?>
          <div class="luna-keyword-category">
            <h3><?php echo ucfirst($category); ?> Keywords</h3>
            <table class="form-table">
              <?php foreach ($keywords as $action => $config): ?>
                <?php 
                // Handle both old format (array of terms) and new format (config object)
                $terms = is_array($config) && isset($config['keywords']) ? $config['keywords'] : $config;
                $template = is_array($config) && isset($config['template']) ? $config['template'] : '';
                $data_source = is_array($config) && isset($config['data_source']) ? $config['data_source'] : 'custom';
                $enabled = is_array($config) && isset($config['enabled']) ? $config['enabled'] : 'off';
                
                // Debug: Show enabled state for this keyword (only in debug mode)
                if (WP_DEBUG) {
                  echo "<!-- DEBUG: {$category}.{$action} - enabled: {$enabled} -->";
                }
                ?>
                <tr>
                  <th scope="row"><?php echo ucfirst($action); ?></th>
                  <td>
                    <div class="luna-keyword-config">
                      <div class="luna-keyword-field">
                        <label>
                          <input type="checkbox" name="keywords[<?php echo $category; ?>][<?php echo $action; ?>][enabled]" 
                                 value="on" <?php checked('on', $enabled); ?> 
                                 onchange="luna_toggle_keyword('<?php echo $category; ?>', '<?php echo $action; ?>')">
                          Enable this keyword
                        </label>
                      </div>
                      
                      <div class="luna-keyword-field">
                        <label>Keywords:</label>
                        <input type="text" name="keywords[<?php echo $category; ?>][<?php echo $action; ?>][terms]" 
                               value="<?php echo esc_attr(is_array($terms) ? implode(', ', $terms) : $terms); ?>" 
                               class="regular-text" 
                               placeholder="Enter keywords separated by commas">
                      </div>
                      
                      <div class="luna-keyword-field">
                        <label>Data Source:</label>
                        <select name="keywords[<?php echo $category; ?>][<?php echo $action; ?>][data_source]" 
                                onchange="luna_toggle_data_source_options(this, '<?php echo $category; ?>', '<?php echo $action; ?>')">
                          <option value="custom" <?php selected($data_source, 'custom'); ?>>Custom Response</option>
                          <option value="wp_rest" <?php selected($data_source, 'wp_rest'); ?>>WordPress Data</option>
                          <option value="security" <?php selected($data_source, 'security'); ?>>Security Data</option>
                        </select>
                      </div>
                      
                      <!-- WordPress Data Options -->
                      <div class="luna-data-source-options luna-wp-rest-options" 
                           style="display: <?php echo $data_source === 'wp_rest' ? 'block' : 'none'; ?>;">
                        <div class="luna-keyword-field">
                          <label>WordPress Data Response:</label>
                          <textarea name="keywords[<?php echo $category; ?>][<?php echo $action; ?>][wp_template]" 
                                    class="large-text" rows="3" 
                                    placeholder="Use variables: {pages_list}, {posts_list}, {themes_list}, {plugins_list}, {user_count}, {user_plural}, {plugin_updates}, {theme_updates}, {core_updates}"><?php echo esc_textarea($config['wp_template'] ?? ''); ?></textarea>
                          <p class="description">
                            <strong>Available Variables:</strong><br>
                            <code>{pages_list}</code> - List of pages with status<br>
                            <code>{posts_list}</code> - List of posts with status<br>
                            <code>{themes_list}</code> - List of themes with active status<br>
                            <code>{plugins_list}</code> - List of plugins with active status<br>
                            <code>{user_count}</code> - Number of users<br>
                            <code>{user_plural}</code> - "s" if multiple users, "" if single<br>
                            <code>{plugin_updates}</code> - Number of plugin updates available<br>
                            <code>{theme_updates}</code> - Number of theme updates available<br>
                            <code>{core_updates}</code> - Number of WordPress core updates available
                          </p>
                        </div>
                        <div class="luna-keyword-field">
                          <label>Shortcode Generator:</label>
                          <select onchange="luna_insert_shortcode(this.value, 'keywords[<?php echo $category; ?>][<?php echo $action; ?>][wp_template]')">
                            <option value="">Select a shortcode to insert...</option>
                            <option value="{pages_list}">Pages List</option>
                            <option value="{posts_list}">Posts List</option>
                            <option value="{themes_list}">Themes List</option>
                            <option value="{plugins_list}">Plugins List</option>
                            <option value="{user_count}">User Count</option>
                            <option value="{plugin_updates}">Plugin Updates</option>
                            <option value="{theme_updates}">Theme Updates</option>
                            <option value="{core_updates}">Core Updates</option>
                          </select>
                        </div>
                      </div>
                      
                      <!-- Security Data Options -->
                      <div class="luna-data-source-options luna-security-options" 
                           style="display: <?php echo $data_source === 'security' ? 'block' : 'none'; ?>;">
                        <div class="luna-keyword-field">
                          <label>Security Data Response:</label>
                          <textarea name="keywords[<?php echo $category; ?>][<?php echo $action; ?>][security_template]" 
                                    class="large-text" rows="3" 
                                    placeholder="Use variables: {ssl_status}, {firewall_status}, {backup_status}, {monitoring_status}"><?php echo esc_textarea($config['security_template'] ?? ''); ?></textarea>
                          <p class="description">
                            <strong>Available Variables:</strong><br>
                            <code>{ssl_status}</code> - SSL certificate status<br>
                            <code>{firewall_status}</code> - Firewall protection status<br>
                            <code>{backup_status}</code> - Backup information<br>
                            <code>{monitoring_status}</code> - Security monitoring details
                          </p>
                        </div>
                        <div class="luna-keyword-field">
                          <label>Shortcode Generator:</label>
                          <select onchange="luna_insert_shortcode(this.value, 'keywords[<?php echo $category; ?>][<?php echo $action; ?>][security_template]')">
                            <option value="">Select a shortcode to insert...</option>
                            <option value="{ssl_status}">SSL Status</option>
                            <option value="{firewall_status}">Firewall Status</option>
                            <option value="{backup_status}">Backup Status</option>
                            <option value="{monitoring_status}">Monitoring Status</option>
                          </select>
                        </div>
                      </div>
                      
                      <!-- Custom Response Options -->
                      <div class="luna-data-source-options luna-custom-options" 
                           style="display: <?php echo $data_source === 'custom' ? 'block' : 'none'; ?>;">
                        <div class="luna-response-type">
                          <label>
                            <input type="radio" name="keywords[<?php echo $category; ?>][<?php echo $action; ?>][response_type]" 
                                   value="simple" <?php checked($config['response_type'] ?? 'simple', 'simple'); ?> 
                                   onchange="luna_toggle_response_type('<?php echo $category; ?>', '<?php echo $action; ?>', 'simple')">
                            Simple Text Response
                          </label>
                          <label>
                            <input type="radio" name="keywords[<?php echo $category; ?>][<?php echo $action; ?>][response_type]" 
                                   value="advanced" <?php checked($config['response_type'] ?? 'simple', 'advanced'); ?> 
                                   onchange="luna_toggle_response_type('<?php echo $category; ?>', '<?php echo $action; ?>', 'advanced')">
                            Advanced Conversation Flows
                          </label>
                        </div>
                        
                        <!-- Simple Text Response -->
                        <div class="luna-simple-response" 
                             style="display: <?php echo ($config['response_type'] ?? 'simple') === 'simple' ? 'block' : 'none'; ?>;">
                          <div class="luna-keyword-field">
                            <label>Response Template:</label>
                            <textarea name="keywords[<?php echo $category; ?>][<?php echo $action; ?>][template]" 
                                      class="large-text" rows="3" 
                                      placeholder="Enter your response template..."><?php echo esc_textarea($template); ?></textarea>
                            <p class="description">
                              <strong>Available Shortcodes:</strong><br>
                              <code>[contact_page]</code> - Link to contact page<br>
                              <code>[booking_link]</code> - Link to booking page<br>
                              <code>[phone_number]</code> - Phone number link<br>
                              <code>[email_link]</code> - Email link<br>
                              <code>[site_url]</code> - Site URL<br>
                              <code>[business_name]</code> - Business name
                            </p>
                          </div>
                          <div class="luna-keyword-field">
                            <label>Shortcode Generator:</label>
                            <select onchange="luna_insert_shortcode(this.value, 'keywords[<?php echo $category; ?>][<?php echo $action; ?>][template]')">
                              <option value="">Select a shortcode to insert...</option>
                              <option value="[contact_page]">Contact Page Link</option>
                              <option value="[booking_link]">Booking Link</option>
                              <option value="[phone_number]">Phone Number</option>
                              <option value="[email_link]">Email Link</option>
                              <option value="[site_url]">Site URL</option>
                              <option value="[business_name]">Business Name</option>
                            </select>
                          </div>
                        </div>
                        
                        <!-- Advanced Conversation Flows -->
                        <div class="luna-advanced-response" 
                             style="display: <?php echo ($config['response_type'] ?? 'simple') === 'advanced' ? 'block' : 'none'; ?>;">
                          <div class="luna-keyword-field">
                            <label>Initial Response:</label>
                            <textarea name="keywords[<?php echo $category; ?>][<?php echo $action; ?>][initial_response]" 
                                      class="large-text" rows="2" 
                                      placeholder="What should Luna say first?"><?php echo esc_textarea($config['initial_response'] ?? ''); ?></textarea>
                          </div>
                          <div class="luna-keyword-field">
                            <label>Follow-up Responses:</label>
                            <div class="luna-branch-responses">
                              <div class="luna-branch-item">
                                <input type="text" name="keywords[<?php echo $category; ?>][<?php echo $action; ?>][branches][yes][trigger]" 
                                       placeholder="User says (e.g., 'yes', 'sure', 'okay')" 
                                       value="<?php echo esc_attr($config['branches']['yes']['trigger'] ?? 'yes'); ?>">
                                <textarea name="keywords[<?php echo $category; ?>][<?php echo $action; ?>][branches][yes][response]" 
                                          placeholder="Luna responds..." 
                                          rows="2"><?php echo esc_textarea($config['branches']['yes']['response'] ?? ''); ?></textarea>
                              </div>
                              <div class="luna-branch-item">
                                <input type="text" name="keywords[<?php echo $category; ?>][<?php echo $action; ?>][branches][no][trigger]" 
                                       placeholder="User says (e.g., 'no', 'not now', 'maybe later')" 
                                       value="<?php echo esc_attr($config['branches']['no']['trigger'] ?? 'no'); ?>">
                                <textarea name="keywords[<?php echo $category; ?>][<?php echo $action; ?>][branches][no][response]" 
                                          placeholder="Luna responds..." 
                                          rows="2"><?php echo esc_textarea($config['branches']['no']['response'] ?? ''); ?></textarea>
                              </div>
                              <div class="luna-branch-item">
                                <input type="text" name="keywords[<?php echo $category; ?>][<?php echo $action; ?>][branches][maybe][trigger]" 
                                       placeholder="User says (e.g., 'maybe', 'not sure', 'tell me more')" 
                                       value="<?php echo esc_attr($config['branches']['maybe']['trigger'] ?? 'maybe'); ?>">
                                <textarea name="keywords[<?php echo $category; ?>][<?php echo $action; ?>][branches][maybe][response]" 
                                          placeholder="Luna responds..." 
                                          rows="2"><?php echo esc_textarea($config['branches']['maybe']['response'] ?? ''); ?></textarea>
                              </div>
                            </div>
                            <p class="description">Define how Luna should respond based on different user inputs.</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </td>
                </tr>
              <?php endforeach; ?>
            </table>
          </div>
        <?php endforeach; ?>
      </div>
      
      <p class="submit">
        <input type="submit" name="save_keywords" class="button-primary" value="Save Keywords & Templates">
        <a href="#" class="button" onclick="luna_export_keywords(); return false;">Export Keywords</a>
        <a href="#" class="button" onclick="luna_import_keywords(); return false;">Import Keywords</a>
      </p>
    </form>
  </div>
  
  <style>
    .luna-keywords-container {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(500px, 1fr));
      gap: 20px;
      margin: 20px 0;
    }
    .luna-keyword-category {
      border: 1px solid #ddd;
      padding: 15px;
      border-radius: 5px;
      background: #f9f9f9;
    }
    .luna-keyword-category h3 {
      margin-top: 0;
      color: #23282d;
    }
    .luna-keyword-config {
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
    .luna-keyword-field {
      display: flex;
      flex-direction: column;
    }
    .luna-keyword-field label {
      font-weight: bold;
      margin-bottom: 5px;
    }
    .luna-keywords-help {
      background: #e7f3ff;
      border: 1px solid #0073aa;
      border-radius: 5px;
      padding: 15px;
      margin: 20px 0;
    }
    .luna-keywords-help h3 {
      margin-top: 0;
      color: #0073aa;
    }
    .luna-keywords-help code {
      background: #fff;
      padding: 2px 4px;
      border-radius: 3px;
      font-family: monospace;
    }
    
    /* Modal Styles */
    .luna-modal {
      position: fixed;
      z-index: 100000;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .luna-modal-content {
      background-color: #fff;
      border-radius: 4px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      width: 90%;
      max-width: 600px;
      max-height: 90vh;
      overflow-y: auto;
    }
    
    .luna-modal-header {
      padding: 20px;
      border-bottom: 1px solid #ddd;
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: #f1f1f1;
    }
    
    .luna-modal-header h2 {
      margin: 0;
      font-size: 18px;
    }
    
    .luna-modal-close {
      font-size: 24px;
      font-weight: bold;
      cursor: pointer;
      color: #666;
    }
    
    .luna-modal-close:hover {
      color: #000;
    }
    
    .luna-modal-body {
      padding: 20px;
    }
    
    .luna-modal-footer {
      padding: 20px;
      border-top: 1px solid #ddd;
      text-align: right;
      background: #f9f9f9;
    }
    
    .luna-modal-footer .button {
      margin-left: 10px;
    }
    
    .keyword-management-item {
      display: flex;
      align-items: center;
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 4px;
      margin-bottom: 10px;
      background: #fff;
    }
    
    .keyword-management-item select {
      margin-left: 10px;
      min-width: 150px;
    }
    
    .keyword-management-item .keyword-info {
      flex: 1;
    }
    
    .keyword-management-item .keyword-name {
      font-weight: 600;
    }
    
    .keyword-management-item .keyword-terms {
      color: #666;
      font-size: 12px;
    }
  </style>
  
  <script>
    function luna_export_keywords() {
      // TODO: Implement keyword export functionality
      alert('Export functionality coming soon!');
    }
    
  function luna_import_keywords() {
    // TODO: Implement keyword import functionality
    alert('Import functionality coming soon!');
  }
  
  // Chat transcript functionality
  function showLunaChatTranscript(licenseKey) {
    // Create modal if it doesn't exist
    if (!document.getElementById('luna-chat-transcript-modal')) {
      var modal = document.createElement('div');
      modal.id = 'luna-chat-transcript-modal';
      modal.className = 'luna-modal';
      modal.innerHTML = `
        <div class="luna-modal-content">
          <div class="luna-modal-header">
            <h3>Luna Chat Transcript - License: ${licenseKey}</h3>
            <span class="luna-modal-close" onclick="closeLunaChatTranscript()">&times;</span>
          </div>
          <div class="luna-modal-body" id="luna-chat-transcript-content">
            <p>Loading chat transcript...</p>
          </div>
          <div class="luna-modal-footer" style="margin-top: 20px; text-align: right;">
            <button type="button" class="button" onclick="closeLunaChatTranscript()">Close</button>
          </div>
        </div>
      `;
      document.body.appendChild(modal);
    }
    
    // Show modal
    document.getElementById('luna-chat-transcript-modal').style.display = 'block';
    
    // Load transcript data
    loadLunaChatTranscript(licenseKey);
  }
  
  function closeLunaChatTranscript() {
    document.getElementById('luna-chat-transcript-modal').style.display = 'none';
  }
  
  function loadLunaChatTranscript(licenseKey) {
    // Make AJAX request to get chat transcript
    jQuery.ajax({
      url: '<?php echo admin_url('admin-ajax.php'); ?>',
      type: 'POST',
      data: {
        action: 'luna_get_chat_transcript',
        license_key: licenseKey,
        nonce: '<?php echo wp_create_nonce('luna_chat_transcript_nonce'); ?>'
      },
      success: function(response) {
        if (response.success) {
          var content = document.getElementById('luna-chat-transcript-content');
          if (response.data.transcript && response.data.transcript.length > 0) {
            var html = '<div class="luna-chat-transcript">';
            response.data.transcript.forEach(function(entry) {
              html += '<div class="luna-chat-entry ' + entry.type + '">';
              html += '<div style="font-weight: bold; color: #333; margin-bottom: 5px;">';
              html += (entry.type === 'user' ? '👤 User' : '🤖 Luna') + ' - ' + entry.timestamp;
              html += '</div>';
              html += '<div style="color: #555;">' + entry.message + '</div>';
              html += '</div>';
            });
            html += '</div>';
            content.innerHTML = html;
          } else {
            content.innerHTML = '<p>No chat transcript available for this license.</p>';
          }
        } else {
          document.getElementById('luna-chat-transcript-content').innerHTML = '<p>Error loading chat transcript: ' + response.data + '</p>';
        }
      },
      error: function() {
        document.getElementById('luna-chat-transcript-content').innerHTML = '<p>Error loading chat transcript. Please try again.</p>';
      }
    });
  }
  
  // Close modal when clicking outside
  window.onclick = function(event) {
    var modal = document.getElementById('luna-chat-transcript-modal');
    if (event.target === modal) {
      closeLunaChatTranscript();
    }
  }
  </script>
  <?php
}

// Analytics admin page
function luna_widget_analytics_admin_page() {
  $performance = luna_get_keyword_performance();
  ?>
  <div class="wrap">
    <h1>Luna Chat Analytics</h1>
    <p>Track keyword performance and usage statistics to optimize your Luna Chat experience.</p>
    
    <div class="notice notice-info">
      <p><strong>Note:</strong> GA4 Analytics integration has been moved to the <a href="https://visiblelight.ai/wp-admin/admin.php?page=vl-hub-profile" target="_blank">VL Client Hub Profile</a> for centralized management.</p>
    </div>
    
    <!-- Interactions Metric -->
    <div class="postbox" style="margin-top: 20px;">
      <h2 class="hndle">Chat Interactions</h2>
      <div class="inside">
        <?php
        $interactions_count = luna_get_interactions_count();
        $license = luna_get_license();
        ?>
        <div class="luna-interactions-metric" style="text-align: center; padding: 20px; background: #f9f9f9; border-radius: 5px; cursor: pointer;" onclick="showLunaChatTranscript('<?php echo esc_js($license); ?>')">
          <div style="font-size: 3em; font-weight: bold; color: #0073aa; margin-bottom: 10px;"><?php echo $interactions_count; ?></div>
          <div style="font-size: 1.2em; color: #666;">Total Interactions</div>
          <div style="font-size: 0.9em; color: #999; margin-top: 5px;">Click to view chat transcript</div>
        </div>
      </div>
    </div>
    
    <!-- AI Chat Metrics -->
    <div class="postbox" style="margin-top: 20px;">
      <h2 class="hndle">AI Chat Metrics</h2>
      <div class="inside">
        <?php
        $chat_metrics = luna_get_ai_chat_metrics();
        ?>
        <div class="luna-ai-chat-metrics">
          <div class="luna-metrics-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 20px 0;">
            <div class="luna-metric-box" style="background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 8px; padding: 20px; text-align: center;">
              <div style="font-size: 2.5em; font-weight: bold; color: #0073aa; margin-bottom: 10px;"><?php echo number_format($chat_metrics['total_conversations']); ?></div>
              <div style="font-size: 1.1em; color: #666; font-weight: 600;">Total Conversations</div>
            </div>
            <div class="luna-metric-box" style="background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 8px; padding: 20px; text-align: center;">
              <div style="font-size: 2.5em; font-weight: bold; color: #0073aa; margin-bottom: 10px;"><?php echo number_format($chat_metrics['total_messages']); ?></div>
              <div style="font-size: 1.1em; color: #666; font-weight: 600;">Total Messages</div>
            </div>
            <div class="luna-metric-box" style="background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 8px; padding: 20px; text-align: center;">
              <div style="font-size: 2.5em; font-weight: bold; color: #00a32a; margin-bottom: 10px;"><?php echo number_format($chat_metrics['active_conversations']); ?></div>
              <div style="font-size: 1.1em; color: #666; font-weight: 600;">Active Conversations</div>
            </div>
            <div class="luna-metric-box" style="background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 8px; padding: 20px; text-align: center;">
              <div style="font-size: 2.5em; font-weight: bold; color: #0073aa; margin-bottom: 10px;"><?php echo $chat_metrics['average_messages_per_conversation']; ?></div>
              <div style="font-size: 1.1em; color: #666; font-weight: 600;">Avg Messages/Conversation</div>
            </div>
          </div>
          
          <div class="luna-metrics-details" style="margin-top: 30px;">
            <h3 style="margin-bottom: 15px;">Activity Breakdown</h3>
            <div class="luna-metrics-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 15px;">
              <div class="luna-metric-item" style="padding: 15px; background: #fff; border: 1px solid #e9ecef; border-radius: 6px;">
                <div style="font-size: 1.8em; font-weight: bold; color: #2271b1; margin-bottom: 5px;"><?php echo number_format($chat_metrics['conversations_today']); ?></div>
                <div style="font-size: 0.95em; color: #646970;">Today</div>
              </div>
              <div class="luna-metric-item" style="padding: 15px; background: #fff; border: 1px solid #e9ecef; border-radius: 6px;">
                <div style="font-size: 1.8em; font-weight: bold; color: #2271b1; margin-bottom: 5px;"><?php echo number_format($chat_metrics['conversations_this_week']); ?></div>
                <div style="font-size: 0.95em; color: #646970;">This Week</div>
              </div>
              <div class="luna-metric-item" style="padding: 15px; background: #fff; border: 1px solid #e9ecef; border-radius: 6px;">
                <div style="font-size: 1.8em; font-weight: bold; color: #2271b1; margin-bottom: 5px;"><?php echo number_format($chat_metrics['conversations_this_month']); ?></div>
                <div style="font-size: 0.95em; color: #646970;">This Month</div>
              </div>
              <div class="luna-metric-item" style="padding: 15px; background: #fff; border: 1px solid #e9ecef; border-radius: 6px;">
                <div style="font-size: 1.8em; font-weight: bold; color: #d63638; margin-bottom: 5px;"><?php echo number_format($chat_metrics['closed_conversations']); ?></div>
                <div style="font-size: 0.95em; color: #646970;">Closed</div>
              </div>
            </div>
          </div>
          
          <div class="luna-message-breakdown" style="margin-top: 30px;">
            <h3 style="margin-bottom: 15px;">Message Breakdown</h3>
            <div class="luna-metrics-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
              <div class="luna-metric-item" style="padding: 15px; background: #e3f2fd; border: 1px solid #90caf9; border-radius: 6px;">
                <div style="font-size: 1.8em; font-weight: bold; color: #1976d2; margin-bottom: 5px;"><?php echo number_format($chat_metrics['total_user_messages']); ?></div>
                <div style="font-size: 0.95em; color: #646970;">User Messages</div>
              </div>
              <div class="luna-metric-item" style="padding: 15px; background: #e8f5e9; border: 1px solid #81c784; border-radius: 6px;">
                <div style="font-size: 1.8em; font-weight: bold; color: #388e3c; margin-bottom: 5px;"><?php echo number_format($chat_metrics['total_assistant_messages']); ?></div>
                <div style="font-size: 0.95em; color: #646970;">Assistant Messages</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <?php if (empty($performance)): ?>
      <div class="notice notice-info">
        <p>No keyword usage data available yet. Start using Luna Chat to see analytics!</p>
      </div>
    <?php else: ?>
      <div class="luna-analytics-container">
        <div class="luna-analytics-summary">
          <h3>Summary</h3>
          <div class="luna-stats-grid">
            <div class="luna-stat-box">
              <h4>Total Keywords Used</h4>
              <span class="luna-stat-number"><?php echo count($performance); ?></span>
            </div>
            <div class="luna-stat-box">
              <h4>Total Interactions</h4>
              <span class="luna-stat-number"><?php echo array_sum(array_column($performance, 'total_uses')); ?></span>
            </div>
            <div class="luna-stat-box">
              <h4>Average Success Rate</h4>
              <span class="luna-stat-number"><?php 
                $avg_success = array_sum(array_column($performance, 'success_rate')) / count($performance);
                echo round($avg_success, 1) . '%';
              ?></span>
            </div>
          </div>
        </div>
        
        <div class="luna-analytics-details">
          <h3>Keyword Performance</h3>
          <table class="wp-list-table widefat fixed striped">
            <thead>
              <tr>
                <th>Keyword</th>
                <th>Category</th>
                <th>Total Uses</th>
                <th>Success Rate</th>
                <th>Last Used</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($performance as $key => $stats): ?>
                <?php 
                list($category, $action) = explode('.', $key, 2);
                $success_class = $stats['success_rate'] >= 80 ? 'success' : ($stats['success_rate'] >= 60 ? 'warning' : 'error');
                ?>
                <tr>
                  <td><strong><?php echo esc_html(ucfirst($action)); ?></strong></td>
                  <td><?php echo esc_html(ucfirst($category)); ?></td>
                  <td><?php echo $stats['total_uses']; ?></td>
                  <td>
                    <span class="luna-success-rate luna-<?php echo $success_class; ?>">
                      <?php echo $stats['success_rate']; ?>%
                    </span>
                  </td>
                  <td><?php echo esc_html($stats['last_used']); ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        
        <div class="luna-analytics-insights">
          <h3>Insights & Recommendations</h3>
          <div class="luna-insights">
            <?php
            $low_performing = array_filter($performance, function($stats) {
              return $stats['success_rate'] < 60 && $stats['total_uses'] > 2;
            });
            
            $unused = array_filter($performance, function($stats) {
              return $stats['total_uses'] == 0;
            });
            
            $high_performing = array_filter($performance, function($stats) {
              return $stats['success_rate'] >= 90 && $stats['total_uses'] > 5;
            });
            ?>
            
            <?php if (!empty($low_performing)): ?>
              <div class="luna-insight warning">
                <h4>⚠️ Low Performing Keywords</h4>
                <p>These keywords have low success rates and may need attention:</p>
                <ul>
                  <?php foreach ($low_performing as $key => $stats): ?>
                    <li><strong><?php echo esc_html(ucfirst(explode('.', $key)[1])); ?></strong> - <?php echo $stats['success_rate']; ?>% success rate</li>
                  <?php endforeach; ?>
                </ul>
                <p><em>Consider reviewing the response templates or adding more specific keywords.</em></p>
              </div>
            <?php endif; ?>
            
            <?php if (!empty($high_performing)): ?>
              <div class="luna-insight success">
                <h4>✅ High Performing Keywords</h4>
                <p>These keywords are working well:</p>
                <ul>
                  <?php foreach ($high_performing as $key => $stats): ?>
                    <li><strong><?php echo esc_html(ucfirst(explode('.', $key)[1])); ?></strong> - <?php echo $stats['success_rate']; ?>% success rate</li>
                  <?php endforeach; ?>
                </ul>
                <p><em>Great job! These responses are working effectively.</em></p>
              </div>
            <?php endif; ?>
            
            <?php if (empty($low_performing) && empty($high_performing)): ?>
              <div class="luna-insight info">
                <h4>📊 Keep Using Luna Chat</h4>
                <p>Continue using Luna Chat to build up more performance data. The more interactions you have, the better insights we can provide!</p>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    <?php endif; ?>
  </div>
  
  <style>
    .luna-analytics-container {
      display: flex;
      flex-direction: column;
      gap: 30px;
    }
    .luna-stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 20px;
      margin: 20px 0;
    }
    .luna-stat-box {
      background: #f8f9fa;
      border: 1px solid #dee2e6;
      border-radius: 8px;
      padding: 20px;
      text-align: center;
    }
    .luna-stat-box h4 {
      margin: 0 0 10px 0;
      color: #6c757d;
      font-size: 14px;
      font-weight: 600;
    }
    .luna-stat-number {
      font-size: 32px;
      font-weight: bold;
      color: #0073aa;
    }
    .luna-success-rate {
      padding: 4px 8px;
      border-radius: 4px;
      font-weight: bold;
    }
    .luna-success-rate.luna-success {
      background: #d4edda;
      color: #155724;
    }
    .luna-success-rate.luna-warning {
      background: #fff3cd;
      color: #856404;
    }
    .luna-success-rate.luna-error {
      background: #f8d7da;
      color: #721c24;
    }
    .luna-insights {
      display: flex;
      flex-direction: column;
      gap: 20px;
    }
    .luna-insight {
      padding: 20px;
      border-radius: 8px;
      border-left: 4px solid;
    }
    .luna-insight.success {
      background: #d4edda;
      border-left-color: #28a745;
    }
    .luna-insight.warning {
      background: #fff3cd;
      border-left-color: #ffc107;
    }
    .luna-composer__response, [data-luna-composer] .luna-composer__response{display:none !important;}
    [data-luna-composer] .luna-composer__response[data-loading="true"], [data-luna-composer] .luna-composer__response[data-loading="false"] {
        display: inline !important;
    }
    .luna-insight.info {
      background: #d1ecf1;
      border-left-color: #17a2b8;
    }
    .luna-insight h4 {
      margin-top: 0;
    }
    .luna-insight ul {
      margin: 10px 0;
    }
    
    /* Chat Transcript Modal Styles */
    .luna-modal {
      position: fixed;
      z-index: 100000;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0,0,0,0.5);
      display: none;
    }
    
    .luna-modal-content {
      background-color: #fff;
      margin: 5% auto;
      padding: 20px;
      border-radius: 8px;
      width: 80%;
      max-width: 800px;
      max-height: 80vh;
      overflow-y: auto;
    }
    
    .luna-modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
      padding-bottom: 10px;
      border-bottom: 1px solid #ddd;
    }
    
    .luna-modal-close {
      font-size: 24px;
      font-weight: bold;
      cursor: pointer;
      color: #666;
    }
    
    .luna-chat-transcript {
      max-height: 400px;
      overflow-y: auto;
      border: 1px solid #ddd;
      padding: 15px;
      background: #f9f9f9;
    }
    
    .luna-chat-entry {
      margin-bottom: 15px;
      padding: 10px;
      border-radius: 5px;
    }
    
    .luna-chat-entry.user {
      background: #e3f2fd;
    }
    
    .luna-chat-entry.assistant {
      background: #f5f5f5;
    }
    
    /* Keyword Interface Styles */
    .luna-data-source-options {
      margin-top: 15px;
      padding: 15px;
      background: #f8f9fa;
      border: 1px solid #dee2e6;
      border-radius: 6px;
    }
    
    .luna-response-type {
      margin-bottom: 15px;
    }
    
    .luna-response-type label {
      display: inline-block;
      margin-right: 20px;
      font-weight: 600;
    }
    
    .luna-response-type input[type="radio"] {
      margin-right: 8px;
    }
    
    .luna-branch-responses {
      display: flex;
      flex-direction: column;
      gap: 15px;
    }
    
    .luna-branch-item {
      display: flex;
      flex-direction: column;
      gap: 8px;
      padding: 12px;
      background: #ffffff;
      border: 1px solid #e9ecef;
      border-radius: 4px;
    }
    
    .luna-branch-item input[type="text"] {
      padding: 8px 12px;
      border: 1px solid #ced4da;
      border-radius: 4px;
      font-size: 14px;
    }
    
    .luna-branch-item textarea {
      padding: 8px 12px;
      border: 1px solid #ced4da;
      border-radius: 4px;
      font-size: 14px;
      resize: vertical;
    }
    
    .luna-keyword-field .description {
      margin-top: 8px;
      font-size: 13px;
      color: #6c757d;
      line-height: 1.4;
    }
    
    .luna-keyword-field .description code {
      background: #e9ecef;
      padding: 2px 4px;
      border-radius: 3px;
      font-family: 'Courier New', monospace;
      font-size: 12px;
    }
    
    .luna-keyword-field select {
      padding: 6px 10px;
      border: 1px solid #ced4da;
      border-radius: 4px;
      font-size: 14px;
    }
  </style>
  <?php
}

// Separate function for JavaScript
function luna_keywords_admin_scripts() {
  ?>
  <script>
  function luna_toggle_keyword(category, action) {
    const checkbox = document.querySelector(`input[name="keywords[${category}][${action}][enabled]"]`);
    const row = checkbox.closest('tr');
    const inputs = row.querySelectorAll('input, textarea, select');
    
    inputs.forEach(input => {
      if (input !== checkbox) {
        input.disabled = !checkbox.checked;
      }
    });
  }
  
  function luna_toggle_data_source_options(select, category, action) {
    const dataSource = select.value;
    const row = select.closest('tr');
    
    console.log('Luna Keywords: Toggling data source to', dataSource, 'for', category, action);
    
    // Hide all data source options
    row.querySelectorAll('.luna-data-source-options').forEach(div => {
      div.style.display = 'none';
    });
    
    // Show the selected data source options
    const targetDiv = row.querySelector(`.luna-${dataSource}-options`);
    if (targetDiv) {
      targetDiv.style.display = 'block';
      console.log('Luna Keywords: Showing', dataSource, 'options');
      
      // If it's custom response, also initialize the response type
      if (dataSource === 'custom') {
        const checkedRadio = targetDiv.querySelector('input[name*="[response_type]"]:checked');
        if (checkedRadio) {
          console.log('Luna Keywords: Found checked radio, initializing response type');
          luna_toggle_response_type(category, action, checkedRadio.value);
        }
      }
    } else {
      console.log('Luna Keywords: Target div not found for', dataSource);
    }
  }
  
  function luna_toggle_response_type(category, action, type) {
    const radio = document.querySelector(`input[name="keywords[${category}][${action}][response_type]"][value="${type}"]`);
    if (!radio) {
      console.log('Luna Keywords: Radio not found for', category, action, type);
      return;
    }
    
    const row = radio.closest('tr');
    
    console.log('Luna Keywords: Toggling response type to', type, 'for', category, action);
    
    // Hide both response types
    row.querySelectorAll('.luna-simple-response, .luna-advanced-response').forEach(div => {
      div.style.display = 'none';
    });
    
    // Show the selected response type
    const targetDiv = row.querySelector(`.luna-${type}-response`);
    if (targetDiv) {
      targetDiv.style.display = 'block';
      console.log('Luna Keywords: Showing', type, 'response');
    } else {
      console.log('Luna Keywords: Target div not found for', type, 'response');
    }
  }
  
  function luna_insert_shortcode(shortcode, targetFieldName) {
    if (!shortcode) return;
    
    const textarea = document.querySelector(`textarea[name="${targetFieldName}"]`);
    if (textarea) {
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const text = textarea.value;
      const before = text.substring(0, start);
      const after = text.substring(end, text.length);
      
      textarea.value = before + shortcode + after;
      textarea.focus();
      textarea.setSelectionRange(start + shortcode.length, start + shortcode.length);
    }
  }
  
  // Modal functionality
  function openModal(modalId) {
    document.getElementById(modalId).style.display = 'flex';
  }
  
  function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
  }
  
  // Add new keyword functionality
  function addNewKeyword() {
    openModal('keyword-modal');
  }
  
  function saveNewKeyword() {
    const category = document.getElementById('new-keyword-category').value;
    const action = document.getElementById('new-keyword-name').value;
    const terms = document.getElementById('new-keyword-terms').value;
    const dataSource = document.getElementById('new-keyword-data-source').value;
    const template = document.getElementById('new-keyword-template').value;
    
    if (!action || !terms) {
      alert('Please fill in the keyword name and terms.');
      return;
    }
    
    // Create new keyword row
    const container = document.querySelector('.luna-keywords-container');
    const newRow = document.createElement('div');
    newRow.className = 'luna-keyword-category';
    newRow.innerHTML = `
      <h3>${category.charAt(0).toUpperCase() + category.slice(1)} Keywords</h3>
      <table class="form-table">
        <tr>
          <th scope="row">${action.charAt(0).toUpperCase() + action.slice(1)}</th>
          <td>
            <div class="luna-keyword-config">
              <div class="luna-keyword-field">
                <label>
                  <input type="checkbox" name="keywords[${category}][${action}][enabled]" value="on" checked onchange="luna_toggle_keyword('${category}', '${action}')">
                  Enable this keyword
                </label>
              </div>
              <div class="luna-keyword-field">
                <label>Keywords:</label>
                <input type="text" name="keywords[${category}][${action}][terms]" class="regular-text" value="${terms}">
              </div>
              <div class="luna-keyword-field">
                <label>Data Source:</label>
                <select name="keywords[${category}][${action}][data_source]" onchange="luna_toggle_data_source_options(this, '${category}', '${action}')">
                  <option value="custom" ${dataSource === 'custom' ? 'selected' : ''}>Custom Response</option>
                  <option value="wp_rest" ${dataSource === 'wp_rest' ? 'selected' : ''}>WordPress Data</option>
                  <option value="security" ${dataSource === 'security' ? 'selected' : ''}>Security Data</option>
                </select>
              </div>
              <div class="luna-keyword-field">
                <label>Response Template:</label>
                <textarea name="keywords[${category}][${action}][template]" class="large-text" rows="3">${template}</textarea>
              </div>
            </div>
          </td>
        </tr>
      </table>
    `;
    
    // Add to container
    container.appendChild(newRow);
    
    // Initialize the new keyword
    luna_toggle_keyword(category, action);
    
    // Clear form and close modal
    document.getElementById('new-keyword-name').value = '';
    document.getElementById('new-keyword-terms').value = '';
    document.getElementById('new-keyword-template').value = '';
    closeModal('keyword-modal');
  }
  
  // Add new category functionality
  function addNewCategory() {
    openModal('category-modal');
  }
  
  function saveNewCategory() {
    const categoryName = document.getElementById('new-category-name').value;
    const description = document.getElementById('new-category-description').value;
    
    if (!categoryName) {
      alert('Please enter a category name.');
      return;
    }
    
    // Add to category dropdown
    const categorySelect = document.getElementById('new-keyword-category');
    const newOption = document.createElement('option');
    newOption.value = categoryName.toLowerCase().replace(/\s+/g, '_');
    newOption.textContent = categoryName.charAt(0).toUpperCase() + categoryName.slice(1);
    categorySelect.appendChild(newOption);
    
    // Clear form and close modal
    document.getElementById('new-category-name').value = '';
    document.getElementById('new-category-description').value = '';
    closeModal('category-modal');
    
    alert(`Category "${categoryName}" added successfully! You can now use it when adding new keywords.`);
  }
  
  // Manage existing keywords functionality
  function manageKeywords() {
    const container = document.getElementById('keyword-management-list');
    container.innerHTML = '';
    
    // Get all existing keywords
    const keywords = [];
    document.querySelectorAll('.luna-keyword-category').forEach(categoryDiv => {
      const categoryName = categoryDiv.querySelector('h3').textContent.replace(' Keywords', '').toLowerCase();
      categoryDiv.querySelectorAll('tr').forEach(row => {
        const th = row.querySelector('th');
        if (th && th.textContent.trim()) {
          const actionName = th.textContent.trim();
          const termsInput = row.querySelector('input[name*="[terms]"]');
          const terms = termsInput ? termsInput.value : '';
          
          keywords.push({
            category: categoryName,
            action: actionName,
            terms: terms,
            element: row
          });
        }
      });
    });
    
    // Create management interface
    keywords.forEach(keyword => {
      const item = document.createElement('div');
      item.className = 'keyword-management-item';
      item.innerHTML = `
        <div class="keyword-info">
          <div class="keyword-name">${keyword.action}</div>
          <div class="keyword-terms">${keyword.terms}</div>
        </div>
        <select data-category="${keyword.category}" data-action="${keyword.action}">
          <option value="business" ${keyword.category === 'business' ? 'selected' : ''}>Business</option>
          <option value="wp_rest" ${keyword.category === 'wp_rest' ? 'selected' : ''}>WordPress Data</option>
          <option value="security" ${keyword.category === 'security' ? 'selected' : ''}>Security</option>
          <option value="custom" ${keyword.category === 'custom' ? 'selected' : ''}>Custom</option>
        </select>
      `;
      container.appendChild(item);
    });
    
    openModal('manage-modal');
  }
  
  function saveKeywordChanges() {
    const changes = [];
    document.querySelectorAll('#keyword-management-list select').forEach(select => {
      const category = select.dataset.category;
      const action = select.dataset.action;
      const newCategory = select.value;
      
      if (category !== newCategory) {
        changes.push({ category, action, newCategory });
      }
    });
    
    if (changes.length === 0) {
      closeModal('manage-modal');
      return;
    }
    
    // Apply changes
    changes.forEach(change => {
      // Find the row and move it to the new category
      const row = document.querySelector(`input[name*="[${change.action}][enabled]"]`).closest('tr');
      const categoryDiv = row.closest('.luna-keyword-category');
      
      // Update the category name in the row
      const categorySelect = row.querySelector('select[name*="[data_source]"]');
      if (categorySelect) {
        const name = categorySelect.name;
        const newName = name.replace(`[${change.category}]`, `[${change.newCategory}]`);
        categorySelect.name = newName;
      }
      
      // Update all form elements in the row
      row.querySelectorAll('input, select, textarea').forEach(input => {
        if (input.name && input.name.includes(`[${change.category}]`)) {
          input.name = input.name.replace(`[${change.category}]`, `[${change.newCategory}]`);
        }
      });
    });
    
    closeModal('manage-modal');
    alert(`Moved ${changes.length} keyword(s) to new categories. Don't forget to save the form!`);
  }
  
  // Initialize the interface on page load
  document.addEventListener('DOMContentLoaded', function() {
    console.log('Luna Keywords: Initializing interface...');
    
    // Button event listeners
    document.getElementById('add-new-keyword').addEventListener('click', addNewKeyword);
    document.getElementById('add-new-category').addEventListener('click', addNewCategory);
    document.getElementById('manage-keywords').addEventListener('click', manageKeywords);
    
    // Modal event listeners
    document.getElementById('save-new-keyword').addEventListener('click', saveNewKeyword);
    document.getElementById('cancel-new-keyword').addEventListener('click', () => closeModal('keyword-modal'));
    document.getElementById('save-new-category').addEventListener('click', saveNewCategory);
    document.getElementById('cancel-new-category').addEventListener('click', () => closeModal('category-modal'));
    document.getElementById('save-keyword-changes').addEventListener('click', saveKeywordChanges);
    document.getElementById('cancel-keyword-changes').addEventListener('click', () => closeModal('manage-modal'));
    
    // Close modal when clicking X
    document.querySelectorAll('.luna-modal-close').forEach(closeBtn => {
      closeBtn.addEventListener('click', function() {
        const modal = this.closest('.luna-modal');
        modal.style.display = 'none';
      });
    });
    
    // Close modal when clicking outside
    document.querySelectorAll('.luna-modal').forEach(modal => {
      modal.addEventListener('click', function(e) {
        if (e.target === this) {
          this.style.display = 'none';
        }
      });
    });
    
    // Initialize all data source options
    document.querySelectorAll('select[name*="[data_source]"]').forEach(select => {
      const categoryMatch = select.name.match(/keywords\[([^\]]+)\]/);
      const actionMatch = select.name.match(/\[([^\]]+)\]\[data_source\]/);
      
      if (categoryMatch && actionMatch) {
        const category = categoryMatch[1];
        const action = actionMatch[1];
        console.log('Luna Keywords: Initializing data source for', category, action, '=', select.value);
        luna_toggle_data_source_options(select, category, action);
      }
    });
    
    // Initialize all response types for custom responses
    document.querySelectorAll('input[name*="[response_type]"]:checked').forEach(radio => {
      const categoryMatch = radio.name.match(/keywords\[([^\]]+)\]/);
      const actionMatch = radio.name.match(/\[([^\]]+)\]\[response_type\]/);
      
      if (categoryMatch && actionMatch) {
        const category = categoryMatch[1];
        const action = actionMatch[1];
        const type = radio.value;
        console.log('Luna Keywords: Initializing response type for', category, action, '=', type);
        luna_toggle_response_type(category, action, type);
      }
    });
  });
  </script>
  <?php
}

/* ============================================================
 * SECURITY HELPERS
 * ============================================================ */
function luna_license_ok( WP_REST_Request $req ) {
  $saved = (string) get_option(LUNA_WIDGET_OPT_LICENSE, '');
  if ($saved === '') return false;
  $hdr = trim((string) ($req->get_header('X-Luna-License') ? $req->get_header('X-Luna-License') : ''));
  $qp  = trim((string) $req->get_param('license'));
  $provided = $hdr ? $hdr : $qp;
  if (!$provided) return false;
  if (!is_ssl() && $qp) return false; // only allow license in query over https
  return hash_equals($saved, $provided);
}
function luna_forbidden() {
  return new WP_REST_Response(array('ok'=>false,'error'=>'forbidden'), 403);
}

/**
 * Analyzes help requests and offers contextual assistance options
 */
function luna_analyze_help_request($prompt, $facts) {
  $help_type = luna_detect_help_type($prompt);
  $site_url = isset($facts['site_url']) ? $facts['site_url'] : home_url('/');
  $site_name = parse_url($site_url, PHP_URL_HOST);
  
  $response = "I understand you're experiencing an issue. Let me help you get this resolved quickly! ";
  
  switch ($help_type) {
    case 'technical':
      $response .= "This sounds like a technical issue. I can help you in a few ways:\n\n";
      $response .= "🔧 **Option 1: Send Support Email**\n";
      $response .= "I can send a detailed snapshot of our conversation and your site data to your email for technical review.\n\n";
      $response .= "📧 **Option 2: Notify Visible Light Team**\n";
      $response .= "I can alert the Visible Light support team about this issue.\n\n";
      $response .= "🐛 **Option 3: Report as Bug**\n";
      $response .= "If this seems like a bug, I can report it directly to the development team.\n\n";
      $response .= "Which option would you prefer? Just say 'support email', 'notify VL', or 'report bug'.";
      break;
      
    case 'content':
      $response .= "This seems like a content or website management issue. I can help you by:\n\n";
      $response .= "📝 **Option 1: Content Support**\n";
      $response .= "Send your content team a detailed report of what you're trying to accomplish.\n\n";
      $response .= "📧 **Option 2: Notify Visible Light**\n";
      $response .= "Alert the Visible Light team about this content issue.\n\n";
      $response .= "Which would you prefer? Say 'support email' or 'notify VL'.";
      break;
      
    case 'urgent':
      $response .= "This sounds urgent! I can help you immediately by:\n\n";
      $response .= "🚨 **Option 1: Emergency Support**\n";
      $response .= "Send an urgent support request with full context to your team.\n\n";
      $response .= "📞 **Option 2: Notify Visible Light**\n";
      $response .= "Alert the Visible Light team immediately about this urgent issue.\n\n";
      $response .= "🐛 **Option 3: Report Critical Bug**\n";
      $response .= "If this is a critical bug, report it directly to development.\n\n";
      $response .= "Which option would you like? Say 'support email', 'notify VL', or 'report bug'.";
      break;
      
    default:
      $response .= "I can help you get this resolved. Here are your options:\n\n";
      $response .= "📧 **Option 1: Send Support Email**\n";
      $response .= "I'll send a detailed snapshot of our conversation to your email.\n\n";
      $response .= "📞 **Option 2: Notify Visible Light**\n";
      $response .= "I'll alert the Visible Light team about this issue.\n\n";
      $response .= "🐛 **Option 3: Report Bug**\n";
      $response .= "If this seems like a bug, I'll report it to the development team.\n\n";
      $response .= "Which option would you prefer? Just say 'support email', 'notify VL', or 'report bug'.";
  }
  
  return $response;
}

/**
 * Detects the type of help request based on keywords and context
 */
function luna_detect_help_type($prompt) {
  $lc = strtolower($prompt);
  
  // Urgent keywords
  if (preg_match('/\b(urgent|critical|emergency|down|crash|fatal|broken|not working|error|bug)\b/', $lc)) {
    return 'urgent';
  }
  
  // Technical keywords
  if (preg_match('/\b(technical|server|database|plugin|theme|code|php|mysql|error|bug|fix|repair)\b/', $lc)) {
    return 'technical';
  }
  
  // Content keywords
  if (preg_match('/\b(content|page|post|edit|update|publish|media|image|text|format)\b/', $lc)) {
    return 'content';
  }
  
  return 'general';
}

/**
 * Handles help option responses
 */
function luna_handle_help_option($option, $prompt, $facts) {
  switch ($option) {
    case 'support_email':
      return luna_handle_support_email_request($prompt, $facts);
    case 'notify_vl':
      return luna_handle_notify_vl_request($prompt, $facts);
    case 'report_bug':
      return luna_handle_bug_report_request($prompt, $facts);
    default:
      return "I'm not sure which option you meant. Please say 'support email', 'notify VL', or 'report bug'.";
  }
}

/**
 * Handles support email requests
 */
function luna_handle_support_email_request($prompt, $facts) {
  return "Great! I'd be happy to send you a detailed snapshot of our conversation and your site data. Which email address would you like me to send this to?";
}

/**
 * Handles Visible Light notification requests
 */
function luna_handle_notify_vl_request($prompt, $facts) {
  $site_url = isset($facts['site_url']) ? $facts['site_url'] : home_url('/');
  $site_name = parse_url($site_url, PHP_URL_HOST);
  
  // Send notification to Visible Light
  $success = luna_send_vl_notification($prompt, $facts);
  
  if ($success) {
    return "✅ I've notified the Visible Light team about your issue. They'll review the details and get back to you soon. Is there anything else I can help you with?";
  } else {
    return "I encountered an issue sending the notification. Let me try the support email option instead - which email address would you like me to send the snapshot to?";
  }
}

/**
 * Handles bug report requests
 */
function luna_handle_bug_report_request($prompt, $facts) {
  $site_url = isset($facts['site_url']) ? $facts['site_url'] : home_url('/');
  $site_name = parse_url($site_url, PHP_URL_HOST);
  
  // Send bug report to Visible Light
  $success = luna_send_bug_report($prompt, $facts);
  
  if ($success) {
    return "🐛 I've reported this as a bug to the Visible Light development team. They'll investigate and work on a fix. You should hear back soon. Is there anything else I can help you with?";
  } else {
    return "I encountered an issue sending the bug report. Let me try the support email option instead - which email address would you like me to send the snapshot to?";
  }
}

/**
 * Sends notification to Visible Light team
 */
function luna_send_vl_notification($prompt, $facts) {
  $site_url = isset($facts['site_url']) ? $facts['site_url'] : home_url('/');
  $site_name = parse_url($site_url, PHP_URL_HOST);
  $license = luna_get_license();
  
  $subject = "Luna Chat Support Request - " . $site_name;
  $message = "
  <html>
  <body style='font-family: Arial, sans-serif; line-height: 1.6; color: #333;'>
    <div style='max-width: 600px; margin: 0 auto; padding: 20px;'>
      <h2 style='color: #2B6AFF;'>Luna Chat Support Request</h2>
      <p><strong>Site:</strong> " . esc_html($site_name) . "</p>
      <p><strong>URL:</strong> " . esc_html($site_url) . "</p>
      <p><strong>License:</strong> " . esc_html($license) . "</p>
      <p><strong>Issue:</strong> " . esc_html($prompt) . "</p>
      
      <h3>Site Information:</h3>
      <ul>
        <li>WordPress Version: " . esc_html($facts['wp_version'] ?? 'Unknown') . "</li>
        <li>PHP Version: " . esc_html($facts['php_version'] ?? 'Unknown') . "</li>
        <li>Theme: " . esc_html($facts['theme'] ?? 'Unknown') . "</li>
        <li>Health Score: " . esc_html($facts['health_score'] ?? 'Unknown') . "%</li>
      </ul>
      
      <p>This request was generated automatically by Luna Chat AI.</p>
    </div>
  </body>
  </html>
  ";
  
  $headers = array('Content-Type: text/html; charset=UTF-8');
  return wp_mail('support@visiblelight.ai', $subject, $message, $headers);
}

/**
 * Sends bug report to Visible Light team
 */
function luna_send_bug_report($prompt, $facts) {
  $site_url = isset($facts['site_url']) ? $facts['site_url'] : home_url('/');
  $site_name = parse_url($site_url, PHP_URL_HOST);
  $license = luna_get_license();
  
  $subject = "🐛 Bug Report - " . $site_name . " - Luna Chat";
  $message = "
  <html>
  <body style='font-family: Arial, sans-serif; line-height: 1.6; color: #333;'>
    <div style='max-width: 600px; margin: 0 auto; padding: 20px;'>
      <h2 style='color: #d63638;'>🐛 Bug Report</h2>
      <p><strong>Site:</strong> " . esc_html($site_name) . "</p>
      <p><strong>URL:</strong> " . esc_html($site_url) . "</p>
      <p><strong>License:</strong> " . esc_html($license) . "</p>
      <p><strong>Bug Description:</strong> " . esc_html($prompt) . "</p>
      
      <h3>System Information:</h3>
      <ul>
        <li>WordPress Version: " . esc_html($facts['wp_version'] ?? 'Unknown') . "</li>
        <li>PHP Version: " . esc_html($facts['php_version'] ?? 'Unknown') . "</li>
        <li>Theme: " . esc_html($facts['theme'] ?? 'Unknown') . "</li>
        <li>Health Score: " . esc_html($facts['health_score'] ?? 'Unknown') . "%</li>
        <li>SSL Status: " . (isset($facts['tls_valid']) && $facts['tls_valid'] ? 'Active' : 'Issues') . "</li>
      </ul>
      
      <p>This bug report was generated automatically by Luna Chat AI.</p>
    </div>
  </body>
  </html>
  ";
  
  $headers = array('Content-Type: text/html; charset=UTF-8');
  return wp_mail('bugs@visiblelight.ai', $subject, $message, $headers);
}

/**
 * Extracts email address from text
 */
function luna_extract_email($text) {
  if (preg_match('/\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b/', $text, $matches)) {
    return $matches[0];
  }
  return false;
}

/**
 * Sends support email with chat snapshot
 */
function luna_send_support_email($email, $prompt, $facts) {
  $site_url = isset($facts['site_url']) ? $facts['site_url'] : home_url('/');
  $site_name = parse_url($site_url, PHP_URL_HOST);
  $license = luna_get_license();
  
  $subject = "Luna Chat Support Snapshot - " . $site_name;
  $message = "
  <html>
  <body style='font-family: Arial, sans-serif; line-height: 1.6; color: #333;'>
    <div style='max-width: 600px; margin: 0 auto; padding: 20px;'>
      <h2 style='color: #2B6AFF;'>Luna Chat Support Snapshot</h2>
      <p>This email contains a detailed snapshot of your Luna Chat conversation and site data.</p>
      
      <h3>Site Information:</h3>
      <ul>
        <li><strong>Site:</strong> " . esc_html($site_name) . "</li>
        <li><strong>URL:</strong> " . esc_html($site_url) . "</li>
        <li><strong>License:</strong> " . esc_html($license) . "</li>
        <li><strong>WordPress Version:</strong> " . esc_html($facts['wp_version'] ?? 'Unknown') . "</li>
        <li><strong>PHP Version:</strong> " . esc_html($facts['php_version'] ?? 'Unknown') . "</li>
        <li><strong>Theme:</strong> " . esc_html($facts['theme'] ?? 'Unknown') . "</li>
        <li><strong>Health Score:</strong> " . esc_html($facts['health_score'] ?? 'Unknown') . "%</li>
        <li><strong>SSL Status:</strong> " . (isset($facts['tls_valid']) && $facts['tls_valid'] ? 'Active' : 'Issues') . "</li>
      </ul>
      
      <h3>Issue Description:</h3>
      <p>" . esc_html($prompt) . "</p>
      
      <h3>System Health Details:</h3>
      <ul>
        <li>Memory Usage: " . esc_html($facts['memory_usage'] ?? 'Unknown') . "</li>
        <li>Active Plugins: " . (isset($facts['active_plugins']) ? count($facts['active_plugins']) : 'Unknown') . "</li>
        <li>Pages: " . esc_html($facts['pages_count'] ?? 'Unknown') . "</li>
        <li>Posts: " . esc_html($facts['posts_count'] ?? 'Unknown') . "</li>
      </ul>
      
      <h3>Analytics Data:</h3>";
  
  if (isset($facts['ga4_metrics'])) {
    $ga4 = $facts['ga4_metrics'];
    $message .= "<ul>";
    $message .= "<li>Total Users: " . esc_html($ga4['totalUsers'] ?? 'N/A') . "</li>";
    $message .= "<li>New Users: " . esc_html($ga4['newUsers'] ?? 'N/A') . "</li>";
    $message .= "<li>Sessions: " . esc_html($ga4['sessions'] ?? 'N/A') . "</li>";
    $message .= "<li>Page Views: " . esc_html($ga4['screenPageViews'] ?? 'N/A') . "</li>";
    $message .= "<li>Bounce Rate: " . esc_html($ga4['bounceRate'] ?? 'N/A') . "%</li>";
    $message .= "<li>Engagement Rate: " . esc_html($ga4['engagementRate'] ?? 'N/A') . "%</li>";
    $message .= "</ul>";
  } else {
    $message .= "<p>No analytics data available</p>";
  }
  
  $message .= "
      <hr style='margin: 30px 0; border: none; border-top: 1px solid #eee;'>
      <p style='font-size: 12px; color: #666;'>This support snapshot was generated automatically by Luna Chat AI on " . date('Y-m-d H:i:s T') . "</p>
    </div>
  </body>
  </html>
  ";
  
  $headers = array('Content-Type: text/html; charset=UTF-8');
  return wp_mail($email, $subject, $message, $headers);
}

/**
 * Handles analytics requests and provides GA4 data
 */
function luna_handle_analytics_request($prompt, $facts) {
  $site_url = isset($facts['site_url']) ? $facts['site_url'] : home_url('/');
  $site_name = parse_url($site_url, PHP_URL_HOST);

  // Get GA4 data from facts array (same as intelligence report)
  $ga4_metrics = null;
  $ga4_meta = array(
    'last_synced'    => isset($facts['ga4_last_synced']) ? $facts['ga4_last_synced'] : null,
    'date_range'     => isset($facts['ga4_date_range']) ? $facts['ga4_date_range'] : null,
    'source_url'     => isset($facts['ga4_source_url']) ? $facts['ga4_source_url'] : null,
    'property_id'    => isset($facts['ga4_property_id']) ? $facts['ga4_property_id'] : null,
    'measurement_id' => isset($facts['ga4_measurement_id']) ? $facts['ga4_measurement_id'] : null,
  );

  if (isset($facts['ga4_metrics'])) {
    $ga4_metrics = $facts['ga4_metrics'];
  }

  // Debug logging
  error_log('[Luna Analytics] Facts keys: ' . implode(', ', array_keys($facts)));
  error_log('[Luna Analytics] GA4 metrics found: ' . ($ga4_metrics ? 'YES' : 'NO'));
  if ($ga4_metrics) {
    error_log('[Luna Analytics] GA4 data: ' . print_r($ga4_metrics, true));
  }

  if (!$ga4_metrics) {
    error_log('[Luna Analytics] Attempting to fetch GA4 metrics directly from Hub data streams.');
    $ga4_info = luna_fetch_ga4_metrics_from_hub();
    if ($ga4_info && isset($ga4_info['metrics'])) {
      $ga4_metrics = $ga4_info['metrics'];
      foreach (array('last_synced','date_range','source_url','property_id','measurement_id') as $meta_key) {
        if (isset($ga4_info[$meta_key]) && empty($ga4_meta[$meta_key])) {
          $ga4_meta[$meta_key] = $ga4_info[$meta_key];
        }
      }
      // Also extract dimensions if available
      if (isset($ga4_info['dimensions']) && is_array($ga4_info['dimensions']) && !empty($ga4_info['dimensions'])) {
        $ga4_dimensions = $ga4_info['dimensions'];
        $facts['ga4_dimensions'] = $ga4_dimensions;
        error_log('[Luna Analytics] GA4 dimensions hydrated from data streams: ' . count($ga4_dimensions) . ' types');
      }
      error_log('[Luna Analytics] GA4 metrics hydrated from data streams: ' . print_r($ga4_metrics, true));
    }
  }

  if (!$ga4_metrics) {
    return "I don't have access to your analytics data right now. Your GA4 integration may need to be refreshed. You can check your analytics settings in the Visible Light Hub profile, or I can help you set up Google Analytics if it's not configured yet.";
  }

  $lc = strtolower($prompt);

  // Get GA4 dimensional data if available
  $ga4_dimensions = isset($facts['ga4_dimensions']) && is_array($facts['ga4_dimensions']) ? $facts['ga4_dimensions'] : null;
  
  // Debug logging for dimensional data
  error_log('[Luna Analytics] GA4 dimensions available: ' . ($ga4_dimensions ? 'YES (' . count($ga4_dimensions) . ' types)' : 'NO'));
  if ($ga4_dimensions) {
    error_log('[Luna Analytics] Dimension keys: ' . implode(', ', array_keys($ga4_dimensions)));
  }

  // Handle geographic questions (where visitors come from, countries, cities, regions)
  // Check for geographic keywords FIRST before other handlers
  if (preg_match('/(where.*(visitors|users|traffic|people).*come.*from|visitors.*from|users.*from|traffic.*from|geographic|location|country|countries|city|cities|region|regions|state|states|where.*are|which.*country|which.*city|most.*visitors.*from|where.*most)/i', $lc)) {
    if ($ga4_dimensions) {
      $geographic_data = null;
      if (isset($ga4_dimensions['geographic']['rows']) && is_array($ga4_dimensions['geographic']['rows'])) {
        $geographic_data = $ga4_dimensions['geographic']['rows'];
      } elseif (isset($ga4_dimensions['geographic']) && is_array($ga4_dimensions['geographic']) && isset($ga4_dimensions['geographic'][0])) {
        $geographic_data = $ga4_dimensions['geographic'];
      }
      
      if ($geographic_data && !empty($geographic_data)) {
        $response = "Based on your Google Analytics 4 data, here's where your visitors are coming from:\n\n";
        $response .= "**Top Locations:**\n";
        
        $top_locations = array_slice($geographic_data, 0, 10);
        foreach ($top_locations as $index => $row) {
          if (!is_array($row) || empty($row['dimensionValues']) || empty($row['metricValues'])) continue;
          
          $country = $row['dimensionValues'][0]['value'] ?? '(not set)';
          $region = $row['dimensionValues'][1]['value'] ?? '(not set)';
          $city = $row['dimensionValues'][2]['value'] ?? '(not set)';
          $users = isset($row['metricValues'][0]['value']) ? (int)$row['metricValues'][0]['value'] : 0;
          $sessions = isset($row['metricValues'][2]['value']) ? (int)$row['metricValues'][2]['value'] : 0;
          $page_views = isset($row['metricValues'][3]['value']) ? (int)$row['metricValues'][3]['value'] : 0;
          
          if ($country === '(not set)' && $region === '(not set)' && $city === '(not set)') continue;
          
          $location_name = $city;
          if ($city !== '(not set)' && $region !== '(not set)') {
            $location_name .= ', ' . $region;
          }
          if ($country !== '(not set)') {
            $location_name .= ', ' . $country;
          }
          
          $response .= ($index + 1) . ". **" . $location_name . "**: " . number_format($users) . " users, " . number_format($sessions) . " sessions, " . number_format($page_views) . " page views\n";
        }
        
        // Calculate totals
        $total_locations = count($geographic_data);
        $response .= "\n**Summary:**\n";
        $response .= "• Total locations tracked: " . $total_locations . "\n";
        
        // Find top country
        $country_totals = array();
        foreach ($geographic_data as $row) {
          if (!is_array($row) || empty($row['dimensionValues']) || empty($row['metricValues'])) continue;
          $country = $row['dimensionValues'][0]['value'] ?? '';
          if ($country && $country !== '(not set)') {
            $users = isset($row['metricValues'][0]['value']) ? (int)$row['metricValues'][0]['value'] : 0;
            if (!isset($country_totals[$country])) {
              $country_totals[$country] = 0;
            }
            $country_totals[$country] += $users;
          }
        }
        if (!empty($country_totals)) {
          arsort($country_totals);
          $top_country = array_key_first($country_totals);
          $response .= "• Top country: **" . $top_country . "** with " . number_format($country_totals[$top_country]) . " users\n";
        }
        
        if (!empty($ga4_meta['date_range']) && is_array($ga4_meta['date_range'])) {
          $start = isset($ga4_meta['date_range']['startDate']) ? $ga4_meta['date_range']['startDate'] : '';
          $end = isset($ga4_meta['date_range']['endDate']) ? $ga4_meta['date_range']['endDate'] : '';
          if ($start && $end) {
            $response .= "\n*Data period: " . $start . " to " . $end . "*";
          }
        }
        
        return $response;
      }
    }
    // Fallback if no geographic data
    $total_users = isset($ga4_metrics['totalUsers']) ? number_format((int)$ga4_metrics['totalUsers']) : 'N/A';
    return "I can see you have " . $total_users . " total users, but I don't have geographic breakdown data available right now. Try syncing your GA4 connection in the Visible Light Hub to get location-specific insights.";
  }

  // Handle device questions (what devices, browsers, mobile, desktop)
  if (preg_match('/\b(device|devices|browser|browsers|mobile|desktop|tablet|what.*device|which.*device|device.*type|device.*used)\b/i', $lc)) {
    if ($ga4_dimensions) {
      $device_data = null;
      if (isset($ga4_dimensions['device']['rows']) && is_array($ga4_dimensions['device']['rows'])) {
        $device_data = $ga4_dimensions['device']['rows'];
      } elseif (isset($ga4_dimensions['device']) && is_array($ga4_dimensions['device']) && isset($ga4_dimensions['device'][0])) {
        $device_data = $ga4_dimensions['device'];
      }
      
      if ($device_data && !empty($device_data)) {
        $response = "Here's the device breakdown for your visitors:\n\n";
        $response .= "**Device Usage:**\n";
        
        foreach ($device_data as $row) {
          if (!is_array($row) || empty($row['dimensionValues']) || empty($row['metricValues'])) continue;
          
          $device = $row['dimensionValues'][0]['value'] ?? '(not set)';
          $brand = $row['dimensionValues'][1]['value'] ?? '(not set)';
          $browser = $row['dimensionValues'][2]['value'] ?? '(not set)';
          $users = isset($row['metricValues'][0]['value']) ? (int)$row['metricValues'][0]['value'] : 0;
          $sessions = isset($row['metricValues'][2]['value']) ? (int)$row['metricValues'][2]['value'] : 0;
          $page_views = isset($row['metricValues'][3]['value']) ? (int)$row['metricValues'][3]['value'] : 0;
          
          $device_label = ucfirst($device);
          if ($brand !== '(not set)' && $browser !== '(not set)') {
            $device_label .= " (" . $brand . " " . $browser . ")";
          } elseif ($browser !== '(not set)') {
            $device_label .= " (" . $browser . ")";
          }
          
          $response .= "• **" . $device_label . "**: " . number_format($users) . " users, " . number_format($sessions) . " sessions, " . number_format($page_views) . " page views\n";
        }
        
        // Calculate device category totals
        $device_totals = array('desktop' => 0, 'mobile' => 0, 'tablet' => 0);
        foreach ($device_data as $row) {
          if (!is_array($row) || empty($row['dimensionValues']) || empty($row['metricValues'])) continue;
          $device = strtolower($row['dimensionValues'][0]['value'] ?? '');
          $users = isset($row['metricValues'][0]['value']) ? (int)$row['metricValues'][0]['value'] : 0;
          if (isset($device_totals[$device])) {
            $device_totals[$device] += $users;
          }
        }
        
        $response .= "\n**Summary:**\n";
        foreach ($device_totals as $device_type => $total) {
          if ($total > 0) {
            $response .= "• " . ucfirst($device_type) . ": " . number_format($total) . " users\n";
          }
        }
        
        return $response;
      }
    }
    // Fallback if no device data
    return "I don't have device breakdown data available right now. Try syncing your GA4 connection in the Visible Light Hub to get device-specific insights.";
  }

  // Handle traffic source questions (where traffic comes from, sources, campaigns, organic, direct)
  if (preg_match('/\b(traffic.*source|traffic.*sources|where.*traffic|source.*traffic|campaign|campaigns|organic|direct|referral|referrals|medium|where.*come.*from)\b/i', $lc)) {
    if ($ga4_dimensions) {
      $traffic_data = null;
      if (isset($ga4_dimensions['traffic']['rows']) && is_array($ga4_dimensions['traffic']['rows'])) {
        $traffic_data = $ga4_dimensions['traffic']['rows'];
      } elseif (isset($ga4_dimensions['traffic']) && is_array($ga4_dimensions['traffic']) && isset($ga4_dimensions['traffic'][0])) {
        $traffic_data = $ga4_dimensions['traffic'];
      }
      
      if ($traffic_data && !empty($traffic_data)) {
        $response = "Here's where your traffic is coming from:\n\n";
        $response .= "**Traffic Sources:**\n";
        
        foreach ($traffic_data as $row) {
          if (!is_array($row) || empty($row['dimensionValues']) || empty($row['metricValues'])) continue;
          
          $source = $row['dimensionValues'][0]['value'] ?? '(not set)';
          $medium = $row['dimensionValues'][1]['value'] ?? '(not set)';
          $campaign = $row['dimensionValues'][2]['value'] ?? '(not set)';
          $users = isset($row['metricValues'][0]['value']) ? (int)$row['metricValues'][0]['value'] : 0;
          $sessions = isset($row['metricValues'][2]['value']) ? (int)$row['metricValues'][2]['value'] : 0;
          $page_views = isset($row['metricValues'][3]['value']) ? (int)$row['metricValues'][3]['value'] : 0;
          
          $source_label = $source;
          if ($medium !== '(not set)') {
            $source_label .= " / " . $medium;
          }
          if ($campaign !== '(not set)') {
            $source_label .= " / " . $campaign;
          }
          
          $response .= "• **" . $source_label . "**: " . number_format($users) . " users, " . number_format($sessions) . " sessions, " . number_format($page_views) . " page views\n";
        }
        
        return $response;
      }
    }
    // Fallback if no traffic data
    return "I don't have traffic source breakdown data available right now. Try syncing your GA4 connection in the Visible Light Hub to get source-specific insights.";
  }

  // Handle top pages questions (most visited, popular pages, top pages)
  if (preg_match('/\b(top.*pages|popular.*pages|most.*visited|most.*popular|which.*pages|page.*traffic|best.*pages)\b/i', $lc)) {
    if ($ga4_dimensions) {
      $pages_data = null;
      if (isset($ga4_dimensions['pages']['rows']) && is_array($ga4_dimensions['pages']['rows'])) {
        $pages_data = $ga4_dimensions['pages']['rows'];
      } elseif (isset($ga4_dimensions['pages']) && is_array($ga4_dimensions['pages']) && isset($ga4_dimensions['pages'][0])) {
        $pages_data = $ga4_dimensions['pages'];
      }
      
      if ($pages_data && !empty($pages_data)) {
        $response = "Here are your top-performing pages:\n\n";
        $response .= "**Top Pages:**\n";
        
        $top_pages = array_slice($pages_data, 0, 15);
        foreach ($top_pages as $index => $row) {
          if (!is_array($row) || empty($row['dimensionValues']) || empty($row['metricValues'])) continue;
          
          $path = $row['dimensionValues'][0]['value'] ?? '(not set)';
          $title = $row['dimensionValues'][1]['value'] ?? '(not set)';
          $users = isset($row['metricValues'][0]['value']) ? (int)$row['metricValues'][0]['value'] : 0;
          $sessions = isset($row['metricValues'][2]['value']) ? (int)$row['metricValues'][2]['value'] : 0;
          $page_views = isset($row['metricValues'][3]['value']) ? (int)$row['metricValues'][3]['value'] : 0;
          
          if ($path === '(not set)') continue;
          
          $page_label = $title !== '(not set)' ? $title : $path;
          $response .= ($index + 1) . ". **" . $page_label . "**\n";
          $response .= "   Path: " . $path . "\n";
          $response .= "   " . number_format($users) . " users, " . number_format($sessions) . " sessions, " . number_format($page_views) . " page views\n\n";
        }
        
        return $response;
      }
    }
    // Fallback if no pages data
    return "I don't have page-level breakdown data available right now. Try syncing your GA4 connection in the Visible Light Hub to get page-specific insights.";
  }

  // Handle events questions (tracked events, event performance)
  if (preg_match('/\b(events|tracked.*events|event.*performance|which.*events|what.*events|event.*data)\b/i', $lc)) {
    if ($ga4_dimensions) {
      $events_data = null;
      if (isset($ga4_dimensions['events']['rows']) && is_array($ga4_dimensions['events']['rows'])) {
        $events_data = $ga4_dimensions['events']['rows'];
      } elseif (isset($ga4_dimensions['events']) && is_array($ga4_dimensions['events']) && isset($ga4_dimensions['events'][0])) {
        $events_data = $ga4_dimensions['events'];
      }
      
      if ($events_data && !empty($events_data)) {
        $response = "Here are your tracked events:\n\n";
        $response .= "**Events:**\n";
        
        foreach ($events_data as $row) {
          if (!is_array($row) || empty($row['dimensionValues']) || empty($row['metricValues'])) continue;
          
          $event_name = $row['dimensionValues'][0]['value'] ?? '(not set)';
          $event_count = isset($row['metricValues'][0]['value']) ? (int)$row['metricValues'][0]['value'] : 0;
          $users = isset($row['metricValues'][1]['value']) ? (int)$row['metricValues'][1]['value'] : 0;
          $conversions = isset($row['metricValues'][2]['value']) ? (int)$row['metricValues'][2]['value'] : 0;
          
          $response .= "• **" . $event_name . "**: " . number_format($event_count) . " events, " . number_format($users) . " users";
          if ($conversions > 0) {
            $response .= ", " . number_format($conversions) . " conversions";
          }
          $response .= "\n";
        }
        
        return $response;
      }
    }
    // Fallback if no events data
    return "I don't have event tracking data available right now. Try syncing your GA4 connection in the Visible Light Hub to get event-specific insights.";
  }

  // Handle specific analytics questions
  if (preg_match('/\b(page.*views|pageviews)\b/', $lc)) {
    $page_views = isset($ga4_metrics['screenPageViews']) ? $ga4_metrics['screenPageViews'] : 'N/A';
    return "Your page views for the current period are: **" . $page_views . "** views. This data comes from your Google Analytics 4 integration.";
  }

  if (preg_match('/\b(users|visitors)\b/', $lc) && !preg_match('/\b(where|from|geographic|location|country|city)\b/i', $lc)) {
    $total_users = isset($ga4_metrics['totalUsers']) ? $ga4_metrics['totalUsers'] : 'N/A';
    $new_users = isset($ga4_metrics['newUsers']) ? $ga4_metrics['newUsers'] : 'N/A';
    $active_users = isset($ga4_metrics['activeUsers']) ? $ga4_metrics['activeUsers'] : null;
    
    $response = "Your user analytics show:\n";
    $response .= "• **Total Users**: " . number_format((int)$total_users) . "\n";
    $response .= "• **New Users**: " . number_format((int)$new_users) . "\n";
    if ($active_users !== null) {
      $response .= "• **Active Users**: " . number_format((int)$active_users) . "\n";
    }
    $response .= "\nThis data comes from your Google Analytics 4 integration.";
    
    // Add context if available
    if (!empty($ga4_meta['date_range']) && is_array($ga4_meta['date_range'])) {
      $start = isset($ga4_meta['date_range']['startDate']) ? $ga4_meta['date_range']['startDate'] : '';
      $end = isset($ga4_meta['date_range']['endDate']) ? $ga4_meta['date_range']['endDate'] : '';
      if ($start && $end) {
        $response .= "\n\n*Reporting period: " . $start . " to " . $end . "*";
      }
    }
    
    return $response;
  }

  if (preg_match('/\b(sessions)\b/', $lc)) {
    $sessions = isset($ga4_metrics['sessions']) ? $ga4_metrics['sessions'] : 'N/A';
    return "Your sessions for the current period are: **" . $sessions . "** sessions. This data comes from your Google Analytics 4 integration.";
  }

  if (preg_match('/\b(bounce.*rate)\b/', $lc)) {
    $bounce_rate = isset($ga4_metrics['bounceRate']) ? $ga4_metrics['bounceRate'] : 'N/A';
    return "Your bounce rate is: **" . $bounce_rate . "%**. This data comes from your Google Analytics 4 integration.";
  }

  if (preg_match('/\b(engagement.*rate|engagement)\b/', $lc)) {
    $engagement_rate = isset($ga4_metrics['engagementRate']) ? $ga4_metrics['engagementRate'] : 'N/A';
    return "Your engagement rate is: **" . $engagement_rate . "%**. This data comes from your Google Analytics 4 integration.";
  }

  if (preg_match('/\b(property\s*id|ga4\s*property)\b/', $lc) && strpos($lc, 'measurement') === false) {
    if (!empty($ga4_meta['property_id'])) {
      return "Your Google Analytics 4 property ID is **" . $ga4_meta['property_id'] . "**.";
    }
    return "I couldn't find a GA4 property ID in your Hub profile. Double-check the Visible Light Hub analytics settings to confirm it's saved.";
  }

  if (preg_match('/measurement\s*id/', $lc)) {
    if (!empty($ga4_meta['measurement_id'])) {
      return "Your GA4 measurement ID is **" . $ga4_meta['measurement_id'] . "**.";
    }
    return "I don't see a GA4 measurement ID recorded yet. Make sure it's configured in your Visible Light Hub analytics settings.";
  }

  if (preg_match('/(last|recent).*(sync|synced|update|updated|refresh)/', $lc)) {
    if (!empty($ga4_meta['last_synced'])) {
      $range_text = '';
      if (!empty($ga4_meta['date_range']) && is_array($ga4_meta['date_range'])) {
        $start = isset($ga4_meta['date_range']['startDate']) ? $ga4_meta['date_range']['startDate'] : '';
        $end   = isset($ga4_meta['date_range']['endDate']) ? $ga4_meta['date_range']['endDate'] : '';
        if ($start || $end) {
          $range_text = ' covering ' . trim($start . ' to ' . $end);
        }
      }
      return "Your GA4 metrics were last synced on **" . $ga4_meta['last_synced'] . "**" . $range_text . ".";
    }
    return "I wasn't able to confirm the last sync time from the Hub profile. Try refreshing the GA4 connection in Visible Light Hub to capture a new sync timestamp.";
  }

  if (preg_match('/(date\s*range|time\s*range|timeframe|time\s*frame|reporting\s*period)/', $lc)) {
    if (!empty($ga4_meta['date_range']) && is_array($ga4_meta['date_range'])) {
      $start = isset($ga4_meta['date_range']['startDate']) ? $ga4_meta['date_range']['startDate'] : 'unknown start';
      $end   = isset($ga4_meta['date_range']['endDate']) ? $ga4_meta['date_range']['endDate'] : 'unknown end';
      return "The current GA4 report covers **" . $start . "** through **" . $end . "**.";
    }
    return "I couldn't determine the reporting range. Try re-syncing GA4 from the Visible Light Hub profile to capture a date window.";
  }

  // Handle traffic-related questions (low traffic, traffic decline, etc.)
  if (preg_match('/\b(traffic.*low|low.*traffic|traffic.*been.*low|traffic.*decline|traffic.*down|decrease.*traffic|drop.*traffic|traffic.*drop)\b/i', $lc)) {
    $total_users = isset($ga4_metrics['totalUsers']) ? (int)$ga4_metrics['totalUsers'] : 0;
    $new_users = isset($ga4_metrics['newUsers']) ? (int)$ga4_metrics['newUsers'] : 0;
    $sessions = isset($ga4_metrics['sessions']) ? (int)$ga4_metrics['sessions'] : 0;
    $page_views = isset($ga4_metrics['screenPageViews']) ? (int)$ga4_metrics['screenPageViews'] : 0;
    $bounce_rate = isset($ga4_metrics['bounceRate']) ? (float)$ga4_metrics['bounceRate'] : null;
    $engagement_rate = isset($ga4_metrics['engagementRate']) ? (float)$ga4_metrics['engagementRate'] : null;
    
    $date_range_text = '';
    if (!empty($ga4_meta['date_range']) && is_array($ga4_meta['date_range'])) {
      $start = isset($ga4_meta['date_range']['startDate']) ? $ga4_meta['date_range']['startDate'] : '';
      $end = isset($ga4_meta['date_range']['endDate']) ? $ga4_meta['date_range']['endDate'] : '';
      if ($start && $end) {
        $date_range_text = " for the period " . $start . " to " . $end;
      }
    }
    
    $response = "Based on your Google Analytics 4 data" . $date_range_text . ", here's what I'm seeing:\n\n";
    $response .= "**Current Traffic Metrics:**\n";
    $response .= "• Total Users: " . number_format($total_users) . "\n";
    $response .= "• New Users: " . number_format($new_users) . "\n";
    $response .= "• Sessions: " . number_format($sessions) . "\n";
    $response .= "• Page Views: " . number_format($page_views) . "\n";
    
    if ($bounce_rate !== null) {
      $bounce_percent = round($bounce_rate * 100, 1);
      $response .= "• Bounce Rate: " . $bounce_percent . "%\n";
    }
    
    if ($engagement_rate !== null) {
      $engagement_percent = round($engagement_rate * 100, 1);
      $response .= "• Engagement Rate: " . $engagement_percent . "%\n";
    }
    
    $response .= "\n**Analysis:**\n";
    
    // Provide context about traffic levels
    if ($total_users < 100) {
      $response .= "Your traffic is relatively low with " . number_format($total_users) . " total users. ";
    } elseif ($total_users < 1000) {
      $response .= "You have " . number_format($total_users) . " total users, which is moderate traffic. ";
    } else {
      $response .= "You have " . number_format($total_users) . " total users. ";
    }
    
    // Analyze bounce rate if available
    if ($bounce_rate !== null && $bounce_rate > 0.5) {
      $response .= "Your bounce rate is " . round($bounce_rate * 100, 1) . "%, which is on the higher side. This could indicate that visitors aren't finding what they're looking for or the content isn't engaging enough. ";
    } elseif ($bounce_rate !== null && $bounce_rate < 0.3) {
      $response .= "Your bounce rate is " . round($bounce_rate * 100, 1) . "%, which is quite good, suggesting visitors are engaging with your content. ";
    }
    
    // Analyze engagement
    if ($engagement_rate !== null && $engagement_rate < 0.4) {
      $response .= "Your engagement rate is " . round($engagement_rate * 100, 1) . "%, which could be improved. ";
    }
    
    $response .= "\n**Recommendations:**\n";
    $response .= "• Review your content strategy and ensure you're publishing regularly\n";
    $response .= "• Check your SEO performance and keyword rankings\n";
    $response .= "• Analyze your top-performing pages to understand what's working\n";
    $response .= "• Consider running marketing campaigns or promotions to drive traffic\n";
    $response .= "• Review your site's loading speed and user experience\n";
    
    if (!empty($ga4_meta['source_url'])) {
      $response .= "\nFor more detailed analysis, check your Google Analytics dashboard: " . $ga4_meta['source_url'];
    }
    
    return $response;
  }
  
  // General analytics summary
  $summary = "Here's your current analytics data from Google Analytics 4:\n\n";
  $summary .= "**Traffic Overview:**\n";
  $summary .= "• **Total Users**: " . (isset($ga4_metrics['totalUsers']) ? number_format((int)$ga4_metrics['totalUsers']) : 'N/A') . "\n";
  $summary .= "• **New Users**: " . (isset($ga4_metrics['newUsers']) ? number_format((int)$ga4_metrics['newUsers']) : 'N/A') . "\n";
  $summary .= "• **Sessions**: " . (isset($ga4_metrics['sessions']) ? number_format((int)$ga4_metrics['sessions']) : 'N/A') . "\n";
  $summary .= "• **Page Views**: " . (isset($ga4_metrics['screenPageViews']) ? number_format((int)$ga4_metrics['screenPageViews']) : 'N/A') . "\n\n";
  $summary .= "**Engagement Metrics:**\n";
  if (isset($ga4_metrics['bounceRate'])) {
    $bounce_percent = round((float)$ga4_metrics['bounceRate'] * 100, 1);
    $summary .= "• **Bounce Rate**: " . $bounce_percent . "%\n";
  } else {
    $summary .= "• **Bounce Rate**: N/A\n";
  }
  if (isset($ga4_metrics['engagementRate'])) {
    $engagement_percent = round((float)$ga4_metrics['engagementRate'] * 100, 1);
    $summary .= "• **Engagement Rate**: " . $engagement_percent . "%\n";
  } else {
    $summary .= "• **Engagement Rate**: N/A\n";
  }
  if (isset($ga4_metrics['averageSessionDuration'])) {
    $summary .= "• **Avg Session Duration**: " . round((float)$ga4_metrics['averageSessionDuration'], 0) . " seconds\n";
  } else {
    $summary .= "• **Avg Session Duration**: N/A\n";
  }

  if (isset($ga4_metrics['totalRevenue']) && $ga4_metrics['totalRevenue'] > 0) {
    $summary .= "• **Revenue**: $" . $ga4_metrics['totalRevenue'] . "\n";
  }

  if (!empty($ga4_meta['property_id'])) {
    $summary .= "• **GA4 Property ID**: " . $ga4_meta['property_id'] . "\n";
  }

  if (!empty($ga4_meta['measurement_id'])) {
    $summary .= "• **Measurement ID**: " . $ga4_meta['measurement_id'] . "\n";
  }

  if (!empty($ga4_meta['last_synced'])) {
    $summary .= "• **Last Synced**: " . $ga4_meta['last_synced'] . "\n";
  }

  if (!empty($ga4_meta['date_range']) && is_array($ga4_meta['date_range'])) {
    $start = isset($ga4_meta['date_range']['startDate']) ? $ga4_meta['date_range']['startDate'] : 'unknown start';
    $end   = isset($ga4_meta['date_range']['endDate']) ? $ga4_meta['date_range']['endDate'] : 'unknown end';
    $summary .= "• **Reporting Range**: " . $start . " → " . $end . "\n";
  }

  $summary .= "\nThis data is pulled from your Google Analytics 4 integration and updated regularly.";

  if (!empty($ga4_meta['source_url'])) {
    $summary .= "\nView more in Google Analytics: " . $ga4_meta['source_url'];
  }

  return $summary;
}

/**
 * Generates a comprehensive web intelligence report using Visible Light Hub data
 */
function luna_generate_web_intelligence_report($facts) {
  $report = array();
  
  // Site Overview
  $site_url = isset($facts['site_url']) ? $facts['site_url'] : home_url('/');
  $site_name = parse_url($site_url, PHP_URL_HOST);
  
  $report[] = "🌐 **WEB INTELLIGENCE REPORT** for " . $site_name;
  $report[] = "Generated: " . date('Y-m-d H:i:s T');
  $report[] = "";
  
  // System Health & Performance
  $report[] = "📊 **SYSTEM HEALTH & PERFORMANCE**";
  $health_score = isset($facts['health_score']) ? $facts['health_score'] : 'N/A';
  $wp_version = isset($facts['wp_version']) ? $facts['wp_version'] : 'Unknown';
  $php_version = isset($facts['php_version']) ? $facts['php_version'] : 'Unknown';
  $memory_usage = isset($facts['memory_usage']) ? $facts['memory_usage'] : 'Unknown';
  
  $report[] = "• Overall Health Score: " . $health_score . "%";
  $report[] = "• WordPress Version: " . $wp_version;
  $report[] = "• PHP Version: " . $php_version;
  $report[] = "• Memory Usage: " . $memory_usage;
  $report[] = "";
  
  // Security Analysis
  $report[] = "🔒 **SECURITY ANALYSIS**";
  $tls_valid = isset($facts['tls_valid']) ? $facts['tls_valid'] : false;
  $tls_issuer = isset($facts['tls_issuer']) ? $facts['tls_issuer'] : 'Unknown';
  $tls_expires = isset($facts['tls_expires']) ? $facts['tls_expires'] : 'Unknown';
  $mfa_status = isset($facts['mfa']) ? $facts['mfa'] : 'Not configured';
  
  $report[] = "• SSL/TLS Status: " . ($tls_valid ? "✅ Active" : "❌ Issues detected");
  $report[] = "• Certificate Issuer: " . $tls_issuer;
  $report[] = "• Certificate Expires: " . $tls_expires;
  $report[] = "• Multi-Factor Auth: " . $mfa_status;
  $report[] = "";
  
  // Analytics & Traffic Intelligence
  $report[] = "📈 **ANALYTICS & TRAFFIC INTELLIGENCE**";
  
  // Check if GA4 data is available
  if (isset($facts['ga4_metrics'])) {
    $ga4 = $facts['ga4_metrics'];
    $report[] = "• Total Users: " . (isset($ga4['totalUsers']) ? $ga4['totalUsers'] : 'N/A');
    $report[] = "• New Users: " . (isset($ga4['newUsers']) ? $ga4['newUsers'] : 'N/A');
    $report[] = "• Sessions: " . (isset($ga4['sessions']) ? $ga4['sessions'] : 'N/A');
    $report[] = "• Page Views: " . (isset($ga4['screenPageViews']) ? $ga4['screenPageViews'] : 'N/A');
    $report[] = "• Bounce Rate: " . (isset($ga4['bounceRate']) ? $ga4['bounceRate'] . '%' : 'N/A');
    $report[] = "• Engagement Rate: " . (isset($ga4['engagementRate']) ? $ga4['engagementRate'] . '%' : 'N/A');
    $report[] = "• Avg Session Duration: " . (isset($ga4['averageSessionDuration']) ? $ga4['averageSessionDuration'] : 'N/A');
    $report[] = "• Total Revenue: " . (isset($ga4['totalRevenue']) ? '$' . $ga4['totalRevenue'] : 'N/A');
  } else {
    $report[] = "• Analytics: GA4 integration not configured or no recent data";
  }
  $report[] = "";
  
  // Content & SEO Intelligence
  $report[] = "📝 **CONTENT & SEO INTELLIGENCE**";
  $theme = isset($facts['theme']) ? $facts['theme'] : 'Unknown';
  $active_plugins = isset($facts['active_plugins']) ? count($facts['active_plugins']) : 0;
  $pages_count = isset($facts['pages_count']) ? $facts['pages_count'] : 'Unknown';
  $posts_count = isset($facts['posts_count']) ? $facts['posts_count'] : 'Unknown';
  
  $report[] = "• Active Theme: " . $theme;
  $report[] = "• Active Plugins: " . $active_plugins;
  $report[] = "• Pages: " . $pages_count;
  $report[] = "• Posts: " . $posts_count;
  $report[] = "";
  
  // Infrastructure Intelligence
  $report[] = "🏗️ **INFRASTRUCTURE INTELLIGENCE**";
  $hosting_provider = isset($facts['hosting_provider']) ? $facts['hosting_provider'] : 'Unknown';
  $server_info = isset($facts['server_info']) ? $facts['server_info'] : 'Unknown';
  $cdn_status = isset($facts['cdn_status']) ? $facts['cdn_status'] : 'Not detected';
  
  $report[] = "• Hosting Provider: " . $hosting_provider;
  $report[] = "• Server Info: " . $server_info;
  $report[] = "• CDN Status: " . $cdn_status;
  $report[] = "";
  
  // Data Streams Intelligence
  $report[] = "🔄 **DATA STREAMS INTELLIGENCE**";
  $streams_count = isset($facts['data_streams_count']) ? $facts['data_streams_count'] : 0;
  $active_streams = isset($facts['active_streams']) ? $facts['active_streams'] : 0;
  $last_sync = isset($facts['last_sync']) ? $facts['last_sync'] : 'Unknown';
  
  $report[] = "• Total Data Streams: " . $streams_count;
  $report[] = "• Active Streams: " . $active_streams;
  $report[] = "• Last Sync: " . $last_sync;
  $report[] = "";
  
  // Recommendations & Insights
  $report[] = "💡 **RECOMMENDATIONS & INSIGHTS**";
  
  // Health-based recommendations
  if (is_numeric($health_score)) {
    if ($health_score >= 90) {
      $report[] = "• ✅ Excellent system health - maintain current practices";
    } elseif ($health_score >= 70) {
      $report[] = "• ⚠️ Good health with room for improvement - consider optimization";
    } else {
      $report[] = "• 🚨 Health score needs attention - review system performance";
    }
  }
  
  // Security recommendations
  if (!$tls_valid) {
    $report[] = "• 🔒 SSL/TLS certificate needs attention";
  }
  
  if ($mfa_status === 'Not configured') {
    $report[] = "• 🔐 Consider implementing Multi-Factor Authentication";
  }
  
  // Analytics recommendations
  if (!isset($facts['ga4_metrics'])) {
    $report[] = "• 📊 Set up Google Analytics 4 for detailed traffic insights";
  }
  
  $report[] = "";
  $report[] = "📋 **REPORT SUMMARY**";
  $report[] = "This intelligence report is generated from your Visible Light Hub data and provides a comprehensive overview of your website's performance, security, and analytics. Use this information to make informed decisions about optimizations and improvements.";
  $report[] = "";
  $report[] = "For detailed analysis of any specific area, ask me about particular aspects like 'security status', 'analytics data', or 'system performance'.";
  
  return implode("\n", $report);
}